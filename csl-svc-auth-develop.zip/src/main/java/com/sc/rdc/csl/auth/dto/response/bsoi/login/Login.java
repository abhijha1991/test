package com.sc.rdc.csl.auth.dto.response.bsoi.login;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import static org.apache.commons.lang3.StringUtils.join;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Login {
    @JsonProperty("inAppEnableFlag")
    public String inAppEnableFlag;
    @JsonProperty("userId")
    public String userId;
    @JsonProperty("introSlideReq")
    public String introSlideReq;
    @JsonProperty("nickName")
    public String nickName;
    @JsonProperty("securityCode")
    public String securityCode;
    @JsonProperty("sessionId")
    public String sessionId;
    @JsonProperty("lastLoginDate")
    public String lastLoginDate;
    @JsonProperty("customerName1")
    public String customerName1;
    @JsonProperty("nonPilotFunction")
    public String nonPilotFunction;
    @JsonProperty("customerId")
    public String customerId;
    @JsonProperty("customerIdType")
    public String customerIdType;
    @JsonProperty("preLoginKey")
    public String preLoginKey;
    @JsonProperty("enableAnalytics")
    public Boolean enableAnalytics;

    @JsonIgnore
    public String getRelId() {
        return join(this.customerIdType, this.customerId);
    }
}
