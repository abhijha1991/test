package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;

@JsonApiResource(type = "profile")
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Profile  implements Serializable{

    private static final long serialVersionUID = 1L;
    @JsonApiId
    private String customerId;
    private String customerEBID;
    private String customerPBID;
    private String custName1;
    private String custName2;
    private String preferredLogin;
}
