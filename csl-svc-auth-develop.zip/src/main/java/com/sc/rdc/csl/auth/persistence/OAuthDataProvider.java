package com.sc.rdc.csl.auth.persistence;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.model.CSLRefreshToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import com.sc.rdc.csl.auth.persistence.repo.AccessTokenRepository;
import com.sc.rdc.csl.auth.service.TokenLifetimeProvider;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.cxf.rs.security.jose.jwt.JwtClaims;
import org.apache.cxf.rs.security.oauth2.common.*;
import org.apache.cxf.rs.security.oauth2.provider.AbstractOAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.apache.cxf.rs.security.oauth2.utils.OAuthUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigInteger;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static com.sc.rdc.csl.auth.constants.AuthConstants.CSL_AUTH_SERVER_NAME;
import static com.sc.rdc.csl.auth.constants.AuthConstants.LANGUAGE_PARAM;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Slf4j
@Getter
@Setter
public class OAuthDataProvider extends AbstractOAuthDataProvider {
    private static final int ONE_DAY = 86400;
    private final Object refreshTokenLock = new Object();

    @Autowired
    private IAuthDataRepository dataRepository;

    @Autowired
    private TokenLifetimeProvider tokenLifetimeProvider;

    @Autowired
    private AccessTokenRepository accessTokenRepo;

	@Override
	protected void saveAccessToken(ServerAccessToken serverToken) {
        dataRepository.saveAccessToken(serverToken);
	}

	@Override
	protected void saveRefreshToken(RefreshToken refreshToken) {
        dataRepository.saveRefreshToken(refreshToken);
	}

	@Override
	public void doRevokeAccessToken(ServerAccessToken accessToken) {
        dataRepository.doRevokeAccessToken(accessToken);
	}

	@Override
	protected void doRevokeRefreshToken(RefreshToken refreshToken) {
        dataRepository.doRevokeRefreshToken(refreshToken);
	}

    //Update on change in cxf-oauth2 version change
    public ServerAccessToken refreshAccessToken(Client client, String refreshTokenKey,
                                                List<String> restrictedScopes,
                                                boolean recycleRefreshTokens) throws OAuthServiceException {
        RefreshToken currentRefreshToken = recycleRefreshTokens
            ? revokeRefreshToken(refreshTokenKey) : getRefreshToken(refreshTokenKey);
        if (currentRefreshToken == null) {
            throw new OAuthServiceException(OAuthConstants.ACCESS_DENIED);
        }
        if (OAuthUtils.isExpired(currentRefreshToken.getIssuedAt(), currentRefreshToken.getExpiresIn())) {
            if (!recycleRefreshTokens) {
                revokeRefreshToken(refreshTokenKey);
            }
            throw new OAuthServiceException(OAuthConstants.ACCESS_DENIED);
        }
        if (recycleRefreshTokens) {
            revokeAccessTokens(currentRefreshToken);
        }

        ServerAccessToken at = doRefreshAccessToken(client, currentRefreshToken, restrictedScopes);
        saveAccessToken(at);
        if (recycleRefreshTokens) {
            createNewRefreshToken(at);
        } else {
            updateExistingRefreshToken(currentRefreshToken, at);
        }
        return at;
    }

    @Override
    protected RefreshToken updateExistingRefreshToken(RefreshToken rt, ServerAccessToken at) {
        synchronized (refreshTokenLock) {
            return updateRefreshToken(rt, at);
        }
    }

	public int[] revokeTokens(String subjectId) {
        return dataRepository.revokeTokens(subjectId);
	}

    public int[] removeExpiredTokens() {
        return dataRepository.removeExpiredTokens();
    }

    public void archiveExpiredTokens() {
        long currentTimeSecs = System.currentTimeMillis() / 1000;
        long expiryTimeInSecs = currentTimeSecs - ONE_DAY;

        log.info("Archiving expired tokens < {}", expiryTimeInSecs);
	    accessTokenRepo.archiveExpiredTokens(new BigInteger(String.valueOf(expiryTimeInSecs)));
    }

	@Override
	public RefreshToken getRefreshToken(String refreshTokenKey) {
        return dataRepository.getRefreshToken(refreshTokenKey);
	}

    @Override
	public ServerAccessToken getAccessToken(String accessTokenKey) throws OAuthServiceException {
        return dataRepository.getAccessToken(accessTokenKey);
	}

	@Override
	protected Client doGetClient(String clientId) {
	    return dataRepository.doGetClient(clientId);
	}

	@Override
	protected void doRemoveClient(Client client) {
        dataRepository.doRemoveClient(client);
    }

	@Override
	public void setClient(Client client) {
        dataRepository.setClient(client);
	}

	@Override
	public List<Client> getClients(UserSubject resourceOwner) {
        throw new NotImplementedException("Not supported");
	}

	@Override
	public List<ServerAccessToken> getAccessTokens(Client client, UserSubject subject) throws OAuthServiceException {
		return dataRepository.getAccessTokens(client, subject);
	}

	@Override
	public List<RefreshToken> getRefreshTokens(Client client, UserSubject subject) throws OAuthServiceException {
	    return dataRepository.getRefreshTokens(client, subject);
	}

	@Override
	protected ServerAccessToken doCreateAccessToken(AccessTokenRegistration atReg) {
		if (atReg.getAudiences() == null) {
			atReg.setAudiences(new LinkedList<>());
		}
        UserSubject subject = atReg.getSubject();
		if(subject != null) {
            Map<String, String> subjectExtraProperties = subject.getProperties();
            Map<String, String> extraProperties = atReg.getExtraProperties();
            extraProperties.putAll(subjectExtraProperties);
        }
        return super.doCreateAccessToken(atReg);
	}

    @Override
    protected void linkRefreshTokenToAccessToken(RefreshToken rt, ServerAccessToken at) {
        at.setRefreshToken(rt.getTokenKey());
        saveAccessToken(at);
    }

	@Override
	protected ServerAccessToken createNewAccessToken(Client client, UserSubject subject) {
		client.setClientSecret(null);
		CSLAccessToken accessToken = new CSLAccessToken(client, accessTokenLifetime(client, subject));
		accessToken.setIssuer(CSL_AUTH_SERVER_NAME);
		return accessToken;
	}

	@Override
	protected RefreshToken doCreateNewRefreshToken(ServerAccessToken at) {
		CSLRefreshToken rt = new CSLRefreshToken(at.getClient(), refreshTokenLifetime(at));

		if (at.getAudiences() != null) {
			List<String> audiences = new LinkedList<String>();
			audiences.addAll(at.getAudiences());
			rt.setAudiences(audiences);
		}
		rt.setGrantType(at.getGrantType());
		if (at.getScopes() != null) {
			List<OAuthPermission> scopes = new LinkedList<OAuthPermission>();
			scopes.addAll(at.getScopes());
			rt.setScopes(scopes);
		}
		rt.setGrantCode(at.getGrantCode());
		rt.setNonce(at.getNonce());
		rt.setSubject(at.getSubject());
		rt.setClientCodeVerifier(at.getClientCodeVerifier());
		return rt;
	}

	@Override
	protected ServerAccessToken doRefreshAccessToken(Client client, RefreshToken oldRefreshToken,
			List<String> restrictedScopes) {
		ServerAccessToken at = super.doRefreshAccessToken(client, oldRefreshToken, restrictedScopes);

		if(client instanceof OAuthClient) {
            updateLanguageIfRequested((OAuthClient) client, at);
        }

		if (isUseJwtFormatForAccessTokens()) {
			JwtClaims claims = createJwtAccessToken(at);
			String jose = processJwtAccessToken(claims);
			at.setTokenKey(jose);
		}

		return at;
	}

    private void updateLanguageIfRequested(OAuthClient client, ServerAccessToken serverAccessToken) {
        String language = client.readProperty(LANGUAGE_PARAM);
        UserSubject subject = serverAccessToken.getSubject();
        if(isNotBlank(language) && subject instanceof CSLUserSubject) {
            log.info("Language being replaced in token : {}", language);
            CSLUserSubject cslUserSubject = (CSLUserSubject) subject;
            CSLRequestContext oldContext = cslUserSubject.getCslRequestContext();
            CSLRequestContext newContext = cloneRequestContext(oldContext, language);
            cslUserSubject.setCslRequestContext(newContext);
        }
    }

    private CSLRequestContext cloneRequestContext(CSLRequestContext c, String language) {
        return new CSLRequestContext(
            c.getOperatorId(), c.getOperatorType(),
            c.getRelId(), c.getUaas2id(),
            c.getCountry(), c.getChannel(),
            language, c.getSegmentCode()
        );
    }

	@Override
	public JwtClaims createJwtAccessToken(ServerAccessToken at) {
		return super.createJwtAccessToken(at);
	}

	private long accessTokenLifetime(Client client, UserSubject subject) {
		return tokenLifetimeProvider.accessTokenLifetime(client, subject);
	}

	private long refreshTokenLifetime(ServerAccessToken accessToken) {
		return tokenLifetimeProvider.refreshTokenLifetime(accessToken);
	}
}
