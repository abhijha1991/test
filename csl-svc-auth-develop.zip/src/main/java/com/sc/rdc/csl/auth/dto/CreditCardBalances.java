package com.sc.rdc.csl.auth.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@Data
@JsonApiResource(type = "eligible-plans")
public class CreditCardBalances {

    @JsonApiId
    private String id;

}
