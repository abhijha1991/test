package com.sc.rdc.csl.auth.dto;

import io.katharsis.resource.annotations.JsonApiId;
import lombok.Data;

@Data
public class OTPRequest {
    @JsonApiId
    private String requestId;
    private String actionName;
}
