package com.sc.rdc.csl.auth.controller;

import static com.sc.rdc.csl.auth.util.ErrorCodes.OTP_GENERATION_ERROR;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.time.DateFormatUtils.format;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerContact;
import com.sc.rdc.csl.auth.dto.CustomerInfo;
import com.sc.rdc.csl.auth.dto.OTPRequest;
import com.sc.rdc.csl.auth.dto.SmsOtp;
import com.sc.rdc.csl.auth.gateway.CustomerGateway;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Path("/otp")
@Component
public class OTPController {

    @Autowired
    private SecurityGateway securityGateway;
    @Autowired
    private CustomerGateway customerGateway;
    @Autowired
    private CSLRequestContext cslRequestContext;

    @Value("${mock.mobile.number:#{null}}")
    private String mockMobileNumber;

    @POST
    @Path("sms")
    @Produces(MediaType.APPLICATION_JSON)
    public SmsOtp sendSms(OTPRequest request) {
        String mobileNumber;
        if(isNotBlank(mockMobileNumber)) {
            log.warn("MockMobileNumber specified, sending OTP to {}", mockMobileNumber);
            mobileNumber = mockMobileNumber;
        } else {
            mobileNumber = fetchCustomerMobileNumber();
        }
        Map<String, String> params = new HashMap<>();
        if("IN".equals(cslRequestContext.getCountry().toUpperCase())) {
            params.put("DATETIME", format(new Date(), "HH:mm:ss, dd/MM/YYYY", TimeZone.getTimeZone("Asia/Calcutta")));
        } else {
            params.put("DATETIME", format(Calendar.getInstance(), "HH:mm:ss, dd/MM/YYYY"));
        }
        return securityGateway.sendOtp(
            mobileNumber, request.getActionName(),
            cslRequestContext.getCountry(),
            cslRequestContext.getLanguage(),
            params
        );
    }

    private String fetchCustomerMobileNumber() {
        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setCustomerId(cslRequestContext.getCustomerId());
        customerInfo.setCustomerIdType(cslRequestContext.getCustomerType());
        log.info("Fetching mobile number from customer service");
        CustomerContact customerContact = customerGateway.topMobileContactInfo(customerInfo);
        if(isBlank(customerContact.getMobileNumber())) {
            TemplateErrorCode errorCode = TemplateErrorCode.create(OTP_GENERATION_ERROR, "Mobile number not found for the customer");
            throw new BusinessException(errorCode);
        }
        log.info("Mobile Number Received :: {} ",customerContact.getMobileNumber());
        return customerContact.getMobileNumber();
    }
}
