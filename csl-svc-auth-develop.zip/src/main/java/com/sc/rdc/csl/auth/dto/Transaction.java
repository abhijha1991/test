package com.sc.rdc.csl.auth.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@Data
@JsonApiResource(type = "transactions")
public class Transaction {
    @JsonApiId
    private String id;
}
