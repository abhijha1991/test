package com.sc.rdc.csl.auth.config;

import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.cxf.rs.security.jose.jwa.SignatureAlgorithm;
import org.apache.cxf.rs.security.jose.jws.JwsSignatureProvider;
import org.apache.cxf.rs.security.jose.jws.JwsSignatureVerifier;
import org.apache.cxf.rs.security.jose.jws.PrivateKeyJwsSignatureProvider;
import org.apache.cxf.rs.security.jose.jws.PublicKeyJwsSignatureVerifier;
import org.apache.cxf.rs.security.oauth2.provider.OAuthJoseJwtProducer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isBlank;

@Slf4j
@Configuration
public class OAuthDataProviderConfig {
    @Value("${rsa.key.path:#{null}}")
    private String keyPath;

    @Bean
    public JwsSignatureProvider jwsSignatureProvider() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        InputStream inputStream = getInputStream("private_key");

        byte[] bytes = IOUtils.toByteArray(inputStream);
        KeySpec keySpec = new PKCS8EncodedKeySpec(bytes);
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);

        return new PrivateKeyJwsSignatureProvider(privateKey, SignatureAlgorithm.RS256);
    }

    @Bean
    public JwsSignatureVerifier jwsSignatureVerifier(PublicKey publicKey) {
        return new PublicKeyJwsSignatureVerifier(publicKey, SignatureAlgorithm.RS256);
    }

    @Bean
    public PublicKey publicKey() throws NoSuchAlgorithmException, IOException, InvalidKeySpecException {
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        InputStream inputStream = getInputStream("public_key");

        byte[] bytes = IOUtils.toByteArray(inputStream);
        KeySpec keySpec = new X509EncodedKeySpec(bytes);
        return keyFactory.generatePublic(keySpec);
    }

    @Bean
    public OAuthJoseJwtProducer oauthJoseJwtProducer(JwsSignatureProvider signatureProvider) {
        OAuthJoseJwtProducer jwtAccessTokenProducer = new OAuthJoseJwtProducer();
        jwtAccessTokenProducer.setSignatureProvider(signatureProvider);
        return jwtAccessTokenProducer;
    }

    @Bean
    public OAuthDataProvider cslOAuthDataProvider(OAuthJoseJwtProducer jwtAccessTokenProducer) {
        OAuthDataProvider dataProvider = new OAuthDataProvider();
        dataProvider.setUseJwtFormatForAccessTokens(true);
        dataProvider.setSupportedScopes(supportedScopes());
        dataProvider.setJwtAccessTokenProducer(jwtAccessTokenProducer);

        return dataProvider;
    }

    private Map<String, String> supportedScopes() {
        Map<String, String> scopes = new HashMap<>();
        scopes.put("refreshToken","refreshToken");
        scopes.put("validate_ivr_session", "validate_ivr_session");

        return scopes;
    }

    private InputStream getInputStream(String keyType) throws IOException {
        String fileName = keyType + ".der";
        String filePath;
        if(isBlank(keyPath)) {
            filePath = "keys/" + fileName;
            log.info("RSA KeyPath not defined. Loading from classpath : {}", filePath);
            ClassPathResource classPathResource = new ClassPathResource(filePath);
            return classPathResource.getInputStream();
        }


        filePath = keyPath + fileName;
        log.info("RSA KeyPath defined. Loading key from : {}", filePath);
        return new FileInputStream(filePath);
    }
}
