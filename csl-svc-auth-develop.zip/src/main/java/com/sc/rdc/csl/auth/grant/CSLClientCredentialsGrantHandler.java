package com.sc.rdc.csl.auth.grant;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.CreditCard;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import com.sc.rdc.csl.auth.gateway.IBankDataAccessGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import com.sc.rdc.csl.auth.service.CreditCardService;
import com.sc.rdc.csl.auth.service.ScopeProvider;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.grants.clientcred.ClientCredentialsGrantHandler;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.List;
import java.util.Map;

import static com.sc.csl.retail.core.auth.AccessLevel.ONE_FACTOR;
import static com.sc.rdc.csl.auth.constants.AuthConstants.*;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.INVALID_REQUEST;

@Slf4j
@Component
public class CSLClientCredentialsGrantHandler extends ClientCredentialsGrantHandler {
    private static final String ACCESS_LEVEL_PARAM = "access_level";
    private static final String TOKEN_TYPE_PARAM = "token_type";

    @Autowired
    private ScopeProvider scopeProvider;

    public CSLClientCredentialsGrantHandler(OAuthDataProvider oAuthDataProvider) {
        super.setDataProvider(oAuthDataProvider);
        super.setCanSupportPublicClients(false);
    }
    @Setter
    @Autowired
    private CreditCardService creditCardService;

    @Setter
    @Autowired
    private IBankDataAccessGateway iBankDataAccessGateway;

    @Override
    public ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params)
        throws OAuthServiceException {

    	String cardNum = params.getFirst(CARD_NUMBER_PARAM);

    	if(isNotBlank(cardNum)) {
    	    log.info("Contains credit-card number, will try to fetch relId and UAAS2_ID");
        	String country = params.getFirst(COUNTRY_PARAM);
            CreditCard customerNumber = creditCardService.customerId(country, cardNum);
            params.putSingle(AuthConstants.REL_ID_PARAM, customerNumber.getCustomerId());

            try {
                CustomerProfile customerProfile = iBankDataAccessGateway.getCustomerProfile(customerNumber.getCustomerId(), country);
                params.putSingle(AuthConstants.UAAS2_ID_PARAM, customerProfile.getUaasId());
            } catch (TechnicalException e) {
                log.debug("Ignoring error (Could be a card only customer) : ", e);
            }
            log.info("RelId and UAAS2_ID obtained for the given credit-card number");
    	}

        UserSubject subject = userSubject(client, params);
        ServerAccessToken at = doCreateAccessToken(client, subject, params);
        if (at.getRefreshToken() != null) {
            LOG.warning("Client credentials grant tokens SHOULD not have refresh tokens");
        }
        return at;
    }

    private UserSubject userSubject(Client client, MultivaluedMap<String, String> params) {
        CSLUserSubject cslUserSubject = new CSLUserSubject();
        CSLRequestContext cslRequestContext = new CSLRequestContext(params);

        String subjectId = null;

        String sessionId = params.getFirst(JSESSION_ID_PARAM);
        String requestId = params.getFirst(REQUEST_ID_PARAM);
        String relId = cslRequestContext.getRelId();

        String accessLevel = params.getFirst(ACCESS_LEVEL_PARAM);
        String tokenType = params.getFirst(TOKEN_TYPE_PARAM);

        if(StringUtils.equals(tokenType, "transferToken")) {
            cslUserSubject.setTransferRequest(true);
        }

        if(isNotBlank(sessionId)) {
            log.info("JSessionId available in params list, using that for subjectId");
            subjectId = sessionId;
            Map<String, String> extraProperties = cslUserSubject.getProperties();
            extraProperties.put(JSESSION_ID_PARAM, sessionId);
        }
        else if(isNotBlank(relId)) {
            log.info("Using relId as subjectId");
            subjectId = relId;
        }
        else if(isNotBlank(requestId)) {
            log.info("Using requestId param as subjectId");
            subjectId = requestId;
        }

        if(isBlank(subjectId)) {
            log.error("SubjectId not available");
            throw new OAuthServiceException(INVALID_REQUEST);
        }

        cslUserSubject.setId(subjectId);
        cslUserSubject.setLogin(subjectId);

        if(isNotBlank(accessLevel)) {
            cslUserSubject.setAccessLevel(AccessLevel.valueOf(accessLevel));
        }
        else {
            cslUserSubject.setAccessLevel(ONE_FACTOR);
        }
        cslUserSubject.setCslRequestContext(cslRequestContext);

        return cslUserSubject;
    }

    @Override
    protected List<String> getApprovedScopes(Client client, UserSubject subject, List<String> requestedScopes) {
        return scopeProvider.getApprovedScopes(client, subject, requestedScopes);
    }
}
