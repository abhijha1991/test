package com.sc.rdc.csl.auth.otp;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.ChallengeOtpValidation;
import com.sc.rdc.csl.auth.dto.SoftTokenValidateOtp;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import io.katharsis.client.ClientException;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.Map;

import static com.sc.rdc.csl.auth.constants.AuthConstants.ST_CHALLENGE_OTP_TYPE;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Slf4j
@Component
public class SoftTokenOtpHandler implements OtpHandler {
    @Setter
    @Autowired
    private SecurityGateway securityGateway;

    @Setter
    @Autowired
    private CSLRequestContext cslRequestContext;

    private static final String TRANSACTION_REFERENCE_NUMBER = "transaction_ref_no";
    private static final String STATUS_VALIDATED = "VALIDATED";
    private static final String TRANSACTION_HASH = "transactionHash";

    @Override
    public CSLUserSubject processOtp(Client client, MultivaluedMap<String, String> params) {
        String otpType = params.getFirst(AuthConstants.OTP_TYPE_PARAM);
        CSLUserSubject subject = new CSLUserSubject();

        if(ST_CHALLENGE_OTP_TYPE.equals(otpType)) {
            processChallengeOtp(params, subject);
        }
        else {
            processSoftTokenOtp(params, subject);
        }

        if(null != cslRequestContext.getRelId()) {
            subject.setId(cslRequestContext.getRelId());
        }
        subject.setCslRequestContext(cloneRequestContext(cslRequestContext));
        return subject;
    }

    void processSoftTokenOtp(MultivaluedMap<String, String> params, CSLUserSubject subject) {
        SoftTokenValidateOtp validateRequest = constructSoftTokenValidateOtp(params);
        try {
			SoftTokenValidateOtp validateResponse = securityGateway.validateSoftTokenOtp(validateRequest);
			subject.setAccessLevel(AccessLevel.TWO_FACTOR);
		}
		catch (ClientException e) {
			if(!isEmpty(e.getErrorData().getCode()) && e.getErrorData().getCode().equalsIgnoreCase("CSL-SEC-503")) {
				throw new OAuthServiceException(new OAuthError(e.getErrorData().getCode(),e.getErrorData().getTitle()));
			}
			else {
				throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT));
			}
		}
		catch (Exception e) {
			throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT));
		}
    }

    void processChallengeOtp(MultivaluedMap<String, String> params, CSLUserSubject subject) {
        if(!params.containsKey(TRANSACTION_REFERENCE_NUMBER)) {
			String errMsg = "Transaction reference number not available in the params list";
			log.error(errMsg);
			throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT, errMsg));
		}

        ChallengeOtpValidation challengeOtpValidation;
        try {
			challengeOtpValidation = securityGateway.challengeOtpValidation(params.getFirst(TRANSACTION_REFERENCE_NUMBER));
		}
		catch (Exception e) {
			log.error("Error while calling challengeOtpValidation :: {}", e.getLocalizedMessage());
			throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT));
		}

        String validationStatus = challengeOtpValidation.getValidationStatus();
        if (validationStatus.equalsIgnoreCase(STATUS_VALIDATED)) {
			Map<String, String> extraProperties = subject.getProperties();
			extraProperties.put(TRANSACTION_HASH, challengeOtpValidation.getTransactionHash());
			subject.setAccessLevel(challengeOtpValidation.getAccesLevelRequired());
		}
		else {
			log.info("Challenge OTP validation status :: {} ", validationStatus);
			throw new OAuthServiceException(new OAuthError(validationStatus));
		}
    }

    private SoftTokenValidateOtp constructSoftTokenValidateOtp(MultivaluedMap<String, String> params) {
        SoftTokenValidateOtp softTokenValidateOtp = new SoftTokenValidateOtp();
        softTokenValidateOtp.setEncryptedOtp(params.getFirst(AuthConstants.ENC_OTP_PARAM));
        softTokenValidateOtp.setTokenType(AuthConstants.SOFT_TOKEN_OTP_TYPE);

        if (params.containsKey(TRANSACTION_REFERENCE_NUMBER)) {
            softTokenValidateOtp.setTxRefNo(params.getFirst(TRANSACTION_REFERENCE_NUMBER));
        }

        String otpSequenceNumber = params.getFirst(AuthConstants.OTP_SEQUENCE_NUMBER);
        String otpSerialNumber = params.getFirst(AuthConstants.OTP_SERIAL_NUMBER_PARAM);

        if (isNotEmpty(otpSequenceNumber) && isNotEmpty(otpSerialNumber)) {
            Long sequenceNNo = Long.parseLong(otpSequenceNumber);
            softTokenValidateOtp.setSequenceNo(sequenceNNo);
            softTokenValidateOtp.setOtpSn(otpSerialNumber);
        }

        return softTokenValidateOtp;
    }

    private CSLRequestContext cloneRequestContext(CSLRequestContext c) {
        return new CSLRequestContext(
                c.getOperatorId(), c.getOperatorType(), c.getRelId(), c.getUaas2id(),
                c.getCountry(), c.getChannel(), c.getLanguage(), c.getSegmentCode()
        );
    }
}
