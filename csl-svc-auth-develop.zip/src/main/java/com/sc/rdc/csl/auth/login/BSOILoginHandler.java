package com.sc.rdc.csl.auth.login;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import com.sc.rdc.csl.auth.dto.request.bsoi.*;
import com.sc.rdc.csl.auth.dto.response.bsoi.ResponseHeader;
import com.sc.rdc.csl.auth.dto.response.bsoi.login.BSOILoginResponse;
import com.sc.rdc.csl.auth.dto.response.bsoi.login.Login;
import com.sc.rdc.csl.auth.dto.response.bsoi.login.LoginResponse;
import com.sc.rdc.csl.auth.gateway.IBankDataAccessGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.HashMap;
import java.util.Map;

import static com.sc.csl.retail.core.util.CSLJsonUtils.parseJson;
import static com.sc.rdc.csl.auth.constants.AuthConstants.JSESSION_ID_PARAM;
import static com.sc.rdc.csl.auth.constants.AuthConstants.PREFERRED_OTP_TYPE_PARAM;

@Slf4j
@Component
public class BSOILoginHandler implements LoginHandler {

    @Setter
	@Autowired
	private IBankDataAccessGateway iBankDataAccessGateway;

	private static final String BSOI_LOGIN_RESPONSE = "response_body";
	private static final String BSOI_LOGIN_REQUEST = "request_body";
	private static final int UNSUCCESSFUL = 0;

	@Override
	public CSLUserSubject login(Client client, MultivaluedMap<String, String> params) {
		return postBSOILogin(client, params);
	}

	private CSLUserSubject postBSOILogin(Client client, MultivaluedMap<String, String> params) {
	    String bsoiRequestStr = params.getFirst(BSOI_LOGIN_REQUEST);
	    String bsoiResponseStr = params.getFirst(BSOI_LOGIN_RESPONSE);

        BSOILoginResponse bsoiLoginResponse = parseJson(bsoiResponseStr, BSOILoginResponse.class);
        LoginResponse loginResponse = bsoiLoginResponse.getLoginResponse();
        ResponseHeader responseHeader = loginResponse.getResponseHeader();

        if (UNSUCCESSFUL == responseHeader.getStatus()) {
            String errorMsg = responseHeader.getErrorCode() + " : " + responseHeader.getErrorMessage();
            OAuthError oAuthError = new OAuthError("Login failed", errorMsg);
            throw new OAuthServiceException(oAuthError);
        }

        BSOILoginRequest bsoiLoginRequest = parseJson(bsoiRequestStr, BSOILoginRequest.class);
        LoginRequest loginRequest = bsoiLoginRequest.getLoginRequest();
        RequestHeader requestHeader = bsoiLoginRequest.getRequestHeader();
        ClientContext clientContext = requestHeader.getClientContext();

        Login loginObj = loginResponse.getLogin();
        String relId;
        if ("IN".equals(clientContext.getCountry()) && StringUtils.isEmpty(loginObj.getCustomerId())) {
            relId = loginObj.getUserId();
        }
        else {
            relId = loginObj.getRelId();
        }

        CustomerProfile customerProfile = iBankDataAccessGateway.getCustomerProfile(relId, clientContext.getCountry());

        Map<String, String> responseParams = new HashMap<>();
        responseParams.put("preferredLogin", customerProfile.getPreferredLogin());

        CSLRequestContext cslRequestContext = cslRequestContext(relId,  customerProfile.getUaasId() , requestHeader);
        CSLUserSubject subject = new CSLUserSubject();
        String sessionId = loginObj.getSessionId();
        subject.setLogin(loginRequest.getUserId());
        subject.setId(sessionId);
        subject.setAccessLevel(AccessLevel.ONE_FACTOR);
        subject.setResponseParams(responseParams);
        subject.setCslRequestContext(cslRequestContext);
        Map<String, String> extraProperties = subject.getProperties();
        extraProperties.put(JSESSION_ID_PARAM, sessionId);
        extraProperties.put(PREFERRED_OTP_TYPE_PARAM, customerProfile.getPreferredLogin());

        return subject;
	}

	private CSLRequestContext cslRequestContext(String relId, String uaas2Id, RequestHeader requestHeader) {
        ClientContext clientContext = requestHeader.getClientContext();
        UserContext userContext = requestHeader.getUserContext();

        return new CSLRequestContext(
		    relId,
            uaas2Id,
            clientContext.getCountry(),
            "IBNK",
            userContext.getLanguage(),
            null
        );
	}
}
