
package com.sc.rdc.csl.auth.dto.request.bsoi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BSOILoginRequest {
    @JsonProperty("loginRequest")
    private LoginRequest loginRequest;
    @JsonProperty("requestHeader")
    private RequestHeader requestHeader;
}
