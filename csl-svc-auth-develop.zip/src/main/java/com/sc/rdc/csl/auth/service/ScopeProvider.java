package com.sc.rdc.csl.auth.service;

import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.sc.csl.retail.core.auth.AccessLevel.HIGH_RISK;
import static org.apache.cxf.rs.security.oauth2.utils.OAuthConstants.REFRESH_TOKEN_SCOPE;

@Component
@Slf4j
public class ScopeProvider {

    public List<String> getApprovedScopes(Client client, UserSubject subject, List<String> requestedScopes) {
        List<String> registeredScopes = client.getRegisteredScopes();
        if(!isRefreshTokenSupported(client, subject, requestedScopes)) {
            registeredScopes.remove(REFRESH_TOKEN_SCOPE);
        }
        return registeredScopes;
    }

    private boolean isRefreshTokenSupported(Client client, UserSubject subject, List<String> requestedScopes) {
        CSLUserSubject cslUserSubject = (CSLUserSubject) subject;

        if(HIGH_RISK.equals(cslUserSubject.getAccessLevel())) {
            log.debug("High risk token, so not generating refresh token");
            return false;
        }

        return true;
    }
}
