package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.exception.CSLKatharsisClientException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import io.katharsis.client.KatharsisClient;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;

@Slf4j
@Component
@ConfigurationProperties("katharsis.gateway.ibank.data.access")
public class IBankDataAccessGateway extends CSLJsonApiGateway {

    @Autowired
    private CSLAsyncRequestContext cslAsyncRequestContext;

    public CustomerProfile getCustomerProfile(String relId, String country) {
        log.info("Requesting getCustomerProfile : {} ", relId);
        List<CustomerProfile> profiles = getCustomerProfiles(relId, country);
        log.info("Received Customer Profile : {} ", profiles);
        if (profiles == null || profiles.isEmpty()) {
            log.error("Customer Profile not found for relId : {}, country : {}", relId, country);
            throw new TechnicalException("Customer profile not found");
        }
        return profiles.get(0);
    }

    private List<CustomerProfile> getCustomerProfiles(String relId, String country) {
        cslAsyncRequestContext.setCountry(country);
        cslAsyncRequestContext.setRelId(relId);
        try {
            KatharsisClient client = getKatharsisClient();
            ResourceRepositoryV2<CustomerProfile, Integer> customerProfileRepo = client.getRepositoryForType(CustomerProfile.class);
            QuerySpec querySpec = new QuerySpec(CustomerProfile.class);
            return customerProfileRepo.findAll(querySpec);
        } catch (CSLKatharsisClientException ex) {
            log.error(ex.getMessage());
            return Collections.emptyList();
        }
    }

}
