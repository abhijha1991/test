package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

@JsonApiResource(type = "device-registrations")
@Getter
@Setter
public class DeviceRegistration {
    @JsonApiId
    private String deviceId;

    @JsonProperty("operator-id")
    private String operatorId;
}
