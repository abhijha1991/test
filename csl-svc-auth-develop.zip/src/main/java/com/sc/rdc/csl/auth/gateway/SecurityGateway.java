package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.auth.TokenType;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.CSLOTPErrorCode;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.*;
import com.sc.rdc.csl.auth.persistence.entity.OtpMessageTemplateEntity;
import com.sc.rdc.csl.auth.persistence.repo.OtpMessageTemplateRepository;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
@ConfigurationProperties(prefix = "katharsis.gateway.security")
public class SecurityGateway extends CSLJsonApiGateway {
    private static String MASK_MOBILE_REGEX = ".(?!.{0,2}$)";

    @Autowired
    @Setter
    private OtpMessageTemplateRepository otpMessageTemplateRepository;

    public EncryptedData decrypt(EncryptedData request) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<EncryptedData, String> decryptRepo = katharsisClient.getRepositoryForType(EncryptedData.class);
        return  decryptRepo.create(request);
    }

    public SmsOtp sendOtp(String contactNumber, String actionName, String country, String language) {
        return sendOtp(contactNumber, actionName, country, language, Collections.emptyMap());
    }

    public SmsOtp sendOtp(String contactNumber, String actionName,
                          String country, String language, Map<String, String> params) {
        SmsOtp smsOtp = new SmsOtp();
        smsOtp.setMobile(contactNumber);
        String messageTemplate = fetchMessageTemplate(TokenType.SMS.name(), actionName, country, language);

        log.info("OTP message template from DB : {}", messageTemplate);
        StrSubstitutor strSubstitutor = new StrSubstitutor(params);
        messageTemplate = strSubstitutor.replace(messageTemplate);
        log.info("OTP message template after param replacement : {}", messageTemplate);

        smsOtp.setMsgTemplate(messageTemplate);
        ResourceRepositoryV2<SmsOtp, String> sendOtpRepo = getKatharsisClient().getRepositoryForType(SmsOtp.class);
        SmsOtp smsOtpResponse = sendOtpRepo.create(smsOtp);

        if (!AuthConstants.UAAS_SUCCESS_CODE.equals(smsOtpResponse.getStatusCode())) {
            throw new BusinessException(new CSLOTPErrorCode(smsOtpResponse.getStatusCode(), "OTP generation failed", smsOtpResponse.getErrorMessage()));
        }

        smsOtpResponse.setMobile(maskMobileNumber(contactNumber));
        return smsOtpResponse;
    }

    String fetchMessageTemplate(String type, String actionName, String country, String language) {
        List<OtpMessageTemplateEntity> templates = otpMessageTemplateRepository.findBy(type, actionName, country, language);

        if(templates.isEmpty()) {
            log.error("OTP message template not found for type : {}, actionName: {}, country: {}, language: {}]", type, actionName, country, language);
            throw new TechnicalException("OTP message template not found");
        }

        if(templates.size() == 1) return templates.get(0).getTemplate();

        List<OtpMessageTemplateEntity> exactMatch = templates.stream().filter(
            t -> t.getCountry().equals(country) && t.getLanguage().equals(language)
        ).collect(Collectors.toList());
        if(exactMatch.size() == 1) return exactMatch.get(0).getTemplate();

        List<OtpMessageTemplateEntity> countryMatch = templates.stream().filter(
            t -> t.getCountry().equals(country) && t.getLanguage().equals("DEFAULT")
        ).collect(Collectors.toList());
        if(countryMatch.size() == 1) return countryMatch.get(0).getTemplate();

        List<OtpMessageTemplateEntity> globalMatch = templates.stream().filter(
            t -> t.getCountry().equals("DEFAULT") && t.getLanguage().equals("DEFAULT")
        ).collect(Collectors.toList());
        if(globalMatch.size() == 1) return globalMatch.get(0).getTemplate();

        throw new TechnicalException("OTP message template not found");
    }

    public ValidateOtp validateOtp(ValidateOtp validateOtp) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<ValidateOtp, String> validateOtpRepo = katharsisClient.getRepositoryForType(ValidateOtp.class);
        return validateOtpRepo.create(validateOtp);
    }

    public SoftTokenValidateOtp validateSoftTokenOtp(SoftTokenValidateOtp softTokenValidateOtp) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<SoftTokenValidateOtp, String> softTokenOtpRepo = katharsisClient.getRepositoryForType(SoftTokenValidateOtp.class);
        return softTokenOtpRepo.create(softTokenValidateOtp);
    }

    public ChallengeOtpValidation challengeOtpValidation(String txRefNo) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<ChallengeOtpValidation, String> challengeOtpValidationRepo = katharsisClient.getRepositoryForType(ChallengeOtpValidation.class);
        return challengeOtpValidationRepo.findOne(txRefNo,  new QuerySpec(ChallengeOtpValidation.class));
    }

    String maskMobileNumber(final String mobileNumber) {
        return StringUtils.replaceAll(mobileNumber, MASK_MOBILE_REGEX, "x");
    }
}
