package com.sc.rdc.csl.auth.dto.response.bsoi.init;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InitLogin {
	@JsonProperty("securityNonce")
	private String securityNonce;

	@JsonProperty("sessionId")
	private String sessionId;

	@JsonProperty("securityParam")
	private SecurityParam securityParam;
}
