package com.sc.rdc.csl.auth.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@JsonApiResource(type = "customers")
public class Customer {
    @JsonApiId
    private String relId;

    @JsonApiRelation(lookUp = LookupIncludeBehavior.AUTOMATICALLY_ALWAYS, opposite = "customer")
    private List<CustomerContact> contacts = new ArrayList<>();
}
