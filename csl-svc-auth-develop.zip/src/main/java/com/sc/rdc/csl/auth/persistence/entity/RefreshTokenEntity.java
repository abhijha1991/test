package com.sc.rdc.csl.auth.persistence.entity;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.rdc.csl.auth.model.CSLRefreshToken;
import lombok.*;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "REFRESH_TOKENS")
public class RefreshTokenEntity {

	@Id
	@Column(name = "token_id")
	private String tokenId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "subject_id")
	private String subjectId;

    @Column(name = "issued_at")
    private long issuedAt;

    @Column(name = "expires_in")
    private long expiresIn;

	@Column(name = "token")
	@Lob
	private String token;

	public RefreshTokenEntity(RefreshToken serverToken) {
		this.clientId = serverToken.getClient().getClientId();
		this.subjectId = serverToken.getSubject().getId();
		this.tokenId = serverToken.getTokenKey();
        this.issuedAt = serverToken.getIssuedAt();
        this.expiresIn = serverToken.getExpiresIn();
        this.token = CSLJsonUtils.toPrettyJson(serverToken);
	}

	public CSLRefreshToken getCSLRefreshToken() {
		return CSLJsonUtils.parseJson(token, CSLRefreshToken.class);
	}
}
