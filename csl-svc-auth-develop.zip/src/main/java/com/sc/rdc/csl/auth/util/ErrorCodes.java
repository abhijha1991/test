package com.sc.rdc.csl.auth.util;

import com.sc.csl.retail.core.exception.ErrorCode;
import lombok.Getter;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@Getter
public enum ErrorCodes implements ErrorCode {
    OTP_GENERATION_ERROR("CSL-OTP-400", "OTP Generation failed", "Error : %s");

    private String code;
    private String title;
    private String description;

    ErrorCodes(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

    public String toString() {
        return convertToString(this);
    }
}
