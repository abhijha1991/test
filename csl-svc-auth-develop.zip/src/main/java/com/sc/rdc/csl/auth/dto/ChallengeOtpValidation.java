package com.sc.rdc.csl.auth.dto;

import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.core.auth.AccessLevel;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonApiResource(type = ChallengeOtpValidation.RESOURCE_NAME)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChallengeOtpValidation {

    @JsonIgnore
    public static final String RESOURCE_NAME = "challenge-otp-validations";

    @JsonApiId
    private String oid;

    @JsonProperty("tx-ref-num")
    private String txRefNo;

    @JsonProperty("tx-data")
    private List<String> txData;

    @JsonProperty("push-tx-data")
    private Map<String,String> pushTxData;

    @NotNull
    @JsonProperty("challenge-otp")
    private String response;

    @NotNull
    @JsonProperty("random-num")
    private String randomNum;

    @JsonProperty("token-serial-number")
    private String tokenSerialNumber;

    @JsonProperty("sequence-number")
    private Integer sequenceNumber;


    @JsonProperty("validation-status")
    private String validationStatus;

    @JsonProperty("ext-ref-id")
    private String externalReferenceId;

    @JsonProperty("tx-hash")
    private String transactionHash;

    @JsonProperty("access-level-required")
    private AccessLevel accesLevelRequired;

}

