package com.sc.rdc.csl.auth;

import com.sc.csl.retail.cache.config.CacheConfig;
import com.sc.csl.retail.core.CSLSpringBootApplication;
import com.sc.csl.retail.core.config.DataSourceConfig;
import com.sc.csl.retail.core.config.FreemarkerConfig;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.jms.activemq.ActiveMQAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication(exclude = {
    MongoAutoConfiguration.class,
    MongoDataAutoConfiguration.class,
    ActiveMQAutoConfiguration.class
})

@Import({
    CacheConfig.class,
	FreemarkerConfig.class,
    DataSourceConfig.class
})
@EnableScheduling
public class Application extends CSLSpringBootApplication {
	public static void main(String[] args) throws Exception {
		configureApplication(new SpringApplicationBuilder()).run(args);
	}

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
		return configureApplication(builder);
	}

	private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
		builder.sources(Application.class);
		initBase(builder, "csl-svc-auth");
		return builder;
	}
}
