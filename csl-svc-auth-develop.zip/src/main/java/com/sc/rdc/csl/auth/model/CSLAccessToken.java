package com.sc.rdc.csl.auth.model;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.tokens.bearer.BearerAccessToken;

@NoArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, defaultImpl = CSLAccessToken.class)
public class CSLAccessToken extends BearerAccessToken {
	private String id;
	@Getter
	private String jti;

	public CSLAccessToken(Client client, long expiresIn) {
		super(client, expiresIn);
		id = this.getTokenKey();
		jti = this.getTokenKey();
	}

	public void setTokenKey(String key) {
		super.setTokenKey(key);
		this.id = key;
	}

    @Override
    public CSLUserSubject getSubject() {
        return (CSLUserSubject) super.getSubject();
    }

    public void setSubject(CSLUserSubject subject) {
        super.setSubject(subject);
    }

    @Override
    public OAuthClient getClient() {
        return (OAuthClient) super.getClient();
    }

    public void setClient(OAuthClient client) {
        super.setClient(client);
    }
}
