package com.sc.rdc.csl.auth.dto.response.bsoi.init;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TmResponse {
	@JsonProperty("uniqueSessionId")
	private String uniqueSessionId;

	@JsonProperty("uniqueSessionId")
	public String getUniqueSessionId() {
		return uniqueSessionId;
	}
}
