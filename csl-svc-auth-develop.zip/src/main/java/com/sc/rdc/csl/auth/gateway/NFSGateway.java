package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.rdc.csl.auth.dto.request.UserAuthenticationRequest;
import com.sc.rdc.csl.auth.dto.response.UserAuthenticationResponse;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.soap.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static java.nio.charset.StandardCharsets.UTF_8;

@Slf4j
@Component
public class NFSGateway {
    @Setter
    @Autowired
    private FreemarkerRenderer renderer;

    public UserAuthenticationResponse authenticateUser(UserAuthenticationRequest authenticationRequest) {
        try {
            UserAuthenticationResponse response = new UserAuthenticationResponse();
            SOAPMessage soapMessage = getSoapResponse(authenticationRequest);

            try {
                ByteArrayOutputStream bout = new ByteArrayOutputStream();
                soapMessage.writeTo(bout);
                String msg = bout.toString("UTF-8");
                log.info(msg);
            }
            catch (IOException ex) {
                log.warn(ex.getMessage());
            }

            SOAPBody soapBody = soapMessage.getSOAPBody();

            NodeList responseList = soapBody.getElementsByTagName("response");

            if (responseList != null && responseList.getLength() != 0) {
                NodeList childNodes = responseList.item(0).getChildNodes();

                for (int i = 0; i < childNodes.getLength(); i++) {
                    Node childNode = childNodes.item(i);
                    String nodeName = childNode.getNodeName();
                    String textContent = childNode.getTextContent();

                    switch (nodeName) {
                        case "errorCode":
                            response.setErrorCode(textContent);break;
                        case "status":
                            response.setStatus(textContent);break;
                        case "errorMessage":
                            response.setErrorMessage(textContent);break;
                    }
                }

                if (response.isSuccessful()) {
                    NodeList userInfoNodes = soapBody.getElementsByTagName("userInfo");

                    if (userInfoNodes != null && userInfoNodes.getLength() != 0) {
                        NodeList userAttributes = userInfoNodes.item(0).getChildNodes();

                        for (int i = 0; i < userAttributes.getLength(); i++) {
                            Node node = userAttributes.item(i);
                            String nodeName = node.getNodeName();
                            String textContent = node.getTextContent();

                            switch (nodeName) {
                                case "customerEBID":
                                    response.setCustomerEBID(textContent);break;
                                case "customerId":
                                    response.setCustomerId(textContent);break;
                                case "customerIdType":
                                    response.setCustomerIdType(textContent);break;
                            }
                        }
                    }
                }
            }
            return response;
        } catch (SOAPException ex) {
            log.error("Error in NFS login : {}", ex.getMessage());
            throw new TechnicalException(ex);
        }
    }


    private SOAPMessage getSoapResponse(UserAuthenticationRequest authenticationRequest) {
        SOAPConnection soapConnection = null;
        SOAPMessage message;

        try {
            SOAPConnectionFactory soapConnectionFactory = soapConnectionFactory();

            MessageFactory messageFactory = MessageFactory.newInstance();
            Map<String, Object> values = new HashMap<>();
            values.put("authRequest", authenticationRequest);
            values.put("userName", userName);
            values.put("password", password);

            String xmlStr = renderer.render(REQUEST_TEMPLATE, values);

            message = messageFactory.createMessage(null, IOUtils.toInputStream(xmlStr, UTF_8));
            message.saveChanges();
            soapConnection = soapConnectionFactory.createConnection();
            return soapConnection.call(message, endpointUrl);
        }
        catch (SOAPException | IOException ex) {
            log.error("NFS user authentication failed : {}", ex.getMessage());
            throw new TechnicalException(ex);
        }
        finally {
            try {
                if (soapConnection != null) soapConnection.close();
            } catch (SOAPException e) {
                log.warn("Error closing soap connection : {}", e.getMessage());
            }
        }
    }

    private SOAPConnectionFactory soapConnectionFactory() throws SOAPException {
        if (soapConnectionFactory == null) {
            soapConnectionFactory = SOAPConnectionFactory.newInstance();
        }

        return soapConnectionFactory;
    }

    @Value("${soap.gateway.nfs.endpointUrl}")
    private String endpointUrl;
    @Value("${soap.gateway.nfs.userName}")
    private String userName;
    @Value("${soap.gateway.nfs.password}")
    private String password;
    private SOAPConnectionFactory soapConnectionFactory;

    private static final String REQUEST_TEMPLATE = "user-authentication-request.ftl";
}
