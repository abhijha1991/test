package com.sc.rdc.csl.auth.dto.response;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class UserAuthenticationResponse {
    private String status;

    private String errorCode;
    private String errorMessage;

    private String customerEBID;
    private String customerId;
    private String customerIdType;

    public String getRelId() {
        return StringUtils.join(customerIdType, customerId);
    }

    public boolean isError() {
        return !isSuccessful();
    }

    public boolean isSuccessful() {
        return "1".equals(this.status);
    }
}

