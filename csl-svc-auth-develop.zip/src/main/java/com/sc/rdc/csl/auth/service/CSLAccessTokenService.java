package com.sc.rdc.csl.auth.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.services.AccessTokenService;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import static org.apache.commons.lang3.StringUtils.equalsAnyIgnoreCase;

@Slf4j
public class CSLAccessTokenService extends AccessTokenService {
    @Override
    protected Response handleException(OAuthServiceException ex, String error) {
        log.error(error, ex);
        return super.handleException(ex, error);
    }

    @Override
    protected boolean isValidPublicClient(Client client, String clientId) {
        return isCanSupportPublicClients() && !client.isConfidential();
    }

    //TODO : Temp fix, remove
    @Override
    protected Client authenticateClientIfNeeded(MultivaluedMap<String, String> params) {
        String clientId = params.getFirst(OAuthConstants.CLIENT_ID);

        if(equalsAnyIgnoreCase(clientId,"MOBILE_BANKING", "IBANKING")) {
            params.remove(OAuthConstants.CLIENT_SECRET);
        }

        return super.authenticateClientIfNeeded(params);
    }
}
