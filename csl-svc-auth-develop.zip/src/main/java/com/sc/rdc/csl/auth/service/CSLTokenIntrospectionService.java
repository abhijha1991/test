package com.sc.rdc.csl.auth.service;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import lombok.Getter;
import lombok.Setter;
import org.apache.cxf.rs.security.jose.jwt.JwtClaims;
import org.apache.cxf.rs.security.jose.jwt.JwtToken;
import org.apache.cxf.rs.security.oauth2.common.TokenIntrospection;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.provider.OAuthJoseJwtProducer;
import org.apache.cxf.rs.security.oauth2.services.TokenIntrospectionService;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.apache.cxf.rs.security.oauth2.utils.OAuthUtils;

import javax.ws.rs.Encoded;
import javax.ws.rs.Path;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Map;

import static com.sc.csl.retail.core.util.CSLConstants.*;
import static com.sc.rdc.csl.auth.constants.AuthConstants.INTERNAL_ACCESS_TOKEN;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Setter
@Getter
@Path("introspect")
public class CSLTokenIntrospectionService extends TokenIntrospectionService {
    private static final long INTERNAL_TOKEN_LIFE_TIME = 60 * 2;
    private OAuthDataProvider dataProvider;
    private OAuthJoseJwtProducer jwtAccessTokenProducer;

    @Override
    public TokenIntrospection getTokenIntrospection(@Encoded MultivaluedMap<String, String> params) {
        TokenIntrospection tokenIntrospection = super.getTokenIntrospection(params);
        String tokenId = params.getFirst(OAuthConstants.TOKEN_ID);

        CSLAccessToken accessToken = cslAccessToken(tokenId);

        if(!tokenIntrospection.isActive()) {
            revokeAccessToken(accessToken);
            return tokenIntrospection;
        }

        String iat = internalAccessToken(accessToken);
        Map<String, String> extensions = tokenIntrospection.getExtensions();
        extensions.put(INTERNAL_ACCESS_TOKEN, iat);

        return tokenIntrospection;
    }

    public String internalAccessToken(CSLAccessToken accessToken) {
        accessToken.setIssuedAt(OAuthUtils.getIssuedAt());
        accessToken.setExpiresIn(INTERNAL_TOKEN_LIFE_TIME);
        UserSubject subject = accessToken.getSubject();

        JwtClaims claims = dataProvider.createJwtAccessToken(accessToken);
        claims.setTokenId(accessToken.getJti());
        claims.setClaim("type", "CSL-IAT");

        if(subject != null) {
            addSubjectClaims(claims, subject);
        }

        return jwtAccessTokenProducer.processJwt(new JwtToken(claims));
    }

    public CSLAccessToken cslAccessToken(String tokenId) {
        return (CSLAccessToken) dataProvider.getAccessToken(tokenId);
    }

    void addSubjectClaims(JwtClaims claims, UserSubject subject) {
        Map<String, String> properties = subject.getProperties();
        for(Map.Entry<String, String> entry : properties.entrySet()) {
            claims.setClaim(entry.getKey(), entry.getValue());
        }

        if(subject instanceof CSLUserSubject) {
            CSLUserSubject cslUserSubject = (CSLUserSubject) subject;
            AccessLevel accessLevel = cslUserSubject.getAccessLevel();

            if(accessLevel == null) throw new TechnicalException("AccessLevel not found in UserSubject");
            claims.setClaim(AUTH_LEVEL_CLAIM, accessLevel.authLevel());
            claims.setClaim(AUTH_LEVEL_NAME_CLAIM, accessLevel.name());

            CSLRequestContext context = cslUserSubject.getCslRequestContext();
            if(context != null) {
                if(isNotEmpty(context.getRelId())) claims.setClaim(REL_ID_CLAIM, context.getRelId());
                if(isNotEmpty(context.getUaas2id())) claims.setClaim(UAAS2_ID_CLAIM, context.getUaas2id());
                if(isNotEmpty(context.getOperatorId())) claims.setClaim(OPERATOR_ID_CLAIM, context.getOperatorId());
                if(isNotEmpty(context.getOperatorType())) claims.setClaim(OPERATOR_TYPE_CLAIM, context.getOperatorType());

                if(isNotEmpty(context.getCountry())) claims.setClaim(COUNTRY_CLAIM, context.getCountry());
                if(isNotEmpty(context.getChannel())) claims.setClaim(CHANNEL_CLAIM, context.getChannel());
                if(isNotEmpty(context.getLanguage())) claims.setClaim(LANGUAGE_CLAIM, context.getLanguage());
                if(isNotEmpty(context.getSegmentCode())) claims.setClaim(SEGMENT_CODE_CLAIM, context.getSegmentCode());
            }
        }
    }

    private void revokeAccessToken(CSLAccessToken accessToken) {
        if(accessToken != null) dataProvider.doRevokeAccessToken(accessToken);
    }

    @Override
    public void setDataProvider(org.apache.cxf.rs.security.oauth2.provider.OAuthDataProvider dataProvider) {
        super.setDataProvider(dataProvider);
        this.dataProvider = (OAuthDataProvider) dataProvider;
    }
}
