package com.sc.rdc.csl.auth.model;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.cxf.rs.security.oauth2.common.Client;

import java.util.HashMap;
import java.util.Map;

@NoArgsConstructor
@Setter
@Getter
@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, defaultImpl = OAuthClient.class)
public class OAuthClient extends Client {
    private Long accessTokenLifetime;
    private Long refreshTokenLifetime;
    private Map<String, String> properties = new HashMap<>();

    public void addProperty(String key, String value) {
        properties.put(key, value);
    }

    public String readProperty(String key) {
        return properties.get(key);
    }

    //Used for Jackson
    public boolean getIsConfidential() {
        return isConfidential();
    }

    //Used for Jackson
    public void setIsConfidential(boolean isConf) {
        setConfidential(isConf);
    }
}
