package com.sc.rdc.csl.auth.otp;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.CreditCard;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import com.sc.rdc.csl.auth.dto.EncryptedData;
import com.sc.rdc.csl.auth.dto.ValidateOtp;
import com.sc.rdc.csl.auth.gateway.CreditCardGateway;
import com.sc.rdc.csl.auth.gateway.IBankDataAccessGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.Map;

import static com.sc.rdc.csl.auth.constants.AuthConstants.REFRESH_TOKEN_LIFE_TIME;

@Component
@Slf4j
@ConfigurationProperties(prefix = "creditcard.otp.handler")
public class CreditCardOtpHandler extends SmsOtpHandler {
    private final static long FIFTEEN_MINS = 900L;

    @Setter
    @Autowired
    private CreditCardGateway creditCardGateway;

    @Setter
    @Autowired
    private IBankDataAccessGateway iBankDataAccessGateway;

    private long refreshTokenLifeTime = FIFTEEN_MINS;

    @Override
    public CSLUserSubject processOtp(Client client, MultivaluedMap<String, String> params) {
        EncryptedData creditCardDecryptRequest = constructCardDecryptRequest(params);
        ValidateOtp validateOtpRequest = constructRequest(params);
        String country = validateOtpRequest.getCountry();
        cslAsyncRequestContext.setCountry(country);
        EncryptedData response = securityGateway.decrypt(creditCardDecryptRequest);

        if (!AuthConstants.UAAS_SUCCESS_CODE.equals(response.getStatusCode())) {
            String errorMsg = response.getStatusCode() + " : " + response.getErrorMessage();
            OAuthError oAuthError = new OAuthError("OTP validation failed", errorMsg);
            throw new OAuthServiceException(oAuthError);
        }

        String cardNumber = response.getDecData();

        cslAsyncRequestContext.setRelId(cardNumber);
        ValidateOtp validateOtpResponse = securityGateway.validateOtp(validateOtpRequest);

        if (!AuthConstants.UAAS_SUCCESS_CODE.equals(validateOtpResponse.getStatusCode())) {
            String errorMsg = validateOtpResponse.getStatusCode() + " : " + validateOtpResponse.getErrorMessage();
            OAuthError oAuthError = new OAuthError("OTP validation failed", errorMsg);
            throw new OAuthServiceException(oAuthError);
        }

        CreditCard customerNumber = creditCardGateway.getCustomerId(cardNumber);
        try {
            CustomerProfile customerProfile = iBankDataAccessGateway.getCustomerProfile(customerNumber.getCustomerId(), country);
            params.putSingle(AuthConstants.UAAS2_ID_PARAM, customerProfile.getUaasId());
        } catch (TechnicalException e) {
            log.info("Card only customer");
        }
        params.putSingle(AuthConstants.REL_ID_PARAM, customerNumber.getCustomerId());

        CSLUserSubject subject = new CSLUserSubject();
        CSLRequestContext cslRequestContext = new CSLRequestContext(params);
        subject.setId(customerNumber.getCustomerId());
        subject.setAccessLevel(AccessLevel.TWO_FACTOR);
        subject.setCslRequestContext(cslRequestContext);
        Map<String, String> properties = subject.getProperties();
        properties.put(REFRESH_TOKEN_LIFE_TIME, String.valueOf(refreshTokenLifeTime));

        return subject;
    }

    private EncryptedData constructCardDecryptRequest(MultivaluedMap<String, String> params) {
        EncryptedData encryptedData = new EncryptedData();
        encryptedData.setEncData(params.getFirst(AuthConstants.ENC_CARD_NUMBER_PARAM));
        encryptedData.setKeyIndex(params.getFirst(AuthConstants.CARD_KEY_INDEX_PARAM));
        encryptedData.setCountry(params.getFirst(AuthConstants.COUNTRY_PARAM));
        encryptedData.setChannel(params.getFirst(AuthConstants.CHANNEL_PARAM));
        return encryptedData;
    }

}
