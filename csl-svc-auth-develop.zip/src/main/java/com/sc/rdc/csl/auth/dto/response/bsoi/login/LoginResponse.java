package com.sc.rdc.csl.auth.dto.response.bsoi.login;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.rdc.csl.auth.dto.response.bsoi.ResponseHeader;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoginResponse {
    @JsonProperty("login")
    public Login login;
    @JsonProperty("responseHeader")
    public ResponseHeader responseHeader;

}
