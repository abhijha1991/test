package com.sc.rdc.csl.auth.persistence.repo;

import com.sc.rdc.csl.auth.persistence.entity.OtpMessageTemplateEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface OtpMessageTemplateRepository extends CrudRepository<OtpMessageTemplateEntity, String> {
	@Query("SELECT A FROM OtpMessageTemplateEntity A WHERE A.type = ?1 AND A.actionName = ?2 " +
        "AND A.country in (?3, 'DEFAULT') " +
        "AND A.language in (?4, 'DEFAULT') ")
    List<OtpMessageTemplateEntity> findBy(String type, String actionName, String country, String language);
}
