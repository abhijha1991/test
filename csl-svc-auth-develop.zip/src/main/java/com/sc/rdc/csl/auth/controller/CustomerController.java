package com.sc.rdc.csl.auth.controller;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerContact;
import com.sc.rdc.csl.auth.dto.CustomerInfo;
import com.sc.rdc.csl.auth.dto.EncryptedData;
import com.sc.rdc.csl.auth.dto.SmsOtp;
import com.sc.rdc.csl.auth.gateway.CustomerGateway;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.auth.util.ErrorCodes.OTP_GENERATION_ERROR;
import static org.apache.commons.lang3.StringUtils.isBlank;

/**
 * This service is to send otp using customerId for pre login user
 */

@Slf4j
@Path("/customer-id")
@Component
public class CustomerController {

    @Autowired
    private SecurityGateway securityGateway;
    @Autowired
    private CustomerGateway customerGateway;

    @Autowired
    private CSLAsyncRequestContext cslAsyncRequestContext;

    @Autowired
    private CustomerTypeMapping customerTypeMapping;

    @POST
    @Path("otp")
    @Produces(MediaType.APPLICATION_JSON)
    public SmsOtp generateOtp(EncryptedData encryptedData) {

        //decrypt customerId
        EncryptedData decryptResponse = securityGateway.decrypt(encryptedData);
        //read customerType from configuration
        String customerType = customerTypeMapping.getCustomerTypeByCountry(encryptedData.getCountry());

        String relId = StringUtils.join(customerType, decryptResponse.getDecData());
        cslAsyncRequestContext.setRelId(relId);
        cslAsyncRequestContext.setCountry(encryptedData.getCountry());
        cslAsyncRequestContext.setChannel(encryptedData.getChannel());
        cslAsyncRequestContext.setLanguage(encryptedData.getLanguage());
        cslAsyncRequestContext.setRequestId(encryptedData.getRequestId());

        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setCustomerId(cslAsyncRequestContext.getCustomerId());
        customerInfo.setCustomerIdType(cslAsyncRequestContext.getCustomerType());
        log.info("Process CustomerInfo for fetching the customer contact");
        CustomerContact customerContact = customerGateway.topMobileContactInfo(customerInfo);

        if (isBlank(customerContact.getMobileNumber())) {
            TemplateErrorCode errorCode = TemplateErrorCode.create(OTP_GENERATION_ERROR, "Mobile number not found for the customer");
            throw new BusinessException(errorCode);
        }
        return securityGateway.sendOtp(customerContact.getMobileNumber(), "CUST_ID_OTP_LOGIN", encryptedData.getCountry(), encryptedData.getLanguage());
    }

    @Bean
    @ConfigurationProperties(prefix = "customerType")
    public CustomerTypeMapping getCustomerTypeMapping() {
        return new CustomerTypeMapping();
    }

}

@Data
class CustomerTypeMapping {
    private Map<String, String> country = new HashMap<>();
    public String getCustomerTypeByCountry(String country) {
        return this.country.get(StringUtils.lowerCase(country));
    }
}
