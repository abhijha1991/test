package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.Data;

import java.util.List;

@Data
@JsonApiResource(type = "credit-cards")
public class CreditCard {
    @JsonApiId
    private String id;

    @JsonProperty("contact-number")
    private String contactNumber;

    @JsonProperty("cust-num")
    private String custNum;

    @JsonProperty("org-num")
    private String orgNum;

    @JsonProperty("customer-id")
    private String customerId;

    @JsonProperty("rel-id")
    private String relId;


    @JsonApiRelation(lookUp = LookupIncludeBehavior.NONE, opposite = "credit-cards")
    @JsonProperty("transactions")
    private List<Transaction> transactions;

    @JsonApiRelation(lookUp = LookupIncludeBehavior.NONE, opposite = "credit-cards")
    @JsonProperty("balances")
    private CreditCardBalances balances;


}
