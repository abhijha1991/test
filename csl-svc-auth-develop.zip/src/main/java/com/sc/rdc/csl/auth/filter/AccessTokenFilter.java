package com.sc.rdc.csl.auth.filter;

import com.sc.csl.retail.core.exception.UnauthorizedException;
import com.sc.csl.retail.core.web.CSLAuthFilter;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.service.CSLTokenIntrospectionService;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Priority;
import java.security.PublicKey;

import static com.sc.csl.retail.core.util.CSLConstants.AUTH_FILTER_PRIORITY;

@Slf4j
@Priority(AUTH_FILTER_PRIORITY)
@Component
public class AccessTokenFilter extends CSLAuthFilter {
    @Autowired
    private PublicKey publicKey;
    @Setter
    @Autowired
    private CSLTokenIntrospectionService tokenIntrospectionService;

    protected byte[] getPublicKey() {
        return publicKey.getEncoded();
    }

	protected String getInternalAccessToken(String accessToken) {
        CSLAccessToken cslAccessToken = tokenIntrospectionService.cslAccessToken(accessToken);
        if(cslAccessToken == null) {
            log.warn("Access token invalid");
            throw new UnauthorizedException();
        }

        return tokenIntrospectionService.internalAccessToken(cslAccessToken);
    }
}
