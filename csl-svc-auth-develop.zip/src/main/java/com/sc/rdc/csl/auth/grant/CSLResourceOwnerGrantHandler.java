package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.login.LoginHelper;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import com.sc.rdc.csl.auth.service.ScopeProvider;
import org.apache.commons.collections.MapUtils;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.grants.owner.ResourceOwnerGrantHandler;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.List;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isAnyEmpty;

@Component
public class CSLResourceOwnerGrantHandler extends ResourceOwnerGrantHandler {

    public CSLResourceOwnerGrantHandler(OAuthDataProvider oAuthDataProvider) {
        super.setDataProvider(oAuthDataProvider);
        super.setCanSupportPublicClients(true);
    }

    @Autowired
    private LoginHelper loginHelper;

    @Autowired
    private ScopeProvider scopeProvider;

    @Override
    public ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params) throws OAuthServiceException {
        String ownerName = params.getFirst(OAuthConstants.RESOURCE_OWNER_NAME);
        String ownerPassword = params.getFirst(OAuthConstants.RESOURCE_OWNER_PASSWORD);
        if (isAnyEmpty(ownerName, ownerPassword)) {
            throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_REQUEST));
        }

        CSLUserSubject subject = loginHelper.login(client, params, getSingleGrantType());

        if (subject == null) {
            throw new OAuthServiceException(OAuthConstants.INVALID_GRANT);
        }

        ServerAccessToken serverAccessToken = doCreateAccessToken(client, subject, params);
        Map<String, String> properties = subject.getProperties();
        Map<String, String> responseParams = subject.getResponseParams();

        if(MapUtils.isNotEmpty(properties)) {
        	serverAccessToken.setExtraProperties(properties);
        }
        if(MapUtils.isNotEmpty(responseParams)) {
        	serverAccessToken.setParameters(responseParams);
        }

        return serverAccessToken;
    }

    @Override
    protected List<String> getApprovedScopes(Client client, UserSubject subject, List<String> requestedScopes) {
        return scopeProvider.getApprovedScopes(client, subject, requestedScopes);
    }
}
