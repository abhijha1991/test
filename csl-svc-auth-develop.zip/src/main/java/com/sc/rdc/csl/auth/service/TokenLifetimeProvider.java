package com.sc.rdc.csl.auth.service;

import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import lombok.Getter;
import lombok.Setter;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.springframework.stereotype.Component;

import java.util.Map;

import static com.sc.csl.retail.core.auth.AccessLevel.HIGH_RISK;
import static com.sc.rdc.csl.auth.constants.AuthConstants.REFRESH_TOKEN_LIFE_TIME;
import static com.sc.rdc.csl.auth.constants.AuthConstants.REGISTERED_DEVICE_GRANT;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Component
@Setter
@Getter
public class TokenLifetimeProvider {
    private final static long NO_EXPIRY = 0L;
    private final static long ONE_MIN = 60L;
    private final static long TWO_MINS = 120L;
    private final static long TEN_MINS = 600L;
    private final static long THIRTY_MINS = 1800L;
    private final static long ONE_DAY = 86400L;

    private static long DEFAULT_REFRESH_TOKEN_LIFE = THIRTY_MINS;
    private static long DEFAULT_ACCESS_TOKEN_LIFE = TEN_MINS;


    public long accessTokenLifetime(Client client, UserSubject subject) {
        if(subject instanceof CSLUserSubject) {
            CSLUserSubject cslUserSubject = (CSLUserSubject) subject;
            String grantType = cslUserSubject.getGrantType();

            if(REGISTERED_DEVICE_GRANT.equalsIgnoreCase(grantType)) {
                return ONE_DAY;
            }

            if(HIGH_RISK.equals(cslUserSubject.getAccessLevel())) {
                return TWO_MINS;
            }

            if(cslUserSubject.isTransferRequest()) {
                //Removing flag as it will propagate to new AT
                cslUserSubject.setTransferRequest(false);
                return TWO_MINS;
            }
        }

        OAuthClient oauthClient = (OAuthClient) client;
        Long accessTokenLifetime = oauthClient.getAccessTokenLifetime();
        return (accessTokenLifetime != null) ? accessTokenLifetime : DEFAULT_ACCESS_TOKEN_LIFE;
    }

    public Long refreshTokenLifetime(ServerAccessToken accessToken) {
        String grantType = accessToken.getGrantType();
        UserSubject subject = accessToken.getSubject();

        if(subject != null && subject instanceof CSLUserSubject) {
            Map<String, String> properties = subject.getProperties();
            String customLifeTimeStr = properties.get(REFRESH_TOKEN_LIFE_TIME);
            if(isNotBlank(customLifeTimeStr)) {
                return Long.valueOf(customLifeTimeStr);
            }
        }

        if(REGISTERED_DEVICE_GRANT.equalsIgnoreCase(grantType)) {
            return NO_EXPIRY;
        }

        OAuthClient client = (OAuthClient) accessToken.getClient();
        Long refreshTokenLifetime = client.getRefreshTokenLifetime();
        return (refreshTokenLifetime != null) ? refreshTokenLifetime: DEFAULT_REFRESH_TOKEN_LIFE;
    }
}
