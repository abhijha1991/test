package com.sc.rdc.csl.auth.controller;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.CreditCard;
import com.sc.rdc.csl.auth.dto.EncryptedData;
import com.sc.rdc.csl.auth.dto.SmsOtp;
import com.sc.rdc.csl.auth.gateway.CreditCardGateway;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import static com.sc.csl.retail.core.exception.TemplateErrorCode.create;
import static com.sc.rdc.csl.auth.util.ErrorCodes.OTP_GENERATION_ERROR;
import static org.apache.commons.lang3.StringUtils.isBlank;
import static org.apache.commons.lang3.time.DateFormatUtils.format;

@Slf4j
@Path("/credit-card")
@Component
public class CreditCardController {

    @Autowired
    private SecurityGateway securityGateway;

    @Autowired
    private CreditCardGateway creditCardGateway;

    @Autowired
    private CSLAsyncRequestContext cslAsyncRequestContext;

    @POST
    @Path("otp")
    @Produces(MediaType.APPLICATION_JSON)
    public SmsOtp generateOtp(EncryptedData encryptedData) {
        cslAsyncRequestContext.setRequestId(encryptedData.getRequestId());
        cslAsyncRequestContext.setCountry(encryptedData.getCountry());
        cslAsyncRequestContext.setChannel(encryptedData.getChannel());
        cslAsyncRequestContext.setLanguage(encryptedData.getLanguage());
        EncryptedData decryptResponse = securityGateway.decrypt(encryptedData);

        String creditCardNumber = decryptResponse.getDecData();
        CreditCard cardResponse = creditCardGateway.getCustomerNumber(creditCardNumber);
        CreditCard contactResponse = creditCardGateway.getCustomerContact(cardResponse.getCustNum(), cardResponse.getOrgNum());

        String contactNumber = contactResponse.getContactNumber();
        if (isBlank(contactNumber)) {
            TemplateErrorCode errorCode = create(OTP_GENERATION_ERROR, "Mobile number not found for the customer");
            throw new BusinessException(errorCode);
        }

        cslAsyncRequestContext.setRelId(creditCardNumber);
        Map<String, String> params = new HashMap<>();

        params.put("DATETIME", format(Calendar.getInstance(), "HH:mm:ss, dd/MM/yyyy"));
        return securityGateway.sendOtp(contactNumber, "CC_LOGIN", encryptedData.getCountry(), encryptedData.getLanguage(),params);
    }
}
