package com.sc.rdc.csl.auth.dto.request.bsoi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Base64;

import static org.apache.commons.lang3.StringUtils.isEmpty;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BSOIRequest {
    @JsonProperty("query_params")
    private String queryParams;

    @JsonProperty("request_body")
    private String requestBody;

    @JsonProperty("bsoi_cookies")
    private String cookies;

    public String getQueryParams() {
		return isEmpty(queryParams) ? queryParams : new String(decoder.decode(queryParams));
	}

	public String getRequestBody() {
		return isEmpty(requestBody) ? requestBody : new String(decoder.decode(requestBody));
	}

	private static Base64.Decoder decoder = Base64.getMimeDecoder();
}
