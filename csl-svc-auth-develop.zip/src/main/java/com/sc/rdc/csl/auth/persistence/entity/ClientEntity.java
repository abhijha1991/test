package com.sc.rdc.csl.auth.persistence.entity;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.rdc.csl.auth.model.OAuthClient;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "CLIENTS")
public class ClientEntity {
	@Id
	@Column(name = "client_id")
	private String clientId;

	@Column(name = "client_secret")
	private String clientSecret;

	@Column(name = "client_data")
	@Lob
	private String clientData;

	public ClientEntity(OAuthClient oAuthclient) {
		this.clientId = oAuthclient.getClientId();
		this.clientSecret = oAuthclient.getClientSecret();
		this.clientData = CSLJsonUtils.toPrettyJson(oAuthclient);
	}

	public OAuthClient getOAuthClient() {
		OAuthClient client = CSLJsonUtils.parseJson(clientData, OAuthClient.class);
        client.setClientId(clientId);
        client.setClientSecret(clientSecret);
		return client;
	}

}
