package com.sc.rdc.csl.auth.dto.request;

import lombok.Data;

@Data
public class UserAuthenticationRequest {
    private String userName;
    private String encPassword;
    private String nonce;
    private String country;
    private String channel;
    private String language;
    private String sessionId;

}
