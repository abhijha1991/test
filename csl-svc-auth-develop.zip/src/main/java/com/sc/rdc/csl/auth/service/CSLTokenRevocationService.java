package com.sc.rdc.csl.auth.service;

import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.services.TokenRevocationService;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.springframework.transaction.annotation.Transactional;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.auth.constants.AuthConstants.JSESSION_TOKEN_HINT;
import static com.sc.rdc.csl.auth.constants.AuthConstants.SUBJECT_ID_TOKEN_HINT;
import static org.apache.commons.lang3.StringUtils.equalsAnyIgnoreCase;

@Slf4j
public class CSLTokenRevocationService extends TokenRevocationService {

    @Transactional
    public Response handleTokenRevocation(MultivaluedMap<String, String> params) {
        String tokenTypeHint = params.getFirst(OAuthConstants.TOKEN_TYPE_HINT);

        if(JSESSION_TOKEN_HINT.equals(tokenTypeHint) || SUBJECT_ID_TOKEN_HINT.equals(tokenTypeHint)) {
            return handleSubjectIdRevoke(params);
        }

        return super.handleTokenRevocation(params);
    }

    private Response handleSubjectIdRevoke(MultivaluedMap<String, String> params) {
        log.info("About to revoke tokens based on subjectId");
        authenticateClientIfNeeded(params);
        String subjectId = params.getFirst(OAuthConstants.TOKEN_ID);
        if (subjectId == null) {
			return createErrorResponse(params, OAuthConstants.INVALID_REQUEST);
		}

        Map<String, Integer> tokenRevokeResponse = new HashMap<>();
        try {
			OAuthDataProvider oauthDataProvider = (OAuthDataProvider) getDataProvider();
            int[] counts = oauthDataProvider.revokeTokens(subjectId);
            tokenRevokeResponse.put("accessTokens", counts[0]);
            tokenRevokeResponse.put("refreshTokens", counts[1]);
        }
        catch (OAuthServiceException ex) {
			log.warn("Exception in token revocation : {}", ex.getMessage());
			// Spec: The authorization server responds with HTTP status code 200 if the
			// token has been revoked successfully or if the client submitted an
			// invalid token
		}

        return Response.ok(tokenRevokeResponse).build();
    }

    @Override
    protected boolean isValidPublicClient(Client client, String clientId) {
        return isCanSupportPublicClients() && !client.isConfidential();
    }

    //TODO : Temp fix, remove
    @Override
    protected Client authenticateClientIfNeeded(MultivaluedMap<String, String> params) {
        String clientId = params.getFirst(OAuthConstants.CLIENT_ID);

        if(equalsAnyIgnoreCase(clientId,"MOBILE_BANKING", "IBANKING")) {
            params.remove(OAuthConstants.CLIENT_SECRET);
        }

        return super.authenticateClientIfNeeded(params);
    }
}
