package com.sc.rdc.csl.auth.persistence.entity;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "OTP_MESSAGE_TEMPLATE")
public class OtpMessageTemplateEntity {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ID")
	private Long id;

    @Column(name = "TYPE")
    private String type;

    @Column(name = "ACTION_NAME")
	private String actionName;

    @Column(name = "COUNTRY")
    private String country;

    @Column(name = "LANGUAGE")
    private String language;

	@Column(name = "TITLE")
	private String title;

	@Column(name = "TEMPLATE")
	private String template;
}
