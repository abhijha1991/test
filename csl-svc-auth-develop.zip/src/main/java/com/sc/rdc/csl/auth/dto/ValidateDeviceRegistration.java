package com.sc.rdc.csl.auth.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@JsonApiResource(type = "validate-device-registrations")
@Data
public class ValidateDeviceRegistration {
    @JsonApiId
    private String deviceId;
    private Boolean isValid;
}
