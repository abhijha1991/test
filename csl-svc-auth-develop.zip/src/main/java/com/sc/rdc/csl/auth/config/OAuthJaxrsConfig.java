package com.sc.rdc.csl.auth.config;

import com.sc.csl.retail.core.config.BaseJaxrsConfig;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.rs.security.oauth2.provider.OAuthJSONProvider;
import org.apache.cxf.rs.security.oauth2.services.AccessTokenService;
import org.apache.cxf.rs.security.oauth2.services.TokenIntrospectionService;
import org.apache.cxf.rs.security.oauth2.services.TokenRevocationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.auth.constants.AuthConstants.CSL_AUTH_SERVER_NAME;
import static java.util.Arrays.asList;
import static org.apache.cxf.rs.security.jose.jwt.JwtConstants.EXPECTED_CLAIM_AUDIENCE;

@Configuration
public class OAuthJaxrsConfig extends BaseJaxrsConfig {
    private static Map<String, Object> properties = new HashMap<>();

    @Override
	public void configureEndpoint(JAXRSServerFactoryBean endpoint) {
        properties.put(EXPECTED_CLAIM_AUDIENCE, CSL_AUTH_SERVER_NAME);

		endpoint.setAddress("/oauth2");
		endpoint.setProperties(properties);
        endpoint.setProviders(asList(
            new OAuthJSONProvider()
        ));
		endpoint.setServiceBeans(asList(
            tokenIntrospectionService,
            tokenRevocationService,
            accessTokenService
        ));
	}

    @Autowired
    private AccessTokenService accessTokenService;
    @Autowired
    private TokenRevocationService tokenRevocationService;
    @Autowired
    private TokenIntrospectionService tokenIntrospectionService;
}
