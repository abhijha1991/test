package com.sc.rdc.csl.auth.login;

import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;

import static com.sc.rdc.csl.auth.constants.AuthConstants.MOBILE_BANKING_CLIENT;
import static org.apache.commons.lang3.StringUtils.startsWith;

@Component
public class LoginHelper {
    @Setter
    @Autowired
    private IBankingLoginHandler iBankingLoginHandler;
    @Setter
    @Autowired
    private BSOILoginHandler bsoiLoginHandler;

    public CSLUserSubject login(Client client, MultivaluedMap<String, String> params, String grantType) {
        LoginHandler loginHandler = loginHandler(client, params, grantType);
        CSLUserSubject cslUserSubject = loginHandler.login(client, params);
        cslUserSubject.setGrantType(grantType);

        return cslUserSubject;
    }

    private LoginHandler loginHandler(Client client, MultivaluedMap<String, String> params, String singleGrantType) {
    	String clientId = params.getFirst(OAuthConstants.CLIENT_ID);

    	if(StringUtils.equals(MOBILE_BANKING_CLIENT, clientId) ||
           startsWith(clientId, "BSOI") ||
           startsWith(clientId, "NFS")) {
    		return bsoiLoginHandler;
    	}
        return iBankingLoginHandler;
    }
}
