package com.sc.rdc.csl.auth.grant;

import static com.sc.rdc.csl.auth.constants.AuthConstants.CREDIT_CARD_OTP_TYPE;
import static com.sc.rdc.csl.auth.constants.AuthConstants.JSESSION_ID_PARAM;
import static com.sc.rdc.csl.auth.constants.AuthConstants.OTP_GRANT;
import static com.sc.rdc.csl.auth.constants.AuthConstants.SOFT_TOKEN_OTP_TYPE;
import static com.sc.rdc.csl.auth.constants.AuthConstants.ST_CHALLENGE_OTP_TYPE;

import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.provider.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.springframework.beans.factory.annotation.Autowired;

import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.otp.CreditCardOtpHandler;
import com.sc.rdc.csl.auth.otp.SmsOtpHandler;
import com.sc.rdc.csl.auth.otp.SoftTokenOtpHandler;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class OtpGrantHandler extends BaseGrantHandler {

    public OtpGrantHandler(OAuthDataProvider oauthDataProvider) {
        super(OTP_GRANT);
        super.setDataProvider(oauthDataProvider);
    }

    @Override
    public ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params) throws OAuthServiceException {
        String otpType = params.getFirst(AuthConstants.OTP_TYPE_PARAM);
        CSLUserSubject subject;

        if (SOFT_TOKEN_OTP_TYPE.equals(otpType) || ST_CHALLENGE_OTP_TYPE.equals(otpType)) {
            subject = softTokenOtpHandler.processOtp(client, params);
        }
        else if(CREDIT_CARD_OTP_TYPE.equals(otpType)) {
            subject = creditCardOtpHandler.processOtp(client, params);
        }
        else {
            subject = smsOtpHandler.processOtp(client, params);
        }

        String sessionId = params.getFirst(JSESSION_ID_PARAM);
        if(StringUtils.isNotBlank(sessionId)) {
            log.warn("JSessionId available in params list, using that for subjectId");
            subject.setId(sessionId);
            Map<String, String> extraProperties = subject.getProperties();
            extraProperties.put(JSESSION_ID_PARAM, sessionId);
        }
        subject.setGrantType(getSingleGrantType());
        return doCreateAccessToken(client, subject, params);
    }

    @Setter
    @Autowired
    private SmsOtpHandler smsOtpHandler;
    @Setter
    @Autowired
    private CreditCardOtpHandler creditCardOtpHandler;
    @Setter
    @Autowired
    private SoftTokenOtpHandler softTokenOtpHandler;
}
