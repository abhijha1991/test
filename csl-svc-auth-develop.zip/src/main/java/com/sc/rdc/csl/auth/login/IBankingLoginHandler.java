package com.sc.rdc.csl.auth.login;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.request.UserAuthenticationRequest;
import com.sc.rdc.csl.auth.dto.response.UserAuthenticationResponse;
import com.sc.rdc.csl.auth.gateway.NFSGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.UUID;

@Slf4j
@Component
public class IBankingLoginHandler implements LoginHandler {
    @Setter
    @Autowired
    private NFSGateway nfsGateway;

    @Override
    public CSLUserSubject login(Client client, MultivaluedMap<String, String> params) {
        return handleNFSLogin(client, params);
    }

    private CSLUserSubject handleNFSLogin(Client client, MultivaluedMap<String, String> params) {
        UserAuthenticationRequest request = constructAuthenticationRequest(params);
        UserAuthenticationResponse response = nfsGateway.authenticateUser(request);

        if(response.isError()) {
            throw new OAuthServiceException(new OAuthError("Login failed", response.getErrorMessage()));
        }

        CSLUserSubject subject = new CSLUserSubject();
        subject.setLogin(request.getUserName());
        subject.setId(request.getUserName());
        subject.setCslRequestContext(cslRequestContext(request, response));
        subject.setAccessLevel(AccessLevel.ONE_FACTOR);

        return subject;
    }

    private CSLRequestContext cslRequestContext(UserAuthenticationRequest request, UserAuthenticationResponse response) {
        return new CSLRequestContext(
                            response.getRelId(),
                            response.getCustomerEBID(),
                            request.getCountry(),
                            request.getChannel(),
                            request.getLanguage(), null
        );
    }

    private UserAuthenticationRequest constructAuthenticationRequest(MultivaluedMap<String, String> params) {
        UserAuthenticationRequest authenticationRequest = new UserAuthenticationRequest();
        authenticationRequest.setUserName(params.getFirst(OAuthConstants.RESOURCE_OWNER_NAME));
        authenticationRequest.setEncPassword(params.getFirst(OAuthConstants.RESOURCE_OWNER_PASSWORD));
        authenticationRequest.setNonce(params.getFirst(AuthConstants.NONCE_PARAM));
        authenticationRequest.setCountry(params.getFirst(AuthConstants.COUNTRY_PARAM));
        authenticationRequest.setChannel(params.getFirst(AuthConstants.CHANNEL_PARAM));
        authenticationRequest.setLanguage(params.getFirst(AuthConstants.LANGUAGE_PARAM));
        authenticationRequest.setSessionId(UUID.randomUUID().toString());

        return authenticationRequest;
    }
}
