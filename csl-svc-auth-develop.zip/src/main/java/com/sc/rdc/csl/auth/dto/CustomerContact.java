package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.Data;
import lombok.ToString;

@Data
@JsonApiResource(type = "contacts")
@ToString
public class CustomerContact {
    @JsonApiId
    @JsonProperty("contact-type-code")
    private String contactTypeCode;

    @JsonProperty("contact-classification")
    private String contactClassification;

    @JsonProperty("primary-flag")
    private String primaryFlag;

    @JsonProperty("contact-details")
    private String mobileNumber;

    @JsonProperty("rel-id")
    private String relId;

    @JsonProperty("customer-name")
    private String customerName;

    @JsonProperty("customer-email")
    private String customerEmail;

    @JsonApiRelation(lookUp = LookupIncludeBehavior.NONE, opposite = "contacts")
    @JsonProperty("customer")
    private Customer customer;

    @JsonProperty("contact-sequence-number")
    private String contactSequenceNumber;
}
