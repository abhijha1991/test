package com.sc.rdc.csl.auth.persistence.repo;

import com.sc.rdc.csl.auth.persistence.entity.RefreshTokenEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface RefreshTokenRepository extends CrudRepository<RefreshTokenEntity, String> {
    @Transactional(readOnly = true)
	List<RefreshTokenEntity> findByClientIdAndSubjectId(String clientId, String subjectId);

    @Transactional
    @Modifying
    @Query(
        value = "delete from REFRESH_TOKENS r where (r.ISSUED_AT + r.EXPIRES_IN) < (?1) and r.EXPIRES_IN > 0",
        nativeQuery = true
    )
    int deleteExpiredTokens(long expiryTimeInSecs);

    @Transactional
    @Procedure(procedureName = "ARCHIVE_REFRESH_TOKENS_BY_SUBJ")
    Integer archiveRefreshTokensBySubjectId(String subjectId);

    @Transactional
    @Procedure(procedureName = "ARCHIVE_REFRESH_TOKEN_BY_ID")
    Integer archiveRefreshTokenByTokenId(String tokenId);

}
