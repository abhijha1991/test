package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.SerializeType;
import lombok.Data;

@JsonApiResource(type = "customer")
@Data
public class CustomerProfile {
    @JsonApiId
    private String id;

    private Integer statusCode;

    @JsonApiRelation(serialize= SerializeType.LAZY)
    private Profile profile;

    @JsonIgnore
    public String getPreferredLogin() {
        return profile.getPreferredLogin();
    }

    @JsonIgnore
    public String getUaasId() {
        return profile.getCustomerEBID();
    }
}
