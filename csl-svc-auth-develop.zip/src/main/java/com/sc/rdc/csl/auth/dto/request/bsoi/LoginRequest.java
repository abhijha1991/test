
package com.sc.rdc.csl.auth.dto.request.bsoi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class LoginRequest {
    @JsonProperty("userId")
    private String userId;
    @JsonProperty("password")
    private String password;
    @JsonProperty("captcha")
    private String captcha;
    @JsonProperty("language")
    private String language;
    @JsonProperty("securityNonce")
    private String securityNonce;
}
