package com.sc.rdc.csl.auth.controller;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.security.PublicKey;

@Slf4j
@Path("/keys")
@Component
public class KeyController {
    @Autowired
    private PublicKey publicKey;

    @GET
    @Path("public")
    @Produces(MediaType.APPLICATION_JSON)
    public AuthPublicKey publicKey() {
        return new AuthPublicKey(
            publicKey.getAlgorithm(),
            publicKey.getFormat(),
            publicKey.getEncoded()
        );
    }
}

@Data
@AllArgsConstructor
@NoArgsConstructor
class AuthPublicKey {
    private String algorithm;
    private String format;
    private byte[] encoded;
}
