package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.CSLKatharsisClientException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.rdc.csl.auth.dto.CreditCard;
import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.common.util.CollectionUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

import static com.sc.rdc.csl.auth.util.ErrorCodes.OTP_GENERATION_ERROR;

@Component
@Slf4j
@ConfigurationProperties(prefix = "katharsis.gateway.creditcard")
public class CreditCardGateway extends CSLJsonApiGateway {

    /**
     * Used to get the customer-contact using customerNumber from cardDetail in cardProfile
     */
    public CreditCard getCustomerContact(final String customerNumber, final String orgNum) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<CreditCard, String> customerRepo = katharsisClient.getRepositoryForType(CreditCard.class);
        QuerySpec querySpec = new QuerySpec(CreditCard.class);
        querySpec.addFilter(new FilterSpec(Arrays.asList("requestType"), FilterOperator.EQ, "cardDetail"));
        querySpec.addFilter(new FilterSpec(Arrays.asList("orgNum"), FilterOperator.EQ, orgNum));
        return customerRepo.findOne(customerNumber, querySpec);
    }

    /**
     * Used to get the the customerId using cardNumber in offline service
     */
    public CreditCard getCustomerId(final String cardNumber) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<CreditCard, String> customerRepo = katharsisClient.getRepositoryForType(CreditCard.class);
        QuerySpec querySpec = new QuerySpec(CreditCard.class);
        querySpec.addFilter(new FilterSpec(Arrays.asList("requestType"), FilterOperator.EQ, "offline"));
        return customerRepo.findOne(cardNumber, querySpec);
    }

    /**
     * Used to get the customerNumber using cardNumber in cardProfile - cardListing
     */
    public CreditCard getCustomerNumber(final String cardNumber) {
        List<CreditCard> creditCards = null;
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        try {
            ResourceRepositoryV2<CreditCard, String> customerRepo = katharsisClient.getRepositoryForType(CreditCard.class);
            QuerySpec querySpec = new QuerySpec(CreditCard.class);
            querySpec.addFilter(new FilterSpec(Arrays.asList("cardNum"), FilterOperator.EQ, cardNumber));
            querySpec.addFilter(new FilterSpec(Arrays.asList("functionCd"), FilterOperator.EQ, "CardListUsingCCNum"));
            creditCards = customerRepo.findAll(querySpec);
        } catch (CSLKatharsisClientException ex) {
            log.error(ex.getMessage());
        }
        if (CollectionUtils.isEmpty(creditCards)) {
            TemplateErrorCode errorCode = TemplateErrorCode.create(OTP_GENERATION_ERROR, "1093 - Customer-Number not found for the card");
            throw new BusinessException(errorCode);
        }
        return creditCards.get(0);
    }
}
