package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.service.ScopeProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.jose.jws.JwsHeaders;
import org.apache.cxf.rs.security.jose.jws.JwsJwtCompactConsumer;
import org.apache.cxf.rs.security.jose.jws.JwsSignatureVerifier;
import org.apache.cxf.rs.security.jose.jwt.JwtToken;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.grants.jwt.Constants;
import org.apache.cxf.rs.security.oauth2.grants.jwt.JwtBearerGrantHandler;
import org.apache.cxf.rs.security.oauth2.provider.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.apache.cxf.rs.security.oauth2.utils.OAuthUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.List;

@Slf4j
@Component
public class CSLJwtBearerGrantHandler extends JwtBearerGrantHandler {
    @Autowired
    private ScopeProvider scopeProvider;

    public CSLJwtBearerGrantHandler(OAuthDataProvider oauthDataProvider,
                                    JwsSignatureVerifier jwsSignatureVerifier) {
        super.setDataProvider(oauthDataProvider);
        super.setCanSupportPublicClients(true);
        super.setJwsVerifier(jwsSignatureVerifier);
    }

    @Override
    public ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params)
        throws OAuthServiceException {
        String assertion = params.getFirst(Constants.CLIENT_GRANT_ASSERTION_PARAM);
        if (assertion == null) {
            throw new OAuthServiceException(OAuthConstants.INVALID_GRANT);
        }
        try {
            JwsJwtCompactConsumer jwsReader = getJwsReader(assertion);
            JwtToken jwtToken = jwsReader.getJwtToken();
            validateSignature(new JwsHeaders(jwtToken.getJwsHeaders()),
                jwsReader.getUnsignedEncodedSequence(),
                jwsReader.getDecodedSignature());

            validateClaims(client, jwtToken.getClaims());

            OAuthDataProvider dataProvider = getDataProvider();
            ServerAccessToken serverAccessToken = dataProvider.getAccessToken(assertion);

            if(serverAccessToken == null) {
                log.warn("JWT not found in accessToken store");
                throw new OAuthServiceException(OAuthConstants.INVALID_GRANT);
            }

            return doCreateAccessToken(client,
                serverAccessToken.getSubject(),
                Constants.JWT_BEARER_GRANT,
                OAuthUtils.parseScope(params.getFirst(OAuthConstants.SCOPE)));
        } catch (OAuthServiceException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new OAuthServiceException(OAuthConstants.INVALID_GRANT, ex);
        }
    }

    @Override
    protected List<String> getApprovedScopes(Client client, UserSubject subject, List<String> requestedScopes) {
        return scopeProvider.getApprovedScopes(client, subject, requestedScopes);
    }
}
