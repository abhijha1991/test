
package com.sc.rdc.csl.auth.dto.request.bsoi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class UserContext {
    @JsonProperty("userId")
    private String userId;
    @JsonProperty("sessionId")
    private String sessionId;
    @JsonProperty("language")
    private String language;
}
