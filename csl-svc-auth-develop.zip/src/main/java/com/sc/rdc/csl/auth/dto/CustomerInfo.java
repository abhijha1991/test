package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
@JsonApiResource(type = "card-customer")
public class CustomerInfo {
    @JsonApiId
    private String cardNo;

    @JsonProperty("customer-id")
    private String customerId;

    @JsonProperty("customer-id-type")
    private String customerIdType;

    public String getRelId() {
        return StringUtils.join(customerIdType, customerId);
    }
}
