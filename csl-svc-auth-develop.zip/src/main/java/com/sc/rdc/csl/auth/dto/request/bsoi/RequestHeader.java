
package com.sc.rdc.csl.auth.dto.request.bsoi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class RequestHeader {
    @JsonProperty("serviceContext")
    private ServiceContext serviceContext;
    @JsonProperty("clientContext")
    private ClientContext clientContext;
    @JsonProperty("userContext")
    private UserContext userContext;
    @JsonProperty("rumContext")
    private RumContext rumContext;
}
