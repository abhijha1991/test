package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.ValidateDeviceRegistration;
import com.sc.rdc.csl.auth.gateway.RegistrationGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.grants.refresh.RefreshTokenGrantHandler;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.apache.cxf.rs.security.oauth2.utils.OAuthUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.List;

import static com.sc.rdc.csl.auth.constants.AuthConstants.REGISTERED_DEVICE_GRANT;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Slf4j
@Component
public class CSLRefreshTokenGrantHandler extends RefreshTokenGrantHandler {
    public CSLRefreshTokenGrantHandler(OAuthDataProvider oAuthDataProvider) {
        super.setDataProvider(oAuthDataProvider);
    }

    @Autowired
    private OAuthDataProvider oAuthDataProvider;

    @Autowired
    private RegistrationGateway registrationGateway;

    private static final String ERROR_INVALID_REFRESH_TOKEN = "invalid_refresh_token";

    @Override
    public ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params)
            throws OAuthServiceException {
        String refreshTokenKey = params.getFirst(OAuthConstants.REFRESH_TOKEN);
        RefreshToken refreshToken = oAuthDataProvider.getRefreshToken(refreshTokenKey);

        if(refreshToken == null) {
            throw new OAuthServiceException(new OAuthError(ERROR_INVALID_REFRESH_TOKEN));
        }

        CSLUserSubject subject = (CSLUserSubject) refreshToken.getSubject();
        String grantType = subject.getGrantType();
        updateLanguageIfRequested(client, params);
        boolean recycleRefreshTokens = true;

        if (REGISTERED_DEVICE_GRANT.equals(grantType)) {
            log.info("Token belongs to a registered device, will validate the device status before refreshing the token");
            String deviceId = subject.getId();

            if (!isValidDevice(deviceId)) {
                log.warn("Device registration with the id {} is not valid", deviceId);
                throw new OAuthServiceException(new OAuthError(ERROR_INVALID_REFRESH_TOKEN,"invalid device registration"));
            }
            recycleRefreshTokens = false;
        }

        return createAccessToken(client, params, recycleRefreshTokens);
    }

    private void updateLanguageIfRequested(Client client, MultivaluedMap<String, String> params) {
        String language = params.getFirst(AuthConstants.LANGUAGE_PARAM);
        if(isNotBlank(language) && client instanceof OAuthClient) {
            OAuthClient oAuthClient = (OAuthClient) client;
            log.info("Language param sent in refresh token call. New language will be used : {}", language);
            oAuthClient.addProperty(AuthConstants.LANGUAGE_PARAM, language);
        }
    }

    //Update on change in cxf-oauth2 version change
    protected ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params, boolean recycleRefreshTokens)
        throws OAuthServiceException {
        String refreshToken = params.getFirst(OAuthConstants.REFRESH_TOKEN);
        List<String> requestedScopes = OAuthUtils.getRequestedScopes(client,
                                            params.getFirst(OAuthConstants.SCOPE),
                                            false,
                                            false);

        return oAuthDataProvider.refreshAccessToken(client, refreshToken, requestedScopes, recycleRefreshTokens);
    }

    protected boolean isValidDevice(String deviceId) {
        List<ValidateDeviceRegistration> deviceRegistrations = registrationGateway.fetchValidateDeviceRegistration(deviceId);
        if (deviceRegistrations == null || deviceRegistrations.isEmpty()) {
            log.warn("No device registration found with id : {}", deviceId);
            return false;
        }

        ValidateDeviceRegistration deviceRegistration = deviceRegistrations.get(0);
        return deviceRegistration.getIsValid();
    }
}
