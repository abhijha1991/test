package com.sc.rdc.csl.auth.persistence.repo;

import com.sc.rdc.csl.auth.persistence.entity.AccessTokenEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.List;

public interface AccessTokenRepository extends CrudRepository<AccessTokenEntity, String> {
    @Transactional(readOnly = true)
	List<AccessTokenEntity> findByClientIdAndSubjectId(String clientId, String subjectId);

    @Transactional
    @Modifying
    @Query(
        value = "delete from ACCESS_TOKENS a where (a.ISSUED_AT + a.EXPIRES_IN) < (?1) and a.EXPIRES_IN > 0",
        nativeQuery = true
    )
    int deleteExpiredTokens(long expiryTimeInSecs);

    @Transactional
    @Procedure(procedureName = "ARCHIVE_EXPIRED_TOKENS")
    void archiveExpiredTokens(BigInteger expiryTimeInSecs);

    @Transactional
    @Procedure(procedureName = "ARCHIVE_ACCESS_TOKENS_BY_SUBJ")
    Integer archiveAccessTokensBySubjectId(String subjectId);

    @Transactional
    @Procedure(procedureName = "ARCHIVE_ACCESS_TOKEN_BY_ID")
    Integer archiveAccessTokenByTokenId(String tokenId);

}
