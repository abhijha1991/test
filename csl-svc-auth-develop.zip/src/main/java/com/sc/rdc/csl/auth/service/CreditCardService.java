package com.sc.rdc.csl.auth.service;

import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.CreditCard;
import com.sc.rdc.csl.auth.gateway.CreditCardGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CreditCardService {
    @Autowired
    private CSLAsyncRequestContext cslAsyncRequestContext;

    @Autowired
    private CreditCardGateway creditCardGateway;

    public CreditCard customerId(String country, String cardNum) {
        cslAsyncRequestContext.setCountry(country);
        cslAsyncRequestContext.setRelId(cardNum);

        return creditCardGateway.getCustomerId(cardNum);
    }
}
