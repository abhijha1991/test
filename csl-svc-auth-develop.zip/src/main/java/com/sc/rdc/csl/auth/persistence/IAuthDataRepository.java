package com.sc.rdc.csl.auth.persistence;

import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;

import java.util.List;

public interface IAuthDataRepository {
    void saveAccessToken(ServerAccessToken serverToken);
    void saveRefreshToken(RefreshToken refreshToken);
    void doRevokeAccessToken(ServerAccessToken accessToken);
    void doRevokeRefreshToken(RefreshToken refreshToken);
    int[] revokeTokens(String subjectId);
    int[] removeExpiredTokens();

    RefreshToken getRefreshToken(String refreshTokenKey);
    ServerAccessToken getAccessToken(String accessTokenKey) throws OAuthServiceException;
    Client doGetClient(String clientId);
    void doRemoveClient(Client client);
    void setClient(Client client);
    List<ServerAccessToken> getAccessTokens(Client client, UserSubject subject) throws OAuthServiceException;
    List<RefreshToken> getRefreshTokens(Client client, UserSubject subject) throws OAuthServiceException;
}
