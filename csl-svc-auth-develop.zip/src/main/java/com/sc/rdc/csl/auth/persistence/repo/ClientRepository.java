package com.sc.rdc.csl.auth.persistence.repo;

import com.sc.rdc.csl.auth.persistence.entity.ClientEntity;
import org.springframework.data.repository.CrudRepository;

public interface ClientRepository extends CrudRepository<ClientEntity, String> {
}
