package com.sc.rdc.csl.auth.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@JsonApiResource(type = "otp")
@Data
public class SoftTokenValidateOtp {
    @JsonApiId
    private String requestId;

    @JsonProperty("otp")
    private String encryptedOtp;

    @JsonProperty("token-type")
    private String tokenType;

    @JsonProperty("token-serial-number")
    private String otpSn;

    @JsonProperty("sequence-number")
    private Long sequenceNo;
    
    @JsonProperty("tx-ref-num")
    private String txRefNo;
}
