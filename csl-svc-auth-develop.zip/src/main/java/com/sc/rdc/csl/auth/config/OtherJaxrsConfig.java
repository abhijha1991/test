package com.sc.rdc.csl.auth.config;

import com.sc.csl.retail.core.config.helper.JaxrsConfigHelper;
import com.sc.rdc.csl.auth.controller.CreditCardController;
import com.sc.rdc.csl.auth.controller.CustomerController;
import com.sc.rdc.csl.auth.controller.KeyController;
import com.sc.rdc.csl.auth.controller.OTPController;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static java.util.Arrays.asList;

@Configuration
public class OtherJaxrsConfig extends JaxrsConfigHelper {

    @Bean
    @Autowired
    public Server otherJaxrsEndpoint() {
        JAXRSServerFactoryBean endpoint = jaxrsServerFactoryBean();

        endpoint.setAddress("/auth");
        endpoint.setServiceBeans(asList(
            creditCardController,
            keyController,
            otpController,
            customerController
        ));
        return endpoint.create();
    }

    @Autowired
    private KeyController keyController;
    @Autowired
    private CreditCardController creditCardController;
    @Autowired
    private OTPController otpController;
    @Autowired
    private CustomerController customerController;
}
