package com.sc.rdc.csl.auth.login;

import com.sc.rdc.csl.auth.model.CSLUserSubject;
import org.apache.cxf.rs.security.oauth2.common.Client;

import javax.ws.rs.core.MultivaluedMap;

public interface LoginHandler {
	CSLUserSubject login(Client client, MultivaluedMap<String, String> params);
}
