package com.sc.rdc.csl.auth.persistence.entity;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import lombok.*;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;

import javax.persistence.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "ACCESS_TOKENS")
public class AccessTokenEntity {

	@Id
	@Column(name = "token_id")
	private String tokenId;

	@Column(name = "client_id")
	private String clientId;

	@Column(name = "subject_id")
	private String subjectId;

    @Column(name = "issued_at")
    private long issuedAt;

    @Column(name = "expires_in")
    private long expiresIn;

	@Lob
	private String token;

	public AccessTokenEntity(ServerAccessToken serverToken) {
		this.tokenId = serverToken.getTokenKey();
		this.clientId = serverToken.getClient().getClientId();
		this.subjectId = serverToken.getSubject().getId();
        this.issuedAt = serverToken.getIssuedAt();
        this.expiresIn = serverToken.getExpiresIn();
        this.token = CSLJsonUtils.toPrettyJson(serverToken);
	}

	public CSLAccessToken getCSLAccessToken() {
		return CSLJsonUtils.parseJson(token, CSLAccessToken.class);
	}
}
