package com.sc.rdc.csl.auth.gateway;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.rdc.csl.auth.dto.DeviceRegistration;
import com.sc.rdc.csl.auth.dto.ValidateDeviceRegistration;

import io.katharsis.client.KatharsisClient;
import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@ConfigurationProperties(prefix = "katharsis.gateway.device.registration")
public class RegistrationGateway extends CSLJsonApiGateway {

    public List<DeviceRegistration> fetchDeviceRegistration(String deviceId) {
        log.info("Requesting Device Registrations. ");
        KatharsisClient client = getKatharsisClient();
        ResourceRepositoryV2<DeviceRegistration, String> deviceRegistrationRepo = client.getRepositoryForType(DeviceRegistration.class);

        QuerySpec querySpec = new QuerySpec(DeviceRegistration.class);
        querySpec.includeField(Arrays.asList("deviceId"));
        querySpec.includeField(Arrays.asList("operator-id"));
        querySpec.addFilter(new FilterSpec(Arrays.asList("deviceId"), FilterOperator.EQ, deviceId));

        List<DeviceRegistration> deviceRegistrations = deviceRegistrationRepo.findAll(querySpec);
        log.info("Received Device Registrations :: {} ",deviceRegistrations);
        return deviceRegistrations;
    }
    public List<ValidateDeviceRegistration> fetchValidateDeviceRegistration(String deviceId) {
        log.info("Requesting Validate Device Registrations");
        KatharsisClient client = getKatharsisClient();
        List<ValidateDeviceRegistration> deviceRegistrations;
        ResourceRepositoryV2<ValidateDeviceRegistration, String> deviceRegistrationRepo = client.getRepositoryForType(ValidateDeviceRegistration.class);

        QuerySpec querySpec = new QuerySpec(ValidateDeviceRegistration.class);
        querySpec.addFilter(new FilterSpec(Arrays.asList("deviceId"), FilterOperator.EQ, deviceId));
        deviceRegistrations = deviceRegistrationRepo.findAll(querySpec);
        log.info("Received Validate Device Registrations :: {} ", deviceRegistrations);

        return deviceRegistrations;
    }
}
