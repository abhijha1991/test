package com.sc.rdc.csl.auth.model;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.NoArgsConstructor;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;

@NoArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, defaultImpl = CSLRefreshToken.class)
public class CSLRefreshToken extends RefreshToken {
	private String id;

	public CSLRefreshToken(Client client, long expiresIn) {
		super(client, expiresIn);
		id = super.getTokenKey();
	}

    @Override
    public CSLUserSubject getSubject() {
        return (CSLUserSubject) super.getSubject();
    }

    public void setSubject(CSLUserSubject subject) {
        super.setSubject(subject);
    }

    @Override
    public OAuthClient getClient() {
        return (OAuthClient) super.getClient();
    }

    public void setClient(OAuthClient client) {
        super.setClient(client);
    }
}
