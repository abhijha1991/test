package com.sc.rdc.csl.auth.grant;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.DeviceRegistration;
import com.sc.rdc.csl.auth.gateway.RegistrationGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.provider.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.isEmpty;

@Slf4j
@Component
public class RegisteredDeviceGrantHandler extends BaseGrantHandler {
    @Autowired
    private RegistrationGateway registrationGateway;

    @Autowired
    private CSLRequestContext cslRequestContext;

    public RegisteredDeviceGrantHandler(OAuthDataProvider oauthDataProvider) {
        super(AuthConstants.REGISTERED_DEVICE_GRANT);
        super.setDataProvider(oauthDataProvider);
    }

    @Override
    public ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params) throws OAuthServiceException {
        String deviceId = params.getFirst(AuthConstants.DEVICE_ID_PARAM);

        if (isEmpty(deviceId)) {
            throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_REQUEST));
        }

        String uaas2id = cslRequestContext.getUaas2id();
        if(isEmpty(uaas2id)) {
            log.warn("No UAAS2-ID found in current request context");
            throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT));
        }

        List<DeviceRegistration> deviceRegistrations = registrationGateway.fetchDeviceRegistration(deviceId);
        if(deviceRegistrations == null || deviceRegistrations.isEmpty()) {
            log.warn("No device registration found with id : {}", deviceId);
            throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT));
        }

        DeviceRegistration deviceRegistration = deviceRegistrations.get(0);
        if(!uaas2id.equals(deviceRegistration.getOperatorId())) {
            log.warn("Uaas2-Id doesn't match with the stored record");
            throw new OAuthServiceException(new OAuthError(OAuthConstants.INVALID_GRANT));
        }

        log.info("Device has a valid registration");
        CSLUserSubject subject = new CSLUserSubject();
        subject.setId(deviceId);
        subject.setLogin(uaas2id);
        subject.setCslRequestContext(cloneRequestContext(cslRequestContext));
        subject.setGrantType(getSingleGrantType());
        subject.setAccessLevel(AccessLevel.REGISTERED_DEVICE);

        return doCreateAccessToken(client, subject, params);
    }

    private CSLRequestContext cloneRequestContext(CSLRequestContext c) {
        return new CSLRequestContext(
            c.getOperatorId(), c.getOperatorType(),
            c.getRelId(), c.getUaas2id(),
            c.getCountry(), c.getChannel(),
            c.getLanguage(), c.getSegmentCode()
        );
    }
}
