package com.sc.rdc.csl.auth.model;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLRequestContext;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;

import java.util.HashMap;
import java.util.Map;

@Setter
@Getter
@NoArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, defaultImpl = CSLUserSubject.class)
public class CSLUserSubject extends UserSubject {
    private String grantType;
    private AccessLevel accessLevel;
    private CSLRequestContext cslRequestContext;
    private Map<String, String> responseParams = new HashMap<>();
    private boolean isTransferRequest = false;
}
