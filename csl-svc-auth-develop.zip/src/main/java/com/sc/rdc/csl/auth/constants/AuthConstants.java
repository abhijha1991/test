package com.sc.rdc.csl.auth.constants;

import com.sc.csl.retail.core.util.CSLConstants;

public class AuthConstants {
    public static final String INTERNAL_ACCESS_TOKEN = "csl_iat";

    //Clients
    public static final String MOBILE_BANKING_CLIENT = "MOBILE_BANKING";

    //Grants
    public static final String REGISTERED_DEVICE_GRANT = "registered_device";
    public static final String OTP_GRANT = "otp";

    //Params
    public static final String DEVICE_ID_PARAM = "device_id";
    public static final String OTP_TYPE_PARAM = "otp_type";
    public static final String OTP_SERIAL_NUMBER_PARAM = "otp_sn";
    public static final String OTP_SEQUENCE_NUMBER = "sequence_no" ;

    public static final String NONCE_PARAM = "nonce";
    public static final String ENC_OTP_PARAM = "encoded_otp";
    public static final String ENC_CARD_NUMBER_PARAM = "encoded_card_num";
    public static final String PURPOSE_PARAM = "purpose";
    public static final String KEY_INDEX_PARAM = "key_index";
    public static final String CARD_KEY_INDEX_PARAM = "card_key_index";

    public static final String OPERATOR_ID_PARAM = CSLConstants.OPERATOR_ID_CLAIM;
    public static final String OPERATOR_TYPE_PARAM = CSLConstants.OPERATOR_TYPE_CLAIM;
    public static final String REL_ID_PARAM = CSLConstants.REL_ID_CLAIM;
    public static final String UAAS2_ID_PARAM = CSLConstants.UAAS2_ID_CLAIM;
    public static final String CHANNEL_PARAM = CSLConstants.CHANNEL_CLAIM;
    public static final String COUNTRY_PARAM = CSLConstants.COUNTRY_CLAIM;
    public static final String LANGUAGE_PARAM = CSLConstants.LANGUAGE_CLAIM;
    public static final String SEGMENT_CODE_PARAM = CSLConstants.SEGMENT_CODE_CLAIM;
    public static final String JSESSION_ID_PARAM = "jsession_id";
    public static final String REQUEST_ID_PARAM = "request_id";
    public static final String PREFERRED_OTP_TYPE_PARAM = "preferred_otp_type";
    public static final String CARD_NUMBER_PARAM = "card_num";

    //Audience
    public static final String CSL_AUTH_SERVER_NAME = "CSL-AUTH";

    // OTP Types
    public static final String SMS_OTP_TYPE = "SMS_OTP";
    public static final String SOFT_TOKEN_OTP_TYPE = "SOFT_TOKEN";
    public static final String ST_CHALLENGE_OTP_TYPE = "ST_CHALLENGE_OTP";
    public static final String CARD_TOKEN_OTP_TYPE = "CARD_TOKEN_OTP";
    public static final String CREDIT_CARD_OTP_TYPE = "CREDIT_CARD_OTP";

    public static final String REFRESH_TOKEN_LIFE_TIME = "REFRESH_TOKEN_LIFE_TIME";
    public static final String ACCESS_TOKEN_LIFE_TIME = "ACCESS_TOKEN_LIFE_TIME";
    public static final String JSESSION_TOKEN_HINT = "JSESSIONID";
    public static final String SUBJECT_ID_TOKEN_HINT = "subject_id";

    public static final String DEFAULT_LANG= "en";
    public static final String UAAS_SUCCESS_CODE = "100";
}
