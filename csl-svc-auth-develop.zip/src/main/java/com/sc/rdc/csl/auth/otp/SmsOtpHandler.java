package com.sc.rdc.csl.auth.otp;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.ValidateOtp;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import lombok.Setter;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthError;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;

@Component
public class SmsOtpHandler implements OtpHandler {
    @Setter
    @Autowired
    CSLAsyncRequestContext cslAsyncRequestContext;

    @Setter
    @Autowired
    SecurityGateway securityGateway;

    @Override
    public CSLUserSubject processOtp(Client client, MultivaluedMap<String, String> params) {
        ValidateOtp validateOtpRequest = constructRequest(params);
        String relId = validateOtpRequest.getRelId();
        cslAsyncRequestContext.setRelId(relId);
        cslAsyncRequestContext.setCountry(validateOtpRequest.getCountry());
        ValidateOtp validateOtpResponse = securityGateway.validateOtp(validateOtpRequest);

        if (!AuthConstants.UAAS_SUCCESS_CODE.equals(validateOtpResponse.getStatusCode())) {
            OAuthError oAuthError = new OAuthError(validateOtpResponse.getStatusCode(), validateOtpResponse.getErrorMessage());
            throw new OAuthServiceException(oAuthError);
        }

        CSLUserSubject subject = new CSLUserSubject();
        CSLRequestContext cslRequestContext = new CSLRequestContext(params);
        subject.setId(validateOtpRequest.getRelId());
        subject.setAccessLevel(AccessLevel.TWO_FACTOR);
        subject.setCslRequestContext(cslRequestContext);

        return subject;
    }

    ValidateOtp constructRequest(MultivaluedMap<String, String> params) {
        ValidateOtp validateOtp = new ValidateOtp();
        validateOtp.setEncOtp(params.getFirst(AuthConstants.ENC_OTP_PARAM));
        validateOtp.setOtpSn(params.getFirst(AuthConstants.OTP_SERIAL_NUMBER_PARAM));
        validateOtp.setPurpose(params.getFirst(AuthConstants.PURPOSE_PARAM));
        validateOtp.setKeyIndex(params.getFirst(AuthConstants.KEY_INDEX_PARAM));

        validateOtp.setRelId(params.getFirst(AuthConstants.REL_ID_PARAM));
        validateOtp.setCountry(params.getFirst(AuthConstants.COUNTRY_PARAM));
        validateOtp.setRequestId(cslAsyncRequestContext.getRequestId());
        validateOtp.setLanguage(params.getFirst(AuthConstants.LANGUAGE_PARAM));
        validateOtp.setChannel(params.getFirst(AuthConstants.CHANNEL_PARAM));
        return validateOtp;
    }

}
