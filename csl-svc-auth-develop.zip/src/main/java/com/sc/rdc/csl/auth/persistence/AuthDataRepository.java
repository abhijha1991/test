package com.sc.rdc.csl.auth.persistence;

import com.sc.csl.retail.cache.annotations.CacheResult;
import com.sc.rdc.csl.auth.model.OAuthClient;
import com.sc.rdc.csl.auth.persistence.entity.AccessTokenEntity;
import com.sc.rdc.csl.auth.persistence.entity.ClientEntity;
import com.sc.rdc.csl.auth.persistence.entity.RefreshTokenEntity;
import com.sc.rdc.csl.auth.persistence.repo.AccessTokenRepository;
import com.sc.rdc.csl.auth.persistence.repo.ClientRepository;
import com.sc.rdc.csl.auth.persistence.repo.RefreshTokenRepository;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
public class AuthDataRepository implements IAuthDataRepository {
    @Transactional
    public void saveAccessToken(ServerAccessToken serverToken) {
        AccessTokenEntity accessToken = new AccessTokenEntity(serverToken);
        accessTokenRepo.save(accessToken);
    }

    @Transactional
    public void saveRefreshToken(RefreshToken refreshToken) {
        RefreshTokenEntity refreshTokenEntity = new RefreshTokenEntity(refreshToken);
        refreshTokenRepo.save(refreshTokenEntity);
    }

    @Transactional
    public void doRevokeAccessToken(ServerAccessToken accessToken) {
        accessTokenRepo.archiveAccessTokenByTokenId(accessToken.getTokenKey());
    }

    @Transactional
    public void doRevokeRefreshToken(RefreshToken refreshToken) {
        refreshTokenRepo.archiveRefreshTokenByTokenId(refreshToken.getTokenKey());
    }

    @Transactional
    public int[] revokeTokens(String subjectId) {
        int deletedATCount = accessTokenRepo.archiveAccessTokensBySubjectId(subjectId);
        int deletedRTCount = refreshTokenRepo.archiveRefreshTokensBySubjectId(subjectId);

        log.info("Deleted {} access tokens and {} refresh tokens", deletedATCount, deletedRTCount);
        return new int[] {deletedATCount, deletedRTCount};
    }

    @Transactional
    public int[] removeExpiredTokens() {
        long currentTimeSecs = System.currentTimeMillis()/1000;
        long expiryTimeInSecs = currentTimeSecs - ONE_DAY;

        log.info("Deleting expired tokens < {}", expiryTimeInSecs);
        int deletedAccessTokenCount = accessTokenRepo.deleteExpiredTokens(expiryTimeInSecs);
        int deletedRefreshTokenCount = refreshTokenRepo.deleteExpiredTokens(expiryTimeInSecs);
        log.info("Deleted {} access tokens and {} refresh tokens", deletedAccessTokenCount, deletedRefreshTokenCount);

        return new int[] {deletedAccessTokenCount, deletedRefreshTokenCount};
    }

    public RefreshToken getRefreshToken(String refreshTokenKey) {
        RefreshTokenEntity refreshTokenEntity = refreshTokenRepo.findOne(refreshTokenKey);
        return (refreshTokenEntity == null) ? null : refreshTokenEntity.getCSLRefreshToken();
    }

    public ServerAccessToken getAccessToken(String accessTokenKey) throws OAuthServiceException {
        AccessTokenEntity accessTokenEntity = accessTokenRepo.findOne(accessTokenKey);
        return (accessTokenEntity == null) ? null : accessTokenEntity.getCSLAccessToken();
    }

    @CacheResult(timeToLive = 1, timeUnit = TimeUnit.DAYS)
    public Client doGetClient(String clientId) {
        log.warn("Missing client cache for : {}", clientId);
        ClientEntity clientEntity = clientRepo.findOne(clientId);
        return (clientEntity == null) ? null : clientEntity.getOAuthClient();
    }

    public void doRemoveClient(Client client) {
        ClientEntity clientEntity = new ClientEntity((OAuthClient) client);
        clientRepo.delete(clientEntity);
    }

    public void setClient(Client client) {
        ClientEntity clientEntity = new ClientEntity((OAuthClient) client);
        clientRepo.save(clientEntity);
    }

    public List<ServerAccessToken> getAccessTokens(Client client, UserSubject subject) throws OAuthServiceException {
        List<AccessTokenEntity> entities = accessTokenRepo.findByClientIdAndSubjectId(client.getClientId(), subject.getId());
        List<ServerAccessToken> tokens = new ArrayList<>();
        for (AccessTokenEntity entity : entities) {
            tokens.add(entity.getCSLAccessToken());
        }
        return tokens;
    }

    public List<RefreshToken> getRefreshTokens(Client client, UserSubject subject) throws OAuthServiceException {
        List<RefreshTokenEntity> entities = refreshTokenRepo.findByClientIdAndSubjectId(client.getClientId(), subject.getId());
        List<RefreshToken> tokens = new ArrayList<>();
        for (RefreshTokenEntity entity : entities) {
            tokens.add(entity.getCSLRefreshToken());
        }
        return tokens;
    }
    @Autowired
    private ClientRepository clientRepo;
    @Setter
    @Autowired
    private AccessTokenRepository accessTokenRepo;
    @Setter
    @Autowired
    private RefreshTokenRepository refreshTokenRepo;
    private static final int ONE_DAY = 86400;
}
