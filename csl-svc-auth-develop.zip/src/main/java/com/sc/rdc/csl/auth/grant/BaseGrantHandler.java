package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.service.ScopeProvider;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.grants.AbstractGrantHandler;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public abstract class BaseGrantHandler extends AbstractGrantHandler {
    @Autowired
    private ScopeProvider scopeProvider;

    BaseGrantHandler(String grant) {
        super(grant);
    }

    @Override
    protected List<String> getApprovedScopes(Client client, UserSubject subject, List<String> requestedScopes) {
        return scopeProvider.getApprovedScopes(client, subject, requestedScopes);
    }
}
