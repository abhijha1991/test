package com.sc.rdc.csl.auth.config;

import com.sc.rdc.csl.auth.grant.CSLRefreshTokenGrantHandler;
import com.sc.rdc.csl.auth.grant.OtpGrantHandler;
import com.sc.rdc.csl.auth.grant.RegisteredDeviceGrantHandler;
import com.sc.rdc.csl.auth.service.CSLAccessTokenService;
import com.sc.rdc.csl.auth.service.CSLTokenIntrospectionService;
import com.sc.rdc.csl.auth.service.CSLTokenRevocationService;
import org.apache.cxf.rs.security.oauth2.grants.clientcred.ClientCredentialsGrantHandler;
import org.apache.cxf.rs.security.oauth2.grants.jwt.JwtBearerGrantHandler;
import org.apache.cxf.rs.security.oauth2.grants.owner.ResourceOwnerGrantHandler;
import org.apache.cxf.rs.security.oauth2.provider.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.provider.OAuthJoseJwtProducer;
import org.apache.cxf.rs.security.oauth2.services.AccessTokenService;
import org.apache.cxf.rs.security.oauth2.services.TokenRevocationService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import static java.util.Arrays.asList;

@Configuration
public class OAuthServiceConfig {
    @Bean
    public TokenRevocationService tokenRevocationService(OAuthDataProvider oauthDataProvider) {
        CSLTokenRevocationService tokenRevocationService = new CSLTokenRevocationService();
        tokenRevocationService.setCanSupportPublicClients(true);
        tokenRevocationService.setDataProvider(oauthDataProvider);
        return tokenRevocationService;
    }

    @Bean
    public CSLTokenIntrospectionService tokenIntrospectionService(
        OAuthDataProvider oauthDataProvider,
        OAuthJoseJwtProducer oAuthJoseJwtProducer) {
        CSLTokenIntrospectionService tokenIntrospectionService = new CSLTokenIntrospectionService();
        tokenIntrospectionService.setDataProvider(oauthDataProvider);
        tokenIntrospectionService.setJwtAccessTokenProducer(oAuthJoseJwtProducer);
        return tokenIntrospectionService;
    }

    @Bean
    public AccessTokenService accessTokenService(
        OAuthDataProvider oauthDataProvider,
        ResourceOwnerGrantHandler resourceOwnerGrantHandler,
        CSLRefreshTokenGrantHandler refreshTokenGrantHandler,
        RegisteredDeviceGrantHandler registeredDeviceGrant,
        OtpGrantHandler otpGrantHandler,
        ClientCredentialsGrantHandler clientCredentialsGrantHandler,
        JwtBearerGrantHandler jwtBearerGrantHandler) {

        CSLAccessTokenService accessTokenService = new CSLAccessTokenService();
        accessTokenService.setDataProvider(oauthDataProvider);
        accessTokenService.setCanSupportPublicClients(true);
        accessTokenService.setWriteCustomErrors(true);
        accessTokenService.setGrantHandlers(asList(
            resourceOwnerGrantHandler,
            refreshTokenGrantHandler,
            clientCredentialsGrantHandler,
            jwtBearerGrantHandler,
            registeredDeviceGrant,
            otpGrantHandler
        ));
        return accessTokenService;
    }
}
