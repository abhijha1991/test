package com.sc.rdc.csl.auth.gateway;

import static java.util.Arrays.asList;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerContact;
import com.sc.rdc.csl.auth.dto.CustomerInfo;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Slf4j
@ConfigurationProperties(prefix = "katharsis.gateway.customer")
public class CustomerGateway extends CSLJsonApiGateway {

    @Autowired
    private CSLRequestContext cslRequestContext;

    private static final List<String> CONTACT_TYPE_CODES = asList("MF1", "MF2", "MF3", "MF4", "MO1", "MO2", "MO3", "MO4","Mobile","MOB");
    private static final String CONTACT_CLASSIFICATION = "M";


    public CustomerContact topMobileContactInfo(CustomerInfo customerInfo) {
        List<CustomerContact> customerContacts = getCustomerContacts(customerInfo);

        if(null != customerContacts && !customerContacts.isEmpty()) {
            Optional<CustomerContact> primaryContact = fetchPrimaryMobile(filterCustomerMobileClassification(customerContacts));

            if (primaryContact.isPresent()) {
                log.info("Found the primary contact info >> {}", primaryContact);
                return primaryContact.get();
            }

            // Fallback to existing logic
            List<CustomerContact> mobileContacts = customerContacts.stream()
                .filter(obj -> CONTACT_TYPE_CODES.contains(obj.getContactTypeCode()))
                .collect(Collectors.toList());

            if(!mobileContacts.isEmpty()) {
                mobileContacts.sort(Comparator.comparing(CustomerContact::getContactSequenceNumber));
                CustomerContact customerContact = mobileContacts.get(0);
                log.info("Did not find the primary contact info, fetch top from the order of sequence >> {}", customerContact);
                return customerContact;
            }
        }

        return new CustomerContact();
    }

    private List<CustomerContact> filterCustomerMobileClassification(List<CustomerContact> customerContacts) {
        return customerContacts.stream()
            .filter(obj -> CONTACT_CLASSIFICATION.equalsIgnoreCase(obj.getContactClassification()))
            .collect(Collectors.toList());
    }

    private Optional<CustomerContact> fetchPrimaryMobile(List<CustomerContact> customerContacts) {
        return customerContacts.stream()
            .filter(obj -> StringUtils.isNotEmpty(obj.getPrimaryFlag()) && obj.getPrimaryFlag().equalsIgnoreCase("Y"))
            .findFirst();
    }

    List<CustomerContact> getCustomerContacts(CustomerInfo customerInfo) {
        log.info("Fetching customer contact for relId: {}", customerInfo.getRelId());

        List<CustomerContact> customerContactList;
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<CustomerContact, String> customerRepo = katharsisClient.getRepositoryForType(CustomerContact.class);
        QuerySpec querySpec = new QuerySpec(CustomerContact.class);
        customerContactList = customerRepo.findAll(querySpec);

        return customerContactList;
    }
}
