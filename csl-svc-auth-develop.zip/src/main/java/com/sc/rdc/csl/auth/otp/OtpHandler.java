package com.sc.rdc.csl.auth.otp;

import com.sc.rdc.csl.auth.model.CSLUserSubject;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.springframework.stereotype.Component;

import javax.ws.rs.core.MultivaluedMap;

@Component
public interface OtpHandler {
    CSLUserSubject processOtp(Client client, MultivaluedMap<String, String> params);
}
