INSERT INTO CLIENTS VALUES (
'BOA_SG',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 120,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'BOA_HK',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 120,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
