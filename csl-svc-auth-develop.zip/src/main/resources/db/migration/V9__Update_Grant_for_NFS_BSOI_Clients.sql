UPDATE CLIENTS SET
CLIENT_DATA =
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}'
WHERE CLIENT_ID IN ('BSOI_SG', 'BSOI_IN', 'BSOI_HK');

UPDATE CLIENTS SET
CLIENT_DATA =
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}'
WHERE CLIENT_ID IN ('NFS_SG', 'NFS_IN', 'NFS_HK');
