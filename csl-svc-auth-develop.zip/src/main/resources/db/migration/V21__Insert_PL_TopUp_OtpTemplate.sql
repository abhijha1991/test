-- Customer OTP Login (PLTOPUP)

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'CUST_ID_OTP_LOGIN', 'HK', 'en', null,
'Your Authentication OTP is {otp}. It will expire after 100 seconds. For assistance, please contact our Customer Service Hotline at 2886-0866');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'CUST_ID_OTP_LOGIN', 'HK', 'zh_HK', null,
'渣打香港：閣下的一次性密碼是{otp}。一次性密碼將於100秒後失效。如有任何查詢，請致電我們的24小時客戶服務熱線 2886-0866。');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'CUST_ID_OTP_LOGIN', 'HK', 'zh_CN', null,
'渣打香港：阁下的一次性密码是{otp}。一次性密码将于100秒后失效。如有任何查询，请致电我们的24小时客户服务热线 2886-0866。');

