-- Default
INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS','2FA', 'DEFAULT', 'DEFAULT', null,
'Your Authentication OTP is {otp}. It will expire after 100 seconds. For assistance, kindly contact our 24/7 phone banking.');

-- Credit card related
INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS','CC_ACTIVATION', 'DEFAULT', 'DEFAULT', null,
'Your One-Time Password to process card activation is {otp} and will expire after 3 minutes. For help, kindly contact our 24/7 phone banking.');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS','CC_PIN_ACTIVATION', 'DEFAULT', 'DEFAULT', null,
'Your One-Time Password to process card activation is {otp} and will expire after 3 minutes. For help, kindly contact our 24/7 phone banking.');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS','CC_PIN_RESET', 'DEFAULT', 'DEFAULT', null,
'Your One-Time Password to process card PIN change is {otp} and will expire after 3 minutes. For help, kindly contact our 24/7 phone banking.');

-- Device registration related
INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'DEVICE_REGISTRATION', 'DEFAULT', 'DEFAULT', null,
'Your Authentication OTP is {otp}. It will expire after 100 seconds. For assistance, kindly contact our 24/7 phone banking.');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'DEVICE_REGISTRATION', 'IN', 'en', null,
'{otp} is your Authentication OTP for your online/mobile banking services ${DATETIME}. Valid for 240 seconds. Please do not share this password with anyone -StanChart');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'DEVICE_REGISTRATION', 'HK', 'en', null,
'SCBHK: You are applying for our product online at ${DATETIME}. Enq:28864111. One-time Password is {otp}.');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'DEVICE_REGISTRATION', 'HK', 'zh_HK', null,
'渣打香港 SCBHK：您正於網上申請本行的產品 ${DATETIME}。如有查詢，請電28864111。 一次有效密碼{otp} 。');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'DEVICE_REGISTRATION', 'CN', 'zh', null,
'渣打香港：閣下的一次性密碼是{otp}。一次性密碼將於100秒後失效。如有任何查詢，請致電我們的24小時客戶服務熱線 2282-3330。');


-- Credit Card Login related
INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'CC_LOGIN', 'HK', 'en', null,
'SCBHK: You are applying for our product online at ${DATETIME}. Enq:28864111. One-time Password is ({otp}).');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'CC_LOGIN', 'HK', 'zh_HK', null,
'渣打香港SCBHK: 您正於網上申請本行的產品 ${DATETIME}。如有查詢，請電28864111。 一次有效密碼 ({otp}) 。');

INSERT INTO OTP_MESSAGE_TEMPLATE(ID, TYPE, ACTION_NAME, COUNTRY, LANGUAGE, TITLE, TEMPLATE) VALUES
(OTP_MESSAGE_TEMPLATE_ID_SEQ.nextval, 'SMS', 'CC_LOGIN', 'HK', 'zh_CN', null,
'渣打香港SCBHK: 您正於網上申請本行的產品 ${DATETIME}。如有查詢，請電28864111。 一次有效密碼 ({otp}) 。');



