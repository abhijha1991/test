INSERT INTO CLIENTS VALUES (
'NFS_MY',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
