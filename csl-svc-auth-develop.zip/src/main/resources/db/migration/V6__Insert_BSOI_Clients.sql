INSERT INTO CLIENTS VALUES (
'BSOI_HK',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'BSOI_SG',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'BSOI_IN',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
