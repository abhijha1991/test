INSERT INTO CLIENTS VALUES (
'ORR',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 120,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
