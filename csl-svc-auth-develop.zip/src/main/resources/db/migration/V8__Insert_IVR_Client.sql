INSERT INTO CLIENTS VALUES (
'IVR',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 120,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : ["validate_ivr_session"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
