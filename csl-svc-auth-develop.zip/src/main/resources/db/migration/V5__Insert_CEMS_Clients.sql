INSERT INTO CLIENTS VALUES (
'CECC',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 240,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'CESP',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 240,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'CECO',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 240,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'CECV',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 240,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
