-- All African countries deployed on the one PRD env
INSERT INTO CLIENTS VALUES (
'BSOI_AF',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'BSOI_PK',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'NFS_AF',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'NFS_PK',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password",
        "otp"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
