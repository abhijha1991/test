DELETE FROM CLIENTS WHERE CLIENT_ID = 'IVR';

INSERT INTO CLIENTS VALUES (
'IVR_HK',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "accessTokenLifetime" : 480,
    "allowedGrantTypes" : [
        "client_credentials"
    ],
    "registeredScopes" : [],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
