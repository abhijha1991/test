INSERT INTO CLIENTS VALUES (
'NFS_SG',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'NFS_HK',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');

INSERT INTO CLIENTS VALUES (
'NFS_IN',
DBMS_RANDOM.STRING('X', 53),
'{
    "isConfidential" : true,
    "allowedGrantTypes" : [
        "client_credentials",
        "refresh_token",
        "password"
    ],
    "registeredScopes" : ["refreshToken"],
    "registeredAudiences" : [
        "CSL-AUTH"
    ]
}');
