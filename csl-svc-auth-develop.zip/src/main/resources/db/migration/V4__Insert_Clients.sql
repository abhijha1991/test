INSERT INTO CLIENTS VALUES (
'MOBILE_BANKING',
'MOBILE_BANKING',
'{
    "isConfidential" : false,
    "allowedGrantTypes" : [
        "password",
        "refresh_token",
        "registered_device",
        "otp",
        "urn:ietf:params:oauth:grant-type:jwt-bearer"
    ],
    "registeredScopes" : ["refreshToken"]
}');

INSERT INTO CLIENTS VALUES (
'IBANKING',
'IBANKING',
'{
    "isConfidential" : false,
    "allowedGrantTypes" : [
        "password",
        "refresh_token",
        "registered_device",
        "otp",
        "urn:ietf:params:oauth:grant-type:jwt-bearer"
    ],
    "registeredScopes" : ["refreshToken"]
}');
