#!/usr/bin/env bash

BASEDIR=$(dirname "$0")
START_INDEX=${1:-1}
FILES=`ls -1 ${BASEDIR}/db/migration | sort -V | tail -n +${START_INDEX}`
TARGET_FILE="csl-svc-auth_consolidated.sql"

echo "-- Consolidated script generated at $(date)" > ${TARGET_FILE}
echo "" >> ${TARGET_FILE}

for f in ${FILES}
do
    FILE_PATH=${BASEDIR}/db/migration/${f}
    echo "Processing ${FILE_PATH}"
    echo "" >> ${TARGET_FILE}
	cat ${FILE_PATH} >> ${TARGET_FILE}
done

echo "" >> ${TARGET_FILE}
echo "-- End of script" >> ${TARGET_FILE}

echo "Done : ${TARGET_FILE}"
