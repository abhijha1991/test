package com.sc.rdc.csl.auth.persistence;

import com.sc.rdc.csl.auth.persistence.entity.AccessTokenEntity;
import com.sc.rdc.csl.auth.persistence.entity.RefreshTokenEntity;
import com.sc.rdc.csl.auth.persistence.repo.AccessTokenRepository;
import com.sc.rdc.csl.auth.persistence.repo.RefreshTokenRepository;
import com.sc.rdc.csl.auth.service.TokenLifetimeProvider;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
@Transactional(propagation = Propagation.NOT_SUPPORTED)
@SpringBootTest(
    classes = {
        OAuthDataProvider.class,
        TokenLifetimeProvider.class
    }
)
public class OAuthDataProviderIT {
    private static final int ONE_DAY = 86400;
    @Autowired
    private OAuthDataProvider oAuthDataProvider;
    @Autowired
    private AccessTokenRepository accessTokenRepository;
    @Autowired
    private RefreshTokenRepository refreshTokenRepository;

    @Before
    public void setUp() {
        long twoDaysBack = getTwoDaysBack();
        long currentTime = currentTime();

        accessTokenRepository.save(AccessTokenEntity.builder().tokenId("1").issuedAt(twoDaysBack).expiresIn(0).build());
        accessTokenRepository.save(AccessTokenEntity.builder().tokenId("2").issuedAt(currentTime).expiresIn(10).build());
        accessTokenRepository.save(AccessTokenEntity.builder().tokenId("3").issuedAt(twoDaysBack).expiresIn(10).build());
        accessTokenRepository.save(AccessTokenEntity.builder().tokenId("4").issuedAt(twoDaysBack).expiresIn(10).build());

        refreshTokenRepository.save(RefreshTokenEntity.builder().tokenId("1").issuedAt(twoDaysBack).expiresIn(0).build());
        refreshTokenRepository.save(RefreshTokenEntity.builder().tokenId("2").issuedAt(currentTime).expiresIn(10).build());
        refreshTokenRepository.save(RefreshTokenEntity.builder().tokenId("3").issuedAt(twoDaysBack).expiresIn(10).build());
        refreshTokenRepository.save(RefreshTokenEntity.builder().tokenId("4").issuedAt(twoDaysBack).expiresIn(10).build());
        refreshTokenRepository.save(RefreshTokenEntity.builder().tokenId("5").issuedAt(twoDaysBack).expiresIn(100).build());
    }

    @Test
    public void shouldRemoveExpiredToken_WithOneDayBuffer() {
        int[] counts = oAuthDataProvider.removeExpiredTokens();
        assertEquals(2, counts[0]);
        assertEquals(3, counts[1]);
    }

    private long getTwoDaysBack() {
        long currentTimeSecs = currentTime();
        return currentTimeSecs - (2 * ONE_DAY);
    }

    private long currentTime() {
        return System.currentTimeMillis() / 1000;
    }
}
