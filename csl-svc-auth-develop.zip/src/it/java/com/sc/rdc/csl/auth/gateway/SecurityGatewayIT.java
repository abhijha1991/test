package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.rdc.csl.auth.persistence.entity.OtpMessageTemplateEntity;
import com.sc.rdc.csl.auth.persistence.repo.OtpMessageTemplateRepository;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import static com.sc.csl.retail.core.auth.TokenType.SMS;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
@Transactional
@SpringBootTest(
    classes = {
        OtpMessageTemplateRepository.class,
        SecurityGateway.class
    }
)
@EntityScan(
    basePackageClasses = {com.sc.rdc.csl.auth.persistence.entity.OtpMessageTemplateEntity.class}
)
@EnableJpaRepositories(
    basePackageClasses = {com.sc.rdc.csl.auth.persistence.repo.OtpMessageTemplateRepository.class}
)
@Slf4j
public class SecurityGatewayIT {
    @Autowired
    private OtpMessageTemplateRepository otpMessageTemplateRepository;

    @Autowired
    private SecurityGateway securityGateway;

    @Before
    public void setUp() {
        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(1L).type("SMS").actionName("2FA").country("DEFAULT").language("DEFAULT").template("Test1").build());
        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(2L).type("SMS").actionName("2FA").country("HK").language("DEFAULT").template("Test2").build());
        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(3L).type("SMS").actionName("2FA").country("HK").language("en").template("Test3").build());

        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(4L).type("SMS").actionName("2FA").country("SG").language("en").template("Test4").build());
    }

    @Test
    public void shouldReturnTheMatchingTemplate() {
        String message = securityGateway.fetchMessageTemplate(SMS.name(), "2FA", "HK", "en");
        assertEquals("Test3", message);

        message = securityGateway.fetchMessageTemplate(SMS.name(), "2FA", "HK", "zh");
        assertEquals("Test2", message);

        message = securityGateway.fetchMessageTemplate(SMS.name(), "2FA", "IN", "en");
        assertEquals("Test1", message);

        message = securityGateway.fetchMessageTemplate(SMS.name(), "2FA", "SG", "en");
        assertEquals("Test4", message);

        message = securityGateway.fetchMessageTemplate(SMS.name(), "2FA", "SG", "zh");
        assertEquals("Test1", message);
    }

    @Test(expected = TechnicalException.class)
    public void shouldFailIfNoTemplateAvailable() {
        securityGateway.fetchMessageTemplate(SMS.name(), "REGISTRATION", "SG", "en");
    }
}
