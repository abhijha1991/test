package com.sc.rdc.csl.auth.persistence.repo;

import com.sc.rdc.csl.auth.persistence.entity.OtpMessageTemplateEntity;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.sc.csl.retail.core.auth.TokenType.SMS;
import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
@Transactional
@SpringBootTest(
    classes = {
        OtpMessageTemplateRepository.class
    }
)
@EntityScan(basePackageClasses = {com.sc.rdc.csl.auth.persistence.entity.OtpMessageTemplateEntity.class})
@Slf4j
public class OtpMessageTemplateRepositoryIT {
    @Autowired
    private OtpMessageTemplateRepository otpMessageTemplateRepository;

    @Before
    public void setUp() {
        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(1L).type("SMS").actionName("2FA").country("DEFAULT").language("DEFAULT").template("Test1").build());
        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(2L).type("SMS").actionName("2FA").country("HK").language("DEFAULT").template("Test2").build());
        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(3L).type("SMS").actionName("2FA").country("HK").language("en").template("Test3").build());

        otpMessageTemplateRepository.save(OtpMessageTemplateEntity.builder().id(4L).type("SMS").actionName("2FA").country("SG").language("en").template("Test4").build());
    }

    @Test
    public void shouldReturnAllPossibleTemplates() {
        List<OtpMessageTemplateEntity> templateEntities = otpMessageTemplateRepository.findBy(SMS.name(), "2FA", "HK", "en");
        assertEquals(3, templateEntities.size());

        templateEntities = otpMessageTemplateRepository.findBy(SMS.name(), "2FA", "IN", "en");
        assertEquals(1, templateEntities.size());

        templateEntities = otpMessageTemplateRepository.findBy(SMS.name(), "2FA", "SG", "en");
        assertEquals(2, templateEntities.size());

        templateEntities = otpMessageTemplateRepository.findBy(SMS.name(), "REGISTRATION", "SG", "en");
        assertEquals(0, templateEntities.size());
    }

}
