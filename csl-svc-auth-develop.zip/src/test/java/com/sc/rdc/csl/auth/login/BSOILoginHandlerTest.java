package com.sc.rdc.csl.auth.login;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import com.sc.rdc.csl.auth.dto.Profile;
import com.sc.rdc.csl.auth.gateway.IBankDataAccessGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class BSOILoginHandlerTest {
    BSOILoginHandler bsoiLoginHandler;
    final String BSOI_RESPONSE_FAIL = "{\"loginResponse\":{\"responseHeader\":{\"status\":0,\"errorCode\":\"ERR_SEC_LOGIN_FAILED\",\"errorMessage\":\"Please verify your Username/Password, and whether the 'Caps Lock' key is pressed on your keyboard, and retry. If the problem still exists, please call our Customer Service Hotline. (Msg Code : 3227)\",\"currentTimestamp\":\"2018-01-23T20:38:19.548+0800\",\"nonce\":\"a10dbd54b95580b90b6acc75ce25fdbe\"}}}";
    final String BSOI_RESPONSE_SUCESS = "{\"loginResponse\":{\"login\":{\"initLoginVO\":{},\"inAppEnableFlag\":\"Y\",\"securityCode\":\"82bb32018e5f58d4672cf777b9a405a4\",\"sessionId\":\"JM9xd9mQfqCYf7wrBqJV8qA\",\"lastLoginDate\":\"2017-12-01T14:29:42.871+0800\",\"customerName1\":\"MOBILE2 UAT C11\",\"customerIdType\":\"01\",\"isHKResident\":true,\"relTyp\":\"00\",\"preLoginKey\":\"\",\"customerId\":\"P657411\"},\"responseHeader\":{\"status\":1,\"currentTimestamp\":\"2017-12-01T14:32:41.891+0800\",\"nonce\":\"77064a65ce0301b0a0b4cc565c1121f1\"}}}";
    final String BSOI_REQUEST = "{\n" +
        "      \"loginRequest\": {\n" +
        "          \"userId\": \"USER01P657411\",\n" +
        "          \"password\": \"370ca2249b5c00d298e58bb97242b688e69ac4ace18a1904a61123b18d715dd7b60b8cbd60e7f619f492b64d60fd22bc607c8de3ea920ee9614f3c6d745979b1e6f5894bf3b663ae994957db8692881ac6aa79610e43d9df0ebbb985e28556d6b165a5dc2e9ba0bf44da5d2e44a78b3a390ec4b2904bbef0c27bfaa910374c7e4d5fb09bac992c596b88aa1e9bac8357f83e6074ab3fdba05f8320c1477e3f919dc2652e942fde2c58d912ea138a9ee68b0ee37cd9aecfb3df04a5be46713ce8522da1bfb2ef429bd2642be1c9f254cb720ca7da6be52dfa4c91a490d766c8d1769e3d9ffdee03b125911565a22485f621ee3f18cadb9847695dfc21f84f676f\",\n" +
        "          \"captcha\": \"IsNewProcess\",\n" +
        "          \"language\": \"en\",\n" +
        "          \"securityNonce\": \"76f71da4184be4828072c82679a5\"\n" +
        "      },\n" +
        "      \"requestHeader\": {\n" +
        "          \"serviceContext\": {\n" +
        "              \"serviceId\": \"serviceID\",\n" +
        "              \"token\": null,\n" +
        "              \"nonce\": \"701411d1320fe7c9794944842389fc96\",\n" +
        "              \"otpToken\": null\n" +
        "          },\n" +
        "          \"clientContext\": {\n" +
        "              \"country\": \"HK\",\n" +
        "              \"channel\": \"IBKBMW\"\n" +
        "          },\n" +
        "          \"userContext\": {\n" +
        "              \"userId\": \"USER01P657411\",\n" +
        "              \"sessionId\": \"p2RfEA_4jJS-vcUsOGUWhaE\",\n" +
        "              \"language\": \"en\"\n" +
        "          },\n" +
        "          \"rumContext\": {\n" +
        "              \"rumData\": \"Mac OS|Chrome|2017-12-01|14:35:26.479|+0800|||Not Available|bsoi_login|6446|\"\n" +
        "          }\n" +
        "      }\n" +
        "  }";

    @Mock
    IBankDataAccessGateway iBankDataAccessGateway;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        bsoiLoginHandler = new BSOILoginHandler();
        bsoiLoginHandler.setIBankDataAccessGateway(iBankDataAccessGateway);
    }


    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_failed_login() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put("response_body", Arrays.asList(BSOI_RESPONSE_FAIL));
        params.put("request_body", Arrays.asList(BSOI_REQUEST));
        bsoiLoginHandler.login(client, params);
    }

    @Test
    public void should_successfully_login() {

        Profile profile = new Profile();
        profile.setCustomerEBID("12345678");
        profile.setPreferredLogin("SMS");

        CustomerProfile customerProfile = new CustomerProfile();
        customerProfile.setProfile(profile);
        when(iBankDataAccessGateway.getCustomerProfile(any(), any())).thenReturn(customerProfile);

        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put("response_body", Arrays.asList(BSOI_RESPONSE_SUCESS));
        params.put("request_body", Arrays.asList(BSOI_REQUEST));

        CSLUserSubject subject = bsoiLoginHandler.login(client, params);

        assertEquals(AccessLevel.ONE_FACTOR, subject.getAccessLevel());
        assertEquals("JM9xd9mQfqCYf7wrBqJV8qA", subject.getId());
    }



}
