package com.sc.rdc.csl.auth.model;

import org.junit.Test;

public class CSLRefreshTokenTest {

    @Test
    public void shouldConstruct_CSLToken_FromRefreshToken() {

    }
}
