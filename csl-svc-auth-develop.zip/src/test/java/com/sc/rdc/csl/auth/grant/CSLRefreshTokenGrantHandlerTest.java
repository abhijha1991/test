package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import static org.mockito.Mockito.when;

public class CSLRefreshTokenGrantHandlerTest {
    @InjectMocks
    private CSLRefreshTokenGrantHandler handler;

    @Mock
    private Client client;

    @Mock
    private OAuthDataProvider oAuthDataProvider;

    private MultivaluedMap<String, String> params;

    private String refreshTokenKey;

    private String refreshTokenKeyNew = "22f61a69bdbc5be8235266983daad19b";

    @Mock
    private RefreshToken refreshToken;

    @Mock
    private CSLUserSubject subject;

    @Before
    public void setup() {
        refreshTokenKey = "34a2b3b4b2e8f530f4eb2fd45977ba";
        handler = new CSLRefreshTokenGrantHandler(oAuthDataProvider) {
            protected ServerAccessToken createAccessToken(Client client, MultivaluedMap<String, String> params, boolean recycleRefreshTokens){
                CSLAccessToken token = new CSLAccessToken();
                token.setTokenKey(refreshTokenKeyNew);
                return token;
            }

            protected boolean isValidDevice(String deviceId) {
                return true;
            }
        };

        MockitoAnnotations.initMocks(this);
        when(oAuthDataProvider.getRefreshToken(refreshTokenKey)).thenReturn(refreshToken);
        when(refreshToken.getSubject()).thenReturn(subject);
        when(subject.getGrantType()).thenReturn(AuthConstants.REGISTERED_DEVICE_GRANT);
        when(subject.getId()).thenReturn("helloworlds19");
    }

    @Test
    public void generate_token_for_valid_device_id_succeeded() {
        params =  new MultivaluedHashMap<>();
        params.add(OAuthConstants.REFRESH_TOKEN,refreshTokenKey );
        ServerAccessToken token =  handler.createAccessToken(client, params);
        Assert.assertNotNull(token);
        Assert.assertEquals(refreshTokenKeyNew, token.getTokenKey());
    }

    @Test(expected = OAuthServiceException.class)
    public void generate_token_for_invalid_device_id_failed() {
        params =  new MultivaluedHashMap<>();
        params.add(OAuthConstants.REFRESH_TOKEN, refreshTokenKey);

        handler = new CSLRefreshTokenGrantHandler(oAuthDataProvider) {
            protected boolean isValidDevice(String deviceId) {
                return false;
            }
        };

        MockitoAnnotations.initMocks(this);
        when(oAuthDataProvider.getRefreshToken(refreshTokenKey)).thenReturn(refreshToken);
        when(refreshToken.getSubject()).thenReturn(subject);
        when(subject.getGrantType()).thenReturn(AuthConstants.REGISTERED_DEVICE_GRANT);
        when(subject.getId()).thenReturn("helloworlds19");

        handler.createAccessToken(client, params);
    }

    @Test(expected = OAuthServiceException.class)
    public void generate_token_for_invalid_refresh_token_failed() {
        when(oAuthDataProvider.getRefreshToken(refreshTokenKey)).thenReturn(null);
        params =  new MultivaluedHashMap<>();
        params.add(OAuthConstants.REFRESH_TOKEN,refreshTokenKey );
        handler.createAccessToken(client, params);
    }

    @Test
    public void generate_token_for_other_grant_type_succeeded() {
        when(subject.getGrantType()).thenReturn(AuthConstants.OTP_GRANT);
        params =  new MultivaluedHashMap<>();
        params.add(OAuthConstants.REFRESH_TOKEN,refreshTokenKey );
        handler.createAccessToken(client, params);
    }

}
