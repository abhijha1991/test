package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.CreditCard;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import com.sc.rdc.csl.auth.dto.Profile;
import com.sc.rdc.csl.auth.gateway.IBankDataAccessGateway;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import com.sc.rdc.csl.auth.service.CreditCardService;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;
import java.util.UUID;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Slf4j
public class CSLClientCredentialsGrantHandlerTest {
    CSLClientCredentialsGrantHandler cslClientCredentialsGrantHandler;

    @Mock
    OAuthDataProvider oAuthDataProvider;
    @Mock
    CreditCardService creditCardService;
    @Mock
    IBankDataAccessGateway iBankDataAccessGateway;
    @Mock
    ServerAccessToken serverAccessToken;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        cslClientCredentialsGrantHandler = new CSLClientCredentialsGrantHandler(oAuthDataProvider) {
            protected ServerAccessToken doCreateAccessToken(Client client, UserSubject subject, MultivaluedMap<String, String> params) {
                return serverAccessToken;
            }

        };
        cslClientCredentialsGrantHandler.setIBankDataAccessGateway(iBankDataAccessGateway);
        cslClientCredentialsGrantHandler.setCreditCardService(creditCardService);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_oauth_exception_createAccessToken() {
        Client client = mock(Client.class);
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        cslClientCredentialsGrantHandler.createAccessToken(client, params);
    }

    @Test
    public void should_throw_oauth_pass_createAccessToken() {
        Client client = mock(Client.class);
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.CARD_NUMBER_PARAM, Arrays.asList("2345234523452"));
        params.put(AuthConstants.JSESSION_ID_PARAM, Arrays.asList("234523452345234523452345234523"));
        params.put(AuthConstants.COUNTRY_PARAM,  Arrays.asList("HK"));
        params.put(AuthConstants.REQUEST_ID_PARAM, Arrays.asList(UUID.randomUUID().toString()));

        params.put("access_level", Arrays.asList("ONE_FACTOR"));
        params.put("token_type", Arrays.asList("transferToken"));

        CreditCard customerNumber = new CreditCard();
        customerNumber.setRelId("01S0294");
        customerNumber.setCustomerId("01S0294");

        Profile profile = new Profile();
        profile.setCustomerEBID("12345678");

        CustomerProfile customerProfile = new CustomerProfile();
        customerProfile.setProfile(profile);

        when(creditCardService.customerId(eq("HK"), eq("2345234523452"))).thenReturn(customerNumber);
        when(iBankDataAccessGateway.getCustomerProfile(eq("01S0294"), eq("HK"))).thenReturn(customerProfile);

        ServerAccessToken at = cslClientCredentialsGrantHandler.createAccessToken(client, params);

        assertTrue(at == serverAccessToken);
    }

}
