package com.sc.rdc.csl.auth.filter;

import com.sc.csl.retail.core.exception.UnauthorizedException;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.service.CSLTokenIntrospectionService;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class AccessTokenFilterTest {

    CSLTokenIntrospectionService cslTokenIntrospectionService;

    AccessTokenFilter accessTokenFilter = new AccessTokenFilter() {
        public String getInternalAccessToken(String accessToken) {
            return super.getInternalAccessToken(accessToken);
        }
    };

    @Before
    public void init() {
        cslTokenIntrospectionService = mock(CSLTokenIntrospectionService.class);
        accessTokenFilter.setTokenIntrospectionService(cslTokenIntrospectionService);
    }

    @Test(expected = UnauthorizedException.class)
    public void should_throw_exception() {
        accessTokenFilter.getInternalAccessToken("token");
    }

    @Test
    public void should_return_token() {
        when(cslTokenIntrospectionService.internalAccessToken(any())).thenReturn("INTERNAL_ACCESS_TOKEN");
        when(cslTokenIntrospectionService.cslAccessToken(any())).thenReturn(mock(CSLAccessToken.class));
        String iat = accessTokenFilter.getInternalAccessToken("ACCESS_TOKEN");
        assertEquals("INTERNAL_ACCESS_TOKEN", iat);
    }
}
