package com.sc.rdc.csl.auth.otp;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.ChallengeOtpValidation;
import com.sc.rdc.csl.auth.dto.SoftTokenValidateOtp;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import io.katharsis.client.ClientException;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class SoftTokenOtpHandlerTest {

    SoftTokenOtpHandler softTokenOtpHandler;

    @Mock
    SecurityGateway securityGateway;

    @Mock
    CSLRequestContext cslRequestContext;

    OAuthClient client;

    @Before
    public void init() {
        client = new OAuthClient();
        softTokenOtpHandler = new SoftTokenOtpHandler();
        MockitoAnnotations.initMocks(this);
        softTokenOtpHandler.setSecurityGateway(securityGateway);
        softTokenOtpHandler.setCslRequestContext(cslRequestContext);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_no_tx_ref_challenge_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.ST_CHALLENGE_OTP_TYPE));
        softTokenOtpHandler.processOtp(client, params);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_processing_error_challenge_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.ST_CHALLENGE_OTP_TYPE));
        params.put("transaction_ref_no", Arrays.asList("4523452345234523452345"));
        when(securityGateway.challengeOtpValidation(eq("4523452345234523452345"))).thenThrow(new RuntimeException());
        softTokenOtpHandler.processOtp(client, params);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_validation_error_challenge_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.ST_CHALLENGE_OTP_TYPE));
        params.put("transaction_ref_no", Arrays.asList("4523452345234523452345"));

        ChallengeOtpValidation challengeOtpValidation = new ChallengeOtpValidation();
        challengeOtpValidation.setValidationStatus("FAILED");

        when(securityGateway.challengeOtpValidation(eq("4523452345234523452345"))).thenReturn(challengeOtpValidation);
        softTokenOtpHandler.processOtp(client, params);
    }

    @Test
    public void should_pass_challenge_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.ST_CHALLENGE_OTP_TYPE));
        params.put("transaction_ref_no", Arrays.asList("4523452345234523452345"));

        ChallengeOtpValidation challengeOtpValidation = new ChallengeOtpValidation();
        challengeOtpValidation.setValidationStatus("VALIDATED");
        when(cslRequestContext.getRelId()).thenReturn("01S0294");

        when(securityGateway.challengeOtpValidation(eq("4523452345234523452345"))).thenReturn(challengeOtpValidation);
        CSLUserSubject subject = softTokenOtpHandler.processOtp(client, params);
        assertEquals("01S0294", subject.getId());
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_gateway_error_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.SOFT_TOKEN_OTP_TYPE));
        when(securityGateway.validateSoftTokenOtp(any())).thenThrow(new RuntimeException(""));
        softTokenOtpHandler.processOtp(client, params);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_client_exception_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.SOFT_TOKEN_OTP_TYPE));
        when(securityGateway.validateSoftTokenOtp(any())).thenThrow(new ClientException(401, "Forbidden"));
        softTokenOtpHandler.processOtp(client, params);
    }

    @Test
    public void should_pass_validation_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(AuthConstants.SOFT_TOKEN_OTP_TYPE));
        SoftTokenValidateOtp validateResponse = new SoftTokenValidateOtp();
        when(securityGateway.validateSoftTokenOtp(any())).thenReturn(validateResponse);
        CSLUserSubject subject = softTokenOtpHandler.processOtp(client, params);
        assertEquals(AccessLevel.TWO_FACTOR, subject.getAccessLevel());
    }

    private MultivaluedMap<String, String> prepareParams() {
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.COUNTRY_PARAM, Arrays.asList("HK"));
        params.put(AuthConstants.CHANNEL_PARAM, Arrays.asList("IBKBMW"));
        return params;
    }
}
