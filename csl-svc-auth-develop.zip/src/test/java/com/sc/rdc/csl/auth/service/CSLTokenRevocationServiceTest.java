package com.sc.rdc.csl.auth.service;

import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@RunWith(PowerMockRunner.class)
@PrepareForTest(CSLTokenRevocationService.class)
public class CSLTokenRevocationServiceTest {
    private CSLTokenRevocationService service;

    @Mock
    private OAuthDataProvider dataProvider;

    @Mock
    private Client mockClient;

    private MultivaluedMap<String, String> params ;

    @Before
    public void setup() {
        service = new CSLTokenRevocationService() {
            protected Client authenticateClientIfNeeded(MultivaluedMap<String, String> params) {
                return mockClient;
            }
        };
        service.setDataProvider(dataProvider);
        when(dataProvider.revokeTokens(any(String.class))).thenReturn(new int[] {1,1});
        initMocks(this);
    }

    @Test
    public void token_revoke_by_session_id_successfully() throws Exception {
        params = new MultivaluedHashMap<>();
        params.add("token_type_hint", "JSESSIONID");
        params.add("token", "session");
        Response res = service.handleTokenRevocation(params);
        Map<String, Integer> responseMap = (Map<String, Integer>) res.readEntity(Map.class);

        assertEquals(200, res.getStatus());
        assertEquals(responseMap.get("accessTokens"), Integer.valueOf(1));
        assertEquals(responseMap.get("refreshTokens"), Integer.valueOf(1));

    }

    @Test
    public void token_revoke_by_subject_id_successfully() throws Exception {
        params = new MultivaluedHashMap<>();
        params.add("token_type_hint", "subject_id");
        params.add("token", "device-id-123");
        Response res = service.handleTokenRevocation(params);
        assertEquals(200, res.getStatus());
    }

    @Test
    public void token_revoke_by_invalidate_hint() throws Exception {
        params = new MultivaluedHashMap<>();
        params.add("token_type_hint", "");

        Response res = service.handleTokenRevocation(params);
        assertEquals(400, res.getStatus());
    }

    @Test
    public void token_revoke_by_invalidate_id() throws Exception {
        params = new MultivaluedHashMap<>();
        params.add("token_type_hint", "subject_id");
        params.add("token", null);

        Response res = service.handleTokenRevocation(params);
        assertEquals(400, res.getStatus());
    }
}
