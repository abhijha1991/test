package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.rdc.csl.auth.dto.response.UserAuthenticationResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.w3c.dom.NodeList;

import javax.xml.soap.*;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({MessageFactory.class, SOAPConnectionFactory.class})
public class NFSGatewayTest {

    NFSGateway nfsGateway;
    MessageFactory mockFactory;
    SOAPConnectionFactory mockSoapFactory;
    FreemarkerRenderer renderer;
    SOAPMessage soapMessage;
    SOAPConnection soapConnection;
    SOAPBody soapBody;

    @Before
    public void init() throws SOAPException, IOException {
        nfsGateway = new NFSGateway();
        soapMessage = mock(SOAPMessage.class);
        mockFactory = mock(MessageFactory.class);
        mockSoapFactory = mock(SOAPConnectionFactory.class);
        soapConnection = mock(SOAPConnection.class);
        renderer = mock(FreemarkerRenderer.class);
        soapBody = mock(SOAPBody.class);

        nfsGateway.setRenderer(renderer);

        PowerMockito.mockStatic(MessageFactory.class);
        when(MessageFactory.newInstance()).thenReturn(mockFactory);
        PowerMockito.mockStatic(SOAPConnectionFactory.class);
        when(SOAPConnectionFactory.newInstance()).thenReturn(mockSoapFactory);

        when(soapMessage.getSOAPBody()).thenReturn(soapBody);
        when(soapConnection.call(any(), any())).thenReturn(soapMessage);
        when(mockSoapFactory.createConnection()).thenReturn(soapConnection);
        when(mockFactory.createMessage(any(), any())).thenReturn(soapMessage);
        when(renderer.render(any(), any())).thenReturn("");
    }


    @Test(expected = TechnicalException.class)
    public void testAuthenticateUserThrowTechnicalExceptionOnCall() throws SOAPException {
        when(soapConnection.call(any(), any())).thenThrow(new SOAPException());
        nfsGateway.authenticateUser(null);
    }

    @Test(expected = TechnicalException.class)
    public void testAuthenticateUserThrowTechnicalExceptionOnBody() throws SOAPException {
        when(soapMessage.getSOAPBody()).thenThrow(new SOAPException());
        nfsGateway.authenticateUser(null);
    }

    @Test
    public void testAuthenticateUserFailedLogin() {
        NodeList subNodeList = mock(NodeList.class);
        Node node1 = mock(Node.class);
        Node node2 = mock(Node.class);
        Node node3 = mock(Node.class);

        when(subNodeList.getLength()).thenReturn(3);
        when(subNodeList.item(eq(0))).thenReturn(node1);
        when(subNodeList.item(eq(1))).thenReturn(node2);
        when(subNodeList.item(eq(2))).thenReturn(node3);

        when(node1.getNodeName()).thenReturn("errorCode");
        when(node1.getTextContent()).thenReturn("3000");

        when(node2.getNodeName()).thenReturn("status");
        when(node2.getTextContent()).thenReturn("0");

        when(node3.getNodeName()).thenReturn("errorMessage");
        when(node3.getTextContent()).thenReturn("Username and password mismatch");

        NodeList nodeList = mock(NodeList.class);
        Node node0 = mock(Node.class);

        when(nodeList.getLength()).thenReturn(1);
        when(nodeList.item(eq(0))).thenReturn(node0);
        when(node0.getChildNodes()).thenReturn(subNodeList);

        when(soapBody.getElementsByTagName(eq("response"))).thenReturn(nodeList);
        UserAuthenticationResponse authenticationResponse = nfsGateway.authenticateUser(null);

        assertEquals("3000", authenticationResponse.getErrorCode());
        assertEquals("0", authenticationResponse.getStatus());
        assertEquals("Username and password mismatch", authenticationResponse.getErrorMessage());

        assertNull(authenticationResponse.getCustomerEBID());
        assertNull(authenticationResponse.getCustomerId());
        assertNull(authenticationResponse.getCustomerIdType());
    }

    @Test
    public void testAuthenticateUserSuccessLogin() {
        NodeList subNodeList = mock(NodeList.class);
        Node node1 = mock(Node.class);
        Node node2 = mock(Node.class);
        Node node3 = mock(Node.class);

        when(subNodeList.getLength()).thenReturn(3);
        when(subNodeList.item(eq(0))).thenReturn(node1);
        when(subNodeList.item(eq(1))).thenReturn(node2);
        when(subNodeList.item(eq(2))).thenReturn(node3);

        when(node1.getNodeName()).thenReturn("customerEBID");
        when(node1.getTextContent()).thenReturn("1234567");

        when(node2.getNodeName()).thenReturn("customerId");
        when(node2.getTextContent()).thenReturn("0345685678");

        when(node3.getNodeName()).thenReturn("customerIdType");
        when(node3.getTextContent()).thenReturn("01");

        NodeList nodeList = mock(NodeList.class);
        Node node0 = mock(Node.class);

        when(nodeList.getLength()).thenReturn(1);
        when(nodeList.item(eq(0))).thenReturn(node0);
        when(node0.getChildNodes()).thenReturn(subNodeList);

        NodeList responseSubNodeList = mock(NodeList.class);
        Node nodeResponse1 = mock(Node.class);

        when(responseSubNodeList.getLength()).thenReturn(1);
        when(responseSubNodeList.item(eq(0))).thenReturn(nodeResponse1);

        when(nodeResponse1.getNodeName()).thenReturn("status");
        when(nodeResponse1.getTextContent()).thenReturn("1");

        NodeList nodeResponseList = mock(NodeList.class);
        Node nodeResponse0 = mock(Node.class);

        when(nodeResponseList.getLength()).thenReturn(1);
        when(nodeResponseList.item(eq(0))).thenReturn(nodeResponse0);
        when(nodeResponse0.getChildNodes()).thenReturn(responseSubNodeList);

        when(soapBody.getElementsByTagName(eq("response"))).thenReturn(nodeResponseList);
        when(soapBody.getElementsByTagName(eq("userInfo"))).thenReturn(nodeList);

        UserAuthenticationResponse authenticationResponse = nfsGateway.authenticateUser(null);

        assertEquals("1234567", authenticationResponse.getCustomerEBID());
        assertEquals("0345685678", authenticationResponse.getCustomerId());
        assertEquals("01", authenticationResponse.getCustomerIdType());
        assertEquals("1", authenticationResponse.getStatus());

        assertNull(authenticationResponse.getErrorCode());
        assertNull(authenticationResponse.getErrorMessage());
    }

}
