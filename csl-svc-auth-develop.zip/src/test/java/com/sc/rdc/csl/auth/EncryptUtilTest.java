package com.sc.rdc.csl.auth;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.bouncycastle.crypto.encodings.PKCS1Encoding;
import org.bouncycastle.crypto.engines.RSAEngine;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.util.encoders.Hex;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class EncryptUtilTest {
    public static String encryptUserId(String userId) {
        return DigestUtils.shaHex(userId);
    }

    public static String encryptPassword(String password, String nonceValue,
                                         String exponentValue, String modulusValue) {
        String encryptedPassword=null;
        byte[] encKey;
        BigInteger exponent = new BigInteger(exponentValue, 16);
        BigInteger modulus = new BigInteger(modulusValue, 16);
        RSAKeyParameters rsaKeyParameters = new RSAKeyParameters(false, modulus, exponent);
        PKCS1Encoding rsaEngine = new PKCS1Encoding(new RSAEngine());
        rsaEngine.init(true, rsaKeyParameters);
        if (StringUtils.isNotBlank(nonceValue)) {
            password = nonceValue + password;
        }
        try {
            encKey = rsaEngine.processBlock(password.getBytes(), 0, password.getBytes().length);

            encryptedPassword = new String(Hex.encode(encKey), "UTF-8");
        } catch (Exception e) {
            String s;
        }
        return encryptedPassword;
    }

    public static String encryptHash(String country, String sessionId, String userId,
                                     String serviceId, String securityCode)
        throws NoSuchAlgorithmException, UnsupportedEncodingException {
        String hash = country + "|" + sessionId + "|" + userId + "|" + serviceId + "|" + securityCode;
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
        byte[] hashed = messageDigest.digest(hash.getBytes("UTF-8"));
        return new String(Base64.encodeBase64(hashed), "UTF-8");
    }
}
