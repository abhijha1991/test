package com.sc.rdc.csl.auth.grant;

import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import com.sc.rdc.csl.auth.otp.CreditCardOtpHandler;
import com.sc.rdc.csl.auth.otp.SmsOtpHandler;
import com.sc.rdc.csl.auth.otp.SoftTokenOtpHandler;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.UserSubject;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static com.sc.rdc.csl.auth.constants.AuthConstants.CREDIT_CARD_OTP_TYPE;
import static com.sc.rdc.csl.auth.constants.AuthConstants.SOFT_TOKEN_OTP_TYPE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class OtpGrantHandlerTest {

    OtpGrantHandler otpGrantHandler;

    @Mock
    OAuthDataProvider oAuthDataProvider;
    @Mock
    SmsOtpHandler smsOtpHandler;
    @Mock
    CSLUserSubject cslUserSubject;
    @Mock
    ServerAccessToken serverAccessToken;
    @Mock
    CreditCardOtpHandler creditCardOtpHandler;
    @Mock
    SoftTokenOtpHandler softTokenOtpHandler;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        otpGrantHandler = new OtpGrantHandler(oAuthDataProvider) {
            protected ServerAccessToken doCreateAccessToken(Client client, UserSubject subject, MultivaluedMap<String, String> params) {
                return serverAccessToken;
            }

        };
        otpGrantHandler.setSmsOtpHandler(smsOtpHandler);
        otpGrantHandler.setCreditCardOtpHandler(creditCardOtpHandler);
        otpGrantHandler.setSoftTokenOtpHandler(softTokenOtpHandler);

        when(smsOtpHandler.processOtp(any(), any())).thenReturn(cslUserSubject);
        when(softTokenOtpHandler.processOtp(any(), any())).thenReturn(cslUserSubject);
        when(creditCardOtpHandler.processOtp(any(), any())).thenReturn(cslUserSubject);
    }

    @Test
    public void testCreateAccessTokenSms() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList("SMS_OTP"));
        otpGrantHandler.createAccessToken(client, params);
        verify(smsOtpHandler, times(1)).processOtp(eq(client), eq(params));
    }

    @Test
    public void testCreateAccessTokenSoftToken() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(SOFT_TOKEN_OTP_TYPE));
        otpGrantHandler.createAccessToken(client, params);
        verify(softTokenOtpHandler, times(1)).processOtp(eq(client), eq(params));
    }

    @Test
    public void testCreateAccessTokenCreditCard() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(CREDIT_CARD_OTP_TYPE));
        otpGrantHandler.createAccessToken(client, params);
        verify(creditCardOtpHandler, times(1)).processOtp(eq(client), eq(params));
    }

    @Test
    public void testCreateAccessTokenSmsWithSessionId() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.OTP_TYPE_PARAM, Arrays.asList(CREDIT_CARD_OTP_TYPE));
        params.put(AuthConstants.JSESSION_ID_PARAM, Arrays.asList("234523452345234523452345234523"));
        otpGrantHandler.createAccessToken(client, params);
        verify(creditCardOtpHandler, times(1)).processOtp(eq(client), eq(params));
        verify(cslUserSubject, times(1)).setId(eq("234523452345234523452345234523"));
    }

}
