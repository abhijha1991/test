package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.rdc.csl.auth.dto.ValidateDeviceRegistration;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import io.katharsis.resource.links.LinksInformation;
import io.katharsis.resource.list.ResourceList;
import io.katharsis.resource.list.ResourceListBase;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class RegistrationGatewayTest {

    ResourceRepositoryV2 repository;
    CSLKatharsisClient cslKatharsisClient;
    RegistrationGateway registrationGateway;

    @Before
    public void init() {
        cslKatharsisClient = mock(CSLKatharsisClient.class);
        repository = mock(ResourceRepositoryV2.class);
        registrationGateway = new RegistrationGateway() {
            @Override
            protected CSLKatharsisClient getKatharsisClient() {
                return cslKatharsisClient;
            }
        };
        when(cslKatharsisClient.getRepositoryForType(any(Class.class))).thenReturn(repository);
    }

    @Test
    public void testFetchDeviceRegistration() {
        when(repository.findAll(any())).thenReturn(new ResourceListBase() {
            @Override
            public LinksInformation getLinks() { return super.getLinks(); }
        });

        List result = registrationGateway.fetchDeviceRegistration("DEVICE_ID");
        verify(repository, times(1)).findAll(any(QuerySpec.class));
        assertEquals(0, result.size());
    }

    @Test
    public void testFetchValidateDeviceRegistration() {
        ResourceList<ValidateDeviceRegistration> deviceRegistrations = new ResourceListBase() {
            @Override
            public LinksInformation getLinks() { return super.getLinks(); }
        };
        ValidateDeviceRegistration deviceRegistration = new ValidateDeviceRegistration();
        deviceRegistration.setIsValid(true);
        deviceRegistration.setDeviceId("DEVICE_ID");
        deviceRegistrations.add(0, deviceRegistration);
        when(repository.findAll(any())).thenReturn(deviceRegistrations);

        List<ValidateDeviceRegistration> result = registrationGateway.fetchValidateDeviceRegistration("DEVICE_ID");
        verify(repository, times(1)).findAll(any(QuerySpec.class));
        assertEquals(1, result.size());
        assertEquals("DEVICE_ID", result.get(0).getDeviceId());
        assertEquals(true, result.get(0).getIsValid());

    }

}
