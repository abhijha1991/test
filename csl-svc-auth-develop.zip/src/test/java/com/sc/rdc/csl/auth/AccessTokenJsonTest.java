package com.sc.rdc.csl.auth;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

@Slf4j
public class AccessTokenJsonTest {
    @Test
    public void should_IncludeType_InJson() {
        CSLAccessToken cslAccessToken = new CSLAccessToken();
        cslAccessToken.setTokenKey("123");
        OAuthClient client = new OAuthClient();
        client.setClientId("Client1");
        cslAccessToken.setClient(client);
        CSLUserSubject subject = new CSLUserSubject();
        subject.setId("Subject1");
        cslAccessToken.setSubject(subject);

        log.info(CSLJsonUtils.toPrettyJson(cslAccessToken));
    }

    @Test
    public void should_Consider_SubClass_OnConverting_JsonToObject() throws IOException {
        InputStream input = this.getClass().getResourceAsStream("/test.json");
        String json = IOUtils.toString(input, Charset.defaultCharset());
        CSLAccessToken cslAccessToken = CSLJsonUtils.parseJson(json, CSLAccessToken.class);

        log.info(CSLJsonUtils.toPrettyJson(cslAccessToken));
    }
}
