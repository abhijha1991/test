package com.sc.rdc.csl.auth.service;

import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Map;

import static com.sc.rdc.csl.auth.constants.AuthConstants.REFRESH_TOKEN_LIFE_TIME;
import static com.sc.rdc.csl.auth.constants.AuthConstants.REGISTERED_DEVICE_GRANT;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class TokenLifetimeProviderTest {
    @InjectMocks
    private TokenLifetimeProvider tokenLifetimeProvider;

    @Mock
    private CSLAccessToken mockAccessToken;

    @Mock
    private OAuthClient mockClient;

    @Mock
    private CSLUserSubject mockSubject;

    @Before
    public void setup() {
        initMocks(this);
        when(mockAccessToken.getClient()).thenReturn(mockClient);
        when(mockAccessToken.getSubject()).thenReturn(mockSubject);
        when(mockClient.getAccessTokenLifetime()).thenReturn(null);
        when(mockClient.getRefreshTokenLifetime()).thenReturn(null);
    }

    @Test
    public void shouldReturn_Default_AccessTokenLifeTime() {
        Long tokenLifetime = tokenLifetimeProvider.accessTokenLifetime(mockClient, mockSubject);
        assertEquals(TEN_MINS, tokenLifetime.longValue());
    }

    @Test
    public void shouldReturn_LongLastingAccessToken_ForRegisteredDevice() {
        when(mockSubject.getGrantType()).thenReturn(REGISTERED_DEVICE_GRANT);

        Long tokenLifetime = tokenLifetimeProvider.accessTokenLifetime(mockClient, mockSubject);
        assertEquals(ONE_DAY, tokenLifetime.longValue());
    }

    @Test
    public void shouldReturn_ClientSpecific_AccessTokenLifeTime() {
        when(mockClient.getAccessTokenLifetime()).thenReturn(Long.valueOf(240));

        Long tokenLifetime = tokenLifetimeProvider.accessTokenLifetime(mockClient, mockSubject);
        assertEquals(FOUR_MINS, tokenLifetime.longValue());
    }

    @Test
    public void shouldReturn_Default_RefreshTokenLifeTime() {
        Long refreshTokenLifetime = tokenLifetimeProvider.refreshTokenLifetime(mockAccessToken);
        assertEquals(THIRTY_MINS, refreshTokenLifetime.longValue());
    }

    @Test
    public void shouldReturn_CustomRefreshTokenLifeTime_IfSpecifiedInSubjectProperty() {
        Map<String, String> properties = new HashMap<>();
        properties.put(REFRESH_TOKEN_LIFE_TIME, String.valueOf(900L));
        when(mockSubject.getProperties()).thenReturn(properties);

        Long refreshTokenLifetime = tokenLifetimeProvider.refreshTokenLifetime(mockAccessToken);
        assertEquals(FIFTEEN_MINS, refreshTokenLifetime.longValue());
    }

    @Test
    public void shouldReturn_NoExpiryRefreshToken_ForRegisteredDevice() {
        when(mockAccessToken.getGrantType()).thenReturn(REGISTERED_DEVICE_GRANT);

        Long refreshTokenLifetime = tokenLifetimeProvider.refreshTokenLifetime(mockAccessToken);
        assertEquals(NO_EXPIRY, refreshTokenLifetime.longValue());
    }

    @Test
    public void shouldReturn_ClientSpecific_RefreshTokenLifeTime() {
        when(mockClient.getRefreshTokenLifetime()).thenReturn(Long.valueOf(240));

        Long refreshTokenLifetime = tokenLifetimeProvider.refreshTokenLifetime(mockAccessToken);
        assertEquals(FOUR_MINS, refreshTokenLifetime.longValue());
    }

    private final static long NO_EXPIRY = 0L;
    private final static long ONE_DAY = 86400L;
    private final static long THIRTY_MINS = 1800L;
    private final static long TEN_MINS = 600L;
    private final static long FIFTEEN_MINS = 900L;
    private final static long TWO_MINS = 120L;
    private final static long FOUR_MINS = 240L;
}
