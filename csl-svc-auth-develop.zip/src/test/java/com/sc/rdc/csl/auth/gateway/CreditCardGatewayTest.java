package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.rdc.csl.auth.dto.CreditCard;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import io.katharsis.resource.links.LinksInformation;
import io.katharsis.resource.list.ResourceList;
import io.katharsis.resource.list.ResourceListBase;
import org.junit.Before;
import org.junit.Test;

import static junit.framework.TestCase.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class CreditCardGatewayTest {
    ResourceRepositoryV2 customerRepo;
    CSLKatharsisClient cslKatharsisClient;
    CreditCardGateway creditCardGateway;

    @Before
    public void init() {
        cslKatharsisClient = mock(CSLKatharsisClient.class);
        customerRepo = mock(ResourceRepositoryV2.class);
        creditCardGateway = new CreditCardGateway() {
            @Override
            protected CSLKatharsisClient getKatharsisClient() {
                return cslKatharsisClient;
            }
        };
        when(cslKatharsisClient.getRepositoryForType(any(Class.class))).thenReturn(customerRepo);
    }

    @Test
    public void testGetCustomerContact() {
        creditCardGateway.getCustomerContact("1234567890", "RETAIL");
        verify(customerRepo, times(1)).findOne(eq("1234567890"), any(QuerySpec.class));
    }

    @Test
    public void testGetCustomerIdByCardNumber() {
        creditCardGateway.getCustomerId("1234567890");
        verify(customerRepo, times(1)).findOne(eq("1234567890"), any(QuerySpec.class));
    }

    @Test(expected = BusinessException.class)
    public void testGetCustomerIdByCustomerNumberEmpty() {
        ResourceList resourceList = mock(ResourceList.class);
        when(resourceList.size()).thenReturn(0);
        when(customerRepo.findAll(any())).thenReturn(resourceList);
        creditCardGateway.getCustomerNumber("1234567890");
        verify(customerRepo, times(1)).findAll(any(QuerySpec.class));
    }

    @Test
    public void testGetCustomerIdByCustomerNumber() {
        ResourceList list = new ResourceListBase() {
            @Override
            public LinksInformation getLinks() { return super.getLinks(); }
        };
        list.add(0, new CreditCard());
        when(customerRepo.findAll(any())).thenReturn(list);
        CreditCard creditCard = creditCardGateway.getCustomerNumber("1234567890");
        verify(customerRepo, times(1)).findAll(any(QuerySpec.class));
        assertNotNull(creditCard);
    }
}
