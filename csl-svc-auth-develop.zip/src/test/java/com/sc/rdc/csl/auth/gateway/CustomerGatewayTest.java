package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerContact;
import com.sc.rdc.csl.auth.dto.CustomerInfo;
import io.katharsis.client.KatharsisClient;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Slf4j
public class CustomerGatewayTest {

    @InjectMocks
    private CustomerGateway customerGateway;

    @Mock
    private CSLAsyncRequestContext cslAsyncRequestContext = new CSLAsyncRequestContext();

    @Mock
    private KatharsisClient katharsisClient;

    @Mock
    private ResourceRepositoryV2 customerRepo;

    private ResourceList<CustomerContact> resourceList;

    @Before
    public void setUp() {
        customerGateway = new CustomerGateway();
        customerGateway.setBaseUrl("http://10.23.210.49:9222");
        customerGateway.setServiceUrl("/customers/api/v3");
        customerGateway.setScbInternal(true);
        cslAsyncRequestContext.setCountry("HK");
        cslAsyncRequestContext.setRelId("01C303360");
        cslAsyncRequestContext.setChannel("IBNK");
        CustomerContact customerContact = new CustomerContact();
        customerContact.setMobileNumber("9291200000");
        customerContact.setRelId("01C303360");
        customerContact.setCustomerEmail("abc@sc.com");
        customerContact.setCustomerName("France");

        List<CustomerContact> customerContactList = new ArrayList<>();
        customerContactList.add(customerContact);

        resourceList = new DefaultResourceList<>();
        resourceList.addAll(customerContactList);
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void contactInfo() {
        when(katharsisClient.getRepositoryForType(CustomerContact.class)).thenReturn(null);
        QuerySpec querySpec = new QuerySpec(CustomerContact.class);
        when(customerRepo.findAll(querySpec)).thenReturn(resourceList);
        CustomerInfo customerInfo = new CustomerInfo();
        customerInfo.setCustomerId("01C303360");
        customerInfo.setCustomerIdType("01");
        // TODO Need to mock the katharsis client used with in the contactInfo() method.
        //customerGateway.contactInfo(customerInfo);
        assertThat(resourceList.size()).isEqualTo(1);
        assertThat(resourceList.get(0).getMobileNumber()).isEqualTo("9291200000");
        assertThat(resourceList.get(0).getRelId()).isEqualTo("01C303360");
        assertThat(resourceList.get(0).getCustomerEmail()).isEqualTo("abc@sc.com");
        assertThat(resourceList.get(0).getCustomerName()).isEqualTo("France");

    }

    @Test
    public void should_ReturnTheCustomerContact_WithLowestSequenceNumber() {
        CustomerGateway customerGateway = new CustomerGateway(){
            @Override
            List<CustomerContact> getCustomerContacts(CustomerInfo customerInfo) {
                return sampleCustomerContacts();
            }
        };
        CustomerInfo customerInfo = Mockito.mock(CustomerInfo.class);
        CustomerContact customerContact = customerGateway.topMobileContactInfo(customerInfo);
        assertNotNull(customerContact);
        assertEquals("MO1", customerContact.getContactTypeCode());
        assertEquals("01", customerContact.getContactSequenceNumber());
    }

    @Test
    public void should_NotThrowError_IfNoMobileContactFound() {
        CustomerGateway customerGateway = new CustomerGateway(){
            @Override
            List<CustomerContact> getCustomerContacts(CustomerInfo customerInfo) {
                List<CustomerContact> customerContacts = new ArrayList<>();
                CustomerContact c1 = new CustomerContact();
                c1.setContactSequenceNumber("03");
                c1.setContactTypeCode("COL");
                customerContacts.add(c1);

                return customerContacts;
            }
        };
        CustomerInfo customerInfo = Mockito.mock(CustomerInfo.class);
        CustomerContact customerContact = customerGateway.topMobileContactInfo(customerInfo);


        assertNull(customerContact.getMobileNumber());
        assertNull(customerContact.getContactTypeCode());
        assertNull(customerContact.getContactSequenceNumber());
    }

    @Test
    public void should_ReturnTheCustomerContact_Primary() {
        CustomerGateway customerGateway = new CustomerGateway(){
            @Override
            List<CustomerContact> getCustomerContacts(CustomerInfo customerInfo) {
                return primaryCustomerContacts();
            }
        };
        CustomerInfo customerInfo = Mockito.mock(CustomerInfo.class);
        CustomerContact customerContact = customerGateway.topMobileContactInfo(customerInfo);
        log.info("Customer Contact Info >> {}", customerContact);
        assertNotNull(customerContact);
        assertEquals("M", customerContact.getContactClassification());
        assertEquals("02", customerContact.getContactSequenceNumber());
        assertEquals("Y", customerContact.getPrimaryFlag());
    }

    @Test
    public void should_return_customer_contacts() {
        CSLKatharsisClient cslKatharsisClient = mock(CSLKatharsisClient.class);
        CustomerInfo customerInfo = Mockito.mock(CustomerInfo.class);

        when(cslKatharsisClient.getRepositoryForType(any())).thenReturn(customerRepo);
        customerGateway.setKatharsisClient(cslKatharsisClient);
        QuerySpec querySpec = new QuerySpec(CustomerContact.class);
        when(customerRepo.findAll(any())).thenReturn(resourceList);

        List resources = customerGateway.getCustomerContacts(customerInfo);

        assertTrue(resources.size() > 0);
    }

    private List<CustomerContact> sampleCustomerContacts() {
        List<CustomerContact> customerContacts = new ArrayList<>();
        CustomerContact c1 = new CustomerContact();
        c1.setContactSequenceNumber("03");
        c1.setContactTypeCode("COL");
        CustomerContact c2 = new CustomerContact();
        c2.setContactSequenceNumber("01");
        c2.setContactTypeCode("MO1");
        CustomerContact c3 = new CustomerContact();
        c3.setContactSequenceNumber("02");
        c3.setContactTypeCode("MF1");
        customerContacts.add(c1);
        customerContacts.add(c2);
        customerContacts.add(c3);

        return customerContacts;
    }

    private List<CustomerContact> primaryCustomerContacts() {
        List<CustomerContact> customerContacts = new ArrayList<>();
        CustomerContact c1 = new CustomerContact();
        c1.setContactSequenceNumber("03");
        c1.setContactTypeCode("COL");
        CustomerContact c2 = new CustomerContact();
        c2.setContactSequenceNumber("01");
        c2.setContactTypeCode("MO1");
        CustomerContact c3 = new CustomerContact();
        c3.setContactSequenceNumber("02");
        c3.setContactClassification("M");
        c3.setPrimaryFlag("Y");
        customerContacts.add(c1);
        customerContacts.add(c2);
        customerContacts.add(c3);

        return customerContacts;
    }

}
