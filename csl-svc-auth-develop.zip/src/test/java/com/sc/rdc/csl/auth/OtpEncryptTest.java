package com.sc.rdc.csl.auth;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.io.codec.Base64;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.model.SmsOtpFields;
import com.sc.csl.retail.core.model.SmsOtpValidation;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.RSAPublicKeySpec;
import java.util.Map;

@Slf4j
public class OtpEncryptTest {
    public static void main(String[] args) {
        Object obj = null;
        synchronized (obj) {
            System.out.println("Synchronized on null");
        }

        String jsonValue = "{\n" +
            "                \"otpSn\": \"19751\",\n" +
            "                \"otpPrefix\": \"wxoj\",\n" +
            "                \"keyIndex\": \"3\",\n" +
            "                \"mobile\": \"xxxxx678\",\n" +
            "                \"base64Challenge\": \"MTUwOTM1NDkwOTI4OF8tX0lCS18tX1NHXy1fMDFTMTU4Njc2NkNfLV9paHppK3IvSV8tX0liUEUrV3Q4YzJOaTVBYmRUaFZadXJzY01yS1ArTUh4RWZzYjJucmpKSVE9\",\n" +
            "                \"modulus\": \"b6b44e815345da9297e595cc88bd6ba7ac5fe4d08bb7aa795951b71b093ad0e0bde4b638570ca038ba0d73222c62286c6a926793f88ae411280c3b92ac5c79d2c142d4a600a376420e101a31936697c2adb56ee0e96be21320eacfefe7f97fd5ad0e59bbf1ff75efa2ae50b6fdb3acd46e89fd993efe4fbf775a071c19d9d694c6f97a47fdd64df0b87338aa839db9b4d5cc907de7c409c5fd7db5921123081b766f795afcb70a7fce5b953a9c4b557b5cebed277cec522fe752c09706d571ebb6620ebdece8c6cd66fc146f562dc5b674cba1361afc6bbe2f050558071b691a0e67e6e57bc9abb8ee64971c23ef14302ab27643fcfad50e123af630c9bc77d9\",\n" +
            "                \"exponent\": \"10001\"\n" +
            "            }";

        String otp = "862979";

        Map<String, String> responseMap = convertJsonIntoMap(jsonValue);
        String toBeEncrypted = otp + "_-_" + responseMap.get("base64Challenge");
        String encOtp = encryptedValue(toBeEncrypted, responseMap.get("modulus"), responseMap.get("exponent"));

        log.info("Encrypted OTP : ");
        log.info(encOtp);

        SmsOtpValidation smsOtpValidation = new SmsOtpValidation();
        SmsOtpFields smsOtpFields = new SmsOtpFields();
        smsOtpFields.setEncOtp(encOtp);
        smsOtpFields.setKeyIndex(responseMap.get("keyIndex"));
        smsOtpFields.setOtpSn(responseMap.get("otpSn"));
        smsOtpFields.setPurpose("1");

        smsOtpValidation.setSmsOtp(smsOtpFields);

        log.info(CSLJsonUtils.toJson(smsOtpValidation));
    }


    public static Map<String, String> convertJsonIntoMap(String jsonValue) {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> map;
        try {
            map = mapper.readValue(jsonValue, new TypeReference<Map<String, String>>() {});
        } catch (IOException e) {
            throw new TechnicalException(e.getMessage());
        }
        return map;
    }


    private static String encryptedValue(String toEncrypt, String mod, String exp) {
        String returnStr;
        try {
            Cipher cipher = Cipher.getInstance("RSA");
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            RSAPublicKeySpec pubKeySpec = new RSAPublicKeySpec(new BigInteger(mod, 16), new BigInteger(exp, 16));
            RSAPublicKey pubKey = (RSAPublicKey) keyFactory.generatePublic(pubKeySpec);
            cipher.init(Cipher.ENCRYPT_MODE, pubKey);
            byte[] cipherText = cipher.doFinal(toEncrypt.getBytes());
            returnStr = Base64.encodeBytes(cipherText);
        } catch (Exception ex) {
            throw new TechnicalException(ex.getMessage());
        }
        return returnStr.replaceAll("[\r\n]+", "");
    }
}
