package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.CustomerInfo;
import com.sc.rdc.csl.auth.dto.CustomerProfile;
import com.sc.rdc.csl.auth.dto.Profile;
import io.katharsis.client.KatharsisClient;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

public class IBankDataAccessGatewayTest {

    @InjectMocks
    private IBankDataAccessGateway ibankDataAccessGateway;

    @Mock
    private CSLAsyncRequestContext cslAsyncRequestContext = new CSLAsyncRequestContext();

    @Mock
    private KatharsisClient client;

    @Mock
    private ResourceRepositoryV2<CustomerProfile, Integer> customerProfileRepo;

    @Mock
    private ResourceRepositoryV2<CustomerInfo, String> customerInfoRepo;

    private ResourceList<CustomerProfile> resourceList;

    @Before
    public void setUp() {
        ibankDataAccessGateway = new IBankDataAccessGateway();
        ibankDataAccessGateway.setBaseUrl("http://localhost:9587/retail/csl/v3");
        ibankDataAccessGateway.setServiceUrl("/ibank/");
        ibankDataAccessGateway.setScbInternal(true);
        cslAsyncRequestContext.setCountry("SG");
        cslAsyncRequestContext.setUaas2id("6523390163");
        cslAsyncRequestContext.setRelId("12200902609H");
        CustomerProfile customerProfile = new CustomerProfile();
        Profile profile = new Profile();
        profile.setCustName1("XXX");
        profile.setCustName2("XXX");
        profile.setPreferredLogin("SMS");
        customerProfile.setProfile(profile);
        List<CustomerProfile> customerProfileList = new ArrayList<>();
        customerProfileList.add(customerProfile);
        resourceList = new DefaultResourceList<>();
        resourceList.addAll(customerProfileList);
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getCustomerProfileTest() {
        when(client.getRepositoryForType(CustomerProfile.class)).thenReturn(null);
        when(customerProfileRepo.findAll(new QuerySpec(CustomerProfile.class))).thenReturn(resourceList);
        String uaas2Id = "6523390163";
        String relId = "12200902609H";
        String country = "SG";
        // TODO Need to mock the katharsis client used with in the getCustomerProfile() method.
        //ibankDataAccessGateway.getCustomerProfile(uaas2Id,relId,country);
        assertThat(resourceList.size()).isEqualTo(1);
        assertThat(resourceList.get(0).getProfile().getCustName1()).isEqualTo("XXX");
        assertThat(resourceList.get(0).getProfile().getCustName2()).isEqualTo("XXX");
        assertThat(resourceList.get(0).getProfile().getPreferredLogin()).isEqualTo("SMS");
    }

    @Test
    public void customerIdTest() {
        CustomerInfo customerInfoResponse = new CustomerInfo();
        customerInfoResponse.setCustomerIdType("01");
        customerInfoResponse.setCustomerId("C303360");
        String creditCardNumber = "9344387026011277";
        when(client.getRepositoryForType(CustomerInfo.class)).thenReturn(null);
        when(customerInfoRepo.findOne(creditCardNumber, new QuerySpec(CustomerInfo.class))).thenReturn(customerInfoResponse);
        //ibankDataAccessGateway.customerId(creditCardNumber);
        assertThat(customerInfoResponse.getCustomerId()).isEqualTo("C303360");
        assertThat(customerInfoResponse.getCustomerIdType()).isEqualTo("01");
    }
}
