package com.sc.rdc.csl.auth;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.rdc.csl.auth.dto.request.bsoi.*;
import com.sc.rdc.csl.auth.dto.response.bsoi.ResponseHeader;
import com.sc.rdc.csl.auth.dto.response.bsoi.init.BSOIInitResponse;
import com.sc.rdc.csl.auth.dto.response.bsoi.init.InitLogin;
import com.sc.rdc.csl.auth.dto.response.bsoi.init.InitLoginResponse;
import lombok.extern.slf4j.Slf4j;

import java.util.Base64;

@Slf4j
public class BsoiLoginEncryptTest {
    public static void main(String[] args) {

        String jsonValue = "{\n" +
            "    \"initLoginResponse\": {\n" +
            "        \"initLogin\": {\n" +
            "            \"sessionId\": \"A7E7A1D072C0999FAF17\",\n" +
            "            \"securityNonce\": \"bb0147bdae8113e9456975bb1aa8\",\n" +
            "            \"securityParam\": {\n" +
            "                \"e2eRsaModulus\": \"a70c3cfa21deffd3ae1b7719d2805c03600f087a369b74e8d5233a8491c91fb5c010a9cd8d2a78816c00819200aa30fe2ea98e709ba9a7e50807ee7cb0d4cf209f90a4fcb33891b09c042b3a5b2b0bee74a96ab1e1828d59140a3d8d242cc375bd020c9f4937aeed9deeeedad21facd2d7e809ce587de9dbb4457cd039e80d545f20a817e33b9059caceea60de8c0e82320a16ef9ab17e3e588505b2e249d4be8717bacc85ec854f2d886147abe6adcb860a7a7aae8ca4013fff1ecf12edb038769f187cb562de303cf65e0d1d48296df79d06e5831471d8f64b8f5836b174c658fe8c9f8ccc08a7169e4bec3da3f3122f9ee5f2aee8ce5455557b3c963be835\",\n" +
            "                \"e2eRsaExponent\": \"10001\"\n" +
            "            }\n" +
            "        },\n" +
            "        \"responseHeader\": {\n" +
            "            \"status\": 1,\n" +
            "            \"nonce\": \"2a24d0104e827b9dc781a07feaf6d5ad\",\n" +
            "            \"currentTimestamp\": \"2017-10-09T17:45:22.945+0800\"\n" +
            "        },\n" +
            "        \"tmResponse\": {\n" +
            "            \"uniqueSessionId\": \"cb230d2398f41888fdd724b29708926e49dbd04d0fecdc3de804031509de712c\"\n" +
            "        }\n" +
            "    }\n" +
            "}";

        BSOIInitResponse initResponse = CSLJsonUtils.parseJson(jsonValue, BSOIInitResponse.class);
        InitLoginResponse initLoginResponse = initResponse.getInitLoginResponse();
        InitLogin initLogin = initLoginResponse.getInitLogin();
        ResponseHeader responseHeader = initLoginResponse.getResponseHeader();

        BSOILoginRequest bsoiLoginRequest = getRequest(
            responseHeader.getNonce(),
            initLogin.getSessionId(),
            initLogin.getSecurityParam().getE2eRsaModulus(),
            initLogin.getSecurityNonce()
        );

        String requestJson = CSLJsonUtils.toPrettyJson(bsoiLoginRequest);
        System.out.println("Request : ");
        System.out.println(requestJson);
        System.out.println("Encoded : ");
        byte[] encoded = Base64.getEncoder().encode(requestJson.getBytes());
        System.out.println(new String(encoded));
    }

    private static BSOILoginRequest getRequest(String nonce, String sessionId, String modulus, String securityNonce) {
        BSOILoginRequest req = new BSOILoginRequest();
        RequestHeader header = new RequestHeader();
        LoginRequest login = new LoginRequest();
        ServiceContext cont = new ServiceContext();

        cont.setServiceId("serviceID");
        cont.setNonce(nonce.trim());
        cont.setToken(null);
        cont.setOtpToken(null);
        header.setServiceContext(cont);

        ClientContext con = new  ClientContext();
        con.setCountry("SG");
        con.setChannel("IBKBMW-SG");
        header.setClientContext(con);

        UserContext u = new UserContext();
        String userId = "PTUSER018";
        u.setUserId(userId);
        u.setSessionId(sessionId.trim());
        u.setLanguage("en");
        header.setUserContext(u);

        RumContext r = new RumContext();
        r.setRumData("Mac OS|Chrome|2017-08-24|17:38:05.943|+0800|||Not Available|bsoi_login|6446|");
        header.setRumContext(r);

        req.setRequestHeader(header);

        login.setUserId(EncryptUtilTest.encryptUserId(userId));
        login.setPassword(EncryptUtilTest.encryptPassword("ibnk1357", securityNonce, "10001", modulus));
        login.setCaptcha("IsNewProcess");
        login.setLanguage("en");
        login.setSecurityNonce(securityNonce.trim());
        req.setLoginRequest(login);

        return req;
    }
}
