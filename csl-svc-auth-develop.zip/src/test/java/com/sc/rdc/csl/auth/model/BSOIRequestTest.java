package com.sc.rdc.csl.auth.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import org.junit.Before;
import org.junit.Test;

import com.sc.rdc.csl.auth.dto.request.bsoi.BSOIRequest;

public class BSOIRequestTest {
	private BSOIRequest request;

	@Before
	public void setUp() throws Exception {
		request = new BSOIRequest();
	}

	@Test
	public void testSuccessfullyDecode() {
		request.setRequestBody("cmFuZD03MA==");
		request.setQueryParams("cmFuZD03MA==");

		assertEquals("rand=70", request.getRequestBody());
		assertEquals("rand=70", request.getQueryParams());
	}

	@Test (expected=IllegalArgumentException.class)
	public void testUnSuccessfullyDecode() {
		request.setRequestBody("cmFuZD03MA==1");
		request.getRequestBody();
	}

	@Test
	public void testUnSuccessfullyDecodeForEmptyRequest() {
		request.setRequestBody("");
		assertEquals("", request.getRequestBody());
	}

	@Test
	public void testUnSuccessfullyDecodeForNullRequest() {
		assertNull(request.getRequestBody());
	}
}
