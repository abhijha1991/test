package com.sc.rdc.csl.auth.persistence;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.rdc.csl.auth.model.CSLRefreshToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import com.sc.rdc.csl.auth.persistence.entity.RefreshTokenEntity;
import com.sc.rdc.csl.auth.persistence.repo.AccessTokenRepository;
import com.sc.rdc.csl.auth.persistence.repo.RefreshTokenRepository;
import com.sc.rdc.csl.auth.service.TokenLifetimeProvider;
import org.apache.cxf.rs.security.oauth2.common.Client;
import org.apache.cxf.rs.security.oauth2.common.OAuthPermission;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.tokens.refresh.RefreshToken;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.when;


@RunWith(PowerMockRunner.class)
@PrepareForTest({CSLJsonUtils.class})
public class OAuthDataProviderTest {

    public static final String SUBJECT_ID_TO_ARCHIVE = "6514711183";
    public static final String REFRESH_TOKEN_TO_ARCHIVE = "62a5adc260fa686f16a85899d7c6c0";
    public static final String ACCESS_TOKEN_TO_ARCHIVE = "eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJkNWIyNDQ5NGZkOTgyYjI3YmI4MmNhMmM2N2IyNDE4IiwiY2xpZW50X2lkIjoiTU9CSUxFX0JBTktJTkciLCJpYXQiOjE1MTQ5NjU4NDYsImV4cCI6MTUxNTA1MjI0Niwic3ViIjoiNjBiN2M5YWQ2M2FmYzViYiIsInVzZXJuYW1lIjoiNjU4MjQzMDE3MiIsImlzcyI6IkNTTC1BVVRIIiwic2NvcGUiOlsicmVmcmVzaFRva2VuIl0sImdyYW50X3R5cGUiOiJyZWdpc3RlcmVkX2RldmljZSJ9.NuLBh3dXCJsUwJUGTe_2kzDBbEUk7cfF5iUNNp4fBvxUksMFa061LL5Ak_8TGUi6-JlNZyaIa-Q7yzWivwRNbpOTJAeYAR_JI_YNzcIxQdQRu_fcPPfSypdjkJP9Xj98r2HH6LnQpQbdvTg91QW8H0n51LlKaTKrK2NHzHlUyptHSKh1HlaiKnG61WyRLMkDB3UhraC6YlIe-KTr5yKJ7C4c579VZDwt5PCxJRd1nZafrt7ZwMua-JglloL09R6P4q0PcY7zKRAxaGumnb2cNGTF06oCNITIJ7LohTNqHAajmDYtOvgUysIIlrfC8j7Ch5dAv2t8eksFGnqvhLQlKw";

    OAuthDataProvider oAuthDataProvider = new OAuthDataProvider();
    AuthDataRepository authDataRepository = new AuthDataRepository();
    AccessTokenRepository accessTokenRepository = mock(AccessTokenRepository.class);
    RefreshTokenRepository refreshTokenRepository = mock(RefreshTokenRepository.class);
    TokenLifetimeProvider tokenLifetimeProvider = mock(TokenLifetimeProvider.class);

    @Before
    public void init() {
        authDataRepository.setAccessTokenRepo(accessTokenRepository);
        authDataRepository.setRefreshTokenRepo(refreshTokenRepository);
        oAuthDataProvider.setAccessTokenRepo(accessTokenRepository);
        oAuthDataProvider.setDataRepository(authDataRepository);
        oAuthDataProvider.setTokenLifetimeProvider(tokenLifetimeProvider);
    }

    @Test
    public void shouldArchiveRevokedTokensBySubjectId() {
        when(accessTokenRepository.archiveAccessTokensBySubjectId(eq(SUBJECT_ID_TO_ARCHIVE))).thenReturn(1);
        when(refreshTokenRepository.archiveRefreshTokensBySubjectId(eq(SUBJECT_ID_TO_ARCHIVE))).thenReturn(1);

        int [] count = oAuthDataProvider.revokeTokens(SUBJECT_ID_TO_ARCHIVE);
        assertEquals(1, count[1]);
        assertEquals(1, count[1]);
        verify(accessTokenRepository, times(1)).archiveAccessTokensBySubjectId(eq(SUBJECT_ID_TO_ARCHIVE));
        verify(refreshTokenRepository, times(1)).archiveRefreshTokensBySubjectId(eq(SUBJECT_ID_TO_ARCHIVE));
    }

    @Test
    public  void shouldArchiveExpiredTokens() {
        oAuthDataProvider.archiveExpiredTokens();
        verify(accessTokenRepository, times(1)).archiveExpiredTokens(any());
    }

    @Test
    public void shouldArchiveRevokedRefreshToken() {
        when(refreshTokenRepository.archiveRefreshTokenByTokenId(eq(REFRESH_TOKEN_TO_ARCHIVE))).thenReturn(1);
        RefreshToken serverRefreshToken = new RefreshToken();
        serverRefreshToken.setTokenKey(REFRESH_TOKEN_TO_ARCHIVE);
        oAuthDataProvider.doRevokeRefreshToken(serverRefreshToken);
        verify(refreshTokenRepository, times(1)).archiveRefreshTokenByTokenId(eq(REFRESH_TOKEN_TO_ARCHIVE));
    }

    @Test
    public void shouldArchiveRevokedAccessToken() {
        when(accessTokenRepository.archiveAccessTokenByTokenId(eq(ACCESS_TOKEN_TO_ARCHIVE))).thenReturn(1);
        ServerAccessToken serverAccessToken = new RefreshToken();
        serverAccessToken.setTokenKey(ACCESS_TOKEN_TO_ARCHIVE);
        oAuthDataProvider.doRevokeAccessToken(serverAccessToken);
        verify(accessTokenRepository, times(1)).archiveAccessTokenByTokenId(eq(ACCESS_TOKEN_TO_ARCHIVE));
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_token_not_found_RefreshAccessToken() {
        Client client = mock(Client.class);
        String refreshTokenKey = "23987456289374567892364589723";
        List<String> restrictedScopes = Arrays.asList("refreshToken");
        boolean recycleRefreshTokens = false;
        oAuthDataProvider.refreshAccessToken(client, refreshTokenKey, restrictedScopes, recycleRefreshTokens);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_expired_token_RefreshAccessToken() {
        Client client = mock(Client.class);
        String refreshTokenKey = "23987456289374567892364589723";
        List<String> restrictedScopes = Arrays.asList("refreshToken");
        boolean recycleRefreshTokens = false;
        CSLRefreshToken currentRefreshToken = mock(CSLRefreshToken.class);
        when(currentRefreshToken.getIssuedAt()).thenReturn((System.currentTimeMillis() - 5000) / 1000);
        when(currentRefreshToken.getExpiresIn()).thenReturn(Long.valueOf(1));

        RefreshTokenEntity refreshTokenEntity = mock(RefreshTokenEntity.class);
        when(refreshTokenEntity.getCSLRefreshToken()).thenReturn(currentRefreshToken);
        when(refreshTokenRepository.findOne(eq("23987456289374567892364589723"))).thenReturn(refreshTokenEntity);

        oAuthDataProvider.refreshAccessToken(client, refreshTokenKey, restrictedScopes, recycleRefreshTokens);
    }

    @Test
    public void should_pass_RefreshAccessToken() {
        OAuthClient client = new OAuthClient();//mock(Client.class);
        client.setSubject(mock(CSLUserSubject.class));
        String refreshTokenKey = "23987456289374567892364589723";
        List<String> restrictedScopes = Arrays.asList("refreshToken");
        boolean recycleRefreshTokens = false;

        CSLRefreshToken currentRefreshToken = mock(CSLRefreshToken.class);
        when(currentRefreshToken.getIssuedAt()).thenReturn(System.currentTimeMillis() / 1000);
        when(currentRefreshToken.getExpiresIn()).thenReturn(Long.valueOf(120));
        when(currentRefreshToken.getSubject()).thenReturn(mock(CSLUserSubject.class));
        when(currentRefreshToken.getClient()).thenReturn(client);

        RefreshTokenEntity refreshTokenEntity = mock(RefreshTokenEntity.class);
        when(refreshTokenEntity.getCSLRefreshToken()).thenReturn(currentRefreshToken);

        OAuthPermission scope = new OAuthPermission();
        scope.setPermission("refreshToken");
        when(currentRefreshToken.getScopes()).thenReturn(Arrays.asList(scope));


        oAuthDataProvider.setPermissionMap(new HashMap<String, OAuthPermission>() {{
            put("refreshToken", scope);
        }});

        PowerMockito.mockStatic(CSLJsonUtils.class);
        when(CSLJsonUtils.toPrettyJson(any())).thenReturn("{}");

        when(refreshTokenRepository.findOne(eq("23987456289374567892364589723"))).thenReturn(refreshTokenEntity);
        when(tokenLifetimeProvider.accessTokenLifetime(any(), any())).thenReturn(120L);
        when(tokenLifetimeProvider.refreshTokenLifetime(any())).thenReturn(300L);
        ServerAccessToken serverAccessToken = oAuthDataProvider.refreshAccessToken(client, refreshTokenKey, restrictedScopes, recycleRefreshTokens);

        assertNotNull(serverAccessToken);
        assertEquals("Bearer", serverAccessToken.getTokenType());
        assertEquals("CSL-AUTH", serverAccessToken.getIssuer());
    }
}
