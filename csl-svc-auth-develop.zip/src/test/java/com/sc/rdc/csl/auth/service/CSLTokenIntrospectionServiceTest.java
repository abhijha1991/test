package com.sc.rdc.csl.auth.service;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.rdc.csl.auth.model.CSLAccessToken;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import com.sc.rdc.csl.auth.persistence.OAuthDataProvider;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.jaxrs.ext.MessageContext;
import org.apache.cxf.rs.security.jose.jwt.JwtClaims;
import org.apache.cxf.rs.security.jose.jwt.JwtToken;
import org.apache.cxf.rs.security.oauth2.common.ServerAccessToken;
import org.apache.cxf.rs.security.oauth2.common.TokenIntrospection;
import org.apache.cxf.rs.security.oauth2.provider.OAuthJoseJwtProducer;
import org.junit.Before;
import org.junit.Test;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.SecurityContext;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;

import static com.sc.csl.retail.core.util.CSLConstants.*;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@Slf4j
public class CSLTokenIntrospectionServiceTest {

    CSLTokenIntrospectionService tokenIntrospectionService = new CSLTokenIntrospectionService();
    OAuthDataProvider oAuthDataProvider;
    CSLAccessToken at;
    OAuthJoseJwtProducer jwtAccessTokenProducer;

    @Before
    public void init() {
        MessageContext mc = mock(MessageContext.class);
        tokenIntrospectionService.setBlockUnsecureRequests(false);
        SecurityContext sc = mock(SecurityContext.class);
        when(mc.getSecurityContext()).thenReturn(sc);
        jwtAccessTokenProducer = mock(OAuthJoseJwtProducer.class);
        oAuthDataProvider = mock(OAuthDataProvider.class);
        tokenIntrospectionService.setDataProvider(oAuthDataProvider);
        tokenIntrospectionService.setMessageContext(mc);
        tokenIntrospectionService.setJwtAccessTokenProducer(jwtAccessTokenProducer);
    }

    @Test
    public void testGetTokenIntrospectionActive() {
        MultivaluedMap<String, String> multivaluedMap = new MultivaluedHashMap<String, String>() ;
        multivaluedMap.put("token", Arrays.asList("234523452345252345234"));
        at = mock(CSLAccessToken.class);
        when(at.getIssuedAt()).thenReturn(new Date().getTime());
        when(at.getExpiresIn()).thenReturn(Long.valueOf(60 * 2));
        OAuthClient client = mock(OAuthClient.class);
        when(at.getClient()).thenReturn(client);
        when(client.getClientId()).thenReturn("12341234");
        JwtClaims jwtClaims = mock(JwtClaims.class);
        when(oAuthDataProvider.createJwtAccessToken(any(ServerAccessToken.class))).thenReturn(jwtClaims);
        when(oAuthDataProvider.getAccessToken(any(String.class))).thenReturn(at);
        TokenIntrospection ti = tokenIntrospectionService.getTokenIntrospection(multivaluedMap);
        assertTrue(ti.isActive());
    }

    @Test
    public void testGetTokenIntrospectionInactive() {
        MultivaluedMap<String, String> multivaluedMap = new MultivaluedHashMap<String, String>() ;
        when(oAuthDataProvider.getAccessToken(any(String.class))).thenReturn(null);
        TokenIntrospection ti = tokenIntrospectionService.getTokenIntrospection(multivaluedMap);
        assertFalse(ti.isActive());
    }

    @Test
    public void testInternalAccessToken() {
        at = mock(CSLAccessToken.class);
        when(at.getJti()).thenReturn("123456");
        JwtClaims jwtClaims = mock(JwtClaims.class);
        when(oAuthDataProvider.createJwtAccessToken(any(ServerAccessToken.class))).thenReturn(jwtClaims);
        tokenIntrospectionService.internalAccessToken(at);

        verify(at, times(1)).setIssuedAt(any(long.class));
        verify(at, times(1)).setExpiresIn(eq(Long.valueOf(60 * 2)));
        verify(jwtClaims, times(1)).setClaim(eq("type"), eq("CSL-IAT"));
        verify(jwtClaims, times(1)).setTokenId(eq("123456"));
        verify(jwtAccessTokenProducer, times(1)).processJwt(any(JwtToken.class));
    }

    @Test
    public void testAdSubjectClaims() {
        JwtClaims jwtClaims = mock(JwtClaims.class);
        CSLUserSubject subject = mock(CSLUserSubject.class);

        HashMap<String, String> propertiesMap = new HashMap<String, String>() {{
            put("type", "CSL-IAT");
        }};
        CSLRequestContext context = new CSLRequestContext(
            "01C12345567",
            "01C12345567",
            "HK",
            "IBKBMW",
            "EN",
            "U"
        );
        when(subject.getProperties()).thenReturn(propertiesMap);
        when(subject.getAccessLevel()).thenReturn( AccessLevel.TWO_FACTOR);
        when(subject.getCslRequestContext()).thenReturn(context);

        tokenIntrospectionService.addSubjectClaims(jwtClaims, subject);

        verify(jwtClaims, times(1)).setClaim(eq(REL_ID_CLAIM), eq("01C12345567"));
        verify(jwtClaims, times(1)).setClaim(eq(UAAS2_ID_CLAIM), eq("01C12345567"));

        verify(jwtClaims, times(1)).setClaim(eq(COUNTRY_CLAIM), eq("HK"));
        verify(jwtClaims, times(1)).setClaim(eq(CHANNEL_CLAIM), eq("IBKBMW"));
        verify(jwtClaims, times(1)).setClaim(eq(LANGUAGE_CLAIM), eq("EN"));
        verify(jwtClaims, times(1)).setClaim(eq(SEGMENT_CODE_CLAIM), eq("U"));
        verify(jwtClaims, times(1)).setClaim(eq("type"), eq("CSL-IAT"));
        verify(jwtClaims, times(1)).setClaim(eq(AUTH_LEVEL_CLAIM), eq(AccessLevel.TWO_FACTOR.authLevel()));
        verify(jwtClaims, times(1)).setClaim(eq(AUTH_LEVEL_NAME_CLAIM), eq(AccessLevel.TWO_FACTOR.name()));
    }

    @Test(expected = TechnicalException.class)
    public void should_throw_TechnicalException_addSubjectClaims() {
        JwtClaims jwtClaims = mock(JwtClaims.class);
        CSLUserSubject subject = mock(CSLUserSubject.class);
        when(subject.getProperties()).thenReturn(Collections.emptyMap());
        when(subject.getAccessLevel()).thenReturn(null);
        tokenIntrospectionService.addSubjectClaims(jwtClaims, subject);
    }

    @Test
    public void testIntrospectNoActiveToken() {
        MultivaluedMap<String, String> multivaluedMap = new MultivaluedHashMap<String, String>() ;
        multivaluedMap.put("token", Arrays.asList("234523452345252345234"));
        OAuthClient client = mock(OAuthClient.class);
        when(client.getClientId()).thenReturn("12341234");
        JwtClaims jwtClaims = mock(JwtClaims.class);
        when(oAuthDataProvider.createJwtAccessToken(any(ServerAccessToken.class))).thenReturn(jwtClaims);
        when(oAuthDataProvider.getAccessToken(any(String.class))).thenReturn(null);
        TokenIntrospection ti = tokenIntrospectionService.getTokenIntrospection(multivaluedMap);
        assertFalse(ti.isActive());
    }
}
