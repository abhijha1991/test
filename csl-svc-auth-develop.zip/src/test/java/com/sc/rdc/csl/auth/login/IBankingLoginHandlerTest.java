package com.sc.rdc.csl.auth.login;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.response.UserAuthenticationResponse;
import com.sc.rdc.csl.auth.gateway.NFSGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class IBankingLoginHandlerTest {

    IBankingLoginHandler iBankingLoginHandler;

    @Mock
    NFSGateway nfsGateway;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        iBankingLoginHandler = new IBankingLoginHandler();
        iBankingLoginHandler.setNfsGateway(nfsGateway);

    }

    @Test (expected = OAuthServiceException.class)
    public void should_fail_during_login() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = prepareParams();
        UserAuthenticationResponse response = new UserAuthenticationResponse();
        response.setStatus("0");
        when(nfsGateway.authenticateUser(any())).thenReturn(response);
        iBankingLoginHandler.login(client, params);
    }

    @Test
    public void should_successfully_login() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = prepareParams();
        UserAuthenticationResponse response = new UserAuthenticationResponse();
        response.setStatus("1");
        response.setCustomerIdType("01");
        response.setCustomerId("123456789");
        response.setCustomerEBID("987654321");

        when(nfsGateway.authenticateUser(any())).thenReturn(response);
        CSLUserSubject subject = iBankingLoginHandler.login(client, params);

        assertEquals(AccessLevel.ONE_FACTOR, subject.getAccessLevel());
        assertEquals("USER", subject.getLogin());
        assertEquals("USER", subject.getId());
    }


    private MultivaluedMap<String, String> prepareParams() {
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(OAuthConstants.RESOURCE_OWNER_NAME, Arrays.asList("USER"));

        params.put(OAuthConstants.RESOURCE_OWNER_PASSWORD,Arrays.asList("USER"));
        params.put(AuthConstants.NONCE_PARAM, Arrays.asList("23523452345234523452345"));
        params.put(AuthConstants.COUNTRY_PARAM, Arrays.asList("HK"));
        params.put(AuthConstants.CHANNEL_PARAM, Arrays.asList("IBKBMW"));
        params.put(AuthConstants.LANGUAGE_PARAM,Arrays.asList("EN"));

        return params;

    }
}
