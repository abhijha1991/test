package com.sc.rdc.csl.auth.login;

import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class LoginHelperTest {

    LoginHelper loginHelper;

    @Mock
    BSOILoginHandler bsoiLoginHandler;

    @Mock
    IBankingLoginHandler iBankingLoginHandler;

    @Mock
    CSLUserSubject subject;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        loginHelper = new LoginHelper();
        loginHelper.setBsoiLoginHandler(bsoiLoginHandler);
        loginHelper.setIBankingLoginHandler(iBankingLoginHandler);
    }

    @Test
    public void should_return_bsoi_login_with_password_grant_form_bsoi() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(OAuthConstants.CLIENT_ID, Arrays.asList("BSOI_HK"));
        when(bsoiLoginHandler.login(any(), any())).thenReturn(subject);
        loginHelper.login(client, params, "password");
        verify(subject, times(1)).setGrantType(eq("password"));
    }

    @Test
    public void should_return_bsoi_login_with_password_grant_for_nfs() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(OAuthConstants.CLIENT_ID, Arrays.asList("NFS_HK"));
        when(bsoiLoginHandler.login(any(), any())).thenReturn(subject);
        loginHelper.login(client, params, "password");
        verify(subject, times(1)).setGrantType(eq("password"));
    }

    @Test
    public void should_return_bsoi_login_with_password_grant_for_mobile_banking() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(OAuthConstants.CLIENT_ID, Arrays.asList("MOBILE_BANKING"));
        when(bsoiLoginHandler.login(any(), any())).thenReturn(subject);
        loginHelper.login(client, params, "password");
        verify(subject, times(1)).setGrantType(eq("password"));
    }

    @Test
    public void should_return_ibank_login_with_password_grant() {
        OAuthClient client = new OAuthClient();
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(OAuthConstants.CLIENT_ID, Arrays.asList("IVR"));
        when(iBankingLoginHandler.login(any(), any())).thenReturn(subject);
        loginHelper.login(client, params, "password");
        verify(subject, times(1)).setGrantType(eq("password"));
    }
}
