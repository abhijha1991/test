package com.sc.rdc.csl.auth.persistence;

public class CSLLoginHandlerTest {

}
