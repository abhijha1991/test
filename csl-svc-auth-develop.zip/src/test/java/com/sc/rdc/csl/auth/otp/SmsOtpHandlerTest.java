package com.sc.rdc.csl.auth.otp;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.ValidateOtp;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class SmsOtpHandlerTest {

    SmsOtpHandler smsOtpHandler;

    @Mock
    SecurityGateway securityGateway;

    @Mock
    CSLAsyncRequestContext cslAsyncRequestContext;

    OAuthClient client;

    @Before
    public void init() {
        client = new OAuthClient();
        smsOtpHandler = new SmsOtpHandler();
        MockitoAnnotations.initMocks(this);
        smsOtpHandler.setSecurityGateway(securityGateway);
        smsOtpHandler.setCslAsyncRequestContext(cslAsyncRequestContext);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_throw_exception_failed_validation_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("101");
        when(securityGateway.validateOtp(any())).thenReturn(validateOtpResponse);
        smsOtpHandler.processOtp(client, params);
    }

    @Test
    public void should_pass_validation_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();
        params.put(AuthConstants.REL_ID_PARAM, Arrays.asList("01S123456"));
        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("100");
        when(securityGateway.validateOtp(any())).thenReturn(validateOtpResponse);
        CSLUserSubject subject = smsOtpHandler.processOtp(client, params);
        assertEquals("01S123456", subject.getId());
        assertEquals(AccessLevel.TWO_FACTOR, subject.getAccessLevel());
    }

    private MultivaluedMap<String, String> prepareParams() {
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.COUNTRY_PARAM, Arrays.asList("HK"));
        params.put(AuthConstants.CHANNEL_PARAM, Arrays.asList("IBKBMW"));
        return params;
    }
}
