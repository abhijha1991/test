package com.sc.rdc.csl.auth.gateway;

import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.dto.EncryptedData;
import com.sc.rdc.csl.auth.dto.SmsOtp;
import com.sc.rdc.csl.auth.dto.ValidateOtp;
import io.katharsis.client.KatharsisClient;
import io.katharsis.repository.ResourceRepositoryV2;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

public class SecurityGatewayTest {

    @InjectMocks
    SecurityGateway securityGateway;

    @Mock
    private CSLAsyncRequestContext cslAsyncRequestContext = new CSLAsyncRequestContext();

    @Mock
    private KatharsisClient katharsisClient;

    @Mock
    private ResourceRepositoryV2<EncryptedData, String> decryptRepo;

    @Mock
    private ResourceRepositoryV2<ValidateOtp, String> validateOtpRepo;

    @Mock
    private ResourceRepositoryV2<SmsOtp, String> smsOtpRepo;

    @Before
    public void setUp() {
        securityGateway = new SecurityGateway();
        securityGateway.setBaseUrl("http://10.23.210.49:9222");
        securityGateway.setServiceUrl("/security/retail/api/v3");
        securityGateway.setScbInternal(true);
        cslAsyncRequestContext.setCountry("HK");
        cslAsyncRequestContext.setRelId("01C303360");
        cslAsyncRequestContext.setChannel("IBNK");
        cslAsyncRequestContext.setRequestId("Id_2312002349234");

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void decryptTest() {
        EncryptedData encryptedData = new EncryptedData();
        encryptedData.setEncData("CFUJ7A63tBc0KrGBVb9JK8mJFxXka6NCOFFyqqSapVzMd0bkltKu");
        encryptedData.setChannel("IBNK");
        encryptedData.setCountry("HK");

        EncryptedData encryptedDataResponse = new EncryptedData();
        encryptedDataResponse.setDecData("9344387026011277");
        when(katharsisClient.getRepositoryForType(EncryptedData.class)).thenReturn(null);
        when(decryptRepo.create(encryptedData)).thenReturn(encryptedDataResponse);
        // TODO Need to mock the katharsis client used with in the decrypt() method.
       // securityGateway.decrypt(encryptedData);
        assertThat(encryptedDataResponse.getDecData()).isEqualTo("9344387026011277");
    }


    @Test
    public void sendOtpTest() {
        SmsOtp smsOtp = new SmsOtp();
        smsOtp.setMobile("9291200000");
        smsOtp.setMsgTemplate("This is a test check {otp}");
        smsOtp.setRequestId(cslAsyncRequestContext.getRequestId());

        SmsOtp smsOtpResponse = new SmsOtp();
        smsOtpResponse.setBase64Challenge("MTUwNDYwOTAxOTc3M18tX0lCS18tX0hLXy1fMDFDMzAzMzYwXy1faWlCbHVRQUtfLV9uUGhndGNNL1BQNjFSdGNrd1prU2hvSHcwTUhjck9DUXNTZ2p6VVZkMDBzPQ==");
        smsOtpResponse.setModulus("b6b44e815345da9297e595cc88bd6ba7ac5fe4d08bb7aa795951b71b093ad0e0bde4b638570ca038ba0d73222c62286c6a926793f88ae411280c3b92ac5c79d2c142d4a600a376420e101a31936697c2adb56ee0e96be21320eacfefe7f97fd5ad0e59bbf1ff75efa2ae50b6fdb3acd46e89fd993efe4fbf775a071c19d9d694c6f97a47fdd64df0b87338aa839db9b4d5cc907de7c409c5fd7db5921123081b766f795afcb70a7fce5b953a9c4b557b5cebed277cec522fe752c09706d571ebb6620ebdece8c6cd66fc146f562dc5b674cba1361afc6bbe2f050558071b691a0e67e6e57bc9abb8ee64971c23ef14302ab27643fcfad50e123af630c9bc77d9");
        smsOtpResponse.setKeyIndex("3");
        smsOtpResponse.setStatusCode("100");
        smsOtpResponse.setOtpSn("89");
        smsOtpResponse.setOtpPrefix("uXvd");
        smsOtpResponse.setExponent("10001");
        when(katharsisClient.getRepositoryForType(SmsOtp.class)).thenReturn(null);
        when(smsOtpRepo.create(smsOtp)).thenReturn(smsOtpResponse);
        // TODO Need to mock the katharsis client used with in the sendOtp() method.
        // securityGateway.sendOtp(smsOtp);
        assertThat(smsOtpResponse.getBase64Challenge()).isEqualTo("MTUwNDYwOTAxOTc3M18tX0lCS18tX0hLXy1fMDFDMzAzMzYwXy1faWlCbHVRQUtfLV9uUGhndGNNL1BQNjFSdGNrd1prU2hvSHcwTUhjck9DUXNTZ2p6VVZkMDBzPQ==");
        assertThat(smsOtpResponse.getModulus()).isEqualTo("b6b44e815345da9297e595cc88bd6ba7ac5fe4d08bb7aa795951b71b093ad0e0bde4b638570ca038ba0d73222c62286c6a926793f88ae411280c3b92ac5c79d2c142d4a600a376420e101a31936697c2adb56ee0e96be21320eacfefe7f97fd5ad0e59bbf1ff75efa2ae50b6fdb3acd46e89fd993efe4fbf775a071c19d9d694c6f97a47fdd64df0b87338aa839db9b4d5cc907de7c409c5fd7db5921123081b766f795afcb70a7fce5b953a9c4b557b5cebed277cec522fe752c09706d571ebb6620ebdece8c6cd66fc146f562dc5b674cba1361afc6bbe2f050558071b691a0e67e6e57bc9abb8ee64971c23ef14302ab27643fcfad50e123af630c9bc77d9");
        assertThat(smsOtpResponse.getKeyIndex()).isEqualTo("3");
        assertThat(smsOtpResponse.getStatusCode()).isEqualTo("100");
        assertThat(smsOtpResponse.getOtpPrefix()).isEqualTo("uXvd");
        assertThat(smsOtpResponse.getOtpSn()).isEqualTo("89");
    }


    @Test
    public void validateOtpTest() {
        ValidateOtp validateOtp = new ValidateOtp();
        validateOtp.setEncOtp("CFUJ7A63tBc0KrGBVb9JK8mJFxXka6NCOFFyqqSapVzMd0bkltKu");
        validateOtp.setOtpSn("86");
        validateOtp.setPurpose("1");
        validateOtp.setKeyIndex("3");
        validateOtp.setCountry("HK");

        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("100");
        validateOtpResponse.setErrorMessage("");
        when(katharsisClient.getRepositoryForType(ValidateOtp.class)).thenReturn(null);
        when(validateOtpRepo.create(validateOtp)).thenReturn(validateOtpResponse);
        // TODO Need to mock the katharsis client used with in the validateOtp() method.
        // securityGateway.validateOtp(validateOtp);
        assertThat(validateOtpResponse.getStatusCode()).isEqualTo("100");

    }

    @Test
    public void shouldMaskMobileNumber() {
        assertEquals("xxxxxxx192", securityGateway.maskMobileNumber("9894683192"));
        assertEquals("xxxxxxxxxxx112", securityGateway.maskMobileNumber("+91-9894683112"));
        assertEquals("xxxxxxxxxx292", securityGateway.maskMobileNumber("+919894683292"));
        assertEquals("xxxxxxxx194", securityGateway.maskMobileNumber("09894683194"));
        assertEquals("xxxxxxxxxx194", securityGateway.maskMobileNumber("91 9894683194"));
    }
}
