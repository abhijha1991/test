package com.sc.rdc.csl.auth.otp;

import com.sc.csl.retail.core.auth.AccessLevel;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.rdc.csl.auth.constants.AuthConstants;
import com.sc.rdc.csl.auth.dto.*;
import com.sc.rdc.csl.auth.gateway.CreditCardGateway;
import com.sc.rdc.csl.auth.gateway.IBankDataAccessGateway;
import com.sc.rdc.csl.auth.gateway.SecurityGateway;
import com.sc.rdc.csl.auth.model.CSLUserSubject;
import com.sc.rdc.csl.auth.model.OAuthClient;
import org.apache.cxf.rs.security.oauth2.provider.OAuthServiceException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

public class CreditCardOtpHandlerTest {

    CreditCardOtpHandler creditCardOtpHandler;

    @Mock
    CreditCardGateway creditCardGateway;

    @Mock
    SecurityGateway securityGateway;

    @Mock
    CSLAsyncRequestContext cslAsyncRequestContext;

    @Mock
    IBankDataAccessGateway iBankDataAccessGateway;

    OAuthClient client;


    @Before
    public void init() {
        client = new OAuthClient();

        MockitoAnnotations.initMocks(this);
        creditCardOtpHandler = new CreditCardOtpHandler();
        creditCardOtpHandler.setCreditCardGateway(creditCardGateway);
        creditCardOtpHandler.setIBankDataAccessGateway(iBankDataAccessGateway);
        creditCardOtpHandler.setSecurityGateway(securityGateway);
        creditCardOtpHandler.setCslAsyncRequestContext(cslAsyncRequestContext);
    }

    @Test(expected = OAuthServiceException.class)
    public void should_fail_decrypt_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();

        EncryptedData response = new EncryptedData();
        response.setStatusCode("101");

        when(securityGateway.decrypt(any())).thenReturn(response);
        creditCardOtpHandler.processOtp(client, params);
    }


    @Test(expected = OAuthServiceException.class)
    public void should_fail_sms_validation_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();

        EncryptedData response = new EncryptedData();
        response.setStatusCode("100");
        response.setDecData("1234567890");

        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("101");

        when(securityGateway.decrypt(any())).thenReturn(response);
        when(securityGateway.validateOtp(any())).thenReturn(validateOtpResponse);
        creditCardOtpHandler.processOtp(client, params);
    }


    @Test
    public void should_pass_processOtp() {
        MultivaluedMap<String, String> params = prepareParams();

        EncryptedData response = new EncryptedData();
        response.setStatusCode("100");
        response.setDecData("1234567890");

        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("100");

        when(securityGateway.decrypt(any())).thenReturn(response);
        when(securityGateway.validateOtp(any())).thenReturn(validateOtpResponse);


        CreditCard customerNumber = new CreditCard();
        customerNumber.setCustomerId("01S0294");
        when(creditCardGateway.getCustomerId(any())).thenReturn(customerNumber);

        Profile profile = new Profile();
        profile.setCustomerEBID("12345678");

        CustomerProfile customerProfile = new CustomerProfile();
        customerProfile.setProfile(profile);

        when(iBankDataAccessGateway.getCustomerProfile(eq("01S0294"), eq("HK"))).thenReturn(customerProfile);

        CSLUserSubject subject = creditCardOtpHandler.processOtp(client, params);

        assertEquals(AccessLevel.TWO_FACTOR, subject.getAccessLevel());
        assertEquals("01S0294", subject.getId());
    }


    private MultivaluedMap<String, String> prepareParams() {
        MultivaluedMap<String, String> params = new MultivaluedHashMap<>();
        params.put(AuthConstants.ENC_CARD_NUMBER_PARAM, Arrays.asList("2498756298345678923645879236457892364589723645897623879456892734568972346"));
        params.put(AuthConstants.CARD_KEY_INDEX_PARAM, Arrays.asList("10"));
        params.put(AuthConstants.COUNTRY_PARAM, Arrays.asList("HK"));
        params.put(AuthConstants.CHANNEL_PARAM, Arrays.asList("IBKBMW"));

        return params;

    }
}
