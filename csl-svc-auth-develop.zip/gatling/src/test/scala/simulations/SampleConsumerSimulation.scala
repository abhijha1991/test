package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import io.gatling.http.request.builder.HttpRequestBuilder

import scala.concurrent.duration._

class SampleConsumerSimulation extends Simulation {

  private val consumerHttpProtocol = http
//    .baseURL("http://localhost:8086")
    .baseURL("http://localhost:8080/csl-svc-sample-consumer-0.0.0-SNAPSHOT")
    .acceptHeader("*/*")

  private val tokenCall = http("token")
      .post("http://localhost:8080/csl-svc-auth-0.0.0-SNAPSHOT/retail/api/v3/oauth2/token")
      .formParam("grant_type", "client_credentials")
      .formParam("client_id", "LOAD_TEST")
      .formParam("client_secret", "LOAD_TEST_123")
      .formParam("channel", "IBNK")
      .formParam("language", "EN")
      .formParam("country", "SG")
      .formParam("segment_code", "IT")
      .formParam("rel_id", "01S7345168Z")
      .formParam("uaas2_id", "user180")
      .formParam("operator_type", "RM")
      .formParam("operator_id", "RM345168Z")
      .check(
        status.is(200),
        jsonPath("$.access_token").saveAs("access_token"),
        jsonPath("$.refresh_token").saveAs("refresh_token")
      )

//  private val cslUser = "{\"uaas2id\": \"9113237698\",\"relId\": \"0199385224456449\",\"country\": \"IN\",\"language\": \"en\",\"segCd\": \"EXBN\"}"
//  private val cslHeader = "{\"user\": {\"uaas2id\": \"9113237694\",\"relId\": \"0199385224456449\",\"country\": \"IN\",\"language\": \"en\",\"segCd\": \"EXBN\"},\"client\": {\"clientRequestId\": \"Id-b8c93759e80e0200b4060000635e8faf-4a3a622a339a\",\"trueClientIP\": \"183.90.36.103\",\"sessionId\": \"82875bc8-335c-494f-8a7a-4a3a622a339a\",\"userAgent\": \"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1\",\"channel\": \"MBNK\",\"deviceTy\": \"IBKIPH\"}}"

  private val greetCall: HttpRequestBuilder = http("greet")
    .get("/retail/api/v3/sample-consumer/remote/greet")
//    .header("csl_user", cslUser)
//    .header("csl_header", cslHeader)
      .header("Authorization", "Bearer ${access_token}")
    .check(
      status.is(200)
    )

  private val scn = scenario("Greet")
    .exec(tokenCall)
    .exitHereIfFailed
    .pause(1 seconds)
    .exec(greetCall)
    .exitHereIfFailed
    .pause(1 seconds)
    .exec(greetCall)

  setUp(
    scn.inject(
//        atOnceUsers(2)
//      rampUsers(1000) over(1 minute)
      constantUsersPerSec(25) during (1 minute)
  )).protocols(consumerHttpProtocol)
}
