package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration._

class CreditCardSimulation3 extends Simulation {

  val httpProtocol = http
    .proxy(Proxy("10.65.1.33", 8080))
    .baseURL("https://10.23.210.51:9253/csl-svc-credit-cards")
    //    .baseURL("http://localhost:2002")
    .acceptHeader("*/*")

  private val cslUser = "{\"uaas2id\" : \"8521921571\",\"relId\" : \"012839102301\",\"country\" : \"IN\",\"language\":\"en\",\"segCd\" : \"EXBN\"}"
  private val cslHeader = "{\"user\": {\"uaas2id\":\"8521921571\",\"relId\" : \"012839102301\",\"country\" : \"IN\",\"language\" : \"en\",\"segCd\" : \"EXBN\"},\"client\":{\"clientRequestId\": \"Id-b8c93759e80e0200b4060000635e8faf-4a3a622a339a\",\"trueClientIP\": \"183.90.36.103\",\"sessionId\": \"82875bc8-335c-494f-8a7a-4a3a622a339a\",\"userAgent\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1\",\"channel\":\"IBNK\",\"deviceTy\" :\"IBKIPH\"}}"
  private val accessToken = "eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiI5MjJkMmRiNjk5ODJjNzA5MDJhYjJiYjIzYjRkMmFhIiwiY2xpZW50X2lkIjoiTE9BRF9URVNUIiwiaWF0IjoxNTExNjA2NDAxLCJleHAiOjE1MTE2MDgyMDEsInN1YiI6IjAxMjgzOTEwMjMwMSIsInVzZXJuYW1lIjoiMDEyODM5MTAyMzAxIiwiaXNzIjoiQ1NMLUFVVEgiLCJzY29wZSI6WyJyZWZyZXNoVG9rZW4iXSwiYXVkIjoiQ1NMLUFVVEgiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIn0.ykewuTLziOxK-CcUxoeluSye1QcNiJNxpLKe_VK1WKK-Pm06eEaQCxEOy_qkOvfGtR4UQwT4tQBqXBCsjN40DPSnwQhOtI_quMUYsGskt0ssNiBM_CpMoPJSRjNq4FQJOjzF9kdKZ7LZu3TWJWVi1EkMaJMEHVG_H39pXCzBXZWhNdyTAb_DWKbD6gPKU4x32jhp0IRL8Reo1ZBLEHubk-I0o812-sEcqv0cCVKvNKTmM1KO-zfmkdx1CrzK8q0LaN6Ayd-Oz8i7_b3d9_vca2j_EArCbTL2Ob8SYqLWuKaExaY1QTdQ8LRv-3UtMMseZbiAWI8S4_4W-M1ndaA4ww"

  val scn = scenario("Credit-Card-Info")
    .exec(
      http("manage/info")
        .get("/manage/info")
//        .header("csl_user", cslUser)
//        .header("csl_header", cslHeader)
//        .header("Authorization", "Bearer " + accessToken)
        .check(
          status.is(200)
        )
    )

  setUp(
    scn.inject(
//      atOnceUsers(1)
      rampUsers(200) over (3 minutes)
//        constantUsersPerSec(1) during(5 minute) randomized
    )).protocols(httpProtocol)
}
