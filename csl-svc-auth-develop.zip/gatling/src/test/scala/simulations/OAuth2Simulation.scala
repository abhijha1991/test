package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration._

class OAuth2Simulation extends Simulation {

	val httpProtocol = http
		.proxy(Proxy("10.65.1.33", 8080))
		.baseURL("https://uat.csl.global.standardchartered.com:8543")
		.acceptHeader("*/*")

	val scn = scenario("OAuth2")
		.exec(http("token")
			.post("/retail/api/v3/oauth2/token")
			.formParam("grant_type", "client_credentials")
			.formParam("client_id", "LOAD_TEST")
			.formParam("client_secret", "LOAD_TEST_123")
			.formParam("channel", "IBNK")
			.formParam("language", "EN")
			.formParam("country", "SG")
			.formParam("segment_code", "IT")
			.formParam("rel_id", "01S7345168Z")
			.formParam("uaas2_id", "user180")
			.formParam("operator_type", "RM")
			.formParam("operator_id", "RM345168Z")
			.check(
				status.is(200),
				jsonPath("$.access_token").saveAs("access_token"),
				jsonPath("$.refresh_token").saveAs("refresh_token")
			)
		)

		.pause(1 seconds)
		.exec(http("introspect")
			.post("/retail/api/v3/oauth2/introspect")
			.formParam("token", "${access_token}")
			.check(
				status.is(200)
			)
		)

		.pause(1 seconds)
		.exec(http("introspect")
			.post("/retail/api/v3/oauth2/introspect")
			.formParam("token", "${access_token}")
			.check(
				status.is(200)
			)
		)

		.pause(1 seconds)
		.exec(http("introspect")
			.post("/retail/api/v3/oauth2/introspect")
			.formParam("token", "${access_token}")
			.check(
				status.is(200)
			)
		)

		.pause(2 seconds)
		.exec(http("refresh")
			.post("/retail/api/v3/oauth2/token")
			.formParam("client_id", "IBANKING")
			.formParam("client_secret", "IBANKING")
			.formParam("grant_type", "refresh_token")
			.formParam("refresh_token", "${refresh_token}")
			.check(
				status.is(200),
				jsonPath("$.access_token").saveAs("new_access_token"),
				jsonPath("$.refresh_token").saveAs("new_refresh_token")
			)
		)

		.pause(2 seconds)
		.exec(http("revoke_token")
			.post("/retail/api/v3/oauth2/revoke")
			.formParam("client_id", "IBANKING")
			.formParam("client_secret", "IBANKING")
			.formParam("token_type_hint", "refresh_token")
			.formParam("token", "${new_refresh_token}")
			.check(
				status.is(200)
			)
		)

	setUp(
		scn.inject(
//			atOnceUsers(1)
			rampUsers(20) over(1 minute)
//			constantUsersPerSec(7) during(5 minute) randomized
	)).protocols(httpProtocol)
}
