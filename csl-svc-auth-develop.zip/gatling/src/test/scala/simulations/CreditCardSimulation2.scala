package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class CreditCardSimulation2 extends Simulation {

  val httpProtocol = http
    .proxy(Proxy("10.65.1.33", 8080))
    .baseURL("https://uat.csl.global.standardchartered.com:8543")
    //    .baseURL("http://localhost:2002")
    .acceptHeader("*/*")

  private val cslUser = "{\"uaas2id\" : \"8521921571\",\"relId\" : \"012839102301\",\"country\" : \"IN\",\"language\":\"en\",\"segCd\" : \"EXBN\"}"
  private val cslHeader = "{\"user\": {\"uaas2id\":\"8521921571\",\"relId\" : \"012839102301\",\"country\" : \"IN\",\"language\" : \"en\",\"segCd\" : \"EXBN\"},\"client\":{\"clientRequestId\": \"Id-b8c93759e80e0200b4060000635e8faf-4a3a622a339a\",\"trueClientIP\": \"183.90.36.103\",\"sessionId\": \"82875bc8-335c-494f-8a7a-4a3a622a339a\",\"userAgent\":\"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_2 like Mac OS X) AppleWebKit/603.2.4 (KHTML, like Gecko) Version/10.0 Mobile/14F89 Safari/602.1\",\"channel\":\"IBNK\",\"deviceTy\" :\"IBKIPH\"}}"
  private val accessToken = "eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiIyM2I5NWI3ODY1Yjc5OTU3MDY2NDdhYmMwNDU2NTI4IiwiY2xpZW50X2lkIjoiTE9BRF9URVNUIiwiaWF0IjoxNTExNjE0NzMwLCJleHAiOjE1MTE2MTY1MzAsInN1YiI6IjAxMjgzOTEwMjMwMSIsInVzZXJuYW1lIjoiMDEyODM5MTAyMzAxIiwiaXNzIjoiQ1NMLUFVVEgiLCJzY29wZSI6WyJyZWZyZXNoVG9rZW4iXSwiYXVkIjoiQ1NMLUFVVEgiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIn0.yexKRajofdpj5dXl3vi67qosyWPsb2la44xVs7fJtQkI7tnwvdNcfghmAQGDTrKvqaEo91XRWwcpulsgbQVMUHc1ObDXYcQPxu5XpZ6mxrQNGnjKxOcFY0BSI5SwiDhpQvue8-6dqN-sNZcbfDp8BehqVMQyly7TaGhUkJD3Gmmevag0JfiUIz_pBuufFHkgb2GlaVL-j0uad2s_PRbu53lHD6wsEY7eXD86GM6BdWZjDAsoD3OhAau4I1nCLq1i0l8YiIUwAubxd7rSMkLag-clfp9hjpeUnRkLV-pifr3iZ1aRu9JBSDhSQGWF1T--p20zaYP-_TKUizLLTLG5dQ"

  val scn = scenario("Credit-Card")
    .exec(
      http("eligibleFeeWaiver")
        .get("/retail/api/v3/credit-cards?filter[eligibleFeeWaiver]=Yes&filter[feeType]=LATE_PAYMENT&filter[cardNumbers]=5546232906002331&include=cardtransactions")
        .header("csl_user", cslUser)
        .header("csl_header", cslHeader)
//        .header("Authorization", "Bearer " + accessToken)
        .check(
          status.is(200)
        )
    )

  setUp(
    scn.inject(
//          atOnceUsers(1)
      rampUsers(100) over (10 minutes)
//        constantUsersPerSec(1) during(5 minute) randomized
    )).protocols(httpProtocol)
}
