# Property File Management
As per RDC-DEV-OPS, the default *.yml files should refer to environment variables for values that are environment-specific. This is to support openshift deployment. For new environment variables, please inform RDC-DEV-OPS.
Aside from the default *.yml files, there are the environment-specific yml files for non-openshift deployment. These yml files will contain the actual values rather than references to the environment variables. These two sets of yml files would co-exist in the meantime while the service has not fully migrated to openshift.

# JAAS Deployment
For JAAS deployment/any deployment in which do not use environment variables, locally rename the following files by removing -"sit" in their filenames, eventually replacing the original yml files:
application-sit.yml ->application.yml
application-db-config-sit.yml-> application-db-config.yml
application-gateway-sit.yml -> application-gateway.yml
application-hbase-config-sit.yml -> application-hbase-config.yml

# Local deployment using environment variables
Another approach to deploying this locally is to make use of the environment variables. Below is a sample on how to set the environment variables in your local machine. Remember to modify the values as per your setup accordingly.

Windows:
```
set CSLDB_JDBC_CREDIT_CARDS_URL=jdbc:oracle:thin:@hklpdudas2a-scan.hk.standardchartered.com:1622/RDC_CSL_SIT.hk.standardchartered.com
set CSLDB_JDBC_CREDIT_CARDS_USERNAME=RDC_CR_CARD_SIT_01
set CSLDB_JDBC_CREDIT_CARDS_PASSWORD=RDC_CR_CARD_SIT_01_123
set SVC_REQ_CLIENT_URL_BASE_URL=http://10.23.210.49:9172/csl-svc-service-request-2.0.0
set CSL_JASYPT_ENCRYPTION_KEY=secret
set EDMI_CREDIT_CARD_PROFILE_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCreditCardCreditCardProfile.v1.ws.provider.v1.creditCardProfile/scbCoreBankingCreditCardCreditCardProfile_v1_ws_provider_v1_creditCardProfile_Port
set EDMI_CREDIT_CARD_WS_TIMEOUT=10000
set EDMI_CREDIT_CARD_WS_USERNAME=picassouser
set EDMI_CREDIT_CARD_WS_PASSWORD=abc12345
set EDMI_WS_TRUSTSTORE=/Users/user/Vasan/jks/soap-edmi.jks
set EDMI_WS_TRUSTSTORE_PASSWORD=changeit
set EDMI_CREDIT_CARD_ENQUIRY_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCreditCardCreditCardEnquiry.v1.ws.provider.v1:creditCardEnquiry/scbCoreBankingCreditCardCreditCardEnquiry_v1_ws_provider_v1_creditCardEnquiry_Port
set CSL_DEBIT_CARD_WS_URL=http://10.23.210.50:9082
set CSL_AUTH_GATEWAY_WS_URL=https://oat.sc.com/retail/api/v3
set HBASE_ZOOKEEPER_PORT=2181
set HBASE_ROOT_DIR=hdfs://STANCDEV1TDH/apps/hbase/data
set HBASE_ZOOKEEPER_QUORUM=10.20.174.132,10.20.174.133,10.20.174.134
set HBASE_ZOOKEEPER_NODE_PARENT=/hbase-unsecure
set HBASE_USERNAME=sjcslapp
set CSL_AUTH_GATEWAY_WS_TRUSTSTORE=/Users/user/Vasan/jks/soap-edmi.jks
set CSL_AUTH_GATEWAY_WS_TRUSTSTORE_PASSWORD=changeit
set EDMI_CUSTOMER_WS_TIMEOUT=10000
set EDMI_CUSTOMER_WS_USERNAME=picassouser
set EDMI_CUSTOMER_WS_PASSWORD=abc12345
set EDMI_CUSTOMER_ENQUIRY_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCustomer.v5.ws.provider.v2:Customer/scbCoreBankingCustomer_v5_ws_provider_v2_Customer_Port
set EDMI_ELIGIBLE_WS_TIMEOUT=10000
set EDMI_ELIGIBLE_WS_USERNAME=picassouser
set EDMI_ELIGIBLE_WS_PASSWORD=abc12345
set EDMI_ELIGIBLE_INSTALLMENT_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCreditCardInstallmentLoanV1.ws.provider.v1:InstallmentLoan/scbCoreBankingCreditCardInstallmentLoanV1_ws_provider_v1_InstallmentLoan_Port
```

Mac
export CSLDB_JDBC_CREDIT_CARDS_URL=jdbc:oracle:thin:@hklpdudas2a-scan.hk.standardchartered.com:1622/RDC_CSL_SIT.hk.standardchartered.com
export CSLDB_JDBC_CREDIT_CARDS_USERNAME=RDC_CR_CARD_SIT_01
export CSLDB_JDBC_CREDIT_CARDS_PASSWORD=RDC_CR_CARD_SIT_01_123
export SVC_REQ_CLIENT_URL_BASE_URL=http://10.23.210.49:9172/csl-svc-service-request-2.0.0
export CSL_JASYPT_ENCRYPTION_KEY=secret
export EDMI_CREDIT_CARD_PROFILE_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCreditCardCreditCardProfile.v1.ws.provider.v1.creditCardProfile/scbCoreBankingCreditCardCreditCardProfile_v1_ws_provider_v1_creditCardProfile_Port
export EDMI_CREDIT_CARD_WS_TIMEOUT=10000
export EDMI_CREDIT_CARD_WS_USERNAME=picassouser
export EDMI_CREDIT_CARD_WS_PASSWORD=abc12345
export EDMI_WS_TRUSTSTORE=/Users/user/Vasan/jks/soap-edmi.jks
export EDMI_WS_TRUSTSTORE_PASSWORD=changeit
export EDMI_CREDIT_CARD_ENQUIRY_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCreditCardCreditCardEnquiry.v1.ws.provider.v1:creditCardEnquiry/scbCoreBankingCreditCardCreditCardEnquiry_v1_ws_provider_v1_creditCardEnquiry_Port
export CSL_DEBIT_CARD_WS_URL=http://10.23.210.50:9082
export CSL_AUTH_GATEWAY_WS_URL=https://oat.sc.com/retail/api/v3
export HBASE_ZOOKEEPER_PORT=2181
export HBASE_ROOT_DIR=hdfs://STANCDEV1TDH/apps/hbase/data
export HBASE_ZOOKEEPER_QUORUM=10.20.174.132,10.20.174.133,10.20.174.134
export HBASE_ZOOKEEPER_NODE_PARENT=/hbase-unsecure
export HBASE_USERNAME=sjcslapp
export CSL_AUTH_GATEWAY_WS_TRUSTSTORE=/Users/user/Vasan/jks/soap-edmi.jks
export CSL_AUTH_GATEWAY_WS_TRUSTSTORE_PASSWORD=changeit
export EDMI_CUSTOMER_WS_TIMEOUT=10000
export EDMI_CUSTOMER_WS_USERNAME=picassouser
export EDMI_CUSTOMER_WS_PASSWORD=abc12345
export EDMI_CUSTOMER_ENQUIRY_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCustomer.v5.ws.provider.v2:Customer/scbCoreBankingCustomer_v5_ws_provider_v2_Customer_Port
export EDMI_ELIGIBLE_WS_TIMEOUT=10000
export EDMI_ELIGIBLE_WS_USERNAME=picassouser
export EDMI_ELIGIBLE_WS_PASSWORD=abc12345
export EDMI_ELIGIBLE_INSTALLMENT_WS_URL=https://10.20.175.66:5501/ws/scbCoreBankingCreditCardInstallmentLoanV1.ws.provider.v1:InstallmentLoan/scbCoreBankingCreditCardInstallmentLoanV1_ws_provider_v1_InstallmentLoan_Port
export CSL_SVC_IBANK_DATA_ACCESS_LAYER_WS_URL=https://uat.csl.global.standardchartered.com:8543