package com.sc.csl.retail.creditcard.dto.post;


import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CCFeeWaiverPostDto {
	private String requestType;
	private String feeType;
	private String reason;
	private String channelId;
	private String entityType;
	private String sourceFlag;
	private String agentId;
	private String frontlineUserId;
	private String functionCode;
	private String userType;
	private String frontlineNotes;
	private String branchCode;
	private String feeTypeCode;
	
	private List<CreditCardPostDto> creditcard;
}
