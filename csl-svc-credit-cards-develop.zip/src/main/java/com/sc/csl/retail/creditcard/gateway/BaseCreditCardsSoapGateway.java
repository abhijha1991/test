package com.sc.csl.retail.creditcard.gateway;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLSoapGateway;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.GatewayHeaderProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.scbml_1.SCBMLHeaderType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.ws.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public abstract class BaseCreditCardsSoapGateway<T> extends CSLSoapGateway<T> {

	@Autowired
	private Map<String, CreditCardProperties> creditCardProperties;

	public enum PropertyCodes {
	    ERROR_CODES, CURRENCY_CODES, ACTIVATION_ERROR_CODES, INTL_CNTRY_CODES
	}
	public BaseCreditCardsSoapGateway(Service service, Class<T> wsClazz) {
		super(service, wsClazz);
	}

	
	public BaseCreditCardsSoapGateway(Service service, Class<T> wsClazz, CSLSoapGatewayProperties properties) {
		super(service, wsClazz, properties);
	}

    public void setupInterceptors() {
        // Remove old interceptors 
	   ClientProxy.getClient(getProxyClient()).getInInterceptors().removeIf( i -> i instanceof LoggingInInterceptor || i instanceof LoggingInInterceptor);
	
	   ClientProxy.getClient(getProxyClient()).getInInterceptors().add(new LoggingInInterceptor(-1));
	   ClientProxy.getClient(getProxyClient()).getOutInterceptors().add(new LoggingOutInterceptor(-1));
	}

    public Object getValuePropertiesByKey(Map<?,?> map, String key){
    	return CardUtil.getValueByKey(map, key);
    }
    
    public CreditCardProperties getCreditCardPropertiesByCountry(String countryCode){
    	CreditCardProperties countryProp = (CreditCardProperties) getValuePropertiesByKey(creditCardProperties, StringUtils.upperCase(countryCode));
    	if(CardUtil.isEmptyOrNull(countryProp)){
    		throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR,"Country Mapping Properties", "Not Found"));
    	}
	    return countryProp;
    }

	
	public Map<String, String> getPropertiesByCode(String countryCode,PropertyCodes code){
    	Map<String, String> propCodes = new HashMap<>();
		CreditCardProperties countryProp = getCreditCardPropertiesByCountry(countryCode);
		
		switch(code) {
		
			case ERROR_CODES:
				
				if(CardUtil.isEmptyOrNull(countryProp.getErrorCodes())){
					propCodes = getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL).getErrorCodes();
				}else{
					propCodes = countryProp.getErrorCodes();
				}
				 break;
			case CURRENCY_CODES:	
				
				if(CardUtil.isEmptyOrNull(countryProp.getCurrencyCodes())){
					propCodes = getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL).getCurrencyCodes();
				}else{
					propCodes = countryProp.getCurrencyCodes();
				}
				 break;
			case INTL_CNTRY_CODES:	
				
				if(CardUtil.isEmptyOrNull(countryProp.getIntlCountryCodes())){
					propCodes = getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL).getIntlCountryCodes();
				}else{
					propCodes = countryProp.getIntlCountryCodes();
				}
				 break;	 
			case ACTIVATION_ERROR_CODES:
				
				if(CardUtil.isEmptyOrNull(countryProp.getCardActivationErrorCodes())){
					propCodes = getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL).getCardActivationErrorCodes();
				}else{
					propCodes = countryProp.getCardActivationErrorCodes();
				}
				 break;
		}	
		return propCodes;
	}

	public Map<String, Object> getGatewayTemplateMap(GatewayHeaderProperties gatewayHeaderProperties, CreditCardVO creditCardVO){
		Map<String, Object> templateMap = new HashMap();
		templateMap.put("gatewayProps", gatewayHeaderProperties);
		templateMap.put("creditCardVO", creditCardVO);
		return templateMap;
	} 

	public void validateSCBMLHeader(SCBMLHeaderType header, CreditCardVO creditCardVO){
		String responseCode = null;
		String responseDesc = null;
		if(CardUtil.isEmptyOrNull(header)){
			return;
		}
		
		if(!CardUtil.isEmptyOrNull(header.getExceptions()) 
				&& !CardUtil.isEmptyOrNull(header.getExceptions().getException()) 
				&& !CardUtil.isEmptyOrNull(header.getExceptions().getException().get(0).getCode())){
			responseCode = header.getExceptions().getException().get(0).getCode().getValue();
			responseDesc = header.getExceptions().getException().get(0).getDescription();
			log.info("[validateSCBMLHeader (Header) responseCode, responseDesc: {},{}", responseCode, responseDesc);
			validateResponseCode(responseCode, responseDesc, creditCardVO);
		}
	}
	
	public void validateResponseCode(String responseCode, String responseDesc, CreditCardVO creditCardVO){
		log.info("[validateResponseCode (Body) responseCode, responseDesc: {},{}", responseCode, responseDesc);
		if(!ArrayUtils.contains(CardGatewayConstant.EDMI_SUCCESS_RES_CDS, responseCode)){
			throw new BusinessException(TemplateErrorCode.create(CreditCardErrorCode.getBusinessErrorCode((String) CardUtil.getValueByKey(getPropertiesByCode(creditCardVO.getCountryCode(),PropertyCodes.ERROR_CODES), responseCode)), responseCode, responseDesc));
		}	

		creditCardVO.setStatusCode(responseCode);
		creditCardVO.setStatusDescription(responseDesc);
	}

	public void populateCreditCardPrimaryStatus(CreditCardProperties props, List<CreditCardDto> creditCards){
		if(!CardUtil.isEmptyOrNull(props.getCreditCardFilters().getIsSupplCardStausCheckEnabled())
				&& StringUtils.equals(CardConstant.CONS_Y, props.getCreditCardFilters().getIsSupplCardStausCheckEnabled())
				&& !CardUtil.isEmptyOrNull(props.getCreditCardFilters().getAllowedPrimaryCardStatus())) {
			for (CreditCardDto creditCard : creditCards) {
				if(!StringUtils.equals(CardConstant.CONS_Y, creditCard.getIsPrimary())) {
					creditCard.setCardRplStatus(CardUtil.getPrimaryCardStatusForSupplCardStatus(props.getCreditCardFilters().getAllowedPrimaryCardStatus(), creditCards, props.getCreditCardFilters().getCardStatus()));
				}
			}
		}
	}

	public void handleException(CreditCardVO creditCardVO, Throwable exception){
		if(!CardUtil.isEmptyOrNull(creditCardVO)
				&& !CardUtil.isEmptyOrNull(creditCardVO.getInclude())
				&& StringUtils.equalsIgnoreCase(CardConstant.INCLUDE_ONLINE, creditCardVO.getInclude())) {
			if (!CardUtil.isEmptyOrNull(exception)) {
				if (exception instanceof BusinessException) {
					throw (BusinessException) exception;
				} else if (exception instanceof TechnicalException) {
					throw (TechnicalException) exception;
				} else {
					throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "handleException", "General Exception"));
				}
			}
		}
	}
}
