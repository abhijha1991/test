package com.sc.csl.retail.creditcard.dto.post;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@EqualsAndHashCode(callSuper=false)
@NoArgsConstructor
public class CreditCardPostDto {

	private static final long serialVersionUID = -6749681420606315210L;

	private String cardNumber;
	private String cardType;
	private String blockCode;
	private String availableCustomerRewardpoints;
	private String cardEligibilityStatus;
	private String eligibilityOverrideFlag;
	private String rewardPointRequired;
	private String rewardPoint;
	private String rewardFeeAmount;
	private String cardCurrency;
	
	private List<CCTransactionPostDto> transaction;
	
}
