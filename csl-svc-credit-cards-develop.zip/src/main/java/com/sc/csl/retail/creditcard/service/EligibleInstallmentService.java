package com.sc.csl.retail.creditcard.service;

import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.EligibleInstallmentDto;
import com.sc.csl.retail.creditcard.gateway.edmi.EligibleInstallmentSoapGateway;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@Setter
@Service
public class EligibleInstallmentService {

    @Autowired
    EligibleInstallmentSoapGateway eligibleInstallmentSoapGateway;


    public EligibleInstallmentDto getEligiblePlans(EligibleInstallmentDto eligibleInstallmentDto)

    {
        EligibleInstallmentDto eligibleInstallmentVO = new EligibleInstallmentDto();
        eligibleInstallmentVO = eligibleInstallmentSoapGateway.getEligiblePlans(eligibleInstallmentDto);
        return eligibleInstallmentVO;
    }



    public List<CreditCardDto> getEligiblePlans1(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditList = new ArrayList<CreditCardDto>();
        CreditCardDto creditCardDto = new CreditCardDto();
        EligibleInstallmentDto eligibleInstallmentVO = new EligibleInstallmentDto();
        eligibleInstallmentVO.setCountry(creditCardVO.getCountryCode());
        eligibleInstallmentVO.setCardNum(creditCardVO.getCardNo());
        eligibleInstallmentVO.setFuncCode(creditCardVO.getFuncCode());
        eligibleInstallmentVO.setSeqNo(creditCardVO.getSeqNo());
        eligibleInstallmentVO.setTxnType(creditCardVO.getFunctionType());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        Date date = null;
        List<CreditCardTransactionDto> creditCardTransactions = null;
        List<CreditCardTransactionDto> tmpCreditCardTransactions = null;
        try {

            eligibleInstallmentVO = eligibleInstallmentSoapGateway.getEligiblePlans(eligibleInstallmentVO);
            creditCardDto.setCardNum(eligibleInstallmentVO.getCardNum());
            creditCardDto.setFuncCode(eligibleInstallmentVO.getFuncCode());
            creditCardDto.setSeqNo(eligibleInstallmentVO.getSeqNo());
            creditCardDto.setTxnType("eligible-plans");
            creditCardDto.setBalances(eligibleInstallmentVO);
            creditList.add(creditCardDto);
            log.info("Credit Card Service - start & end time...{},{}", date,
                    new Date());
        } finally {
            log.debug("[findAllCreditCard Exit]");
        }
        return creditList;
    }



}
