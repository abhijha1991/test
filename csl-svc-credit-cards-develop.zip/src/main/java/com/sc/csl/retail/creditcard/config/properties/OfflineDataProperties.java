package com.sc.csl.retail.creditcard.config.properties;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class OfflineDataProperties {
    private String creditCardPortfolio;
}
