package com.sc.csl.retail.creditcard.vo;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class BaseVO implements Serializable {

	private static final long serialVersionUID = -9212478054904426781L;

	private String countryCode;
	private String channelId;
	private String requestId;
	private String sessionId;
	private String trackingId;
	private String endToEndId;
	private String messageTimestamp;
	private String statusCode;
	private String statusDescription;
	private String relId;
	private String customerId;
	private String customerType;
	private String operationName;
}
