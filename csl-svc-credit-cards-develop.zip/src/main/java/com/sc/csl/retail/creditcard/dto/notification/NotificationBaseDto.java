package com.sc.csl.retail.creditcard.dto.notification;

import lombok.Data;

@Data
public class NotificationBaseDto {

    private String trackingId;

    private String status;

    private String statusDesc;

    private String responseType;

    private String messageSender;

    private String captureSystem;

    private String dateTimeStamp;
}
