package com.sc.csl.retail.creditcard.dto.post;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PayloadDto {
	
	private String operationName;
	
	Map<String, Object> payLoad;

}
