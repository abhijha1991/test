package com.sc.csl.retail.creditcard.service.security;

import com.sc.csl.retail.core.gateway.CSLRestGateway;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;
import javax.ws.rs.core.Response;

@Service
@Slf4j
@ConfigurationProperties(prefix = "uaas.gateway")
public class UAASServiceGateway extends CSLRestGateway {

	private static String pinresetEndpoint = "/uaas/api/pinreset/v1/smsotp";

	public Response updatePin(String requestJson) {

		log.info("Entered updatePin()....");
		try {
			Response response = post(requestJson, pinresetEndpoint);
			return response;
		} finally {
			log.info("Exit updatePin()....");
		}
	}

}
