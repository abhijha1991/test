package com.sc.csl.retail.creditcard.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


@ToString
@Data
@EqualsAndHashCode(callSuper=false)
@Entity
@Table(name = "CSL_SR_PARAM_MST")
public class SRParamDto extends CslBase{

	private static final long serialVersionUID = 1L;
	/*
	@EmbeddedId
	private SRParamStatusId id;
	*/
	@Column(name = "C_CTRY_CD", nullable=false)
	private String countryCode;

	@Column(name = "C_LANG_CD", nullable=false)
	private String languageCode;
	@Id
	@NotNull
	@Column(name = "ID_PARAM ", nullable=false)
	private String paramId = null;
	
	@Column(name = "X_PARAM_KEY_1", nullable=false)
	private String paramKey1 = null;
	
	@Column(name = "X_PARAM_KEY_2", nullable=false) 
	private String paramKey2 = null;
	
	@Column(name = "X_PARAM_KEY_3", nullable=false) 
	private String paramKey3 = null;
	
	@Column(name = "X_PARAM_KEY_4", nullable=false)   
	private String paramKey4 = null;
	
	@Column(name = "X_PARAM_KEY_5", nullable=false) 
	private String paramKey5 = null;
	
	@Column(name = "X_PARAM_KEY_6", nullable=false)   
	private String paramKey6 = null;
	
	@Column(name = "X_PARAM_KEY_7", nullable=false) 
	private String paramKey7 = null;
	
	@Column(name = "X_PARAM_KEY_8", nullable=false) 
	private String paramKey8 = null;
	
	@Column(name = "X_PARAM_KEY_9", nullable=false) 
	private String paramKey9 = null;
	
	@Column(name = "X_PARAM_KEY_10", nullable=false) 
	private String paramKey10 = null;
	
	@Column(name = "X_PARAM_DATA_1", nullable=false)
	private String paramData1 = null;
	
	@Column(name = "X_PARAM_DATA_2", nullable=false)
	private String paramData2 = null;
	
	@Column(name = "X_PARAM_DATA_3", nullable=false)
	private String paramData3 = null;
	
	@Column(name = "X_PARAM_DATA_4", nullable=false)
	private String paramData4 = null;
	
	@Column(name = "X_PARAM_DATA_5", nullable=false)
	private String paramData5 = null;
	
	@Column(name = "X_PARAM_DATA_6", nullable=false)
	private String paramData6 = null;
	
	@Column(name = "X_PARAM_DATA_7", nullable=false)
	private String paramData7 = null;
	
	@Column(name = "X_PARAM_DATA_8", nullable=false)
	private String paramData8 = null;
	
	@Column(name = "X_PARAM_DATA_9", nullable=false)
	private String paramData9 = null;
	
	@Column(name = "X_PARAM_DATA_10", nullable=false)
	private String paramData10 = null;
	
	@Column(name = "X_PARAM_DATA_11", nullable=false)
	private String paramData11 = null;
	
	@Column(name = "X_PARAM_DATA_12", nullable=false)
	private String paramData12 = null;
	
	@Column(name = "X_PARAM_DATA_13", nullable=false)
	private String paramData13 = null;
	
	@Column(name = "X_PARAM_DATA_14", nullable=false)
	private String paramData14 = null;
	
	@Column(name = "X_PARAM_DATA_15", nullable=false)
	private String paramData15 = null;
	
	@Column(name = "X_PARAM_DATA_16", nullable=false)
	private String paramData16 = null;
	
	@Column(name = "X_PARAM_DATA_17", nullable=false)
	private String paramData17 = null;
	
	@Column(name = "X_PARAM_DATA_18", nullable=false)
	private String paramData18 = null;
	
	@Column(name = "X_PARAM_DATA_19", nullable=false)
	private String paramData19 = null;
	
	@Column(name = "X_PARAM_DATA_20", nullable=false)
	private String paramData20 = null;
	

}
