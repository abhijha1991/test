package com.sc.csl.retail.creditcard.helper;

import java.math.BigDecimal;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardEligibilityCriteriaDao;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityCriteriaDto;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityDto;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
/**
 * @author 1570288
 * Aug-17
 */
@Slf4j
@Component
public class CCFeeWaiverEligibilityUtility {

	@Autowired
	private CreditCardService creditCardService;
	@Autowired
	private CreditCardEligibilityCriteriaDao eligibilityDao;
	
	/**
	 * This method is used to fetch the eligibility details - EligibilityFlag
	 * and EligibilityPercentage from EDMP for IN, SG, HK and MY.
	 * 
	 * @param journeyMap
	 * @param creditCardVO
	 * @param crDto
	 * @param props
	 */
	public void getEligibilityDetails(Map<String, Object> journeyMap,
			CreditCardVO creditCardVO, CreditCardDto crDto,
			CreditCardFeeWaiverProperties props) {
		log.info("[CreditCardFeeWaiverService getEligibilityDetails [from EDMP] Entered...] :"+props.getRaEligibilityCriteria()
				.get(CardConstant.KEY_ELIGIBLE_FEE_TYPE));
		
		String eligibilityFlag = null;
		if (props.getRaEligibilityCriteria()
				.get(CardConstant.KEY_ELIGIBLE_FEE_TYPE)
				.contains(creditCardVO.getFeeType())) {
			// connect to EDMP to perform RA BAse validation
			String blockCode = crDto.getBlockCode().trim();
			String feeType = creditCardVO.getFeeType();
			String countryCode = creditCardVO.getCountryCode();
			CreditCardEligibilityDto creditDto = new CreditCardEligibilityDto();
			
				if (CardConstant.CONTRY_IN.equalsIgnoreCase(countryCode)) {
					getEligibilityIN(journeyMap, creditCardVO, props,
							blockCode, feeType);
				} else if (CardConstant.CONTRY_SG.equalsIgnoreCase(countryCode)) {
					getEligibilitySG(journeyMap, creditCardVO, feeType, props);
				} else if (CardConstant.CONTRY_MY.equalsIgnoreCase(countryCode)) {
					getEligibilityMY(journeyMap, creditCardVO, props);
				}else if (CardConstant.CONTRY_HK.equalsIgnoreCase(countryCode)) {
					getEligibilityHK(journeyMap, creditCardVO,feeType, props);
				}
				
				eligibilityFlag = (String) journeyMap.get(CardConstant.KEY_ELIGIBILITY);
				creditDto.setCardEligibilityFlag(eligibilityFlag);
				if (CardConstant.CONTRY_IN.equalsIgnoreCase(countryCode) && (journeyMap
						.get(CardConstant.KEY_ELIGIBILITY_PERCENTAGE)) != null) {
					creditDto
							.setPercentageEligible((BigDecimal)journeyMap
											.get(CardConstant.KEY_ELIGIBILITY_PERCENTAGE));
					
				}
				
				if (null != eligibilityFlag && CardConstant.CONTRY_HK.equalsIgnoreCase(countryCode)) {
						creditDto.setPercentageEligible(BigDecimal.valueOf(1));
				}
				
				if (null != eligibilityFlag && !CardConstant.CONTRY_HK.equalsIgnoreCase(countryCode)) {
					if (CardConstant.CONS_N.equalsIgnoreCase(eligibilityFlag)) {
							/*creditDto.setPercentageEligible(BigDecimal
									.valueOf(1));*/
						crDto.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_CUST_NOT_ELIGIBLE);
						crDto.setErrorDescription(CardConstant.CC_FEE_WAIVER_ERR_MSG_CUST_NOT_ELIGIBLE);
					}
					if (CardConstant.CONS_Y.equalsIgnoreCase(eligibilityFlag) && !(countryCode.equalsIgnoreCase(CardConstant.CONTRY_IN))) {
						creditDto.setPercentageEligible(BigDecimal
								.valueOf(1));
					}
				}
				if (CardConstant.CONTRY_IN
						.equalsIgnoreCase(countryCode)) {
					if(journeyMap.containsKey(CardConstant.KEY_VALUE_TO_BANK_IN) && CardConstant.FEE_TYPE_IF.equalsIgnoreCase(feeType)){
						if(CardConstant.VALUE_VERYHIGH.equalsIgnoreCase((String)journeyMap.get(CardConstant.KEY_VALUE_TO_BANK_IN))){
							creditDto.setEligibleReversalCapAmount(CardConstant.VERY_HIGH_VTB_CAPPED_AMNT_IN);
						}
						else{
							creditDto.setEligibleReversalCapAmount(CardConstant.OTHER_VTB_CAPPED_AMNT_IN);
						}
					}
				}
				crDto.setCreditCardEligibility(creditDto);

		} else {
			CreditCardEligibilityDto creditcardeligibilitydto = new CreditCardEligibilityDto();
			creditcardeligibilitydto.setCardEligibilityFlag(CardConstant.CONS_Y);
			creditcardeligibilitydto.setPercentageEligible(BigDecimal
					.valueOf(1));
			crDto.setCreditCardEligibility(creditcardeligibilitydto);
		}
		log.info("[CreditCardFeeWaiverService getEligibilityDetails [from EDMP] Exit...] ");
	}

	/**
	 * @param journeyMap
	 * @param creditCardVO
	 * @param props
	 * @param blockCode
	 * @param feeType
	 */
	public void getEligibilityIN(Map<String, Object> journeyMap,
			CreditCardVO creditCardVO, CreditCardFeeWaiverProperties props,
			String blockCode, String feeType) {
		
		log.info("Entered in getEligibilityIN().");
		String customerId = "";
		
		if (!props.getRaEligibilityCriteria()
				.get(CardConstant.KEY_DELIQUENCY_BLOCK_CODES)
				.contains("'"+blockCode.toUpperCase()+"'")) {
			String tableName = props.getEligibiltityTable();
			CreditCardEligibilityCriteriaDto resultParam = null;
			CreditCardEligibilityCriteriaDto creditCardEligibilityDto = eligibilityDao
					.getINEligibilityCriteria(journeyMap,
							creditCardVO.getCardNo(),
							CardConstant.ELIGIBILITY_CARD_LEVEL, tableName);
			if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto
					.getIsObjNull())) {
				log.debug("getEligibilityDetails - Card details found in EDMP for card number ["+creditCardVO.getCardNo()+"]");
				resultParam = creditCardEligibilityDto;
			} else {
				customerId = creditCardVO.getCustomerId();
				log.debug("getEligibilityDetails - Card details not found in EDMP. Checking for cards at customer level. Cust Id["+ customerId +"]");
								
				creditCardEligibilityDto = eligibilityDao
						.getINEligibilityCriteria(journeyMap,
								customerId,
								CardConstant.ELIGIBILITY_CUSTOMER_LEVEL,
								tableName);
				if (null != creditCardEligibilityDto) {
					resultParam = creditCardEligibilityDto;
				} else {
					log.debug("getEligibilityDetails - Customer record not found in EDMP for eligibility check.");
				}
			}
			if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto
					.getIsObjNull())) {
				BigDecimal per = null;
				if (CardConstant.FEE_TYPE_OL.equalsIgnoreCase(feeType)) {
					journeyMap.put(CardConstant.KEY_ELIGIBILITY,
							resultParam.getEligibilityStatusOL());
					per = percentage(resultParam.getEligibilityPercentageOL());
				} else {
					journeyMap.put(CardConstant.KEY_ELIGIBILITY,
							resultParam.getEligibilityStatusOthers());
					switch (feeType) {
					case CardConstant.FEE_TYPE_AF:
						per = percentage(resultParam
								.getEligibilityPercentageAF());
						break;
					case CardConstant.FEE_TYPE_IF:
						per = percentage(resultParam
								.getEligibilityPercentageIF());
						break;
					case CardConstant.FEE_TYPE_LF:
						per = percentage(resultParam
								.getEligibilityPercentageLF());
						break;
					}
				}
				journeyMap.put(CardConstant.KEY_ELIGIBILITY_PERCENTAGE, per);
				journeyMap.put(CardConstant.KEY_VALUE_TO_BANK_IN,
						resultParam.getValueToBank());
			}else{
				journeyMap.put(CardConstant.KEY_ELIGIBILITY, CardConstant.CONS_N);
				log.info("Eligibility details not found in EDMP for card number"
						+ creditCardVO.getCardNo() + ",and Customer ID: "+creditCardVO.getCustomerId()+". Hence setting the eligibility as N.");
						
			}
		} else {
			journeyMap.put(CardConstant.KEY_ELIGIBILITY, CardConstant.CONS_N);
			log.info("getEligibilityDetails - Card:"
					+ creditCardVO.getCardNo()
					+ " is delinquent and hence not eligible for fee waiver. : Elig Percent["+journeyMap.get(CardConstant.KEY_ELIGIBILITY_PERCENTAGE)+"]");
		}
		
		log.info("getEligibilityIN - Exit. Elig Percent["+journeyMap.get(CardConstant.KEY_ELIGIBILITY_PERCENTAGE)+"]");
	}

	/**
	 * 
	 * @param journeyMap
	 * @param creditCardVO
	 * @param feeType
	 */
	public void getEligibilitySG(Map<String, Object> journeyMap,
			CreditCardVO creditCardVO, String feeType,
			CreditCardFeeWaiverProperties props) {
		log.info("Entered in getEligibilitySG().");
		CreditCardEligibilityCriteriaDto resultParam = null;
		String tableName = props.getEligibiltityTable();
		CreditCardEligibilityCriteriaDto creditCardEligibilityDto = eligibilityDao
				.getSGEligibilityCriteria(journeyMap, creditCardVO.getCardNo(),
						CardConstant.ELIGIBILITY_CARD_LEVEL, tableName);
		if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto
				.getIsObjNull())) {
			log.debug("getEligibilityDetails - Card details found in EDMP for the card number["+ creditCardVO.getCardNo() +"]");
			resultParam = creditCardEligibilityDto;
		} else {
			log.debug("getEligibilityDetails - Card details not found in EDMP. Checking for cards at customer level for customerId ["+ creditCardVO.getCustomerId() +"].");
			creditCardEligibilityDto = eligibilityDao.getSGEligibilityCriteria(
					journeyMap, creditCardVO.getCustomerId(),
					CardConstant.ELIGIBILITY_CUSTOMER_LEVEL, tableName);
			if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto
					.getIsObjNull())) {
				resultParam = creditCardEligibilityDto;
			} else {
				log.debug("getEligibilityDetails - Customer record not found in EDMP for eligibility check.");
			}
		}
		if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto
				.getIsObjNull())) {
			if (CardConstant.FEE_TYPE_LF.equalsIgnoreCase(feeType)) {
				journeyMap.put(CardConstant.KEY_ELIGIBILITY,
						resultParam.getLateFeeEligible());
			} else if (feeType.startsWith(CardConstant.FEE_TYPE_AF)) {
				journeyMap.put(CardConstant.KEY_ELIGIBILITY,
						resultParam.getAnnualFeeEligible());
			}
		} else {
			journeyMap.put(CardConstant.KEY_ELIGIBILITY, CardConstant.CONS_N);
			log.debug("getEligibilityDetails - Record not found for selected Card:"
					+ creditCardVO.getCardNo()
					+ ", and Customer:"
					+ creditCardVO.getCustomerId()
					+ " in EDMP. Hence setting the value as N");
		}
		log.info("Exit from getEligibilitySG().");
	}

	/**
	 * 
	 * @param journeyMap
	 * @param creditCardVO
	 */
	public void getEligibilityMY(Map<String, Object> journeyMap,
			CreditCardVO creditCardVO, CreditCardFeeWaiverProperties props) {
		log.info("Entered in getEligibilityMY().");
		CreditCardEligibilityCriteriaDto resultParam = null;
		String tableName = props.getEligibiltityTable();
		CreditCardEligibilityCriteriaDto creditCardEligibilityDto = eligibilityDao
				.getMYEligibilityCriteria(journeyMap,
						creditCardVO.getCustomerId(), tableName);
		if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto
				.getIsObjNull())) {
			resultParam = creditCardEligibilityDto;
			if (CardConstant.ELIGIBILITY_MY_XREMARK_VAL_N
					.equalsIgnoreCase(resultParam.getXRemark()))
				journeyMap.put(CardConstant.KEY_ELIGIBILITY,
						CardConstant.CONS_N);
			else if (CardConstant.ELIGIBILITY_MY_XREMARK_VAL_Y
					.equalsIgnoreCase(resultParam.getXRemark()))
				journeyMap.put(CardConstant.KEY_ELIGIBILITY,
						CardConstant.CONS_Y);
		} else {
			log.debug("getEligibilityDetails - MY - Customer:"
					+ creditCardVO.getCustomerId()
					+ ", details not found in EDMP");
			journeyMap.put(CardConstant.KEY_ELIGIBILITY, CardConstant.CONS_N);
		}
		log.info("Exit from getEligibilityMY().");
	}
	
	private BigDecimal percentage(String value) {
		value = (value != null && value.length() > 0) ? value : "0";
		return new BigDecimal(Double.parseDouble(value) / 100).setScale(2,
				BigDecimal.ROUND_HALF_EVEN);
	}
	
	/**
	 * 
	 * @param journeyMap
	 * @param creditCardVO
	 * @param feeType
	 */
	public void getEligibilityHK(Map<String, Object> journeyMap,CreditCardVO creditCardVO, String feeType,
			CreditCardFeeWaiverProperties props) {
		
		log.info("[CreditCardFeeWaiverService getEligibilityDetails->getEligibilityHK Entry");
		String tableName = props.getEligibiltityTable();
		CreditCardEligibilityCriteriaDto creditCardEligibilityDto = eligibilityDao.getHKEligibilityCriteria(journeyMap, creditCardVO.getCardNo(),CardConstant.ELIGIBILITY_CARD_LEVEL, tableName);
		
		if (CardConstant.CONS_N.equalsIgnoreCase(creditCardEligibilityDto.getIsObjNull())) {
			log.info("[CreditCardFeeWaiverService getEligibilityDetails->getEligibilityHK Card is Eligible...");
			journeyMap.put(CardConstant.KEY_ELIGIBILITY, CardConstant.CONS_Y);
		} else {
			journeyMap.put(CardConstant.KEY_ELIGIBILITY, CardConstant.CONS_N);
			log.debug("getEligibilityHK - Record not found for selected Card:"+ creditCardVO.getCardNo()+ ", and Customer:"	+ creditCardVO.getCustomerId()+ " in EDMP. Hence setting the value as N");
		}
	}
}
