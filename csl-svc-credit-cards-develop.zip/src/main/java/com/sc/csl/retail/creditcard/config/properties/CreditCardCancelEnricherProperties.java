package com.sc.csl.retail.creditcard.config.properties;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;

import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * @author 1452875
 * @since Sep 18, 2017
 */
@Getter
@Setter
@Slf4j
public class CreditCardCancelEnricherProperties {
    private String serviceType = null;
    private String processId = null;
    private Map<String, GenericMappingProperties> genericMapping = null;
    private Map<String, Map<String, String>> customMapping = null;

    public GenericMappingProperties getGenericMappingDetails(String mapId) {
        if (CardUtil.isEmptyOrNull(genericMapping) || StringUtils.isBlank(mapId)) {
            return null;
        }
        GenericMappingProperties genMappingProp = genericMapping.get(mapId);
        log.debug("[Map ID: " + mapId + "] [Details: " + genMappingProp + "]");
        return genMappingProp;
    }

    public Map<String, String> getCustomMappingDetails(String mapId) {
        if (CardUtil.isEmptyOrNull(customMapping) || StringUtils.isBlank(mapId)) {
            return null;
        }
        Map<String, String> mapDetail = customMapping.get(mapId);
        log.debug("[Map ID: " + mapId + "] [Details: " + mapDetail + "]");
        return mapDetail;
    }
}
