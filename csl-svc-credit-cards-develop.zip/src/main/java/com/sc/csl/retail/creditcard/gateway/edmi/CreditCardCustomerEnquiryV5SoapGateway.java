package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.v5.customer.SingleCustomerView;
import com.sc.corebanking.v5.ws.provider.customer.CustomerPortType;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerPortfolioDetails;
import com.sc.corebanking.v5.ws.provider.customer.GetCustomerPortfolioDetailsRes;
import com.sc.corebanking.v5.ws.provider.customer.ScbCoreBankingCustomerV5WsProviderV2Customer;
import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;


@Slf4j
public class CreditCardCustomerEnquiryV5SoapGateway extends BaseCreditCardsSoapGateway<CustomerPortType> {

	@Autowired
	public FreemarkerRenderer renderer;


	public CreditCardCustomerEnquiryV5SoapGateway(CSLSoapGatewayProperties creditCardCustomerEnquiryV5SoapGatewayProperties) {
        super(new ScbCoreBankingCustomerV5WsProviderV2Customer(), CustomerPortType.class, creditCardCustomerEnquiryV5SoapGatewayProperties);
        setupInterceptors();
	}

	public List<CreditCardDto> getCreditCards(CreditCardVO creditCardVO){
		List<CreditCardDto> creditCards = new ArrayList<CreditCardDto>();
		CreditCardProperties props = null;
		GetCustomerPortfolioDetails request = null;
		List<SingleCustomerView> singleCustomerViews = null;
		try{
			log.debug("[getCreditCards Entry]");
			props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
			CardUtil.setGatewayProperties(creditCardVO);
			request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_CUSTOMER_ENQUIRY_CARD_LIST_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardListProperties(), creditCardVO)), GetCustomerPortfolioDetails.class);
		    if(CardUtil.isEmptyOrNull(request)){
				throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR,"Card List Request", "empty or null"));
			}
			if(creditCardVO.getServiceTimeOut()!=null) {
				setupClientTimeout(creditCardVO.getServiceTimeOut());
			}
			GetCustomerPortfolioDetailsRes response = this.getProxyClient().getCustomerPortfolioDetails(request.getGetCustomerPortfolioDetailsRequest());
			if (CardUtil.isEmptyOrNull(response)) {
				return creditCards;
			}
			validateSCBMLHeader(response.getHeader(), creditCardVO);
			if (CardUtil.isEmptyOrNull(response.getGetCustomerPortfolioDetailsResPayload())
					|| CardUtil.isEmptyOrNull(response.getGetCustomerPortfolioDetailsResPayload().getGetCustomerPortfolioDetailsRes())
					|| CardUtil.isEmptyOrNull(response.getGetCustomerPortfolioDetailsResPayload().getGetCustomerPortfolioDetailsRes().getCustomerInfo())
					|| CardUtil.isEmptyOrNull(response.getGetCustomerPortfolioDetailsResPayload().getGetCustomerPortfolioDetailsRes().getCustomerInfo().getSingleCustomerView())){
				throw new BusinessException(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND);
			}
			singleCustomerViews = response.getGetCustomerPortfolioDetailsResPayload().getGetCustomerPortfolioDetailsRes().getCustomerInfo().getSingleCustomerView();
			creditCards = processCreditCardCustomerCardListEdmiResponse(singleCustomerViews,creditCardVO,props);
			if (CollectionUtils.isEmpty(creditCards)) {
				throw new BusinessException(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND);
			}
			creditCardVO.setCreditCards(creditCards);
			log.info("[getCreditCards resposne.size : {}]", CollectionUtils.size(creditCardVO.getCreditCards()));
			return creditCardVO.getCreditCards();
		} finally {
			log.debug("[getCreditCards Exit]");
		}
	}

	public List<CreditCardDto> processCreditCardCustomerCardListEdmiResponse(List<SingleCustomerView> singleCustomerViews,CreditCardVO creditCardVO,CreditCardProperties props){
		log.info("processCreditCardCustomerCardListEdmiResponse entry");
		List<CreditCardDto> creditCards = new ArrayList<CreditCardDto>();
		CreditCardDto creditCardDto = null;
		String cardNo = null;
		for (SingleCustomerView singleCustomerView : singleCustomerViews) {
			if (!CardUtil.isEmptyOrNull(singleCustomerView.getAccountProductCode())
					&& !CardUtil.isEmptyOrNull(singleCustomerView.getAccountProductCode().getValue())
					&& StringUtils.equals(singleCustomerView.getAccountProductCode().getValue(), CardConstant.HOGAN_CREDIT_CARD_PRODUCT_CODE)
			     	&& !CardUtil.isEmptyOrNull(singleCustomerView.getAccountNumber())
					&& !CardUtil.isEmptyOrNull(singleCustomerView.getAccountNumber().getValue())
					&& StringUtils.length(singleCustomerView.getAccountNumber().getValue()) > 1
					&& !CardUtil.isEmptyOrNull(singleCustomerView.getV53Organization())
					&& !CardUtil.isEmptyOrNull(singleCustomerView.getV53Organization().getValue())) {
				creditCardDto = new CreditCardDto();
				creditCardDto.setCountry(creditCardVO.getCountryCode());
				creditCardDto.setCustomerId(creditCardVO.getCustomerId());
				creditCardDto.setChannel(creditCardVO.getChannelId());
				creditCardDto.setRelId(creditCardVO.getRelId());
				creditCardDto.setCustomerType(creditCardVO.getCustomerType());
				cardNo = singleCustomerView.getAccountNumber().getValue();
				creditCardDto.setCardID(CardUtil.generateCardId(creditCardDto.getCountry(), cardNo, creditCardDto.getCustomerId()));
				creditCardDto.setOrgNum(singleCustomerView.getV53Organization().getValue());
				creditCardDto.setCardNum(cardNo);
				creditCardDto.setIsComboFlag(CardConstant.CONS_N);
				creditCardDto.setOperationName(creditCardVO.getOperationName());
				creditCards.add(creditCardDto);
			}
		}
		log.info("processCreditCardCustomerCardListEdmiResponse end");
		return creditCards;
	}
}	