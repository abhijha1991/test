package com.sc.csl.retail.creditcard.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CardActivationValidationProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.customer.CreditCardContact;
import com.sc.csl.retail.creditcard.dto.post.CardActivationDto;
import com.sc.csl.retail.creditcard.dto.post.OtpInfo;
import com.sc.csl.retail.creditcard.dto.security.SmsOtp;
import com.sc.csl.retail.creditcard.dto.security.ValidateOtp;
import com.sc.csl.retail.creditcard.exception.CardActivationErrorCode;
import com.sc.csl.retail.creditcard.exception.CardException;
import com.sc.csl.retail.creditcard.exception.UAASErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway.PropertyCodes;
import com.sc.csl.retail.creditcard.gateway.csl.CustomerJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.DecryptGateway;
import com.sc.csl.retail.creditcard.gateway.csl.SmsOtpGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ValidateOtpGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.UAASUtil;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import io.katharsis.repository.response.HttpStatus;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@Service
public class CardActivationService extends BaseService {

	@Autowired
	protected CSLRequestContext cslRequestContext;

	@Autowired
	DecryptGateway securityGateway;

	@Autowired
	private CreditCardV1SoapGateway creditCardV1SoapGateway;

	@Autowired
	private CreditCardValidator cardValidator;

	@Autowired
	private CustomerJsonApiGateway customerGateway;

	@Autowired
	private SmsOtpGateway smsOtpGateway;

	@Autowired
	private ValidateOtpGateway validateOtpGateway;

	@Autowired
	private UAASUtil uaasUtil;

	@Autowired
	private CardUtil cardUtil;

	@Autowired
	private CSLAsyncRequestContext cslAsyncRequestContext;

	@Autowired
	private CardActivationAsyncService cardActivationAsyncService;

	@Autowired
	private CardActivationProcessingService cardProcessingService;
	
    @Autowired
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;

	private static final String STATUS_CODE_KEY = "statusCode";
	private static final String ERROR_MESSAGE = "errorMessage";
	private static final String RELID = "relId";

	public CreditCardDto activateCard(CreditCardDto creditCardDto) {
		CreditCardDto responseDto = new CreditCardDto();
		CreditCardVO creditCardVO=null;
		try {
			log.info("[CardActivationService.activateCardForPreLogin Entry]");

			validateCard(creditCardDto);
			validate2FA(creditCardDto);
			if(StringUtils.isNotEmpty(cslRequestContext.getCountry())) {
			creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
			}else
			{
				creditCardVO = getCreditCardVO(creditCardDto);				
			}
			creditCardVO.setCardNo(creditCardDto.getCardNum());
			creditCardVO.setEmbosserName(creditCardDto.getEmbossedName());	
			creditCardVO.setOperationName(creditCardDto.getOperationName());
			creditCardVO = creditCardV1SoapGateway.updateCardStatus(creditCardVO);
			 
			creditCardDto.setCardNum(CardConstant.PAD_EMPTY + creditCardVO.getCardNo());
			creditCardDto.setStatus(creditCardVO.getStatusCode());
			creditCardDto.setErrorDescription(creditCardVO.getStatusDescription());
			responseDto.setCountry(creditCardDto.getCountry());
			try {
				String receiptID = cardProcessingService.generateReceiptNumber();
				
				responseDto.setReceiptId(receiptID);
				responseDto.setCardNum(creditCardDto.getCardNum());
				creditCardDto.setReceiptId(receiptID);
				creditCardDto.setChannel(CardConstant.DEFAULT_CHANNEL);
				creditCardDto.setLanguage(CardConstant.ENG_LANG_CODE);
				// Call Async Post processing service for SMS,Email and
				// Inbox notifications
				cardProcessingService.postProcess(creditCardDto);
				return responseDto;
			} catch (Exception ex) {
				if (!(ex instanceof TechnicalException) && !(ex instanceof BusinessException)) {
					throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
				} else {
					throw ex;
				}
			}

		} finally {
			log.info("[CardActivationService.activateCardForPreLogin Exit]");
		}
	}

	private CreditCardVO getCreditCardVO(CreditCardDto creditCardDto) {
		CreditCardVO creditCardVO;
		creditCardVO=new CreditCardVO();		
		creditCardVO.setCountryCode(creditCardDto.getCountryCode());
		creditCardVO.setChannelId(CardConstant.DEFAULT_CHANNEL);
		creditCardVO.setLangCode(CardConstant.ENG_LANG_CODE);
		return creditCardVO;
	}

	public CreditCardDto activateCardForSMS(CreditCardDto creditCardDto) {
		CreditCardVO creditCardVO =null;
		try {
			log.debug("[CardActivationService.activateCardForPreLogin Entry]");

			cardValidator.validateCardActivationSMSRequest(creditCardDto);
			CreditCardDto response = new CreditCardDto();
			response.setReceiptId(creditCardDto.getReceiptId());
			response.setStatus("Submitted");

			response.setEligibleFeeWaiver(null);
			response.setIsCardHasPartialPayment(null);
			setCSLContext(creditCardDto);
			if(StringUtils.isNotEmpty(cslRequestContext.getCountry())) {
				creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
				}else
				{
					creditCardVO = getCreditCardVO(creditCardDto);				
				}
			creditCardVO.setCardNo(creditCardDto.getCardNum());
			creditCardVO.setEmbosserName(creditCardDto.getEmbossedName());
			creditCardVO.setOperationName(creditCardDto.getOperationName());
			creditCardVO.setContactNum(creditCardDto.getContactNumber());
    		cardActivationAsyncService.processSMSActivation(cslAsyncRequestContext, creditCardVO);
    		
    		try {
				// Call Async Post processing service for SMS,Email and
				// Inbox notifications
				cardProcessingService.postProcess(creditCardDto);
			} catch (Exception ex) {
				if (!(ex instanceof TechnicalException) && !(ex instanceof BusinessException)) {
					throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
				} else {
					throw ex;
				}
			}
			log.debug("[CardActivationService.activateCardForPreLogin Exit]");
			return response;
		} finally {
			log.debug("[activateCardForPreLogin Exit]");
		}
	}

	private void validateCard(CreditCardDto creditCardDto) {
		
		CreditCardDto ccEnquiryDto = null;

		cardValidator.validatePreLoginCardActivationRequest(creditCardDto);

		setCSLContext(creditCardDto);

		String decryptedCardNumber = null;
		
		CreditCardVO creditCardVO = null;

		try {
			decryptedCardNumber = creditCardV1SoapGateway.getDecryptedCardNumber(creditCardDto);
		} catch (Exception ex) {
			if (!(ex instanceof TechnicalException) && !(ex instanceof BusinessException)) {
				throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
			} else {
				throw ex;
			}
		}
		creditCardDto.setCardNum(decryptedCardNumber);

		setCSLContext(creditCardDto);
		
		creditCardVO = cardUtil.populateCreditCardVO(cslAsyncRequestContext);
		
		log.info("[CardActivationService.activateCardForPreLogin Entry]");
		
		creditCardVO.setCardNo(creditCardDto.getCardNum());
		
		ccEnquiryDto = creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO);
		
		if (StringUtils.isNotBlank(ccEnquiryDto.getRelId()) && creditCardDto.getOperationName().equalsIgnoreCase(CardConstant.OPERATION_CC_ACTIVATION)) {
			creditCardDto.setRelId(ccEnquiryDto.getRelId());
		}
		
		cslAsyncRequestContext.setRelId(ccEnquiryDto.getRelId());
		
		if (StringUtils.isNotBlank(ccEnquiryDto.getActivationStatus()) && !"0".equalsIgnoreCase(ccEnquiryDto.getActivationStatus())) {
			throw new BusinessException(TemplateErrorCode.create(CardActivationErrorCode.CSL_CREDIT_CARD_ACTIVE_STATUS));
		}

		String cardBin = StringUtils.substring(decryptedCardNumber, 0, 6);
		CardActivationValidationProperties activationProperties = cardUtil
				.getCreditCardPropertiesBean(creditCardDto.getCountryCode()).getCreditCardActivationProps();
		if (!activationProperties.getAllowedBin().contains(cardBin)) {
			throw new BusinessException(TemplateErrorCode.create(CardActivationErrorCode.CSL_CREDIT_CARD_INVALID_BIN));
		}
	}

	@SuppressWarnings("unchecked")
	private void validate2FA(CreditCardDto creditCardDto) {
		String countryCode=null;

		CardActivationDto cardActivationDto = creditCardDto.getCardActivationDto();

		if (CardUtil.isEmptyOrNull(cardActivationDto.getOtpInfo())) {
			List<CreditCardContact> creditCardContacts = null;
			try {
				creditCardContacts = customerGateway.getCreditContactWithCardNumber(creditCardDto.getCardNum());
			} catch (Exception ex) {
				if (!(ex instanceof TechnicalException) && !(ex instanceof BusinessException)) {
					throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
				} else {
					throw ex;
				}
			}

			if (CardUtil.isEmptyOrNull(creditCardContacts)) {
				throw new BusinessException(CardActivationErrorCode.CSL_CREDIT_CARD_NO_CONTACT_FOUND);
			}

			Optional<CreditCardContact> cardContacts = creditCardContacts.stream()
					.filter(m -> m.getContactTypeDesc().equals(CardConstant.CONTACT_TYPE_MOBILE_DESC)).findFirst();
			
			CreditCardContact cardContact = null;
			
			if(cardContacts.isPresent()) {
				cardContact = cardContacts.get();
			}else {
				log.info("[CardActivationService.validate2FA  Mobile Element detail not Found] ");
				cardContact = null;
			}

			if (cardContact == null || StringUtils.isBlank(cardContact.getContactDetails())) {
				throw new BusinessException(CardActivationErrorCode.CSL_CREDIT_CARD_NO_CONTACT_FOUND);
			}

			String contactNumber = cardContact.getContactDetails();
			countryCode=cslRequestContext.getCountry()!=null?cslRequestContext.getCountry():creditCardDto.getCountryCode();
			String telephoneCntryCode=(String)CardUtil.getValueByKey(creditCardV1SoapGateway.getPropertiesByCode(countryCode,PropertyCodes.INTL_CNTRY_CODES),countryCode);
			contactNumber = cardUtil.validateContactNumber(telephoneCntryCode,contactNumber);

			String messageTemplate = cardProcessingService.getOtpMessageTemplateDetail(countryCode,
					creditCardDto.getOperationName(), cslRequestContext.getLanguage()!=null?cslRequestContext.getLanguage():CardConstant.ENG_LANG_CODE);// loaded from DB
			SmsOtp smsOtp=null;
			try {
			 smsOtp = smsOtpGateway.sendOtp(contactNumber, messageTemplate);
			} catch (Exception ex) {
				if (ex instanceof TechnicalException) {
				throw new TechnicalException(TemplateErrorCode.create(UAASErrorCode.UAAS_CONNECTION_ERROR,
						"UAAS Service Error", ex.getMessage()));
				}else {
					throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
				}
			}

			Map<String, Object> otpResponseMap = CSLJsonUtils.convertValue(smsOtp, Map.class);
			if (CardConstant.UAAS_SUCCESS_CODE.equals(smsOtp.getStatusCode())) {
				otpResponseMap.remove(STATUS_CODE_KEY);
				otpResponseMap.remove(ERROR_MESSAGE);
				otpResponseMap.remove(RELID);
				otpResponseMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_REQUIRED);
			} else {
				otpResponseMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_FAILED);
			}
			throw new CardException(HttpStatus.UNAUTHORIZED_401, CSLJsonUtils.toJson(otpResponseMap));

		} else {

			cardValidator.validateCardActivationOTPBlock(cardActivationDto.getOtpInfo());
			ValidateOtp otpResponse = validateOtpGateway
					.validateOtp(prepareValidateOTP(cardActivationDto.getOtpInfo(),creditCardDto));
			if (!CardConstant.UAAS_SUCCESS_CODE.equals(otpResponse.getStatusCode())) {
				Map<String, Object> validateOtpErrorMap = CSLJsonUtils.convertValue(otpResponse, Map.class);
				validateOtpErrorMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_VALIDATION_FAILED);
				throw new CardException(HttpStatus.UNAUTHORIZED_401, CSLJsonUtils.toJson(validateOtpErrorMap));
			}
		}
	}

	

	private ValidateOtp prepareValidateOTP(OtpInfo otpInfo,CreditCardDto creditCardDto) {
		ValidateOtp validateOtp = new ValidateOtp();
		validateOtp.setEncOtp(otpInfo.getEncOtp());
		validateOtp.setPurpose(otpInfo.getPurpose());
		validateOtp.setOtpSn(otpInfo.getOtpSn());
		validateOtp.setKeyIndex(otpInfo.getKeyIndex());
		validateOtp.setRelId(cslRequestContext.getRelId()!=null?cslRequestContext.getRelId():creditCardDto.getRelId());
		validateOtp.setCountry(cslRequestContext.getCountry()!=null?cslRequestContext.getCountry():creditCardDto.getCountryCode());
		validateOtp.setRequestId(cslRequestContext.getRequestId());
		validateOtp.setLanguage(cslRequestContext.getLanguage()!=null?cslRequestContext.getLanguage():CardConstant.ENG_LANG_CODE);
		validateOtp.setChannel(cslRequestContext.getChannel()!=null?cslRequestContext.getChannel():CardConstant.DEFAULT_CHANNEL);
		return validateOtp;
	}

	private void setCSLContext(CreditCardDto creditCardDto) {
		cslAsyncRequestContext.setRelId(creditCardDto.getCardNum());
		cslAsyncRequestContext.setCountry(creditCardDto.getCountryCode());
		cslAsyncRequestContext.setChannel(CardConstant.DEFAULT_CHANNEL);
		cslAsyncRequestContext.setLanguage(CardConstant.ENG_LANG_CODE);		
	}

}
