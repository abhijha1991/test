package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

import java.math.BigInteger;

@ToString
@Data
public class CardEmbossingInfoDto {

    @JsonProperty("issue-num")
    private BigInteger issueNum;
    @JsonProperty("embosser-name")
    private String embosserName;
    @JsonProperty("card-sequence-num")
    private BigInteger cardSequenceNum;
}
