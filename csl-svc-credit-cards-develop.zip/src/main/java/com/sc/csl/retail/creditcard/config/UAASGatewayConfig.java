package com.sc.csl.retail.creditcard.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.sc.csl.retail.creditcard.config.properties.UAASServiceProperties;

@Configuration
public class UAASGatewayConfig {

	@Bean
	@ConfigurationProperties(prefix = "uaas.hk")
	public UAASServiceProperties uaasPropertiesHK() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.sg")
	public UAASServiceProperties uaasPropertiesSG() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.ci")
	public UAASServiceProperties uaasPropertiesCI() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.ae")
	public UAASServiceProperties uaasPropertiesAE() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.ng")
	public UAASServiceProperties uaasPropertiesNG() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.ke")
	public UAASServiceProperties uaasPropertiesKE() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.gh")
	public UAASServiceProperties uaasPropertiesGH() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.bw")
	public UAASServiceProperties uaasPropertiesBW() {
		return new UAASServiceProperties();
	}

	@Bean
	@ConfigurationProperties(prefix = "uaas.zm")
	public UAASServiceProperties uaasPropertiesZM() {
		return new UAASServiceProperties();
	}
	
	@Bean
	@ConfigurationProperties(prefix = "uaas.my")
	public UAASServiceProperties uaasPropertiesMY() {
		return new UAASServiceProperties();
	}
	
	@Bean
	@ConfigurationProperties(prefix = "uaas.in")
	public UAASServiceProperties uaasPropertiesIN() {
		return new UAASServiceProperties();
	}

}
