package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.creditcard.v1.ws.provider.creditcardlimit.CreditCardLimitPortType;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardlimit.ScbCoreBankingCreditCardCreditCardLimitV1WsProviderV1CreditCardLimit;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardlimit.ValidateLimitIncrease;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardlimit.ValidateLimitIncreaseRes;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Slf4j
@Service
public class CreditCardLimitV1SoapGateway extends BaseCreditCardsSoapGateway<CreditCardLimitPortType> {

    @Autowired
    public FreemarkerRenderer renderer;


    public CreditCardLimitV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardLimitV1SoapGatewayProperties) {
        super(new ScbCoreBankingCreditCardCreditCardLimitV1WsProviderV1CreditCardLimit(), CreditCardLimitPortType.class, edmiCreditCardLimitV1SoapGatewayProperties);
        setupInterceptors();
    }

    public ValidateLimitIncreaseRes getCreditCardBalanceLimit(CreditCardVO creditCardVO) {

        CreditCardProperties props = null;
        ValidateLimitIncrease request = null;
        ValidateLimitIncreaseRes response = null;

        try {
            log.debug("[getCreditCardBalanceLimit Entry]");
            props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
            CardUtil.setGatewayProperties(creditCardVO);
            request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_LIMIT_BALANCE_DETAILS_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardLimitProperties(), creditCardVO)),ValidateLimitIncrease.class);
            response =this.getProxyClient().validateLimitIncrease(request.getValidateLimitIncreaseRequest());
        } catch (Exception e) {
            throw new TechnicalException(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT);
        }

         return response;

    }
}