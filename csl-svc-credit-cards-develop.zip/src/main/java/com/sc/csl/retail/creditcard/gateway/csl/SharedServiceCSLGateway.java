package com.sc.csl.retail.creditcard.gateway.csl;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.creditcard.dto.CardPinResetAuditDto;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ConfigurationProperties(prefix = "jsonapi.gateway.sharedservice.creditcard")
public class SharedServiceCSLGateway extends CSLJsonApiGateway {

	public CardPinResetAuditDto insertAuditDetails(CardPinResetAuditDto auditDto) {
		try {
			log.info("[auditDetails entry]");
			CardPinResetAuditDto audit = new CardPinResetAuditDto();
			ResourceRepositoryV2<CardPinResetAuditDto, String> custRepo = getKatharsisClient().getRepositoryForType(CardPinResetAuditDto.class);
			audit = custRepo.create(auditDto);
			return audit;
		} finally {
			log.info("[auditDetails End]");
		}
	}
}
