package com.sc.csl.retail.creditcard.helper;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

@Component
@Slf4j
public class EncryptionDecryptionHelper {
	
	private static final String ENCODE_UTF8="UTF-8";
	private static final String TDES_ENC_SCH="DESede";
	private KeySpec ks;
	private SecretKeyFactory skf;
	Cipher cipher;
	byte [] desedks;
	String mEncryptionScheme;
	SecretKey key;

	/**
	 * 
	 * @param encdecKey
	 */
	public  void initEncryptionMech(String encdecKey ) {
		mEncryptionScheme = TDES_ENC_SCH;
		log.info("Entered in initEncryptionMech()........]");
		
		try {
			
			desedks = encdecKey.getBytes(ENCODE_UTF8);
			ks = new DESedeKeySpec(desedks);
			skf = SecretKeyFactory.getInstance(mEncryptionScheme);
			cipher = Cipher.getInstance(mEncryptionScheme);
			key = skf.generateSecret(ks);
			
		} catch (UnsupportedEncodingException  |InvalidKeyException | NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeySpecException e) {
			log.error("Error in initEncryptionMech(), Exception ["+e+"]");
		}
	}
	
	/**
	 * 
	 * @param unEncryptedString
	 * @param encdecKey
	 * @return
	 */
	public String getEncryptedData(String unEncryptedString,String encdecKey){
		log.info("Entered in getEncryptedData()........]");
		
		String encryptedString = null;
		byte[] plainText = null;
		byte[] encryptedText = null;
		initEncryptionMech(encdecKey);
		
		try{			
			cipher.init(Cipher.ENCRYPT_MODE, key);
			plainText = unEncryptedString.getBytes(ENCODE_UTF8);
			encryptedText = cipher.doFinal(plainText);
			encryptedString = new String (Base64.getEncoder().encode(encryptedText));
			
		} catch (UnsupportedEncodingException  |InvalidKeyException | IllegalBlockSizeException | BadPaddingException  e) {
			log.error("Error in getEncryptedData(), Exception ["+e+"]");
		}
		return encryptedString;
	}
	
	/**
	 * 
	 * @param encryptedString
	 * @param encdecKey
	 * @return
	 */
	public String getDecryptedData(String encryptedString,String encdecKey){
		log.info("Entered in getDecryptedData()........]");
		
		String decryptedString = null;
		byte []decryptedText =null;
		byte []plainText = null;
		initEncryptionMech(encdecKey);
		try{
			cipher.init(Cipher.DECRYPT_MODE, key);
			encryptedString = URLDecoder.decode(encryptedString, "UTF-8");
			decryptedText =Base64.getDecoder().decode(encryptedString.getBytes());
			plainText = cipher.doFinal(decryptedText);
			decryptedString = new String (plainText);
		} catch (InvalidKeyException | IllegalBlockSizeException | BadPaddingException  e) {
			log.error("Error in getDecryptedData(), Exception ["+e+"]");
		} catch (UnsupportedEncodingException e) {
			log.error("UnsupportedEncodingException in getDecryptedData(), Exception ["+e+"]");
		} 
		
		return decryptedString;
	}
	
	/**
	 * 
	 * @param cardnum
	 * @param mode
	 * @param encdecKey
	 * @return
	 */
	public String  performEncryptDecrypt(int firstPart,int lastPart,String cardnum,String mode,String encdecKey){
		
		log.info("Entered in performEncryptDecrypt()........] [Card No:"+cardnum+"] [Key :"+encdecKey+"]");
		
		String result="";
		String firstPartDigits=cardnum.substring(0,firstPart);
		String variableDigits=cardnum.substring(firstPart,cardnum.length()-lastPart);
		String lastPartDigits=cardnum.substring(cardnum.length()-lastPart);
		StringBuffer buffer = new StringBuffer();
		buffer.append(encdecKey);
		buffer.append(buffer).append(buffer).append(buffer);
		if(CardConstant.ENCRYPT.equalsIgnoreCase(mode)){
			result =getEncryptedData(variableDigits,buffer.toString()); 
			try {
				result = java.net.URLEncoder.encode(result,"UTF-8");
			} catch (UnsupportedEncodingException e) {
				log.info("Error while doing encryption ...."+e.getMessage());
			}
		}
		else if (CardConstant.DECRYPT.equalsIgnoreCase(mode)){
			result =getDecryptedData(variableDigits, buffer.toString());
		}
		
		log.info("Exit from performEncryptDecrypt()........] ");
		return (firstPartDigits+result+lastPartDigits);
	}
	
	
}
