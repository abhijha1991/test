package com.sc.csl.retail.creditcard.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.creditcard.dto.SRParamDto;

@Repository
public interface CreditCardRepositoryDao extends
		CrudRepository<SRParamDto, Serializable> {

	@Query("select srprm from SRParamDto srprm "
			+ "where  "
			+ "srprm.countryCode = :countryCode and srprm.paramId = :paramId "
			+ " and srprm.paramKey1 =:paramKey1 and srprm.paramKey2 =:paramKey2"
			+ " and srprm.paramKey3 =:paramKey3 and srprm.paramKey4 =:paramKey4"
			+ " and srprm.paramKey5 =:paramKey5 and srprm.paramKey6 =:paramKey6"
			+ " and srprm.paramKey7 =:paramKey7 and srprm.paramKey8 =:paramKey8"
			+ " and srprm.paramKey9 =:paramKey9 and srprm.paramKey10 =:paramKey10")
	public List<SRParamDto> getSrParam(
			@Param("countryCode") String countryCode,
			@Param("paramId") String paramId,
			@Param("paramKey1") String paramKey1,
			@Param("paramKey2") String paramKey2,
			@Param("paramKey3") String paramKey3,
			@Param("paramKey4") String paramKey4,
			@Param("paramKey5") String paramKey5,
			@Param("paramKey6") String paramKey6,
			@Param("paramKey7") String paramKey7,
			@Param("paramKey8") String paramKey8,
			@Param("paramKey9") String paramKey9,
			@Param("paramKey10") String paramKey10);

}
