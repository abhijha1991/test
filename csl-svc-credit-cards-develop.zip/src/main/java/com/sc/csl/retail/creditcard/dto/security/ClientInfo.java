package com.sc.csl.retail.creditcard.dto.security;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ClientInfo {

	@JsonProperty("clientIP")
	private String clientIp;
	@JsonProperty("remoteIP")
	private String remoteIp;

}
