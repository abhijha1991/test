package com.sc.csl.retail.creditcard.helper;

import java.lang.reflect.InvocationTargetException;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.beanutils.BeanUtils;

import com.sc.csl.retail.core.exception.TechnicalException;

/**
 * @author 1452875
 * @since Sep 19, 2017
 */
@Slf4j
public class BeanUtility {
    public static void setProperty(Object sourceBean, Object destBean, String sourceProp, String destProp) {
        if (null == sourceBean || null == destBean || null == sourceProp || null == destProp) {
            return;
        }
        setProperty(destBean, destProp, getProperty(sourceBean, sourceProp));
    }

    public static void setProperty(Object bean, String prop, String value) {
        try {
            if (null == bean || null == prop) {
                return;
            }
            log.debug("[Bean: " + bean + "] [Property: " + prop + "] [Value: " + value + "]");
            BeanUtils.setProperty(bean, prop, value);
        } catch (InvocationTargetException | IllegalAccessException ex) {
            log.error("Error while set property value. [Object: " + bean + "] [Property: " + prop + "] [Value: "
                    + value + "]");
            throw new TechnicalException(ex.getMessage());
        }
    }

    public static String getProperty(Object bean, String prop) {
        try {
            if (null == bean || null == prop) {
                return null;
            }
            String value = BeanUtils.getProperty(bean, prop);
            log.debug("[Bean: " + bean + "] [Property: " + prop + "] [Value: " + value + "]");
            return value;
        } catch (NoSuchMethodException | InvocationTargetException | IllegalAccessException ex) {
            log.error("Error while get property value. [Object: " + bean + "] [Property: " + prop + "]");
            throw new TechnicalException(ex.getMessage());
        }
    }
}
