package com.sc.csl.retail.creditcard.exception;

import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@Getter
@Slf4j
public enum CreditCardErrorCode implements ErrorCode {

    ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT("ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT", "EDMI Connection Error", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_CCMS_DOWN_TIMEOUT("ERR_CSL_CREDIT_CARDS_CCMS_DOWN_TIMEOUT", "CCMS Connection Error", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO("ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO", "Credit Card No Invalid", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_INVALID_INPUT("ERR_CSL_CREDIT_CARDS_INVALID_INPUT", "Invalid Input", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND("ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND", "Customer Id Not Found", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_INVALID_REQUEST("ERR_CSL_CREDIT_CARDS_INVALID_REQUEST", "Invalid Request", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_GENERAL_ERROR("ERR_CSL_CREDIT_CARDS_GENERAL_ERROR", "General Error", "%s - %s"),
    ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID("ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID", "Customer Id Invalid", "Response Empty"),
    ERR_CSL_NO_VALID_CARDS_FOUND("ERR_CSL_NO_VALID_CARDS_FOUND","No eligible Credit Card Found","You do not have any eligible Credit Card(s) to initiate the request."),
    ERR_CSL_NO_EXCESS_AMOUNT("ERR_CSL_NO_EXCESS_AMOUNT","No available excess amount to refund","There is no excess amount to refund."),
    ERR_CSL_PENDING_ADDRCHANGE_SELF("ERR_CSL_PENDING_ADDR_CHANGE","Cashier Order - Pending address change request","We are unable to process your request at the moment since you have a pending address change request. Please contact our 24-hour Phone Banking service for assistance."),
    ERR_CSL_NO_POSTING_SERVICE("ERR_CSL_NO_POST_SERVICE", "System Error", "Posting service not available"),
    ERR_EDMI_EXCEPTION("ERR_EDMI_EXCEPTION", "EDMI Exception", "EDMI Exception"),
    ERR_24x7_EXCEPTION("ERR_CSL_24X7","Request rejected by 24x7","Reason: %s"),
    ERR_CSL_CREDIT_CARDS_MISSING_FIELDS("ERR_CSL_CREDIT_CARDS_MISSING_FIELDS", "Validation failed", "Missing mandatory field(s) :  %s"),
    ERR_CSL_CREDIT_CARD_NOT_MATCHED("ERR_CSL_CREDIT_CARD_NOT_MATCHED","General Error","Doesn't Find Card Number for Id"),
    ERR_OTP_NUMBER_ERROR("OTP_NUMBER_ERROR","Cashier Order - OTP request","We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance."),
    ERR_CSL_CREDIT_CARD_NO_LIMIT_FOUND("ERR_CSL_CREDIT_CARD_LIMIT_NOT_FOUND","No Limit Details Available","Card Limit Details Not Available in CCMS"),	
	ERR_CSL_CREDIT_CARDS_ACCT_NOT_FOUND("ERR_CSL_CREDIT_CARDS_ACCT_NOT_FOUND","Credit Card Account Not Found","Credit Card Account Not Available in Card Systems"),
	ERR_CSL_CREDIT_CARDS_SUPREL_CUSTOMER_NOT_FOUND("ERR_CSL_CREDIT_CARDS_SUPREL_CUSTOMER_NOT_FOUND","Supplimentary REL Details Not Found","Supplimentary REL Details Not Available in Card Systems"),
	ERR_CSL_CREDIT_CARDS_FILE_NOT_OPEN_IN_SUPREL("ERR_CSL_CREDIT_CARDS_FILE_NOT_OPEN_IN_SUPREL","Card File Not Open in Sub REL","Card File Not Open in Sub REL in Card System"),
	ERR_CSL_CREDIT_CARDS_SYSTEM_NOT_AVAILABLE("ERR_CSL_CREDIT_CARDS_SYSTEM_NOT_AVAILABLE","System Not Available","Card System Not Available"),
	ERR_CSL_CREDIT_CARDS_ORG_NOT_FOUND("ERR_CSL_CREDIT_CARDS_ORG_NOT_FOUND","Org Details Not Found","Org Details Not Available in Card Systems");
	

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    CreditCardErrorCode(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

    public static ErrorCode getBusinessErrorCode(String hostErrorCode) {
        ErrorCode errorCode = CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR;
        try {
            log.debug("[getBusinessErrorCode hostErrorCode : {}", hostErrorCode);
            if (!CardUtil.isEmptyOrNull(hostErrorCode)) {
                errorCode = CreditCardErrorCode.valueOf(hostErrorCode);
            }
        } catch (Exception e) {
            log.error("[getBusinessErrorCode exception : {}", e);
        }
        return errorCode;
    }
}
