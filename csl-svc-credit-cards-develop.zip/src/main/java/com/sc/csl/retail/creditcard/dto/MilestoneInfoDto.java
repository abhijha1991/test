package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonApiResource(type = "milestones")
public class MilestoneInfoDto implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3506032146354728492L;

	@JsonApiId
    @JsonProperty("id")
    private String milestoneId;

    @JsonProperty("description")
    private String description;

    @JsonProperty("elapsed-time")
    private String elapsedTime;

    @JsonProperty("start-time")
    private String startTime;

    @JsonProperty("end-time")
    private String endTime;

    @JsonProperty("status")
    private String status;
}