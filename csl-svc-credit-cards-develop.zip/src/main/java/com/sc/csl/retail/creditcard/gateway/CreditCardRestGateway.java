package com.sc.csl.retail.creditcard.gateway;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CardCustDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@ConfigurationProperties(prefix = "katharsis.client.dal.creditcards")
public class CreditCardRestGateway extends CSLJsonApiGateway {
    @Autowired
    ApplicationContext context;

    @Autowired
    CSLRequestContext cslRequestContext;

    @Autowired
    CSLAsyncRequestContext cslAsyncRequestContext;

    public CreditCardDto getOfflineCreditCardDetails(CreditCardVO creditCardVO) {
        CreditCardDto creditCardDto = null;
        try{
            ResourceRepositoryV2<CreditCardDto, String> customerRepo = getKatharsisClient().getRepositoryForType(CreditCardDto.class);
            QuerySpec querySpec = new QuerySpec(CreditCardDto.class);
            creditCardDto = customerRepo.findOne(creditCardVO.getCardNo(), querySpec);
            log.info("Getting the Offline Credit Card Details");
        } catch (BusinessException | TechnicalException ex) {
            log.error("Error in getCreditCardDetails. [Message: "
                    + ex.getMessage() + "]");
            throw ex;
        } catch (Exception ex) {
            log.error("Error in getCreditCardDetails. [Exception: {}]", ex);
            throw new TechnicalException(ex.getMessage());
        } finally {
            log.debug("[getRelId Exit]");
        }
        return creditCardDto;
    }

    public List<CreditCardDto> getOfflineCreditCardSummary() {
        ResourceList<CreditCardDto> offlineCreditCardDto = null;
        try {
            QuerySpec querySpec = new QuerySpec(CreditCardDto.class);
            offlineCreditCardDto = getKatharsisClient().getRepositoryForType(CreditCardDto.class).findAll(querySpec);
            log.info("Getting the Offline Cred Card Summary/List");
        } catch (BusinessException | TechnicalException ex) {
            log.error("Error in getCreditCardDetails. [Message: "
                    + ex.getMessage() + "]");
            throw ex;
        } catch (Exception ex) {
            log.error("Error in getRelId. [Exception: {}]", ex);
             throw new TechnicalException(ex.getMessage());
        } finally {
            log.debug("[getRelId Exit]");
        }

        return offlineCreditCardDto;
    }

    public List<CardCustDto> getCardNumber() {
        List<CardCustDto> cardCustDto = null;
        try{
            QuerySpec querySpec = new QuerySpec(CardCustDto.class);
            cardCustDto = getKatharsisClient().getRepositoryForType(CardCustDto.class).findAll(querySpec);
            log.info("Getting the Offline Credit Card Number");
        } catch (BusinessException | TechnicalException ex) {
            log.error("Error in getCreditCardDetails. [Message: "
                    + ex.getMessage() + "]");
            throw ex;
        } catch (Exception ex) {
            log.error("Error in getCreditCardDetails. [Exception: {}]", ex);
            throw new TechnicalException(ex.getMessage());
        }
        return cardCustDto;
    }
}
