package com.sc.csl.retail.creditcard.dto;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@NoArgsConstructor
@JsonApiResource(type = "reference-data")
public class ReferenceDataDto {

    private static final long serialVersionUID = -1L;
    @JsonApiId
    private String id = UUID.randomUUID().toString();
    @JsonProperty("logical-name")
    private String logicalName;
    @JsonProperty("device-group")
    private String deviceGroup;
    @JsonProperty("ref-id")
    private String refId;
    @JsonProperty("ref-value")
    private String refValue;

}
