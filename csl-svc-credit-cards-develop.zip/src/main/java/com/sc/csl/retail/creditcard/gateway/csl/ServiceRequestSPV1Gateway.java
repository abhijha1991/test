package com.sc.csl.retail.creditcard.gateway.csl;

import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.creditcard.dto.Spv1ServiceRequestInfo;
import com.sc.csl.retail.creditcard.dto.UserInfo;


@Slf4j
@Component
@ConfigurationProperties(prefix = "spv1.client.url")
public class ServiceRequestSPV1Gateway extends CSLJsonApiGateway {

    /**
     * Get the user related info like Group from SP db by making microservice call.
     * 
     * @param userId
     * @param countryCd
     * @return
     */
    public List<UserInfo> getUserInfo(String userId,String countryCd) {
		List<UserInfo> userDetailList = null;
		
        try {
            log.info("ServiceRequestSPV1Gateway getUserInfo Entry..User Id["+userId+"] Country ["+countryCd+"]");
            
        	ResourceRepositoryV2<UserInfo,String> spv1ServiceRepository = getKatharsisClient().
        			getRepositoryForType(UserInfo.class);
            QuerySpec querySpec = new QuerySpec(UserInfo.class);
            userDetailList = spv1ServiceRepository.findAll(querySpec);
        } finally{
            log.info("ServiceRequestSPV1Gateway getUserInfo Exit..");
        }
        return userDetailList;
    }

    public List<Spv1ServiceRequestInfo> getServiceRequests(String customerId, String countryCd) {
    	
        List<Spv1ServiceRequestInfo> requests = null;
        List<String> propertyList = new ArrayList<String>();
        List<String> filterValues = new ArrayList<String>();
        List<FilterSpec> filterSpecList = new ArrayList<FilterSpec>();
        FilterSpec filterSpec = null;
        
        try {
            ResourceRepositoryV2<Spv1ServiceRequestInfo, String> spv1ServiceRepository = getKatharsisClient().
            getRepositoryForType(Spv1ServiceRequestInfo.class);
            QuerySpec querySpec = new QuerySpec(Spv1ServiceRequestInfo.class);

            propertyList = new ArrayList<>();
            filterValues = new ArrayList<>();

            propertyList.add("CCFeeWaiver");
            filterValues.add("yes");
            filterSpec = new FilterSpec(propertyList, FilterOperator.EQ, filterValues);
            filterSpecList.add(filterSpec);

            querySpec.setFilters(filterSpecList);
            requests = spv1ServiceRepository.findAll(querySpec);
            log.info("ServiceRequestSPV1Gateway Requests : {}", requests);
        } catch (Exception ex) {
            log.error("Error in ServiceRequestSPV1Gateway getServiceRequests [Message2: " + ex.toString() + "]");
            throw new TechnicalException(ex);
        }
        return requests;
    }
}
