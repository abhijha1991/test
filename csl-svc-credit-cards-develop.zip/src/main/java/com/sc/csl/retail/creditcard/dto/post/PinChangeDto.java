package com.sc.csl.retail.creditcard.dto.post;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.creditcard.dto.BaseDto;

import io.katharsis.resource.annotations.JsonApiId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class PinChangeDto extends BaseDto {

	private static final long serialVersionUID = 1L;
	@JsonApiId
	private String id;
	
	@JsonProperty("enc-card-pin")
	private String encCardPin;
	
	@JsonProperty("enc-card-info")
	private String encCardInfo;
	
	@JsonProperty("pin-key-index")
	private String pinKeyIndex;
	
	@JsonProperty("card-number")
	private String cardNumber;
	
	@JsonProperty("otp-info")
	private OtpInfo otpInfo;	
	
	@JsonProperty(defaultValue="CREDIT", value="card-type")
	private String cardType;
	
	@JsonProperty("card-activation-flag")
	private String cardActivationFlag;
	
	@JsonProperty("sequence-number")
	private String sequenceNumber;
	
	
	
	/**
	 * UAAS Response Fields
	 */
	private String statusCode;
	private String errorMessage;
	
	/**
	 * Receipt Response Fields
	 */
	private String receiptNumber;
	
	
}
