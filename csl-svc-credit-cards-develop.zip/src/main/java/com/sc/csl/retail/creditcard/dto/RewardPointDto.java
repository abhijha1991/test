package com.sc.csl.retail.creditcard.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RewardPointDto {
	/**
	 * 
	 */
	private String rewardsPoints; 
	
	private String initialReffAmount;
	private String finalReffAmount;
	private String reffRewardPoints;

}
