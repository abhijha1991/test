package com.sc.csl.retail.creditcard.gateway.csl;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.creditcard.dto.DebitCardDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;

@Slf4j
@Component
@ConfigurationProperties(prefix = "jsonapi.csl.debitcards.v3")
public class DebitCardsV3CSLGateway extends CSLJsonApiGateway {

    @Async("threadPoolTaskExecutor")
    public CompletableFuture<DebitCardDto> getAsyncComboCardDetails(CreditCardVO creditCardVO) {
        return CompletableFuture.completedFuture(getCardDetails(creditCardVO));
    }

    public DebitCardDto getCardDetails(CreditCardVO creditCardVO) {
        try {
            log.info("[getCardDetails entry]");
            ResourceRepositoryV2<DebitCardDto, String> custRepo = getKatharsisClient().getRepositoryForType(DebitCardDto.class);
            QuerySpec querySpc = new QuerySpec(DebitCardDto.class);
            return custRepo.findOne(creditCardVO.getCardNo(),querySpc);
       } finally {
            log.info("[getCardDetails End]");
        }
    }
}
