package com.sc.csl.retail.creditcard.dto.customer;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.creditcard.dto.BaseDto;

/**
 * CreditCardContact.java
 * 
 * <pre>
 * 
 * </pre>
 * 
 * @author 1481163
 * @since Sept 4, 2017
 */
@ToString
@Setter
@Getter
@JsonApiResource(type = "cc-contacts")
public class CreditCardContact extends BaseDto {

    private static final long serialVersionUID = 7058050006460825314L;
    @JsonApiId
    @JsonProperty("contact-type-code")
    private String contactTypeCode = null;
    @JsonProperty("contact-type-desc")
    private String contactTypeDesc = null;
    @JsonProperty("contact-classification")
    private String contactClassification = null;
    @JsonProperty("contact-details")
    private String contactDetails = null;
    @JsonProperty("primary-flag")
    private String primaryFlag = null;
    @JsonProperty("rel-id")
    private String relId = null;
    @JsonProperty("customer-name")
    private String customerName = null;
    @JsonProperty("customer-email")
    private String customerEmail = null;

    /**
     * RELATIONSHIP
     */
    @JsonApiRelation(lookUp = LookupIncludeBehavior.AUTOMATICALLY_ALWAYS, opposite = "cc-contacts")
    @JsonProperty("customer")
    private Customer customer = null;

}
