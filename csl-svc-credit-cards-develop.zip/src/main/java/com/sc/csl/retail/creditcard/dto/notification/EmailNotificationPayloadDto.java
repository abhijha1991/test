package com.sc.csl.retail.creditcard.dto.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class EmailNotificationPayloadDto {

    @JsonProperty(value = "email-id")
    private String emailId;
    
    @JsonProperty(value = "sender-email")
    private String senderEmail;
    
    
    @NotNull(message = "notify-type can not be Null")
    @JsonProperty(value = "notify-type")
    private String notifyType;

    @NotNull(message = "is-encoded can not be Null")
    @JsonProperty(value = "is-encoded")
    private char isEncoded;

    @JsonProperty(value = "cc-email-id")
    private String ccEmailId;

    @NotNull(message = "multiple-recipients-indicator can not be Null")
    @JsonProperty(value = "multiple-recipients-indicator")
    private String multipleRecipientsIndicator;

    @NotNull(message = "message-subject can not be Null")
    @JsonProperty(value = "message-subject")
    private String messageSubject;

    @NotNull(message = "message-content can not be Null")
    @JsonProperty(value = "message-content")
    private String messageContent;

    @JsonProperty(value = "message-attachment-name")
    private String messageAttachmentName;

    @JsonProperty(value = "message-attachment-type")
    private String messageAttachmentType;

    @JsonProperty(value = "message-attachment-content")
    private String messageAttachmentContent;

    @NotNull(message = "language can not be Null")
    @JsonProperty(value = "language")
    private String language;

}
