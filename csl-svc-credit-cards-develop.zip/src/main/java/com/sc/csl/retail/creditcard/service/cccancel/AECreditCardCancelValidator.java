package com.sc.csl.retail.creditcard.service.cccancel;

import java.math.BigDecimal;

import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelValidationProperties;
import com.sc.csl.retail.creditcard.dto.BusinessRuleAlert;
import com.sc.csl.retail.creditcard.dto.BusinessRuleAlertType;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * @author 1452875
 * @since Dec 4, 2017
 */
public class AECreditCardCancelValidator extends CreditCardCancelValidator {

    protected void validateFinancialDetail(CreditCardDto creditCardDto,
            CreditCardCancelValidationProperties ccCancelValidationProperties) {
        super.validateFinancialDetail(creditCardDto, ccCancelValidationProperties);
        if (!CardUtil.isEmptyOrNull(creditCardDto.getAlerts())) {
            return;
        }

        // Reason with Outstanding Balance
        if (CardUtil.isValueInList(ccCancelValidationProperties.getIneligibleReasonCode(),
                creditCardDto.getReasonCode(), false)) {
            BigDecimal amount = creditCardDto.getOutstandingBalance();
            if (null != amount && amount.compareTo(BigDecimal.ZERO) < 0) {
                creditCardDto.addAlert(new BusinessRuleAlert(BusinessRuleAlertType.ERROR,
                        CardConstant.ERROR_CD_CC_CANCEL_INELIGIBLE_CARD, ccCancelValidationProperties.getAlertMessage(
                                CardConstant.PROP_CC_CANCEL_MSG_BAL_INELIGIBLE, creditCardDto.getLanguage())));
                return;
            }
        }

        // Sanctioned Category with Outstanding Balance
        if (CardUtil.isValueInList(ccCancelValidationProperties.getIneligibleSanctionedBlockCode(),
                creditCardDto.getBlockCode(), false)) {
            BigDecimal amount = creditCardDto.getOutstandingBalance();
            if (null != amount && amount.compareTo(BigDecimal.ZERO) != 0) {
                creditCardDto.addAlert(new BusinessRuleAlert(BusinessRuleAlertType.ERROR,
                        CardConstant.ERROR_CD_CC_CANCEL_INELIGIBLE_CARD, ccCancelValidationProperties.getAlertMessage(
                                CardConstant.PROP_CC_CANCEL_MSG_BAL_INELIGIBLE, creditCardDto.getLanguage())));
                return;
            }
        }
    }
}
