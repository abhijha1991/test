package com.sc.csl.retail.creditcard.dto.security;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
@JsonApiResource(type = "sms-otp")
public class SmsOtp {
    @JsonApiId
    private String requestId;
    private String mobile;
    private String msgTemplate;

    private String statusCode;
    private String otpSn;
    private String otpPrefix;

    private String base64Challenge;
    private String keyIndex;
    private String exponent;
    private String modulus;
    private String relId;

    private String isEncoded;
}