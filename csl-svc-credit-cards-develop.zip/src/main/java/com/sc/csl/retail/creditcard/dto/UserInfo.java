package com.sc.csl.retail.creditcard.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;

import java.io.Serializable;

import lombok.Data;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
@JsonApiResource(type = "spv1-service-requests-user-details")
public class UserInfo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@JsonApiId
	@JsonProperty("user-id")
	private String userId;
	
	@JsonProperty("channel-id")
	private String channelId;
	
	@JsonProperty("country")
	private String country;
	
	@JsonProperty("py-group-code")
	private String primaryGroupCode;
	
	@JsonProperty("branch-code")
	private String branchCode;

}
