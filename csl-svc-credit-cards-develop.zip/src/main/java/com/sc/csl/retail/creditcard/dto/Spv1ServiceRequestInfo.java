package com.sc.csl.retail.creditcard.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;

import java.io.Serializable;
import java.util.HashMap;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.fasterxml.jackson.annotation.JsonProperty;
	

@Data
@EqualsAndHashCode(of = { "receiptId" }, callSuper = false)
@JsonApiResource(type = "spv1-service-requests")

public class Spv1ServiceRequestInfo implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonApiId
	@JsonProperty("receipt-id")
	private String receiptId;
	
	@JsonProperty("rel-number")
	private String relNumber;

	private String status;

	@JsonProperty("service-type")
	private String serviceType;

	private String country;

	@JsonProperty("host-receipt-id")
	private String hostReceiptId;

	@JsonProperty("created-by")
	private String createdBy;

	@JsonProperty("updated-by")
	private String updatedBy;

    private HashMap<String, Object> payload = new HashMap<String, Object>();

    @JsonProperty("submitted-date")
	private String submittedDate;

	@JsonProperty("completed-date")
	private String completedDate;

	@JsonProperty("last-group-completed-date")
	private String lastGroupCompletedDate;

	@JsonProperty("last-updated-date")
	private String lastUpdatedDate;
	
	@JsonProperty("estimated-completion-date")
	private String estimatedCompletionDate;
	
	@JsonProperty("status-order")
	private int statusOrder;
	
	@JsonProperty("date-order")
	private int dateOrder;
	
	@JsonProperty("status-description")
	private String statusDescription;


    public HashMap<String, Object> getPayload() {
        return payload;
    }
}
