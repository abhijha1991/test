package com.sc.csl.retail.creditcard.helper;


import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.UAASServiceProperties;
import com.sc.csl.retail.creditcard.dto.CardInfo;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.post.PinChangeDto;
import com.sc.csl.retail.creditcard.dto.security.ClientInfo;
import com.sc.csl.retail.creditcard.dto.security.EncryptedData;
import com.sc.csl.retail.creditcard.dto.security.UAASOtpInfo;
import com.sc.csl.retail.creditcard.dto.security.UAASRequest;
import com.sc.csl.retail.creditcard.dto.security.UAASTransactionInfo;
import com.sc.csl.retail.creditcard.dto.security.UAASUserInfo;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class UAASUtil {

	@Autowired
	ApplicationContext context;

	@Autowired
	private Map<String, CreditCardProperties> creditCardProperties;

	final static Map<String, String> timeZoneMap = new HashMap<>();
	{
		timeZoneMap.put(CardConstant.CONTRY_SG, CardConstant.SG_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_MY, CardConstant.MY_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_HK, CardConstant.HK_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_IN, CardConstant.IN_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_AE, CardConstant.AE_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_KE, CardConstant.KE_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_GH, CardConstant.GH_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_BW, CardConstant.BW_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_ZM, CardConstant.ZM_TIMEZONEID);
		timeZoneMap.put(CardConstant.CONTRY_NG, CardConstant.NG_TIMEZONEID);
	}

	static int sequenceNo = 0;

	private UAASServiceProperties getPropertiesBean(String beanKey) {
		return (UAASServiceProperties) context.getBean(beanKey);
	}

	protected UAASServiceProperties getPropertiesBean(String countryCode, String beanKey) {
		String beanId = null;
		try {
			if (StringUtils.isBlank(countryCode)) {
				return null;
			}

			beanId = MessageFormat.format(beanKey, new Object[] { countryCode.toUpperCase() });
			log.debug("[UAASUtil getPropertiesBean] [Country: " + countryCode + "] [Bean Key: " + beanKey
					+ "] [Bean ID: " + beanId + "]");
			return getPropertiesBean(beanId);
		} catch (Exception ex) {
			log.error("Error in getPropertiesBean. [Message: " + ex.getMessage() + "]");
			throw new TechnicalException(ex.getMessage());
		}
	}

	/**
	 * request is more than 40 char, so we are splitting
	 */
	protected String getFormattedClientRequestId(String requestId) {
		String str = requestId;
		String[] reqIdPart = str.split(CardConstant.PAD_HYPHEN);
		return reqIdPart[1];
	}

	public UAASRequest prepareUAASPinSetRequest(CreditCardDto creditCardDto, CSLRequestContext cslRequestContext) {
		UAASServiceProperties uaasServiceProperties = getPropertiesBean(cslRequestContext.getCountry(),
				CardConstant.BEAN_ID_UAAS_PROPERTY);

		UAASRequest uaasRequest = new UAASRequest();

		UAASUserInfo user = setUAASUserInfo(uaasServiceProperties, cslRequestContext);

		CardInfo cardInfo = setCardInfo(creditCardDto, cslRequestContext.getCountry());

		UAASTransactionInfo txtInfo = setTransactionInfo(cslRequestContext.getCountry());

		UAASOtpInfo otpInfo = setUAASOtpInfo(creditCardDto.getPinChangeDto());

		ClientInfo clientInfo = new ClientInfo();

		uaasRequest.setUser(user);
		uaasRequest.setCardInfo(cardInfo);
		uaasRequest.setTxnInfo(txtInfo);
		uaasRequest.setOtpInfo(otpInfo);
		uaasRequest.setClientInfo(clientInfo);
		return uaasRequest;

	}

	/**
	 * 
	 * @param country
	 * @return
	 */
	protected UAASTransactionInfo setTransactionInfo(String country) {

		UAASTransactionInfo transactionInfo = new UAASTransactionInfo();

		String countryZone = timeZoneMap.get(country.toUpperCase());

		TimeZone timeZone = TimeZone.getDefault();
		if (countryZone != null) {
			timeZone = TimeZone.getTimeZone(countryZone);
			if (timeZone == null) {
				timeZone = TimeZone.getDefault();
			}
		}
		Calendar calendar = Calendar.getInstance(timeZone);

		SimpleDateFormat timeStampFormatter = new SimpleDateFormat(CardConstant.UAAS_TXN_TIME_STAMP_FORMAT);
		timeStampFormatter.setTimeZone(timeZone);
		transactionInfo.setTxnLocalDateTime(timeStampFormatter.format(calendar.getTime()));

		SimpleDateFormat dateFormatter = new SimpleDateFormat(CardConstant.UAAS_TXN_DATE_FORMAT);
		// dateFormat.setTimeZone(timeZone);
		transactionInfo.setTxnDate(dateFormatter.format(calendar.getTime()));

		SimpleDateFormat timeFormatter = new SimpleDateFormat(CardConstant.UAAS_TXN_TIME_FORMAT);
		// timeFormat.setTimeZone(timeZone);
		transactionInfo.setTxnTime(timeFormatter.format(calendar.getTime()));
		log.info("TransactionTime :: Localdate :: " + transactionInfo.getTxnLocalDateTime() + ":: Server Txndate ::"
				+ transactionInfo.getTxnDate() + ":: Serve Txntime :: " + transactionInfo.getTxnTime());
		return transactionInfo;
	}

	/**
	 * 
	 * @param country
	 * @return
	 */
	public String getLocalTimeAndDate(String country, String format) {
		
		String countryZone = timeZoneMap.get(country.toUpperCase());
		
		String txtInfo= "";

		TimeZone timeZone = TimeZone.getDefault();
		if (countryZone != null) {
			timeZone = TimeZone.getTimeZone(countryZone);
			if (timeZone == null) {
				timeZone = TimeZone.getDefault();
			}
		}
		Calendar calendar = Calendar.getInstance(timeZone);
		SimpleDateFormat timeStampFormatter = new SimpleDateFormat();
		
		if (format.equalsIgnoreCase(CardConstant.TXN_INFO_DATE_FORMAT))

			timeStampFormatter = new SimpleDateFormat(CardConstant.UAAS_TXN_TIME_STAMP_FORMAT);
		else if (format.equalsIgnoreCase(CardConstant.EMAIL_HEADER_DATE_FORMAT_INFO))
			timeStampFormatter = new SimpleDateFormat(CardConstant.EMAIL_HEADER_DATE_FARMAT);
		else
			timeStampFormatter = new SimpleDateFormat(CardConstant.MESSAGE_TEMPLATE_DATE_FORMAT);
		
		timeStampFormatter.setTimeZone(timeZone);
		txtInfo = timeStampFormatter.format(calendar.getTime());
		
		log.info("TransactionTime :: LocalTimedate :: " + txtInfo);
		return txtInfo;
	}
	/**
	 * @param uaasServiceProperties
	 * @param clientRequestId
	 * @return
	 */
	protected UAASUserInfo setUAASUserInfo(UAASServiceProperties uaasServiceProperties,
			CSLRequestContext cslRequestContext) {
		UAASUserInfo user = new UAASUserInfo();

		user.setAppId(uaasServiceProperties.getAppId());
		user.setApiKey(uaasServiceProperties.getApiKey());

		user.setGroupId(cslRequestContext.getCountry());
		user.setUserId(cslRequestContext.getUaas2id());
		user.setClientRequestId(getFormattedClientRequestId(cslRequestContext.getRequestId()));

		return user;
	}

	/**
	 * @param set
	 *            card info for UAAS Request
	 * @return
	 */
	protected CardInfo setCardInfo(CreditCardDto creditCardDto, String country) {
		CardInfo cardInfo = new CardInfo();
		cardInfo.setCardSequenceNo(creditCardDto.getSeqNo());
		cardInfo.setCardType(creditCardDto.getPinChangeDto().getCardType());
		cardInfo.setEncCardPin(creditCardDto.getPinChangeDto().getEncCardPin());
		cardInfo.setEncCardInfo(creditCardDto.getPinChangeDto().getEncCardInfo());
		cardInfo.setKeyIndex(creditCardDto.getPinChangeDto().getPinKeyIndex());
		cardInfo.setTxnRefNo(getTransactionRefNumber(country));

		/**
		 * Set Card Activation as YES only for POST login Card Activation and
		 * for C400 countries alone
		 */
		if (CardConstant.CONS_YES.equalsIgnoreCase(creditCardDto.getPinChangeDto().getCardActivationFlag())
				&& !CardConstant.CCMS_COUNTRY_LIST.contains(country)
				&& CardConstant.OPERATION_CC_PINACTIV.equalsIgnoreCase(creditCardDto.getOperationName())) {
			cardInfo.setCardActivationFlag(CardConstant.CONS_Y);
		}
		return cardInfo;
	}

	/**
	 * 
	 * @param pinChangeDto
	 * @return
	 */
	protected UAASOtpInfo setUAASOtpInfo(PinChangeDto pinChangeDto) {
		UAASOtpInfo otpInfo = new UAASOtpInfo();
		otpInfo.setOtpSn(pinChangeDto.getOtpInfo().getOtpSn());
		otpInfo.setEncOtp(pinChangeDto.getOtpInfo().getEncOtp());
		otpInfo.setKeyIndex(pinChangeDto.getOtpInfo().getKeyIndex());
		return otpInfo;
	}

	/**
	 * @param Get
	 *            UAAS Error Codes from properties
	 * @return
	 */

	public Map<String, String> getUAASErrorCodes() {
		Map<String, String> errorCodes = new HashMap<String, String>();
		errorCodes = getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL).getUaasErrorCodes();
		return errorCodes;
	}

	/**
	 * 
	 * @param countryCode
	 * @return
	 */
	private CreditCardProperties getCreditCardPropertiesByCountry(String countryCode) {
		CreditCardProperties countryProp = (CreditCardProperties) getValuePropertiesByKey(creditCardProperties,
				StringUtils.upperCase(countryCode));
		if (CardUtil.isEmptyOrNull(countryProp)) {
			throw new TechnicalException(TemplateErrorCode.create(
					CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Country Mapping Properties", "Not Found"));
		}
		return countryProp;
	}

	private Object getValuePropertiesByKey(Map<?, ?> map, String key) {
		return CardUtil.getValueByKey(map, key);
	}

	/**
	 * @param Get
	 *            Transaction Ref Number Formate 1 to 4 - MMDD (0213) 5 to 10 -
	 *            HHMMSS (145522) 11 to 15 - Running sequence number (12345)
	 *            ex:021314552212345
	 * @return
	 */

	protected String getTransactionRefNumber(String country) {

		String txnRefNo = null;
		String sequenceNum = StringUtils.leftPad(Long.toString(sequenceNo), 5, "0");
		sequenceNo++;

		String countryZone = timeZoneMap.get(country.toUpperCase());

		TimeZone timeZone = TimeZone.getDefault();
		if (countryZone != null) {
			timeZone = TimeZone.getTimeZone(countryZone);
			if (timeZone == null) {
				timeZone = TimeZone.getDefault();
			}
		}
		Calendar calendar = Calendar.getInstance(timeZone);
		SimpleDateFormat dateStampFormatter = new SimpleDateFormat("MMdd");
		String dateFormat = dateStampFormatter.format(calendar.getTime());

		SimpleDateFormat timeStampFormatter = new SimpleDateFormat("HHmmss");
		String timeFormat = timeStampFormatter.format(calendar.getTime());

		txnRefNo = dateFormat + timeFormat + sequenceNum;
		log.info("TransactionREFNO :: " + txnRefNo);

		return txnRefNo;
	}

	/**
	 * 
	 * @param creditCardDto
	 * @return
	 */
	public EncryptedData constructCardDecryptRequest(CreditCardDto creditCardDto) {
		EncryptedData encryptedData = new EncryptedData();
		encryptedData.setEncData(creditCardDto.getCardActivationDto().getEncData());
		encryptedData.setKeyIndex(creditCardDto.getCardActivationDto().getKeyIndex());
		encryptedData.setChannel(CardConstant.DEFAULT_CHANNEL);
		return encryptedData;
	}

}
