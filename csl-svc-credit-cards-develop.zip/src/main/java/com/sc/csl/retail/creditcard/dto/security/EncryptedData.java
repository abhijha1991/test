package com.sc.csl.retail.creditcard.dto.security;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@Data
@JsonApiResource(type = "decryptor")
public class EncryptedData {
    @JsonApiId
    private String requestId;
    
    private String country;
    private String channel;
    private String language;

    @JsonProperty("enc-data")
    private String encData;
    private String keyIndex;
    private String decData;
    private String userId;
    

    private String statusCode;
    private String errorMessage;
}
