package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@JsonApiResource(type = "card-customer")
public class CardCustDto extends BaseDto {

    @JsonApiId
    private String cardNo;

    @JsonProperty("credit-card-no")
    private String creditCardNo;

    @JsonProperty("customer-id")
    private String customerId;

    @JsonProperty("customer-id-type")
    private String customerIdType;

    @JsonProperty("customer-id-no")
    private String customerIdNo;
}

