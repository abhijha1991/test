package com.sc.csl.retail.creditcard.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardEligibilityCriteriaDao;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dao.CreditCardTransactionEDMPDao;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionsEDMPDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.dto.TransactionAsyncDto;
import com.sc.csl.retail.creditcard.dto.post.CCFeeWaiverPostDto;
import com.sc.csl.retail.creditcard.dto.post.CreditCardPostDto;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestSPV1Gateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CCFeeWaiverEligibilityUtility;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.EncryptionDecryptionHelper;
import com.sc.csl.retail.creditcard.helper.ReconcileRewardPoint;
import com.sc.csl.retail.creditcard.helper.ReconcileTransaction;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.csl.retail.creditcard.dto.UserInfo;

/**
 * @author 1553836 Sinha, Shantanu Aug-17
 */
/**
 * @author 1553836
 *
 */
@Slf4j
@Service
public class CreditCardFeeWaiverService {

	@Autowired
	private CreditCardService creditCardService;
	@Autowired
	private CardUtil cardUtil;
	@Autowired
	private EncryptionDecryptionHelper encryptDecryptHelper;
	@Autowired
	private ReconcileTransaction reconcileTransaction;
	@Autowired
	private ReconcileRewardPoint reconcileRewardPoint;
	@Autowired
	private CCFeeWaiverEligibilityUtility ccFeeWaiverEligibilityUtility;
	@Autowired
	CreditCardRepositoryDao ccDao;
	@Autowired
	private MapperFacade orikaMapper;
	@Autowired
	protected ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
	@Autowired
	private CreditCardEligibilityCriteriaDao eligibilityDao;
	@Autowired
	private CreditCardTransactionEDMPDao transDao;
	@Autowired
	private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
	@Autowired
	private CreditCardValidator creditCardValidator;
	@Autowired
	protected CSLRequestContext cslRequestContext;
	@Autowired
	private CCFeeWaiverAsyncService ccFeeWaiverAsyncService;
	@Autowired
	private ServiceRequestSPV1Gateway spv1Gateway;

	/**
	 * This method will get invoked if the request is from any channel other
	 * than IVR Channel
	 * 
	 * @param creditCardVO
	 * @return
	 */
	@SuppressWarnings("static-access")
	public List<CreditCardDto> getAllActiveCreditCards(CreditCardVO creditCardVO) {

		log.info("[CreditCardFeeWaiverService getAllActiveCreditCards Entered] ");

		final List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
		//GetCardList - to pull all cards at customer level.
		List<CreditCardDto> creditcardDtolist = creditCardService
				.getAllCreditCards(creditCardVO);
		String isCardMaskingRequired=getCardMaskRequiredStatus(creditCardVO.getCountryCode());
		CreditCardProperties ccProps = cardUtil.getCreditCardPropertiesBean();
		creditcardDtolist
				.forEach(creditCardDto -> {
					creditCardDto.setCustomerId(creditCardVO.getCustomerId());
					creditCardDto.setActiveCards(creditCardVO.getActiveCards());
					creditCardDto.setSrName(creditCardVO.getSrName());
					if(CardConstant.CONS_Y.equalsIgnoreCase(isCardMaskingRequired)){
						String encryptedCardNumber = encryptDecryptHelper
								.performEncryptDecrypt(6, 4,
										creditCardDto.getCardNum(),
										CardConstant.ENCRYPT,
										creditCardVO.getCustomerId());
						creditCardDto.setCardNum(encryptedCardNumber);
					}
					creditCardDto.setIsMaskCardNo(isCardMaskingRequired);
					if(cardUtil.isEmptyOrNull(creditCardDto.getCardType())){
						creditCardDto.setCardType(CardUtil.getOriginalCardType(creditCardDto.getCardNum(), ccProps.getCreditCardFilters().getCardTypes()));
			        }
					validateBusinessRules(creditCardDto, creditCardVO,
							activeCreditCardList);

				});

		if (activeCreditCardList.size() == CardConstant.ZERO) { // Business
																// Exception
			CreditCardDto returnCreditCardDto = new CreditCardDto();
			returnCreditCardDto.setCustomerId(creditCardVO.getCustomerId());
			returnCreditCardDto.setActiveCards(creditCardVO.getActiveCards());
			returnCreditCardDto.setSrName(creditCardVO.getSrName());
			returnCreditCardDto.setIsMaskCardNo(isCardMaskingRequired);
			returnCreditCardDto
					.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS);
			returnCreditCardDto
					.setErrorDescription(CardConstant.CC_FEE_WAIVER_ERR_MSG_NO_ACTIVE_CARDS);
			activeCreditCardList.add(returnCreditCardDto);
		}

		log.info("[CreditCardFeeWaiverService getAllActiveCreditCards Exit][ activeCreditCardList size] "
				+ activeCreditCardList.size()+"] Mask Required["+isCardMaskingRequired+"]");

		return activeCreditCardList;
	}
	/**This method is used to fetch the country level card no masking required or not.
	 * @param countryCode
	 * @return Y/N
	 */
	public String getCardMaskRequiredStatus(String countryCode) {
		SRParamDto inputParam=new SRParamDto();
		inputParam.setCountryCode(countryCode);
		inputParam.setParamId(CardConstant.ID_PARAM_I0006);
		inputParam.setParamKey1(CardConstant.CARD_NO_MASK_REQ);
		log.info("DAO Object :" +ccDao);
		
		List<SRParamDto> parmList = CardUtil.loadSrParamByObject(inputParam,ccDao);
				
		String output = parmList.get(CardConstant.ZERO).getParamData1();
		
		return  output;
	}

	/**
	 * This method will get invoked if the request is from IVR Channel
	 * 
	 * @param creditCardVO
	 * @return
	 */
	public CreditCardDto getCreditcardTransactionsAndRewardPointIVR(
			CreditCardVO creditCardVO) {

		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPointIVR Entered] ");

		CreditCardDto creditcardDto = null;
		List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
		List<CreditCardDto> creditcardTransAndRewardList = null;

		creditcardDto = creditCardService.findOneCreditCard(creditCardVO);
		activeCreditCardList = validateBusinessRules(creditcardDto,
				creditCardVO, activeCreditCardList);
		if (activeCreditCardList.size() == CardConstant.ZERO) { // Business
																// Exception
			CreditCardDto returnCreditCardDto = new CreditCardDto();
			returnCreditCardDto.setCustomerId(creditCardVO.getCustomerId());
			returnCreditCardDto.setActiveCards(creditCardVO.getActiveCards());
			returnCreditCardDto
					.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS);
			returnCreditCardDto
					.setErrorDescription(CardConstant.CC_FEE_WAIVER_ERR_MSG_NO_ACTIVE_CARDS);
			activeCreditCardList.add(returnCreditCardDto);
		}
		if (activeCreditCardList.get(CardConstant.ZERO).getErrorCode()
				.equalsIgnoreCase(CardConstant.PAD_EMPTY)) {
			creditcardTransAndRewardList = getCreditcardTransactionsAndRewardPoint(creditCardVO);
		} else {
			creditcardTransAndRewardList = new ArrayList<CreditCardDto>();
			creditcardTransAndRewardList.add(activeCreditCardList
					.get(CardConstant.ZERO));
		}

		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPointIVR Exit] ");

		return creditcardTransAndRewardList.get(0);
	}

	private List<CreditCardDto> validateBusinessRules(
			CreditCardDto creditCardDto, CreditCardVO creditCardVO,
			List<CreditCardDto> activeCreditCardList) {
		CreditCardFeeWaiverProperties props = getBean();
		if (!creditCardDto.getBlockCode().equalsIgnoreCase(props.getBlockCode())) {
			if ((props.getActiveStatusCode()).contains(creditCardDto
					.getCardStatus())) {
				activeCreditCardList.add(creditCardDto);
			}
		}
		return activeCreditCardList;
	}

	/**
	 * This method will return the country specific credit card property bean
	 * 
	 * @return props
	 */
	public CreditCardFeeWaiverProperties getBean() {
		
		CreditCardFeeWaiverProperties props = null;
		if(cardUtil.getCreditCardPropertiesBean() != null){
			props = (CreditCardFeeWaiverProperties) cardUtil
					.getCreditCardPropertiesBean().getCreditCardFeeWaiverProps();
			
		}
		return props;
	}

	/**
	 * This method will get invoked if the request is from Any Channel Except
	 * IVR directly
	 * 
	 * @param creditcardvo
	 *            - Input from UI.
	 * @return CreditCardList
	 */
	@SuppressWarnings("unchecked")
	public List<CreditCardDto> getCreditcardTransactionsAndRewardPoint(
			CreditCardVO creditcardvo) {

		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint Entered] [Customer Id: "
				+ creditcardvo.getCustomerId() + "]");
		List<CreditCardDto> CreditCardList = null;
		CreditCardList = new ArrayList<CreditCardDto>();
		List<CreditCardTransactionDto> unBilledtransactionList = null;
		List<CreditCardTransactionDto> reconciledTransactionList = null;
		List<CreditCardTransactionDto> edmp12MonthTransactions = null;
		List<CreditCardTransactionDto> statemantedTransaction = null;
		List<CreditCardTransactionDto> ccmsC400Transactions = null;
		List<CreditCardTransactionDto> eligibilityList = null;
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		CreditCardDto creditcardDto = null;
		String cardNumbersArray[];
		String cardNumbers;
		//EDMP conn attribute set - to pull the data from primary db.
		journeyMap.put(CardConstant.KEY_EDMP_CONFIG,CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY);
		String isCardMaskingRequired ="Y";
		
		cardNumbers = creditcardvo.getCardNo();
		cardNumbersArray = cardNumbers.split(",");
		if(journeyMap.get(CardConstant.CARD_NO_MASK_REQ)==null){
			 isCardMaskingRequired=getCardMaskRequiredStatus(creditcardvo.getCountryCode());
			 journeyMap.put(CardConstant.CARD_NO_MASK_REQ,isCardMaskingRequired);
		}
		//to pull the fee type related description [Narration, Tran code] and other detail from DB.
		SRParamDto param = getTxnDetails(creditcardvo.getCountryCode(), creditcardvo.getFeeType());
		journeyMap.put(CardConstant.KEY_PARAM_DTO, param);
		CreditCardFeeWaiverProperties props = getBean();
		//for duplicate check from Eops.
		Map<String, String> srStatusMap = fetchServiceRequestFromEops(creditcardvo, cardNumbersArray, param.getParamData1(),props); 

		for (String cardno : cardNumbersArray) {
			creditcardvo.setCardNo(cardno);
			creditcardDto = new CreditCardDto();
			
			if(isCardMaskingRequired.equalsIgnoreCase(CardConstant.CONS_Y)){
				String decryptedCardNumber = encryptDecryptHelper
						.performEncryptDecrypt(6, 4, creditcardvo.getCardNo(),
								CardConstant.DECRYPT, creditcardvo.getCustomerId());
				creditcardvo.setCardNo(decryptedCardNumber);
			}
			
			if(!CardUtil.isEmptyOrNull(srStatusMap.get(creditcardvo.getCardNo()))){
				log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint ] [Customer Id: "
						+ creditcardvo.getCustomerId() + "] [Eops - Duplicate transaction found ] [Card No"+cardno+"]");
				creditcardDto.setCardNum(creditcardvo.getCardNo());
				setErrorMessage(creditcardDto, CardConstant.CC_FEE_WAIVER_ERR_CD_DUPLICATE, CardConstant.CC_FEE_WAIVER_ERR_MSG_DUPLICATE);
			}
			else{
				log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint ] [Customer Id: "
						+ creditcardvo.getCustomerId() + "] [Eops - NO Duplicate transaction found ] [Card No"+cardno+"]");
				/*// To fetch the card related details form CCMS/C400 [GetDetail - CC Enquiry]
				creditcardDto = creditCardEnquiryV1SoapGateway
						.getCreditCard(creditcardvo);
				journeyMap.put(CardConstant.KEY_CARD_DETAILS, creditcardDto);*/
				
				//get all cards against a card to get the primary and supp status of a card.
				List<CreditCardDto> creditcardDtolist=new ArrayList<CreditCardDto>();
				if (null == journeyMap.get(CardConstant.KEY_CC_LIST)) {
					 creditcardDtolist = creditCardService
							.getAllCreditCards(creditcardvo);
					 journeyMap
						.put(CardConstant.KEY_CC_LIST, creditcardDtolist);
				} else if (null != journeyMap.get(CardConstant.KEY_CC_LIST)) {
					creditcardDtolist = (List<CreditCardDto>) journeyMap
							.get(CardConstant.KEY_CC_LIST);
				}
				for (Iterator<CreditCardDto> iter = creditcardDtolist.listIterator(); iter.hasNext();) {
					creditcardDto = iter.next();
					if ((creditcardDto).getCardNum().equalsIgnoreCase(
							creditcardvo.getCardNo())) {
						break;
					}
				}
				
				//creditcardDto.setIsPrimary(creditcardvo.getIsPrimary());
				//creditcardDto.setCardNum(creditcardvo.getCardNo());
				
				creditcardDto.setEligibleFeeWaiver(creditcardvo
						.getEligibleFeeWaiver());
				creditcardDto.setFeeType(creditcardvo.getFeeType());
				creditcardDto.setCardNumbers(cardNumbers);
				creditcardvo.setCardType(creditcardDto.getDesc());
				creditcardvo.setCardTypeCode(creditcardDto.getDescCode());
				creditcardvo.setTxtCurrCode(creditcardDto.getCurrencyCode());
				
				//CreditCardFeeWaiverProperties props = getBean();
				//to pull the transaction refresh date from EDMP
				//this method pulls the data from primary HBase cluster, if unable to connect then connect to DR box to pull the data and subsequent EDMP process
				//uses the DR connection.
				transDao.getTxnRefreshdate(journeyMap, props);
				Date edmpTransactionrefreshDate = (Date) journeyMap
						.get(CardConstant.KEY_EDMP_TRANC_BATCH_DT);
				//to pull the latest eligibility loaded date from EDMP.
				eligibilityDao.getEligibilityRefreshdate(journeyMap, props);
				Date edmpRAEligibilityRefreshDate = (Date) journeyMap
						.get(CardConstant.KEY_EDMP_ELIGIBILITY_BATCH_DT);
				// Checking for the eligible card type for the selected fee type [configured in yml]
				// Ineligible card types are not allowed to be take the Service Request.
				if (props.getInEligCardTypeForFeeTypes()
						.get(creditcardvo.getFeeType()) == null || !props.getInEligCardTypeForFeeTypes().get(creditcardvo.getFeeType())
						.contains("'"+creditcardvo.getCardType()+"'")) {
					//country level check
					//String rewardEligibleForCountry=getCountryRewardEligibility(creditcardvo);
					//to pull the Reward related info. [Param table].
	//				if(rewardEligibleForCountry.equalsIgnoreCase(CardConstant.CONS_Y)){
						getReconcilationParams(props, creditcardvo, journeyMap);
	//				}
	//				else{
	//					journeyMap.put(CardConstant.REWARD_POINT_REQUIRED,false);
	//				}
						
					//journeyMap.put(CardConstant.UNPROCESSED_TRANC, unprocessedTransactions);
					//LPA2 validation. [duplicate check against CCMS for the unprocessed records posted by today and batch is not yet started]
					fetchUnprocessedCCMSTransactions(props,creditcardvo,journeyMap);
					List<CreditCardTransactionDto> unprocessedTransactions = (List<CreditCardTransactionDto>) journeyMap.get(CardConstant.UNPROCESSED_CREDIT_TRANC);
	
					if(unprocessedTransactions.size()==CardConstant.ZERO)
					{
							//to get the transactions from EDMP for the selected fee type.
							edmp12MonthTransactions = findAllTransactionsFromEDMP(
									creditcardvo, creditcardDto, journeyMap, props);
							
							log.info("List of transactions [From EDMP] ["+edmp12MonthTransactions+"]  for the selected Fee type  ["+creditcardvo.getFeeType()+"]");
							
							creditcardvo.setStartPageNumber(CardConstant.START_PAGE_01);
							creditcardvo.setFunctionCd(CardConstant.FUNC_CD_U);
							creditcardvo.setNavIndicator(CardConstant.CONS_Y);
							
							//to get the transaction from CCMS / C400 system. [to pull unbilled]
							try{
								ccmsC400Transactions = creditCardService
										.findCreditCardTransactions(creditcardvo);
							}
							//To Handle the business exceptions when there is no transaction available
							catch(BusinessException ex){
								ccmsC400Transactions=new ArrayList<CreditCardTransactionDto>();
								log.info("No Unbilled-transactions found in CCMS System");
							}
							
							unBilledtransactionList = new LinkedList<CreditCardTransactionDto>();
							eligibilityList = new ArrayList<CreditCardTransactionDto>();
							log.info("Date pulled from EDMP - Tran Batch Dt["+edmpTransactionrefreshDate+"] RA Refresh Dt["+edmpRAEligibilityRefreshDate+"]");
							log.info("List of transactions from CCMS / C400 ["+ccmsC400Transactions+"]  UnBilled ["+unBilledtransactionList+"] ");
							
						boolean isStatementedTransactionRequired = true;
						statemantedTransaction = validateCCSystemTransactions(
								creditcardvo, unBilledtransactionList,
								statemantedTransaction, ccmsC400Transactions,
								eligibilityList, isStatementedTransactionRequired,
								edmpTransactionrefreshDate,
								edmpRAEligibilityRefreshDate,null);
							
							//actual debit and credit recon. process.
							reconciledTransactionList = reconcileTransaction
									.getReconciledTransaction(unBilledtransactionList,edmp12MonthTransactions,statemantedTransaction, creditcardvo,
											journeyMap, creditcardDto);
							
							log.info("List of transactions from CCMS / C400 - Recon Tran List ["+reconciledTransactionList+"] Stmt Trans ["+statemantedTransaction+"]");
							
							//building error messages.
							if ((reconciledTransactionList.size() == CardConstant.SIZE_ONE) && (!CardUtil.isEmptyOrNull(reconciledTransactionList.get(CardConstant.ZERO)
											.getErrorCode()))) {
	
								log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint() - No data validation ...] ");
	
								if (reconciledTransactionList.get(CardConstant.ZERO).getErrorCode().equalsIgnoreCase(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT)) {
									setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT,CardConstant.CC_FEE_WAIVER_MSG_CD_NO_DEBIT);
								}
								else if (reconciledTransactionList.get(0).getErrorCode().equalsIgnoreCase(CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED)) {
									setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED,CardConstant.CC_FEE_WAIVER_ERR_MSG_ALL_TRANC_PROCESSED);
								}
							} else {
								log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint() - about to do the Eligibility and Reward Point validation...] ");
								
								//validate against EDMP
								checkEligibilityandRewardPoint(reconciledTransactionList,eligibilityList, journeyMap, creditcardDto,creditcardvo, props);
							}
					}
					else{
						log.info("Duplicate Unprocessed transaction found in CCMS ["+creditcardvo.getCardType()+"]");
						setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_DUPLICATE,CardConstant.CC_FEE_WAIVER_ERR_MSG_DUPLICATE);
					}
				}else {
					log.info("Card Type-not Eligible for Selected type of Fee for Reversal.......["+creditcardvo.getCardType()+"]");
					setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_CARD_NOT_ELIGIBLE,CardConstant.CC_FEE_WAIVER_ERR_MSG_CARD_NOT_ELIGIBLE);
				}
			}
			if(isCardMaskingRequired.equalsIgnoreCase(CardConstant.CONS_Y)){
				String encryptedCardNum = encryptDecryptHelper.performEncryptDecrypt(6, 4, creditcardDto.getCardNum(),CardConstant.ENCRYPT, creditcardvo.getCustomerId());
				creditcardDto.setCardNum(encryptedCardNum);
			}
			//
			//Setting Up filter Properties
			setFilterProperties(creditcardvo, creditcardDto, cardNumbers, isCardMaskingRequired);
			
//			if(!CardUtil.isEmptyOrNull(creditcardDto.getCardtransactions())){
//				creditcardDto.setTransactions(creditcardDto.getCardtransactions());
//			}
			
			CreditCardList.add(creditcardDto);

		}
		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint Exit] ");
		return CreditCardList;
	}
	/**
	 * @param creditcardvo
	 * @param creditcardDto
	 * @param cardNumbers
	 */
	private void setFilterProperties(CreditCardVO creditcardvo,
			CreditCardDto creditcardDto, String cardNumbers , String isCardMaskingRequired) {
		creditcardDto.setEligibleFeeWaiver(creditcardvo
				.getEligibleFeeWaiver());
		creditcardDto.setFeeType(creditcardvo.getFeeType());
		creditcardDto.setCardNumbers(cardNumbers);
		creditcardDto.setIsMaskCardNo(isCardMaskingRequired);
		
		if(creditcardDto.getCreditCardEligibility() != null){
			if(CardConstant.CONS_Y.equalsIgnoreCase(creditcardDto.getCreditCardEligibility().getCardEligibilityFlag())){
				creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_YES);
			}else{
				creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_NO);
			}
			log.info("[CreditCardFeeWaiverService getCreditcardTransactionsAndRewardPoint] [Eligible Flag ...:"+creditcardDto.getCreditCardEligibility().getCardEligibilityFlag()+"]");
		}
	}

	/**This method id to check the at country level whether Reward redemption is available or not.
	 * @param creditcardvo
	 * @return 'Y'/'N'
	 */
	private String getCountryRewardEligibility(CreditCardVO creditcardvo) {

		SRParamDto inputParam = new SRParamDto();
		List<SRParamDto> paramList= null;
		inputParam.setCountryCode(creditcardvo.getCountryCode());
		inputParam.setParamId(CardConstant.ID_PARAM_I0004);
		inputParam.setParamKey1(CardConstant.COUNTRY_REWARD_ENABLED);
		paramList = CardUtil.loadSrParamByObject(inputParam,
				ccDao);
		SRParamDto paramDto = paramList.get(CardConstant.ZERO);
		return paramDto.getParamData1();
		
	}

	/**
	 * @param creditcardDto
	 * @param errorMessage 
	 * @param errorCode 
	 */
	public void setErrorMessage(
		CreditCardDto creditcardDto, String errorCode, String errorMessage) {
		CreditCardTransactionDto errorHandlingcctransDto= new CreditCardTransactionDto();
		List <CreditCardTransactionDto> errorHandlingtransList=new ArrayList<CreditCardTransactionDto>();
		creditcardDto.setErrorCode(errorCode);
		creditcardDto.setErrorDescription(errorMessage);
		errorHandlingcctransDto.setTxnRefNo(creditcardDto.getCardNum());
		errorHandlingtransList.add(errorHandlingcctransDto);
		creditcardDto.setCardtransactions(errorHandlingtransList);
//		creditcardDto.setTransactions(errorHandlingtransList);
	}

	/**
	 * @param props
	 * @param creditcardvo
	 * @param journeyMap
	 * Checks for the unprocessed transactions at card level and checks whether any unprocessed credit is available or not
	 */
	public void fetchUnprocessedCCMSTransactions(
			CreditCardFeeWaiverProperties props, CreditCardVO creditcardvo,
			Map<String, Object> journeyMap) {
		
		log.info("CreditCardFeeWaiver Service-FetchUnprocessedTransactions [LPA2]..................");
		
		creditcardvo.setStartPageNumber(CardConstant.START_PAGE_01);
		creditcardvo.setFunctionCd(CardConstant.FUNC_CD_LPA);
		creditcardvo.setStatementType(CardConstant.STMT_CD_01);
		List<CreditCardTransactionDto> unprocessedCreditTransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> unprocessedDebitTransactionList = new ArrayList<CreditCardTransactionDto>();

		if(CardConstant.CONS_Y.equalsIgnoreCase(props.getCcmsDuplicateChekRequired())){
			try{
				
				List<CreditCardTransactionDto> ccmsC400Transactions = creditCardService.findCCMSUnprocessedCCTransactions(creditcardvo);
				if (CardConstant.CONTRY_HK.equalsIgnoreCase(creditcardvo.getCountryCode())) {
					List<String> listOfCreditNarrations  = getHKTrasactionDesc(journeyMap);
					ccmsC400Transactions.forEach(creditCardTransactionDto -> {
						if (props.getCreditTransactionsCodes().contains(creditCardTransactionDto.getTxnCode()) &&
								isCreditDbitDescMatching(listOfCreditNarrations,creditCardTransactionDto.getDesc(),true)) {
							unprocessedCreditTransactionList.add(creditCardTransactionDto);
						}
					});
					
				} else {
					SRParamDto param = (SRParamDto) journeyMap.get(CardConstant.KEY_PARAM_DTO);
					String paymentCreditcode = param.getParamData4();
					String truncCreditNarration = param.getParamData9();
					String nonpaymentCreditcode;
					if (null != param.getParamData5()) {
						 nonpaymentCreditcode = param.getParamData5();
					}
					else {
						 nonpaymentCreditcode = CardConstant.PAD_EMPTY;
					}
					
					String debitCode = param.getParamData2();
					String dNarration = param.getParamData3();
					
					//to validate credit tran code and narration.
					ccmsC400Transactions.forEach(creditCardTransactionDto -> {
						if((paymentCreditcode.equals(creditCardTransactionDto
								.getTxnCode()) || (nonpaymentCreditcode
								.equals(creditCardTransactionDto.getTxnCode())))
								&& creditCardTransactionDto.getDesc().toUpperCase()
										.contains(truncCreditNarration)){
							unprocessedCreditTransactionList.add(creditCardTransactionDto);}
						
						//To fetch Unprocessed Debit Transaction(s).Future use.
						if((debitCode.equals(creditCardTransactionDto
								.getTxnCode()))
								&& creditCardTransactionDto.getDesc().toUpperCase()
										.contains(dNarration)){
							unprocessedDebitTransactionList.add(creditCardTransactionDto);}
						
					});
				}
				
			}catch(BusinessException be){
				log.info("CreditCardFeeWaiver Service - No Data found for LPA2 transaction...");
			}catch(Exception ep){
				log.debug("[Error in fetching of duplicate transaction [LPA2 - fetchUnprocessedCCMSTransactions].......]");
			}
		}else{
			log.debug("[CCMS duplicate validation disabled.....]");
		}
		
		journeyMap.put(CardConstant.UNPROCESSED_CREDIT_TRANC,unprocessedCreditTransactionList);
		journeyMap.put(CardConstant.UNPROCESSED_DEBIT_TRANC, unprocessedDebitTransactionList);
		
		log.info("CreditCardFeeWaiver Service-FetchUnprocessedTransactions using [LPA2] completed...");
	}

	/**
	 * To pull the statement and unstatement record from CCMS system for recon purpose.
	 * @param creditcardvo
	 * @param unBilledtransactionList
	 * @param statemantedTransaction
	 * @param ccmsC400Transactions
	 * @param eligibilityList
	 * @param isStatementedTransactionRequired
	 * @param edmpTransactionrefreshDate
	 * @param edmpRAEligibilityRefreshDate
	 * @return
	 */
	public List<CreditCardTransactionDto> validateCCSystemTransactions(CreditCardVO creditcardvo,List<CreditCardTransactionDto> unBilledtransactionList,
			List<CreditCardTransactionDto> statemantedTransaction,List<CreditCardTransactionDto> ccmsC400Transactions,	List<CreditCardTransactionDto> eligibilityList,
			boolean isStatementedTransactionRequired,Date edmpTransactionrefreshDate, Date edmpRAEligibilityRefreshDate,
			List<CompletableFuture<TransactionAsyncDto>> creditCardsFutureList) {
		
		log.info("Entered in validateCCSystemTransactions.....");
		boolean isUnbilledTransactionsExists=false;
		
		Iterator<CreditCardTransactionDto> transactions = ccmsC400Transactions
				.iterator();
		
		while (transactions.hasNext()) {
			isUnbilledTransactionsExists=true;
			CreditCardTransactionDto transactionDto = transactions
					.next();
			log.info("Entered in validateCCSystemTransactions.....CCMS - Txn Dt["+transactionDto.getTxnDate()+"]");

			if(CardUtil.isEmptyOrNull(transactionDto.getTxnDate())) continue;
			
			if(CardUtil.isEmptyOrNull(transactionDto.getTxnCode())) {
				transactionDto.setTxnCode(transactionDto.getTransactionCode());
			}
			transactionDto.setTxnCurr(creditcardvo.getTxtCurrCode());
				
			String date = cardUtil.formatStringDate(transactionDto.getTxnDate(),CardConstant.CCMS_DATE_FORMAT1,CardConstant.REQ_DATE_FORMAT);
			Date transactionDt = cardUtil.formatDate(CardConstant.DATE_FORMAT,transactionDto.getTxnDate());
			
			transactionDto.setTxnDate(date);
			transactionDto.setTransactionDt(transactionDt);
			
			// if EDMP transaction refresh date is before the
			// transaction date then those transactions to be considered
			log.info("CCFEEW validateCCSystemTransactions edmpTxnRefreshDate ["+edmpTransactionrefreshDate+"]");
			log.info("CCFEEW validateCCSystemTransactions ccmsTxnDate ["+transactionDt+"]");
			if(null != edmpTransactionrefreshDate && null != transactionDt){ /// refresh date 4th, transaction date 4th
				if (edmpTransactionrefreshDate.before(transactionDt)) {
					unBilledtransactionList.add(transactionDto);
				}
				// if EDMP RA BAse refresh date is before the transaction
				// date then those transactions to be considered.
				if(null != edmpRAEligibilityRefreshDate && null != transactionDt)
				if (edmpRAEligibilityRefreshDate.before(transactionDt)) {
					eligibilityList.add(transactionDto);
				} else if (edmpTransactionrefreshDate.after(transactionDt)
						|| edmpRAEligibilityRefreshDate
								.after(transactionDt)) {
					isStatementedTransactionRequired = false;
					log.info("CCFEEW validateCCSystemTransactions Billed Transaction is not required");
				}
			}		
		}
		log.info("CCFEEW validateCCSystemTransactions isUnbilledTransactionsExists ["+isUnbilledTransactionsExists+"]");
		log.info("CCFEEW validateCCSystemTransactions isStatementedTransactionRequired ["+isStatementedTransactionRequired+"]");
		// To fetch the statemented data from CCMS/C400
		if (isStatementedTransactionRequired || (!isUnbilledTransactionsExists)) {
			log.info("CCFEEW validateCCSystemTransactions Billed Transaction is required");
			ccmsC400Transactions.clear();
			if (creditCardsFutureList == null) {
				creditcardvo.setStartPageNumber(CardConstant.START_PAGE_01);
				creditcardvo.setFunctionCd(CardConstant.FUNC_CD_B);
				creditcardvo.setStatementType(CardConstant.STMT_CD_01);
				try{
					ccmsC400Transactions = creditCardService.findCreditCardTransactions(creditcardvo);
				}
				catch(BusinessException ex){
					log.info("No Billed-transactions found in CCMS System");
						
				}
			} else {
				try {
	                CompletableFuture<List<TransactionAsyncDto>> creditCardDetailsFuture = allOf(creditCardsFutureList);
	                for(TransactionAsyncDto transactionAsyncDto : creditCardDetailsFuture.get()){
	                	ccmsC400Transactions = transactionAsyncDto.getCcmsC400Transactions();
	                	break;
	                }
		        } catch(Exception ex){
		        	creditCardsFutureList = null;
		        	throw new TechnicalException(ex);
		        }
			}
			transactions = ccmsC400Transactions.iterator();
			statemantedTransaction = new LinkedList<CreditCardTransactionDto>();
			while (transactions.hasNext()) {
				CreditCardTransactionDto transactionDto = transactions.next();
				if(!CardUtil.isEmptyOrNull(transactionDto.getTxnDate())){
					
					if(CardUtil.isEmptyOrNull(transactionDto.getTxnCode())) {
						transactionDto.setTxnCode(transactionDto.getTransactionCode());
					}
						transactionDto.setTxnCurr(creditcardvo.getTxtCurrCode());

					String date = cardUtil.formatStringDate(transactionDto.getTxnDate(),CardConstant.CCMS_DATE_FORMAT1,CardConstant.REQ_DATE_FORMAT);
					Date transactionDt = cardUtil.formatDate(CardConstant.DATE_FORMAT,transactionDto.getTxnDate());
					transactionDto.setTxnDate(date);
					transactionDto.setTransactionDt(transactionDt);
					if (edmpTransactionrefreshDate.before(transactionDt)) {
						statemantedTransaction.add(transactionDto);
					}
					if (edmpRAEligibilityRefreshDate.before(transactionDt)) {
						eligibilityList.add(transactionDto);
					}
				}
			}
			
		} else if(null != creditCardsFutureList) {
	            try {
	                CompletableFuture<Void> allFuturesResult = CompletableFuture
	                              .allOf(creditCardsFutureList
	                                            .toArray(new CompletableFuture[creditCardsFutureList
	                                                          .size()]));
	                allFuturesResult.cancel(true);
	          } catch (Exception ex) {
	                creditCardsFutureList = null;
	          }
	    }
		log.info("Exit from validateCCSystemTransactions.....");

		return statemantedTransaction;
	}

	/**
	 * @param reconciledTransactionList
	 * @param eligibilityList
	 * @param journeyMap
	 * @param creditcardDto
	 * @param creditcardvo
	 * @param props
	 */
	public void checkEligibilityandRewardPoint(List<CreditCardTransactionDto> reconciledTransactionList,List<CreditCardTransactionDto> eligibilityList,
			Map<String, Object> journeyMap, CreditCardDto creditcardDto,CreditCardVO creditcardvo, CreditCardFeeWaiverProperties props) {

		log.info("[CreditCardFeeWaiverService checkEligibilityandRewardPoint Entered] ");

		creditcardDto.setCardtransactions(reconciledTransactionList);
		// Check eligibility for eligible fee types

		if (!CardConstant.CONTRY_HK.equalsIgnoreCase(creditcardvo.getCountryCode())) {
			ccFeeWaiverEligibilityUtility.getEligibilityDetails(journeyMap, creditcardvo, creditcardDto, props);
		}

		BigDecimal percentageEligible = creditcardDto.getCreditCardEligibility().getPercentageEligible();
		Iterator<CreditCardTransactionDto> it = reconciledTransactionList.iterator();
		while (it.hasNext()) {
			CreditCardTransactionDto creditcardtransactions = it.next();
			if (!CardConstant.CONTRY_HK.equalsIgnoreCase(creditcardvo.getCountryCode())) {
				if (!((creditcardtransactions.getOriginTxnAmt().compareTo(
						creditcardtransactions.getActualTxnAmount()) == CardConstant.ZERO))) {
					creditcardDto.setIsCardHasPartialPayment(CardConstant.CONS_Y);
				}
			}
			//to set the eligible amount based on eligibility percentage from EDMP system.
			if(percentageEligible != null)
			{
				creditcardtransactions.setActualTxnAmount(creditcardtransactions
						.getActualTxnAmount().multiply(percentageEligible));
			}
			else{
				creditcardtransactions.setActualTxnAmount(creditcardtransactions.getActualTxnAmount());
			}
			if(creditcardtransactions.getActualTxnAmount().intValue() == CardConstant.ZERO){
				it.remove();
			}
		}
		if(reconciledTransactionList.size() == CardConstant.ZERO){
			log.info("[The selected transactions are eligible but the percentage eligibility is"+percentageEligible+"]");
			setErrorMessage(creditcardDto, CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT, CardConstant.CC_FEE_WAIVER_MSG_CD_NO_DEBIT);
		}
		/**
		 * If Country is INDIA and RA eligibility is yes then checking for
		 * whether any reversal has happened in past 1 month as functional
		 * requirement is for 6 months but 5 month validation we are performing
		 * in EDMP and remaining days we are performing here.
		 */
		if ((creditcardDto.getCreditCardEligibility().getCardEligibilityFlag()
				.equalsIgnoreCase(CardConstant.CONS_Y))
				&& (creditcardvo.getCountryCode()
						.equalsIgnoreCase(CardConstant.CONTRY_IN))) {

			int creditListSize = performEligibilityCheckCCMSIN(creditcardvo,eligibilityList, props,journeyMap);

			if (creditListSize != CardConstant.ZERO) {
				creditcardDto.getCreditCardEligibility()
						.setCardEligibilityFlag(CardConstant.CONS_N);
			}

		}

		//if eligibility no then looking for the respective reward point from CSL db.
		boolean rewardPointRequired=(boolean) journeyMap.get(CardConstant.REWARD_POINT_REQUIRED);
		if ((creditcardDto.getCreditCardEligibility().getCardEligibilityFlag()
				.equalsIgnoreCase(CardConstant.CONS_N))&&(rewardPointRequired))
				{
			if (creditcardDto.getIsCardHasPartialPayment().equalsIgnoreCase(
					CardConstant.CONS_N)) {
				
				log.info("[CreditCardFeeWaiverService checkEligibilityandRewardPoint() - As Card not eligible, looking for reward point... ] ");
				reconcileRewardPoint.reconcileRewardPoint(creditcardDto,
						creditcardvo, reconciledTransactionList, journeyMap,
						props);
			}else{
				log.info("[CreditCardFeeWaiverService checkEligibilityandRewardPoint() - As partial payment already happened, reward point check is not required... ] ");
			}
		}

		log.info("[CreditCardFeeWaiverService checkEligibilityandRewardPoint Exit] ");
	}

	/**To check the eligibility for 6 months transactions
	 * @param creditcardvo
	 * @param transactions
	 * @param props
	 * @param journeyMap 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private int performEligibilityCheckCCMSIN(
			CreditCardVO creditcardvo, List<CreditCardTransactionDto> transactions,
			CreditCardFeeWaiverProperties props, Map<String, Object> journeyMap) {
		
		log.info("[Entered in performEligibilityCheckCCMSIN() ...]");
		
		List<CreditCardTransactionDto> creditTransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> unprocessedCreditTransactionsList = (List<CreditCardTransactionDto>) journeyMap.get(CardConstant.UNPROCESSED_CREDIT_TRANC);
		transactions.addAll(unprocessedCreditTransactionsList);
		String eligibleFeeTypes = props.getRaEligibilityCriteria().get(	CardConstant.KEY_ELIGIBLE_FEE_TYPE);
		String[] eligibleFeeTypesarr = eligibleFeeTypes.split(",");
		for (String feeType : eligibleFeeTypesarr) {

			feeType = feeType.replace("'", "");
			SRParamDto inputParam = new SRParamDto();
			inputParam.setCountryCode(creditcardvo.getCountryCode());
			inputParam.setParamId(CardConstant.ID_PARAM_RECONCILATIONPARAMS);
			inputParam.setParamKey1(CardConstant.CC_FEE_TYPE);
			inputParam.setParamKey2(feeType);
			SRParamDto param = CardUtil.loadSrParamByObject(inputParam, ccDao)
					.get(CardConstant.ZERO);
			String nonpaymentCreditcode;
			String paymentCreditcode = param.getParamData4();

			if (creditcardvo.getCountryCode().equalsIgnoreCase(CardConstant.CONTRY_IN)) {
				nonpaymentCreditcode = param.getParamData5();
			} else {
				nonpaymentCreditcode = CardConstant.PAD_EMPTY;
			}
			String truncCreditNarration = param.getParamData9();

			transactions.forEach(creditCardTransactionDto -> {
				if (paymentCreditcode.equalsIgnoreCase(creditCardTransactionDto
						.getTxnCode())
						|| (nonpaymentCreditcode
								.equalsIgnoreCase(creditCardTransactionDto.getTxnCode()))
						&& creditCardTransactionDto.getDesc().toUpperCase()
								.contains(truncCreditNarration)) {
					creditTransactionList.add(creditCardTransactionDto);
				}

			});
		}

		log.info("[Exit from performEligibilityCheckCCMSIN() ...]");
		return creditTransactionList.size();
	}
	
	/**
	 * 
	 * @param creditcardvo
	 * @param creditcardDto
	 * @param journeyMap
	 * @return
	 */
	public List<CreditCardTransactionDto> findAllTransactionsFromEDMP(
			CreditCardVO creditcardvo, CreditCardDto creditcardDto,
			Map<String, Object> journeyMap, CreditCardFeeWaiverProperties props) {
		log.info("[CreditCardFeeWaiverService findAllTransactionsFromEDMP Enterd...] ");
		// connect to EDMP to fetch 12 months transaction and maximum date of
		// transactions
		SRParamDto srDto = null;
		if (!ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditcardvo.getCountryCode())) {
			srDto = (SRParamDto) journeyMap.get(CardConstant.KEY_PARAM_DTO);
		}

		List<CreditCardTransactionsEDMPDto> list = transDao
				.getCreditTransactions(creditcardvo, srDto, journeyMap, props);
		List<CreditCardTransactionDto> creditTxnList = new ArrayList<CreditCardTransactionDto>();
		for (Iterator<CreditCardTransactionsEDMPDto> itr = list.iterator(); itr
				.hasNext();) {
			CreditCardTransactionsEDMPDto ccEDMP = itr.next();
			Date edmpTransactionrefreshDate = (Date) journeyMap
					.get(CardConstant.KEY_EDMP_TRANC_BATCH_DT);
			Date transactionDt = cardUtil.formatDate(
					CardConstant.REQ_DATE_FORMAT, ccEDMP.getTransactionDate());
			//add the transaction records till the EDMP batch loaded date.
			if (!(transactionDt.after(edmpTransactionrefreshDate))) {
				
				CreditCardTransactionDto ccdto = orikaMapper.map(ccEDMP,CreditCardTransactionDto.class);
				if (ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditcardvo.getCountryCode())) {
					ccdto.setTxnCurr(creditcardvo.getTxtCurrCode());
				} else {
					ccdto.setTxnCurr(props.getLocalCurrency());
				}
				ccdto.setTransactionDt(transactionDt);
				creditTxnList.add(ccdto);
			}
		}
		log.info("[CreditCardFeeWaiverService findAllTransactionsFromEDMP Exit...] EDMP Tran["
				+ creditTxnList
				+ "] Local Curr["
				+ props.getLocalCurrency()
				+ "]");
		return creditTxnList;
	}


	/**
	 * This method used to get the data required for reconcilliation of
	 * transaction and respective reward detail from CSL Credit Card data base.
	 * Based on the country code, param id, and param keys.
	 * 
	 * @param props
	 * 
	 * @param creditcardvo
	 * @param journeyMap
	 * @return SRParamDto if data is available, otherwise null.
	 */
	private void getReconcilationParams(CreditCardFeeWaiverProperties props,
			CreditCardVO creditcardvo, Map<String, Object> journeyMap) {
		SRParamDto inputParam = new SRParamDto();
		boolean rewardPointRequired=false;
		List<SRParamDto> paramList= null;
		
		log.info("[getReconcilationParams-ENTRY...]" + "[FeeType]"
				+ creditcardvo.getFeeType());

		//only allowed for Eligible fee type and other than particular card type.
		Map<String, String> exclutionRewardPtsCardTypes = (Map<String, String>) props
				.getRewardPoint().get(CardConstant.KEY_EXCLUTION_CARD_TYPES);
		
		if (creditcardvo.getCountryCode().equalsIgnoreCase(CardConstant.CONTRY_IN)&&(props.getRewardPoint().get(CardConstant.KEY_ELIGIBLE_FEE_TYPE).
				toString().contains("'"+creditcardvo.getFeeType()+"'")
				&& null != exclutionRewardPtsCardTypes.get(creditcardvo.getFeeType())
				&& (!exclutionRewardPtsCardTypes.get(creditcardvo.getFeeType())
				.toString().contains(creditcardvo.getCardType()))))
		{
			rewardPointRequired=true;
			inputParam.setCountryCode(creditcardvo.getCountryCode());
			inputParam.setParamId(CardConstant.ID_PARAM_I0003);
			inputParam.setParamKey3(creditcardvo.getFeeType());
			inputParam.setParamKey1(CardConstant.CC_REWARD_PT);
			inputParam.setParamKey2(creditcardvo.getCardType());
			paramList = CardUtil.loadSrParamByObject(inputParam,
					ccDao);
		}
		
		if (creditcardvo.getCountryCode().equalsIgnoreCase(CardConstant.CONTRY_SG)&&
				(props.getRewardPoint().get(CardConstant.KEY_ELIGIBLE_FEE_TYPE).
						toString().contains("'"+creditcardvo.getFeeType()+"'")
				&& null != exclutionRewardPtsCardTypes.get(creditcardvo.getFeeType())
				&& (!exclutionRewardPtsCardTypes.get(creditcardvo.getFeeType())
				.toString().contains("'"+creditcardvo.getCardTypeCode()+"'"))))
		{
			rewardPointRequired=true;
			inputParam.setCountryCode(creditcardvo.getCountryCode());
			inputParam.setParamId(CardConstant.ID_PARAM_I0003);
			inputParam.setParamKey3(creditcardvo.getFeeType());
			inputParam.setParamKey1(CardConstant.CC_REWARD_PT);
			if(creditcardvo.getFeeType().equalsIgnoreCase(CardConstant.ANNUAL_FEE_BASIC)||
					(creditcardvo.getFeeType().equalsIgnoreCase(CardConstant.ANNUAL_FEE_SUPP))){
				inputParam.setParamKey2(creditcardvo.getCardTypeCode());
				inputParam.setParamKey3(CardConstant.FEE_TYPE_AF);
			}
			else{
				inputParam.setParamKey2(CardConstant.PAD_EMPTY);
			}
			paramList = CardUtil.loadSrParamByObject(inputParam,
					ccDao);
		}
		
		else{
			log.info("CreditcardfeeWaiverService--GetReconcile params-Card type not eligible for reward redemption...");
		}
		
		if (paramList != null && paramList.size() > CardConstant.ZERO) {
			SRParamDto param1 = paramList.get(CardConstant.ZERO);
			journeyMap.put(CardConstant.KEY_REWARD_PARAM_DTO, param1);
		} else {
			rewardPointRequired=false;
			SRParamDto param1 = new SRParamDto();
			journeyMap.put(CardConstant.KEY_REWARD_PARAM_DTO, param1);
		}
		journeyMap.put(CardConstant.REWARD_POINT_REQUIRED, rewardPointRequired);

	}

	/**
	 * To prepare the ServiceRequest object and invoke the respective Rest
	 * service to post the data to EDMI queue.
	 * 
	 * @param creditcardDto
	 */
	@SuppressWarnings("static-access")
	public ServiceRequest createServiceRequest(CreditCardDto creditcardDto) {
		
		log.info("[CreditCardFeeWaiverService createServiceRequest Entered.....] [Operation :"+creditcardDto.getOperationName()+"] Channel["+
				creditcardDto.getChannel()+"] Login User Id["+cslRequestContext.getOperatorId()+"] Client Id["+cslRequestContext.getClientId()+"] User Type["+
				creditcardDto.getFrontLineUserType()+"] ");
		
		String eligibilityOverrideFlag = "N";
        String rewardPointRequired = "N";
		ServiceRequest serviceRequest = null;
		CCFeeWaiverPostDto ccPostDto = new CCFeeWaiverPostDto();
		CreditCardFeeWaiverProperties props = getBean();
		creditCardValidator.validateCCFPostServiceRequest(creditcardDto);
		cardUtil.populateCreditCardDTO( cslRequestContext, creditcardDto);
		
		if(!CardUtil.isEmptyOrNull(creditcardDto.getOperationName())){
			ccPostDto.setChannelId(cslRequestContext.getChannel());
			
			//TODO:set the client id.[CECC, CESP,CECO]
			if("CEMS".equalsIgnoreCase(cslRequestContext.getChannel())){//need to fix.
				ccPostDto.setAgentId(cslRequestContext.getChannel()); 
				ccPostDto.setFrontlineUserId(cslRequestContext.getOperatorId());
				Map<String,String> frontlineUserType=props.getFrontlineUserType();
				if(!cardUtil.isEmptyOrNull(frontlineUserType.get(creditcardDto.getFrontLineUserType().trim()))){
				ccPostDto.setUserType(frontlineUserType.get(creditcardDto.getFrontLineUserType()));
				}
				
				//changes for Branch code
				if(!CardUtil.isEmptyOrNull(creditcardDto.getFrontLineUserType()) && creditcardDto.getFrontLineUserType().indexOf("BRANCH") != -1 ){
					List<UserInfo> userList = spv1Gateway.getUserInfo(ccPostDto.getFrontlineUserId(), cslRequestContext.getCountry());
					for(UserInfo usrInfo : userList){
						if(!usrInfo.getChannelId().equals("NO_CHNL") && (!usrInfo.getBranchCode().equals("NO_BRANCH"))){
							ccPostDto.setBranchCode(usrInfo.getBranchCode().trim());
						}
					}
				}
			}
				
			// To fetch the card related details form CCMS/C400 [GetDetail - CC Enquiry]
			CreditCardVO cardVO = cardUtil.populateCreditCardVO(cslRequestContext);
			
			log.info("[CreditCardFeeWaiverService createServiceRequest] [Posting initiated for Reversal ...........] [Branch ID:"+ccPostDto.getBranchCode()+"]");
			
			for(CreditCardDto crDto: creditcardDto.getPostCreditCards()){
				//if masking required
				String isMaskingRequire=getCardMaskRequiredStatus(creditcardDto.getCountry());
				if(CardConstant.CONS_Y.equalsIgnoreCase(isMaskingRequire)){
				String decryptedCardNumber = encryptDecryptHelper
						.performEncryptDecrypt(6, 4, crDto.getCardNum(),
								CardConstant.DECRYPT, cslRequestContext.getCustomerId());
				crDto.setCardNum(decryptedCardNumber);
				}				cardVO.setCardNo(crDto.getCardNum());
				
				if("REVERSAL".equalsIgnoreCase(creditcardDto.getRequestType())){
					//to pull the card detail [like : block code]
					if(CardUtil.isEmptyOrNull(crDto.getBlockCode())){
						CreditCardDto tmpCreditcardDto = creditCardEnquiryV1SoapGateway.getCreditCard(cardVO);
						crDto.setBlockCode(tmpCreditcardDto.getBlockCode());
					}
					for(CreditCardTransactionDto ccTransactionDto:crDto.getCardtransactions() ){
						if(!CardUtil.isEmptyOrNull(ccTransactionDto.getUiTrancAmt())){
							ccTransactionDto.setActualTxnAmount(ccTransactionDto.getUiTrancAmt());
						}
						log.info("[CreditCardFeeWaiverService createServiceRequest] [Posting initiated for charges...........][UI Amt :"+ccTransactionDto.getUiTrancAmt()+"]");
						
						if(ccTransactionDto.getOriginTxnAmt() != null && (ccTransactionDto.getActualTxnAmount() == null
								|| ((CardConstant.STRING_ZERO).equalsIgnoreCase(ccTransactionDto.getActualTxnAmount().toString())))){
							ccTransactionDto.setActualTxnAmount(ccTransactionDto.getOriginTxnAmt());
						}
					}
				}else{
					
					for(CreditCardTransactionDto ccTransactionDto:crDto.getCardtransactions() ){
						if(!CardUtil.isEmptyOrNull(ccTransactionDto.getUiTrancAmt())){
							ccTransactionDto.setActualTxnAmount(ccTransactionDto.getUiTrancAmt());
						}
					}
					log.info("[CreditCardFeeWaiverService createServiceRequest] [Posting initiated for charges...........]");
				}
				
			}
		
			orikaMapper.map(creditcardDto, ccPostDto);
			
			if (!ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditcardDto.getCountry())) {
				//to get the any one of the override flag and reward sent by UI
		        for(CreditCardPostDto crcPostDto: ccPostDto.getCreditcard()){
		               if(!CardUtil.isEmptyOrNull((crcPostDto.getEligibilityOverrideFlag()))){
		                     eligibilityOverrideFlag = crcPostDto.getEligibilityOverrideFlag();
		               }
		               if(!CardUtil.isEmptyOrNull(crcPostDto.getRewardPointRequired())){
		                     rewardPointRequired = crcPostDto.getRewardPointRequired();
		               }else{
			   				log.info("[CreditCardFeeWaiverService createServiceRequest...] [Reward Required :"+crcPostDto.getRewardPointRequired()+"]"
			   						+ " Reward Point ["+crcPostDto.getRewardPoint()+"] "
			   								+ "	Reward Point - IsNumeric ["+ NumberUtils.isNumber(crcPostDto.getRewardPoint())+"]");
		               }
		        }
			}
	        
	        //to set the same value into all the credit cards while posting.
	        for(CreditCardPostDto crcPostDto: ccPostDto.getCreditcard()){
	               crcPostDto.setEligibilityOverrideFlag(eligibilityOverrideFlag);
	               crcPostDto.setRewardPointRequired(rewardPointRequired);
               if (!ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditcardDto.getCountry())) {
		    	   crcPostDto.setCardCurrency(props.getLocalCurrency());
		       }
			}
		}		
		
		serviceRequest = creditCardService.generatePayLoad(creditcardDto, ccPostDto);
		if(serviceRequest != null){
			serviceRequest.setCountryCode(creditcardDto.getCountry());
			serviceRequest.setOperationName(creditcardDto.getOperationName());
			ccPostDto.setFeeTypeCode(ccPostDto.getFeeType());
			if(ccPostDto.getFeeType() != null){
				SRParamDto paramDto = null;
				if (ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditcardDto.getCountry())) {
					paramDto = ccFeeWaiverAsyncService.getHKUITxnDetails(creditcardDto.getCountry(),ccPostDto.getFeeType());
				} else {
					paramDto = getTxnDetails(creditcardDto.getCountry(),ccPostDto.getFeeType());
				}
				if(!CardUtil.isEmptyOrNull(paramDto)){
					String feeType = paramDto.getParamData1();
		            ccPostDto.setFeeType(feeType);
				}
			}
		}
		
		//remove it before moving to PRD
		log.info("[CreditCardFeeWaiverService createServiceRequest] [Posting List:"+ccPostDto+"]");
		ServiceRequest serviceReq = serviceRequestJsonApiGateway.createServiceRequest(serviceRequest);

		log.info("[CreditCardFeeWaiverService createServiceRequest Exit...]  ");
		return serviceReq;

	}

	public SRParamDto getTxnDetails(String countryCode,String feeType){
        SRParamDto inputParam = new SRParamDto();
        log.info("[getTxnDetails-ENTRY]" + "[FeeType]"
                     + feeType);
        inputParam.setCountryCode(countryCode);
        inputParam.setParamId(CardConstant.ID_PARAM_RECONCILATIONPARAMS);
        inputParam.setParamKey1(CardConstant.CC_FEE_TYPE);
        inputParam.setParamKey2(feeType);
        List<SRParamDto> paramList= CardUtil.loadSrParamByObject(inputParam, ccDao);
        inputParam = paramList.get(CardConstant.ZERO);
        
        return inputParam;
	}

	/**
	 * This method pulls the Pending Services Request for a customer from Eops sytem.
	 * The result will be used to validate the duplication of the selected fee type [Customer id, Card No, Fee type, Status {Pending}].
	 * 
	 * @param creditcardvo
	 * @param cardNumbersArray
	 * @param props 
	 * @return
	 */
	public Map<String, String> fetchServiceRequestFromEops(CreditCardVO creditcardvo, String[] cardNumbersArray, String feeType, CreditCardFeeWaiverProperties props) {
		log.info("[CreditCardFeeWaiverService fetchServiceRequestFromEops Entered...] [FeeType:"+feeType+"]");
		Map<String, String> cardStatusMap = new HashMap<String, String>();
		List<String> cardNumList = Arrays.asList(cardNumbersArray);
		
		if(CardConstant.CONS_Y.equalsIgnoreCase(props.getEopsDuplicateChekRequired())){
			List<ServiceRequest> serviceReq = serviceRequestJsonApiGateway.enquireStatus(creditcardvo.getCountryCode(), creditcardvo.getRelId(), creditcardvo.getChannelId(),null);
			serviceReq.forEach(serviceRequestObj -> {
	
	            String subServiceType = serviceRequestObj.getServiceType();
	    		log.info("[CreditCardFeeWaiverService fetchServiceRequestFromEops ] [Service Type:"+subServiceType+"]  [FeeType:"+feeType+"]");
	    		
	            if("Credit Card Fee Waiver".equalsIgnoreCase(subServiceType)){
	                  List<LinkedHashMap<String, String>> info = (List<LinkedHashMap<String, String>>) serviceRequestObj.getPayload().get("products");
	                  for (LinkedHashMap<String, String> detMap : info) {
	                         String cardNumber = detMap.get("accountNumber");
	                         String feeTypeRsp = detMap.get("productType");
	                         String status = detMap.get("status");
	                         //TODO : Fee description matching [desc should match with CSL and Eops]
	                         if(CardUtil.isEmptyOrNull(status)&& feeTypeRsp.equals(feeType)){
	                        	 log.info("If condition satisfied....");
	                             cardStatusMap.put(cardNumber, "PENDING");
	                   } 
                    }
	            }
			});
		}
		
		log.info("[CreditCardFeeWaiverService fetchServiceRequestFromEops Status Details["+ cardStatusMap +"]");
		log.info("[CreditCardFeeWaiverService fetchServiceRequestFromEops Exit...] ");
		return cardStatusMap;
	}

	public List<CreditCardDto> getCreditcardTransactions(
			CreditCardVO creditcardvo) {
		
		log.info("[CreditCardFeeWaiverService getCreditcardTransactions Entered] [Customer Id: "
				+ creditcardvo.getCustomerId() + "]");
		List<CreditCardDto> creditCardList = new ArrayList<CreditCardDto>();
		String cardNumbersArray[];
		List<CreditCardDto> creditCardListing = null;
		
		String cardNumbers = creditcardvo.getCardNo();
		cardNumbersArray = cardNumbers.split(",");
		List<CompletableFuture<CreditCardDto>> creditCardsFutureList = new ArrayList<>();
		
		Map<String, Map<String, String>> cardStatusMap = ccFeeWaiverAsyncService.getEopsCemsSRStatus(creditcardvo);
		String isCardMaskingRequired = getCardMaskRequiredStatus(creditcardvo.getCountryCode());
		log.info("[CreditCardFeeWaiverService getCreditcardTransactions Entered] isCardMaskingRequired "+isCardMaskingRequired);
		for (String cardNum : cardNumbersArray) {
			String cardNumStr = cardNum.substring(0,cardNum.length()-3);
			creditcardvo.setCardNo(cardNumStr);
			creditcardvo.setTxtCurrCode(cardNum.substring(cardNum.length()-3));
			if(CardConstant.CONS_Y.equalsIgnoreCase(isCardMaskingRequired)){
				String decryptedCardNumber = encryptDecryptHelper.performEncryptDecrypt(6, 4, creditcardvo.getCardNo(),	
						CardConstant.DECRYPT, creditcardvo.getCustomerId());
				creditcardvo.setCardNo(decryptedCardNumber);
			}
			
			CompletableFuture<CreditCardDto> creditCardsFuture =  ccFeeWaiverAsyncService.getAsyncTransactionList(populateCreditCardVO(creditcardvo,creditcardvo.getCardNo()), cardNumbers, 
					creditCardListing,cardStatusMap,"",isCardMaskingRequired);
	        creditCardsFutureList.add(creditCardsFuture);
		}
		
		try {
            if (CollectionUtils.isNotEmpty(creditCardsFutureList)) {
                CompletableFuture<List<CreditCardDto>> creditCardDetailsFuture = allOf(creditCardsFutureList);
                for(CreditCardDto creditCardDto : creditCardDetailsFuture.get()){
                	creditCardList.add(creditCardDto);
                }
            }
        } catch(BusinessException ex){
            log.info("getAsyncCreditCardList...BusinessException....{}", ex.getErrorCode());
            throw ex;
        } catch( ExecutionException | InterruptedException ex){
            log.info("getAsyncCreditCardList...ExecutionException/InterruptedException....{}", ex);
            throw new TechnicalException(ex);
        } catch (Exception ex) {
        	log.info("getAsyncCreditCardList...Exception....{}", ex);
            throw new TechnicalException(ex);
		}
		
		creditCardList = getCreditCardSortedOrder(cardNumbersArray, creditCardList, creditcardvo);
		return creditCardList;
	}
	
	protected <T> CompletableFuture<List<T>> allOf(List<CompletableFuture<T>> futuresList) {
        CompletableFuture<Void> allFuturesResult =
                CompletableFuture.allOf(futuresList.toArray(new CompletableFuture[futuresList.size()]));
        return allFuturesResult.thenApply(v ->
                futuresList.stream().
                        map(future -> future.join()).
                        collect(Collectors.<T>toList())
        );
    }
	
	public CreditCardVO populateCreditCardVO(CreditCardVO creditCardVO, String cardNo){
        CreditCardVO creditCardVOTmp = new CreditCardVO();
        creditCardVOTmp.setCustomerId(creditCardVO.getCustomerId());
        creditCardVOTmp.setRelId(creditCardVO.getRelId());
        creditCardVOTmp.setCustomerType(creditCardVO.getCustomerType());
        creditCardVOTmp.setChannelId(creditCardVO.getChannelId());
        creditCardVOTmp.setCountryCode(creditCardVO.getCountryCode());
        creditCardVOTmp.setCardNo(cardNo);
        creditCardVOTmp.setCslRequestContext(creditCardVO.getCslRequestContext());
        creditCardVOTmp.setFeeType(creditCardVO.getFeeType());
        creditCardVOTmp.setEligibleFeeWaiver(creditCardVO.getEligibleFeeWaiver());
        creditCardVOTmp.setTxtCurrCode(creditCardVO.getTxtCurrCode());
        creditCardVOTmp.setLangCode(creditCardVO.getLangCode());
        return creditCardVOTmp;
    }
	
	public List<CreditCardDto> getCreditCardSortedOrder(String[] cardNumbersArray, List<CreditCardDto> creditCardList, CreditCardVO creditcardvo) {
		
		int totalErrorCardCount = 0;	
		List<CreditCardDto> creditCardSortedOrderList = new ArrayList<CreditCardDto>();
			for(String cardNum : cardNumbersArray) {
			 String cardNumber = cardNum.substring(0,cardNum.length()-3);
			 for(CreditCardDto creditCardDto : creditCardList) {
				if(cardNumber.equalsIgnoreCase(creditCardDto.getCardNum())) {
					creditCardSortedOrderList.add(creditCardDto);
					if((CardConstant.CC_FEE_WAIVER_ERR_HK_CD_CUST_NOT_ELIGIBLE).equals(creditCardDto.getErrorCode())) {
						totalErrorCardCount++;
					}
					break;
				}
			 }
			}
			if(totalErrorCardCount == creditCardSortedOrderList.size()) {
				CreditCardProperties ccProps = cardUtil.getCreditCardPropertiesBean();
				String errorDesc = ccFeeWaiverAsyncService.getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_HK_COMMON_CD, creditcardvo.getLangCode(),ccProps.getCreditCardFeeWaiverProps().getErrorCodesAndDesc());
				for(CreditCardDto creditCardDto : creditCardSortedOrderList) {
					creditCardDto.setErrorDescription(errorDesc);
				}
			}
		   
			Collections.reverse(creditCardSortedOrderList);
			return creditCardSortedOrderList;
	}
	
	@SuppressWarnings({ "unchecked"})
	private List<String> getHKTrasactionDesc(Map<String, Object> journeyMap){
		List<SRParamDto> list = (List<SRParamDto>) journeyMap.get(CardConstant.KEY_PARAM_DTO);
		ArrayList<String> listOfCreditNarrations = new ArrayList<>();
		for (SRParamDto txtCode : list) {
			String[] searchStr = txtCode.getParamData8().toUpperCase().split("#");
			for (String str : searchStr) {
				listOfCreditNarrations.add(str);
				break;
			}
		}
		return listOfCreditNarrations;
	}
	

	private boolean isCreditDbitDescMatching(List<String> listOfNarrations,
			String desc,boolean matchAll) {
		
		if (desc == null) return false;
		
		desc = desc.toUpperCase().trim().replaceAll(" ", "");
		for (String creditNarration : listOfNarrations) {
			if (!desc.contains(creditNarration.toUpperCase())) {
				return false;
			}
		}
		return true;
	}
}
