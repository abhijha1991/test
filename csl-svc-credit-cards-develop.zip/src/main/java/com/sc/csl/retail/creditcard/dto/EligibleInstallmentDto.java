package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@ToString
@NoArgsConstructor
@JsonApiResource(type = "eligible-plans")
public class EligibleInstallmentDto extends BaseDto {
    @JsonApiId
    private String id;
    private String funcCode;
    @JsonProperty("tenure")
    private String tenure;
    @JsonProperty("card-num")
    private String cardNum;
    private String seqNo;
    private String statusDescription;
    private String installmentAmt;
    private String txnType;
    @JsonProperty("status-code")
    private String statusCode;

    @JsonProperty("status-desc")
    private String statusDesc;

    @JsonProperty("total-eligbile-amount")
    private String eligbileAmount;

    @JsonProperty("max-eligbile-normal-amount")
    private String maxEligbileNormalAmount;

    @JsonProperty("max-eligbile-overseas-amount")
    private String maxEligbileOverseasAmount;


    @JsonProperty("max-eligbile-special-amount")
    private String maxEligbileSpecialAmount;

    @JsonProperty("tenures")
    private List<String>  tenures;

    @JsonProperty("last-payment-date")
    private String  lastPaymentDate;

    @JsonProperty("minimum-payment-amount")
    private String minimumPaymentAmount;

    @JsonProperty("bill-due-date")
    private String billDueDate;

    @JsonProperty("monthly-installment-amount")
    private String monthlyInstallmentAmount;

    @JsonProperty("application-fee")
    private String applicationFee;

    @JsonProperty("total-handling-fees")
    private String totalHandlingFees;

    @JsonProperty("days-before-due")
    private String daysBeforeDue;

    @JsonProperty("statement-date")
    private String statementDate;

    private String trackingId;

    private String messageTimestamp;

}
