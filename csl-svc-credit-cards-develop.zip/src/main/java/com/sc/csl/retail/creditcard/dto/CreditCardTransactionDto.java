package com.sc.csl.retail.creditcard.dto;

import io.katharsis.resource.annotations.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;
import lombok.NoArgsConstructor;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;


@Data
@NoArgsConstructor
@JsonApiResource(type = "cardtransactions")
public class CreditCardTransactionDto extends BaseDto implements Serializable{

	private static final long serialVersionUID = 5874886117375293695L;

	@JsonApiId
	private String txnRefNo;
	@JsonProperty("card-num")
	private String cardNum;
	@JsonProperty("origin-txn-amt")
	private BigDecimal originTxnAmt;
	@JsonProperty("txn-currency")
	private String txnCurr;
	@JsonProperty("transaction-desc")
	private String desc;	
	@JsonProperty("transaction-amount")
	private BigDecimal actualTxnAmount;
	@JsonProperty("actual-txn-amt")
	private BigDecimal uiTrancAmt;
	@JsonProperty("partialrev-txn-amt")
	private BigDecimal partialRevTxnAmt;
	@JsonProperty("equivalent-reward-points")
	private RewardPointDto equivalentRewardPoints;
	@JsonProperty("txn-date")
	private String txnDate;
	@JsonProperty("partialrev-txn-date")
	private String partialRevTxnDate;
	@JsonProperty("debit-credit-flag")
	private String debitCreditFlag;
	@JsonProperty("txn-code")
	private String txnCode;
	@JsonIgnore
	private String sendPageCount;
	@JsonProperty("sequence-number")
	private String sequenceNumber;
	@JsonProperty("batch-number")
	private String batchNumber;
	
	@JsonProperty("is-partially-reversed")
	private String isPartiallyReversed="N";
	@JsonProperty("primary-supp-ind")
	private String primarySuppInd;

	@JsonProperty("posting-date")
	private String  posting_Date ;

	@JsonProperty("date-of-purchase")
	private String effDt;

	@JsonProperty("amount-spent")
	private String amount;
	@JsonProperty("local-curency-amount")
	private String localCurrencyAmount;

	@JsonProperty("transaction-id")
	private String transactionId;

	@JsonProperty("transaction-description")
	private String refDesc;

	@JsonProperty("Currency")
	private String currency ;

	@JsonProperty("transaction-code")
	private String transactionCode;

	@JsonProperty("credit-debit-transaction-indicator")
    private String creditDebitTransactionIndicator;
	
	@JsonProperty("transaction-type")
	private String transactionType;

	@JsonProperty("local-currency")
	private String localCurrency ;

	@JsonProperty("posted-date")
	private String postedDate;

	@JsonIgnore
	private String pageNum;

	private String functionType;
	private String functionCd;

	@JsonProperty("statement-date")
	private String statementDate;

	@JsonProperty("payment-due-date")
	private String paymentDueDate;
	@JsonProperty("transaction-date")
	private Date transactionDate;

	@JsonProperty("transaction-currency-code")
	private String transactionCurrencyCode;

	@JsonApiRelation(serialize = SerializeType.LAZY, lookUp = LookupIncludeBehavior.AUTOMATICALLY_WHEN_NULL, opposite = "cardtransactions")
	private CreditCardDto creditCardDto;

	@JsonProperty("fee-sub-type-code")
	private String feeSubTypeCode;
	
	@JsonProperty("fee-type-desc")
	private String feeTypeDesc;
	
	@JsonIgnore
	private Date transactionDt;
	public String toString() {
		return ReflectionToStringBuilder.toString(this,	ToStringStyle.SHORT_PREFIX_STYLE);
	}

	private String fromDate;

	private String toDate;
}
