package com.sc.csl.retail.creditcard.gateway.jms;

import com.sc.csl.retail.core.gateway.CSLJmsGateway;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;



@Component
@Slf4j
public class NotificationGateway extends CSLJmsGateway {
	
	@Autowired
	public NotificationGateway(JmsTemplate jmsTemplate,
			@Value("${jms.destination}") String destinationName) {
		super(jmsTemplate, destinationName);
	}

	public void postNotifyMessage(String jmsMsg) {
		try {
			log.info("about to publish to Active MQ Server with this Json payload {} ", jmsMsg);
			post(jmsMsg);
			log.info("Successfully published to Active MQ Server");
		} catch (Exception ex) {
			log.error("Error while posting notification::", ex);
		}
	}

}
