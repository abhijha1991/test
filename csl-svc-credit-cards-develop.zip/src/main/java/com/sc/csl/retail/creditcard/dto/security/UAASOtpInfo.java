package com.sc.csl.retail.creditcard.dto.security;

import lombok.Data;

@Data
public class UAASOtpInfo {

	private String otpSn;
	private String encOtp;
	private String keyIndex;
}
