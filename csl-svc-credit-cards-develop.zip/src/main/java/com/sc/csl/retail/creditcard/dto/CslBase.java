package com.sc.csl.retail.creditcard.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;



@Data
@MappedSuperclass
public class CslBase implements Serializable, Cloneable {

    private static final long serialVersionUID = 1L;

    @Column(name = "D_CREAT_DT", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdTimestamp;

    @Column(name = "X_CREAT_BY")
    private String createdBy;

    @Column(name = "D_UPD_DT")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedTimestamp;

    @Column(name = "X_UPD_BY")
    private String updatedBy;

    @PrePersist
    void preInsert() {
        createdTimestamp = new Date();
        if (createdBy == null)
            createdBy = "SYSTEM";
    }

    @PreUpdate()
    void PreUpdate() {
        updatedTimestamp = new Date();
        if (updatedBy == null)
            updatedBy = "SYSTEM";
    }

}
