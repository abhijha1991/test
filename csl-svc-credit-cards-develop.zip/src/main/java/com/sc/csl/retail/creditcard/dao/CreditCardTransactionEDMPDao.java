package com.sc.csl.retail.creditcard.dao;

import java.util.List;
import java.util.Map;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionsEDMPDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public interface CreditCardTransactionEDMPDao {

	public List<CreditCardTransactionsEDMPDto> getCreditTransactions(
			CreditCardVO creditcardVO, SRParamDto srParamDto,
			Map<String, Object> journeyMap, CreditCardFeeWaiverProperties props);

	public void getTxnRefreshdate(Map<String, Object> journeyMap,
			CreditCardFeeWaiverProperties props);
}
