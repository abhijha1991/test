package com.sc.csl.retail.creditcard.config;

import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.OfflineDataProperties;

import org.springframework.boot.context.properties.ConfigurationProperties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CreditCardConfig {

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.all")
    public CreditCardProperties ALL() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.in")
    public CreditCardProperties IN() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.sg")
    public CreditCardProperties SG() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.my")
    public CreditCardProperties MY() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.hk")
    public CreditCardProperties HK() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.ae")
    public CreditCardProperties AE() {
        return new CreditCardProperties();
    }
    
    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.ke")
    public CreditCardProperties KE() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.gh")
    public CreditCardProperties GH() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.bw")
    public CreditCardProperties BW() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.ng")
    public CreditCardProperties NG() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditCardProps.zm")
    public CreditCardProperties ZM() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "hbase.conf")
    public CreditCardProperties HBaseConfig() {
        return new CreditCardProperties();
    }
    
    @Bean
    @ConfigurationProperties(prefix = "hbase.drConf")
    public CreditCardProperties HBaseDRConfig() {
        return new CreditCardProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "creditcard.offline.data.enabled")
    public  OfflineDataProperties offlineDataProperties() {
        return new OfflineDataProperties();
    }
}
