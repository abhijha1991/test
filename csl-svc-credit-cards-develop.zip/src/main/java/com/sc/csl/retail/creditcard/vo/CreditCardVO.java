package com.sc.csl.retail.creditcard.vo;

import java.util.List;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CreditCardVO extends BaseVO {
    private static final long serialVersionUID = 1L;
    private String cardNo;
    private String cardTransactionRefNo;
    private List<CreditCardDto> creditCards;
    private List<CreditCardTransactionDto> creditCardTransactions;
    private CSLRequestContext cslRequestContext;
	private boolean isCardNoSearch;
    private String activeCards;
    private String cardType;
    private String cardTypeCode;
    private String feeType;
    private String eligibleFeeWaiver;
    private String srName;
    private String functionCd;
    private String statementType = "";
    private String startPageNumber;
    private String navIndicator;
    private String eligibleForCreditBalRefund;
    private String eligibleForCreditCardCancel;
    private String functionCode;
    private String isPrimary;
    private String include;
    private String noOfDaysToFetchTransactions;
    private String cardBalanceLimit;
    private String requestType;
    private String custNum;
    private String functionType;
    private String orgNum;
    private String otpRequired;
    private String funcCode;
    private String seqNo;
    private String txnType;
    private String startPageRefNumber;
    private String txtCurrCode;
    private String langCode;
    private String embosserName;
    private Long serviceTimeOut;
    private String reasonCode;
    private String contactNum;
    private boolean isMobileBalance ;
}
