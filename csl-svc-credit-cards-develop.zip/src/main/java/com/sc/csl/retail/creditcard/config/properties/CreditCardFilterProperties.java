package com.sc.csl.retail.creditcard.config.properties;

import lombok.Data;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@ToString
@Data
public final class CreditCardFilterProperties {
	
	private Map<String, String> cardTypes = new HashMap<String, String>();
	private Map<String, String> cardStatus = new HashMap<String, String>();
	private Map<String, String> blockInds = new HashMap<String, String>();
	private Map<String, String> statementFlags = new HashMap<String, String>();
	private Map<String, String> agmtStsInds = new HashMap<String, String>();
	private String expiryDateFrmt;
	private String blockCodesForAltBlockCodeCheck;
	private String altBlockCodes;
	private String blockCodeDateBlockCodes;
	private Integer blockCodeDateDays;
	private String transferEffectiveDateBlockCodes;
	private Integer embossingLastRequestNoOfDays;
	private String embossingLastRequestDateFormat;
	private String isSupplCardStausCheckEnabled;
	private String allowedPrimaryCardStatus;
	private Map<String, String> activationStatus = new HashMap<String, String>();
	private String cardRplStatusIndStopReasonCodes;
	private String cardRplStatusIndActivationStatus;
	private String cardRplIndActPrimaryStopReasonCodes;
	private String cardRplIndActPrimaryCardStatus;
	private String cardRplIndInActPrimaryStopReasonCodes;
	private String cardRplIndInActPrimaryCardStatus;
	private String cardRplIndInActPrimaryActiveAgreementSts;
	private String cardRplIndInActPrimaryActiveCardStatus;
	private String cardRplIndInActPrimaryActiveStopReasonCodes;
	private String cardRplIndActSupStopReasonCodes;
	private String cardRplIndActSupCardStatus;
	private String cardRplIndInActSupStopReasonCodes;
	private String cardRplIndInActSupCardStatus;
}
