package com.sc.csl.retail.creditcard.service;

import com.sc.corebanking.creditcard.v1.creditcardlimit.AcctBalType;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardlimit.ValidateLimitIncreaseRes;
import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.CSLKatharsisClientException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.*;
import com.sc.csl.retail.creditcard.dto.post.CCFeeWaiverPostDto;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.CreditCardRestGateway;
import com.sc.csl.retail.creditcard.gateway.csl.DebitCardsV3CSLGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardCustomerEnquiryV5SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardLimitV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardProfileV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.errorhandling.exception.BadRequestException;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.IncludeRelationSpec;
import io.katharsis.queryspec.QuerySpec;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;


@Slf4j
@Setter
@Service
public class CreditCardService extends BaseService {

    @Autowired
    CreditCardRestGateway creditCardRestGateway;

    @Autowired
    private CreditCardValidator creditCardValidator;

    @Autowired
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;

    @Autowired
    private CreditCardProfileV1SoapGateway creditCardProfileV1SoapGateway;

    @Autowired
    private CreditCardCustomerEnquiryV5SoapGateway creditCardCustomerEnquiryV5SoapGateway;

    @Autowired
    private CreditCardLimitV1SoapGateway creditCardLimitV1SoapGateway;

    @Autowired
    private DebitCardsV3CSLGateway debitCardsV3CSLGateway;

    @Autowired
    protected CSLRequestContext cslRequestContext;

    @Autowired
    private CardUtil cardUtil;

    @Autowired
    private MapperFacade orikaMapper;



    public List<CreditCardDto> findAllCreditCard(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = new ArrayList<>();
        List<CreditCardDto> hoganCreditCards = null;
        Map<String, String> creditCardDtoMap = null;
        String errorCode = null;
        log.info("[findAllCreditCard Entry]");
        creditCardValidator.validateRequest(creditCardVO);
        if (StringUtils.equalsIgnoreCase(CardConstant.OFFLINE, creditCardVO.getInclude())) {
            log.info("Get offline Credit Card Information");
            creditCards = creditCardRestGateway.getOfflineCreditCardSummary();
            for (CreditCardDto creditCardDto : creditCards) {
                creditCardDto.setInclude(creditCardVO.getInclude());
            }
            return creditCards;
        }
        creditCardVO.setCardNoSearch(false);
        try {
            if (ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditCardVO.getCountryCode())) {
                creditCardVO.setCardNoSearch(true);
                if (CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC.equalsIgnoreCase(creditCardVO.getFunctionCd())) {
                    creditCardDtoMap = new HashMap<String, String>();
                    creditCardDtoMap.put(creditCardVO.getOrgNum(), creditCardVO.getCardNo());
                } else if (!CardUtil.isEmptyOrNull(creditCardVO.getRelId())) {
                    try {
                        log.info("Getting Credit Card Information from hogan system");
                        hoganCreditCards = creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO);
                        log.info("No. Of Credit Cards Found for  relId in hogan : {} , {} ",cslRequestContext.getRelId(),creditCards.size() );
                    } catch (Exception e) {
                        log.info("Fetching from 24x7 DB for getCreditCards");
                        hoganCreditCards = fetchCreditCardsFromSharedServices(creditCardVO, e);
                    }
                    creditCardDtoMap = hoganCreditCards.stream().filter(i -> ArrayUtils.contains(CardConstant.CCMS_ORG_NUMS_HK, i.getOrgNum())).collect(Collectors.toMap(CreditCardDto::getOrgNum, CreditCardDto::getCardNum, (oldValue, newValue) -> oldValue));
                }
                creditCards = getAsyncCreditCardList(creditCardDtoMap, creditCardVO);
            } else {
                log.info(" Fetching Credit Card from EDMI for :: {} ",cslRequestContext.getRelId());
                creditCards = creditCardProfileV1SoapGateway.getCreditCards(creditCardVO);
                log.info("No. Of Credit Cards Found for  relId in EDMI : {} , {} ",cslRequestContext.getRelId(),creditCards.size() );
            }

        } catch (BusinessException e) {
            errorCode = e.getLocalizedMessage();
            if (StringUtils.containsWhitespace(errorCode)) {
                errorCode = StringUtils.split(errorCode, StringUtils.SPACE)[0];
            }
            /**
             * Get Card details from Shared service only on Technical Exceptions,
             * Exceptions like RELATION SHIP NOT FOUND can be skipped from calling SS
             */
            if (ArrayUtils.contains(CardConstant.CARDS_NOT_AVAILABLE_REDIRECT_SS, errorCode)) {
                log.info("Fetching from 24x7 DB for getCreditCards");
                creditCards = fetchCreditCardsFromSharedServices(creditCardVO, e);
            } else {
                log.error("Error in getCreditCardList. [Message: " + e.getMessage() + "]");
                throw e;
            }
        } catch (Exception e) {
            log.error("Error in getCreditCardList. [Message: " + e.getMessage() + "]");
            throw e;
        }


        // check page indicator available or not
        creditCards = combineNextCreditCardsListByPageIndicator(creditCards, creditCardVO);
        if (ArrayUtils.contains(CardConstant.CARD_ENQUIRY_FINANCE_CTR_CDS, creditCardVO.getCountryCode())
                && ArrayUtils.contains(CardConstant.CARD_ENQUIRY_FINANCE_OPERATION_NAMES, creditCardVO.getOperationName())) {
            creditCards = getAsyncCreditCardFinanceDetails(creditCards, creditCardVO);
        }
        if (StringUtils.equals(creditCardVO.getOperationName(), CardConstant.OPERATION_CC_REPLACEMENT)) {
            creditCards = getAsyncCreditCardDetails(creditCards, creditCardVO);
        } else if (StringUtils.equals(creditCardVO.getOperationName(), CardConstant.OPERATION_CC_BLOCK)
                && ArrayUtils.contains(CardConstant.COMBO_CARD_ENABLE_CTR_CDS, creditCardVO.getCountryCode())) {
            creditCards = getAsyncComboCardDetails(creditCards, creditCardVO);
        }
        if (StringUtils.equals(creditCardVO.getOperationName(), CardConstant.OPERATION_CC_REPLACEMENT)) {
            populateReplacementFileds(creditCards, creditCardVO);
        }

        /**
         *
         * COMMENTED SINCE THIS CALL FAILS THE COMPLETE REQUEST WHEN IT THROWS EXCEPTION
         *
         * Get Card embossed Name for only HK & SG Markets
         */
       /*
       try {
       if(ArrayUtils.contains(CardConstant.PRODUCT_DESC_SUFFIX_NA_CTR_CDS, creditCardVO.getCountryCode())) {
            creditCards = getAsyncCCDetailsForEmbosserName(creditCards, creditCardVO);
            }
        }catch (Exception e) {
       	 log.error("Error in getCreditCardList. [Message: "
                    + e.getMessage() + "]");
       	throw new TechnicalException(e);
       }*/
        log.info("findAllCreditCard - Before Filter Card List.size...{}", CollectionUtils.size(creditCards));

        if (creditCardVO.isMobileBalance()) {
            creditCards = creditCards.stream().filter(creditCardDto -> !StringUtils.equals("L",creditCardDto.getBlockCode().toUpperCase())).collect(Collectors.toList());
            setProductDescription(creditCards, creditCardVO);
            creditCards.forEach(creditCardDto -> creditCardDto.setOperationName(CardConstant.OPERATION_MOBILE_BALANCE));
        }
        // for online only records need to add again that include
        if(!CardUtil.isEmptyOrNull(creditCards)
                && !CardUtil.isEmptyOrNull(creditCardVO)
                && !CardUtil.isEmptyOrNull(creditCardVO.getInclude())
                && StringUtils.equalsIgnoreCase(CardConstant.INCLUDE_ONLINE, creditCardVO.getInclude())) {
            for (CreditCardDto creditCardDto : creditCards) {
                creditCardDto.setInclude(creditCardVO.getInclude());
            }
        }
        return creditCards;
    }

    private void setProductDescription(List<CreditCardDto> creditCardDtoList, CreditCardVO creditCardVO) {
        List<String> creditcards = new ArrayList<>();
        creditCardDtoList.forEach(creditCardDto -> {
            creditcards.add(creditCardDto.getCardNum());
        });
        Map<String, CreditCardDto> creditCardFromSS = creditCardProfileV1SoapGateway.getProvidedCreditCardsFromSharedService(creditCardVO, creditcards, cslRequestContext.getCountry() + cslRequestContext.getLanguage() + cslRequestContext.getRelId());
        creditCardDtoList.forEach(creditCardDto -> {
            if (creditCardFromSS != null && creditCardFromSS.containsKey(creditCardDto.getCardNum())) {
                CreditCardDto cardDtoFromSS = creditCardFromSS.get(creditCardDto.getCardNum());
                creditCardDto.setDesc(cardDtoFromSS.getDesc());
            }
        });
    }


    private List<CreditCardDto> fetchCreditCardsFromSharedServices(CreditCardVO creditCardVO, Throwable e) {
        handleException(creditCardVO, e);
        List<CreditCardDto> creditCardDto = new ArrayList<>();
        try {
            creditCardDto = creditCardProfileV1SoapGateway.getCreditCardsFromSharedService(creditCardVO, e, cslRequestContext.getCountry() + cslRequestContext.getLanguage() + cslRequestContext.getRelId());
        } catch (Exception be) {
            handleException(creditCardVO, be);
            log.error("Error while fetching from 24x7 CreditCards :: {} ", be);
        }
        return creditCardDto;
    }

    // TODO use spring hystrix for fallback implemention
    private List<CreditCardDto> getCreditCardDetailsFromEdmi(CreditCardVO creditCardVO) {
        try {
            return creditCardProfileV1SoapGateway.getCreditCards(creditCardVO);
        } catch (BusinessException | TechnicalException ex) {
            if (cardUtil.isEmptyOrNull(creditCardVO.getInclude())) {
                return creditCardRestGateway.getOfflineCreditCardSummary();
            }
        }
        return null;
    }


    public List<CreditCardDto> getAllCreditCards(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = null;
        Date date = null;
        try {
            log.debug("[findAllCreditCard Entry]");
            date = new Date();
            log.info("start time...{}", date);
            creditCardValidator.validateRequest(creditCardVO);
            try {
                creditCards = creditCardProfileV1SoapGateway.getCreditCards(creditCardVO);
            } catch (Exception e) {
                log.info("Fetching from 24x7 DB for getCreditCards");
                creditCardProfileV1SoapGateway.getCreditCardsFromSharedService(creditCardVO, e, cslRequestContext.getCountry() + cslRequestContext.getLanguage() + cslRequestContext.getRelId());
            }
            log.info("Credit Card Service - start & end time...{},{}", date,
                    new Date());
        } finally {
            log.debug("[findAllCreditCard Exit]");
        }
        return creditCards;
    }

    public CreditCardDto findOneCreditCard(CreditCardVO creditCardVO) {
        CreditCardDto creditCard = null;
        try {
            log.info("[findOneCreditCard Entry]");
            creditCardVO.setCardNo(getCreditCardFromCardId(creditCardVO.getCardNo(), creditCardVO));
            validateCreditCardNo(creditCardVO);
            try {
                creditCard = creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO);
                if (!CardConstant.ENG_LANG_CODE.equals(cslRequestContext.getLanguage()) || creditCardVO.isMobileBalance()) {
                    CreditCardDto creditCardFromSS = creditCardEnquiryV1SoapGateway.findOneCreditCardInfoFromDB(creditCardVO, new Throwable("Prod Desc Not Available"), cslRequestContext.getCountry() + cslRequestContext.getLanguage() + cslRequestContext.getRelId());
                    if (StringUtils.isNotEmpty(creditCardFromSS.getDesc())) {
                        creditCard.setDesc(creditCardFromSS.getDesc());
                    }
                }
            } catch (Exception e) {
                creditCard = creditCardEnquiryV1SoapGateway.findOneCreditCardInfoFromDB(creditCardVO, e, cslRequestContext.getCountry() + cslRequestContext.getLanguage() + cslRequestContext.getRelId());
            }
        } finally {
            log.debug("[findOneCreditCard Exit]");
        }
        return creditCard;
    }


    public List<CreditCardDto> getCreditCardTransaction(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditList = new ArrayList<CreditCardDto>();
        CreditCardDto creditCard = null;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        Date date = null;
        List<CreditCardTransactionDto> creditCardTransactions = null;
        List<CreditCardTransactionDto> tmpCreditCardTransactions = null;
        try {
            if (!CardConstant.TRANSACTION.equalsIgnoreCase(creditCardVO.getFunctionType())) {
                validateCreditCardNo(creditCardVO);
            }
            creditCardTransactions = new ArrayList<CreditCardTransactionDto>();
            if ("S".equalsIgnoreCase(creditCardVO.getFunctionCd())) {
                tmpCreditCardTransactions = creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
                creditCardTransactions.addAll(tmpCreditCardTransactions);
            } else {
                do {
                    tmpCreditCardTransactions = creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
                    if (tmpCreditCardTransactions != null) {
                        creditCardVO.setStartPageNumber(tmpCreditCardTransactions.get(0).getSendPageCount());
                        creditCardTransactions.addAll(tmpCreditCardTransactions);
                    }
                }
                while (tmpCreditCardTransactions != null && (tmpCreditCardTransactions.get(0).getSendPageCount().substring(2, 3)
                        .equals(CardConstant.CONS_Y)));
            }
            for (CreditCardTransactionDto transactionDto : creditCardTransactions) {
                creditCard = new CreditCardDto();
                creditCard.setCardNum(transactionDto.getCardNum());
                creditCard.setFunctionCd(transactionDto.getFunctionCd());
                creditCard.setTxnType(transactionDto.getFunctionType());
            }
            creditCard.setCardtransactions(creditCardTransactions);
            creditList.add(creditCard);
            log.info("Credit Card Service - start & end time...{},{}", date, new Date());
        } finally {
            log.debug("[findAllCreditCard Exit]");
        }
        return creditList;
    }

    /**
     * @param creditCardVO
     * @return
     */
    public List<CreditCardTransactionDto> findAllCreditCardTransaction(CreditCardVO creditCardVO) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        try {
            log.info("[findAllCreditCardTransaction Entry]");
            validateCreditCardNo(creditCardVO);
            final List<CreditCardTransactionDto> creditCardTransactions = new ArrayList<>();
            creditCardEnquiryV1SoapGateway.getBilledTransactions(creditCardVO).forEach(billedTransaction -> creditCardTransactions.add(billedTransaction));
            try {
                List<CreditCardTransactionDto> unBilledTransactions = creditCardEnquiryV1SoapGateway.getUnBilledTransactions(creditCardVO).get();
                unBilledTransactions.forEach(unBilledTransaction -> creditCardTransactions.add(unBilledTransaction));
            }catch (Exception e) {
                log.error("Error while getting unbilled transactions from EDMI :: {} ",e.getMessage());
            }
            creditCardTransactions.sort((o1, o2) -> LocalDate.parse(o2.getEffDt(), formatter).compareTo(LocalDate.parse(o1.getEffDt(), formatter)));
            return creditCardTransactions;
        } finally {
            log.info("[findAllCreditCardTransaction Exit]");
        }
    }

    public List<CreditCardTransactionDto> findProvidedCreditCardTransactions(List<CreditCardVO> creditCards, QuerySpec querySpec) {
        log.info("Get Credit Card Transactions");
        List<CreditCardTransactionDto> alltransactions = new ArrayList<>();
        List<String> cCards = new ArrayList<>();
        List<String> cards = new ArrayList<>();
        List<CompletableFuture<List<CreditCardTransactionDto>>> futureList = new ArrayList<>();
        creditCards.forEach(creditCardVO -> {
            cCards.add("cc-" + creditCardVO.getCardNo());
            cards.add(creditCardVO.getCardNo());
            if (requestEdmi(querySpec)) {
                log.info("Fetching Credit Card Transactions from EDMI for {} ",creditCardVO.getCardNo());
                CompletableFuture<List<CreditCardTransactionDto>> unbilledTransactions = creditCardEnquiryV1SoapGateway.getUnBilledTransactions(creditCardVO);
                log.info("Credit Card Transactions from EDMI for {} ",creditCardVO.getCardNo());
                futureList.add(unbilledTransactions);

            }
        });
        Map<String, CreditCardDto> creditCardDtoMap = creditCardProfileV1SoapGateway.getProvidedCreditCardsFromSharedService(creditCards.get(0), cards, cslRequestContext.getCountry() + cslRequestContext.getLanguage() + cslRequestContext.getRelId());
        alltransactions.addAll(creditCardEnquiryV1SoapGateway.fetchProvidedCredidCardTransactions(cCards, querySpec, creditCardDtoMap));
        futureList.forEach(futureObj -> {
            try {
                alltransactions.addAll(futureObj.get());
            } catch (Exception e) {
                log.error("Error while getting the EDMI transactions future object :: {} ",e.getMessage() );
            }
        });
        return alltransactions;
    }

    private boolean requestEdmi(QuerySpec querySpec) {
        boolean executeEdmi = true;
        if (querySpec != null) {
            List<FilterSpec> filterSpecList = querySpec.getFilters();
            for (FilterSpec filterSpec : filterSpecList) {
                if (filterSpec.getAttributePath().contains("toDate")) {
                    DateTimeFormatter toDateformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                    String toDate = String.valueOf(filterSpec.getValue());
                    return toDate.equals(LocalDate.now().format(toDateformatter));
                }
            }
        }
        return executeEdmi;
    }


    public List<CreditCardTransactionDto> findCreditCardTransactionsFromDB(CreditCardVO creditCardVO, Throwable exception) {
        return creditCardEnquiryV1SoapGateway.fetchCreditCardTransactions(creditCardVO);
    }


    private long getNoOfDaysToFetchTransactions(String noOfdays) {
        long daysToFetchTrans = 1L;
        try {
            return Long.valueOf(noOfdays);
        } catch (NumberFormatException e) {
            log.error("Error while getting NoOfDays :: {} ", noOfdays);
            return daysToFetchTrans;
        }
    }

    private boolean isCurrentDayTransaction(Date transactionEffectiveDate) {
        try {
            return transactionEffectiveDate != null && transactionEffectiveDate.equals(new Date());
        } catch (IllegalArgumentException ex) {
            log.error("Error while validating the transaction Date :: {} , {}  ", transactionEffectiveDate, ex.getMessage());
            return false;
        }
    }

    public List<CreditCardTransactionDto> findCreditCardTransactions(CreditCardVO creditCardVO) {
        List<CreditCardTransactionDto> creditCardTransactions = null;
        List<CreditCardTransactionDto> tmpCreditCardTransactions = null;
        try {
            log.debug("[findAllCreditCardTransaction Entry]");
            creditCardTransactions = new ArrayList<CreditCardTransactionDto>();
            do {
                try {
                    tmpCreditCardTransactions = creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
                } catch (BusinessException be) {
                    log.info("No CreditCardTransactions found......");
                    throw be;
                } catch (Exception e) {
                    log.info("Fetching Credit card Transactions from 24x7 DB.");
                    tmpCreditCardTransactions = creditCardEnquiryV1SoapGateway.fetchCreditCardTransactions(creditCardVO);
                }
                if (tmpCreditCardTransactions != null
                        && tmpCreditCardTransactions.size() > CardConstant.ZERO) {
                    creditCardVO.setStartPageNumber(tmpCreditCardTransactions.get(0).getSendPageCount());
                    creditCardTransactions.addAll(tmpCreditCardTransactions);
                }
            } while (tmpCreditCardTransactions != null
                    && tmpCreditCardTransactions.size() > CardConstant.ZERO
                    && (tmpCreditCardTransactions.get(0).getSendPageCount()
                    .substring(2, 3).equals(CardConstant.CONS_Y)));
        } finally {
            log.debug("[findAllCreditCardTransaction Exit]");
        }
        return creditCardTransactions;
    }

    /**
     * this method would pull the Un-processed transaction from CCMS system using [getTransactionHistory - LPA2]
     *
     * @param creditCardVO
     * @return
     */
    public List<CreditCardTransactionDto> findCCMSUnprocessedCCTransactions(CreditCardVO creditCardVO) {
        List<CreditCardTransactionDto> creditCardTransactions = null;
        List<CreditCardTransactionDto> tmpCreditCardTransactions = null;
        try {
            log.debug("[findCCMSUnprocessedCCTransactions Entry]");
            creditCardTransactions = new ArrayList<CreditCardTransactionDto>();
            tmpCreditCardTransactions = creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
            creditCardTransactions.addAll(tmpCreditCardTransactions);
        } finally {
            log.debug("[findCCMSUnprocessedCCTransactions Exit]");
        }

        return creditCardTransactions;
    }

    private void validateCreditCardNo(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = null;
        log.info("[validateCreditCardNo Entry]");
        creditCardValidator.validateRequest(creditCardVO);
        creditCardValidator.validateCardNo(creditCardVO);
        if (ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditCardVO.getCountryCode())) {
            creditCards = creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO);
            creditCardVO.setCardNo(creditCards.get(0).getCardNum());
            creditCardVO.setCardNoSearch(true);
        } else {
        creditCardVO.setCardNoSearch(false);
    }
        try {
            creditCards = creditCardProfileV1SoapGateway.getCreditCards(creditCardVO);
        } catch (Exception e) {
            log.info("Fetching from 24x7 DB for getCreditCards");
            creditCards = creditCardProfileV1SoapGateway.getCreditCardsFromSharedService(creditCardVO, e, creditCardVO.getCountryCode() + creditCardVO.getRelId() + creditCardVO.getLangCode());
        }
        creditCardValidator.isCardExistByCustomerId(creditCards, creditCardVO);
        log.info("[validateCreditCardNo End]");
    }

    /**
     * @param creditCardVO
     * @return
     */
    public CreditCardDto findOneCreditCardDelinquencyHistory(CreditCardVO creditCardVO) {
        CreditCardDto creditCardDto = null;
        try {
            log.debug("[findOneCreditCardDelinquencyHistory Entry]");
            validateCreditCardNo(creditCardVO);
            creditCardDto = creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO);
        } finally {
            log.debug("[findOneCreditCardDelinquencyHistory Exit]");
        }
        return creditCardDto;
    }

    /**
     * @param ccPostDto
     * @return
     */
    public ServiceRequest generatePayLoad(CreditCardDto creditcardDto, CCFeeWaiverPostDto ccPostDto) {
        ServiceRequest serviceRequest = new ServiceRequest();
        HashMap<String, Object> feeWaiverRequstPayLoad = new HashMap<String, Object>();
        HashMap<String, Object> serviceRequestPayLoad = new HashMap<String, Object>();
        CustomerDto customerDetails = new CustomerDto();
        customerDetails.setRelationshipNo(cslRequestContext.getRelId());
        if (!CardUtil.isEmptyOrNull(cslRequestContext.getCustomerType())) {
            customerDetails.setRelationshipType(cslRequestContext.getCustomerType());
        } else {
            customerDetails.setRelationshipType(cslRequestContext.getRelId().substring(0, 2));
        }
        feeWaiverRequstPayLoad.put("customerDetails", customerDetails);
        feeWaiverRequstPayLoad.put("operationName", creditcardDto.getOperationName());
        feeWaiverRequstPayLoad.put("feeWaiverRequest", ccPostDto);
        serviceRequest.setServiceType(CardConstant.SERVICETYPE);
        serviceRequest.setStatus(CardConstant.INIT);


        serviceRequestPayLoad.put("serviceRequests", feeWaiverRequstPayLoad);
        serviceRequest.setPayload(serviceRequestPayLoad);

        serviceRequest.setCreatedBy(cslRequestContext.getOperatorId());
        return serviceRequest;
    }

    private LocalDate getTransactionStartDate(Long noOfDays) {
        LocalDate now = LocalDate.now();
        return now.minusDays(noOfDays);
    }


    public String getCreditCardFromCardId(String cardId, CreditCardVO creditCardVO) {
        int cardNoStartIndex = (cslRequestContext.getCountry() + cslRequestContext.getCustomerId()).length();
        String cardIdStartIndex = cardId.substring(0, cardNoStartIndex + 4);
        String cardNo = null;
        creditCardVO.setCardNo(null);
        List<CreditCardDto> cardDtoList = findAllCreditCard(creditCardVO);
        for (CreditCardDto creditCardDto : cardDtoList) {
            if (creditCardDto.getCardID().startsWith(cardIdStartIndex)) {
                cardNo = creditCardDto.getCardNum();
                break;
            }
        }
        if (cardNo == null) {
            log.warn("=====Card Id doesn't Match =====");
            throw new BusinessException(CreditCardErrorCode.ERR_CSL_CREDIT_CARD_NOT_MATCHED);
        }
        log.info("CardNumber :: {} ", cardNo);
        return cardNo;
    }

    public CreditCardDto getCardDetail(CreditCardVO creditCardVO) {
        CreditCardDto creditCard = null;
        try {
            log.debug("[findOneCreditCard Entry]");
            creditCard = creditCardProfileV1SoapGateway.getCardDetails(creditCardVO);
            creditCard.setIsCardHasPartialPayment(null);
        } finally {
            log.debug("[findOneCreditCard Exit]");
        }
        return creditCard;
    }

    private CreditCardVO populateCreditCardVO(CreditCardVO creditCardVO, String cardNo) {
        CreditCardVO creditCardVOTmp = new CreditCardVO();
        creditCardVOTmp.setCustomerId(creditCardVO.getCustomerId());
        creditCardVOTmp.setRelId(creditCardVO.getRelId());
        creditCardVOTmp.setCustomerType(creditCardVO.getCustomerType());
        creditCardVOTmp.setChannelId(creditCardVO.getChannelId());
        creditCardVOTmp.setCountryCode(creditCardVO.getCountryCode());
        creditCardVOTmp.setCardNo(cardNo);
        creditCardVOTmp.setCslRequestContext(creditCardVO.getCslRequestContext());
        creditCardVOTmp.setCardNoSearch(true);
        creditCardVOTmp.setFunctionCd(creditCardVO.getFunctionCd());
        creditCardVOTmp.setOperationName(creditCardVO.getOperationName());
        creditCardVOTmp.setInclude(creditCardVO.getInclude());
        creditCardVOTmp.setServiceTimeOut(creditCardVO.getServiceTimeOut());
        return creditCardVOTmp;
    }

    public List<CreditCardDto> getAsyncCreditCardList(Map<String, String> cardNumMap, CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = new ArrayList<>();
        List<CompletableFuture<CreditCardVO>> creditCardsFutureList = new ArrayList<>();
        try {
            if (CollectionUtils.size(cardNumMap) > 0) {
                log.info("creditCardDtoMap...{}", cardNumMap);
                List<String> cardNumList = new ArrayList(cardNumMap.values());
                for (String cardNo : cardNumList) {
                    CompletableFuture<CreditCardVO> creditCardsFuture = creditCardProfileV1SoapGateway.getAsyncCreditCardsList(populateCreditCardVO(creditCardVO, cardNo));
                    creditCardsFutureList.add(creditCardsFuture);
                }
            }

            if (CollectionUtils.isNotEmpty(creditCardsFutureList)) {
                CompletableFuture<List<CreditCardVO>> creditCardDetailsFuture = allOf(creditCardsFutureList);
                for (CreditCardVO vo : creditCardDetailsFuture.get()) {
                    if (!CardUtil.isEmptyOrNull(vo) && CollectionUtils.isNotEmpty(vo.getCreditCards())) {
                        creditCards.addAll(vo.getCreditCards());
                    }
                }
                log.info("getAsyncCreditCardList...before remove duplicate cardList.size....{}", CollectionUtils.size(creditCards));
                creditCards = creditCards.stream().filter(distinctByKey(p -> p.getCardNum())).collect(Collectors.toList());
                log.info("getAsyncCreditCardList...after removed duplicate cardList.size....{}", CollectionUtils.size(creditCards));
            }
        } catch (BusinessException ex) {
            log.info("getAsyncCreditCardList...BusinessException....{}", ex.getErrorCode());
            throw ex;
        } catch (ExecutionException | InterruptedException ex) {
            log.info("getAsyncCreditCardList...ExecutionException/InterruptedException....{}", ex);
            throw new TechnicalException(ex);
        }
        return creditCards;
    }

    public List<CreditCardDto> getAsyncCreditCardDetails(List<CreditCardDto> cardList, CreditCardVO creditCardVO) {
        List<CompletableFuture<CreditCardDto>> creditCardDetailsFutureList = new ArrayList<>();
        try {
            if (CollectionUtils.size(cardList) > 0) {
                for (CreditCardDto dto : cardList) {
                    CompletableFuture<CreditCardDto> creditCardDetailsFuture = creditCardEnquiryV1SoapGateway.getAsyncCreditCard(populateCreditCardVO(creditCardVO, dto.getCardNum()));
                    creditCardDetailsFutureList.add(creditCardDetailsFuture);
                }
            }

            if (CollectionUtils.isNotEmpty(creditCardDetailsFutureList)) {
                CompletableFuture<List<CreditCardDto>> creditCardDetailsFuture = allOf(creditCardDetailsFutureList);
                for (CreditCardDto dto : cardList) {
                    for (CreditCardDto cardDetailsDto : creditCardDetailsFuture.get()) {
                        if (!CardUtil.isEmptyOrNull(dto) && StringUtils.equals(dto.getCardNum(), cardDetailsDto.getCardNum())) {
                            dto.setCardExpired(cardDetailsDto.getCardExpired());
                            dto.setBlkCdDtRplPeriod(cardDetailsDto.getBlkCdDtRplPeriod());
                            dto.setCardRplTrnEffDate(cardDetailsDto.getCardRplTrnEffDate());
                            dto.setAltBlockCode(cardDetailsDto.getAltBlockCode());
                            dto.setCardRplAltBlockCode(cardDetailsDto.getCardRplAltBlockCode());
                            dto.setCardEmbossingInfos(cardDetailsDto.getCardEmbossingInfos());
                            dto.setCardValiditySts(cardDetailsDto.getCardValiditySts());
                        }
                    }
                }
            }
        } catch (BusinessException ex) {
            log.info("getAsyncCreditCardDetails...BusinessException....{}", ex.getErrorCode());
            throw ex;
        } catch (ExecutionException | InterruptedException ex) {
            log.info("getAsyncCreditCardDetails...ExecutionException/InterruptedException....{}", ex);
            throw new TechnicalException(ex);
        }
        return cardList;
    }

    public List<CreditCardDto> getAsyncCCDetailsForEmbosserName(List<CreditCardDto> cardList, CreditCardVO creditCardVO) throws CloneNotSupportedException {
        List<CompletableFuture<CreditCardDto>> creditCardDetailsFutureList = new ArrayList<>();
        List<CreditCardDto> embosserNameList = new ArrayList<>();
        if (CollectionUtils.size(cardList) > 0) {
            for (CreditCardDto dto : cardList) {
                CompletableFuture<CreditCardDto> creditCardDetailsFuture = creditCardEnquiryV1SoapGateway.getAsyncCreditCard(populateCreditCardVO(creditCardVO, dto.getCardNum()));
                if (null != creditCardDetailsFuture) {
                    creditCardDetailsFutureList.add(creditCardDetailsFuture);
                }
            }
        }
        try {
            if (CollectionUtils.isNotEmpty(creditCardDetailsFutureList)) {
                CompletableFuture<List<CreditCardDto>> creditCardDetailsFuture = allOf(creditCardDetailsFutureList);
                for (CreditCardDto dto : cardList) {
                    for (CreditCardDto cardDetailsDto : creditCardDetailsFuture.get()) {
                        if (!CardUtil.isEmptyOrNull(dto)
                                && StringUtils.equals(dto.getCardNum(), cardDetailsDto.getCardNum())) {
                            dto.setCardExpired(cardDetailsDto.getCardExpired());
                            dto.setBlkCdDtRplPeriod(cardDetailsDto.getBlkCdDtRplPeriod());
                            dto.setCardRplTrnEffDate(cardDetailsDto.getCardRplTrnEffDate());
                            dto.setAltBlockCode(cardDetailsDto.getAltBlockCode());
                            dto.setCardRplAltBlockCode(cardDetailsDto.getCardRplAltBlockCode());
                            if (cardDetailsDto.getCardEmbossingInfos().size() > 1) {
                                for (int i = 0; i < cardDetailsDto.getCardEmbossingInfos().size(); i++) {
                                    if (i == 0) {
                                        dto.setDesc(dto.getDesc() + CardConstant.PAD_HYPHEN + cardDetailsDto.getCardEmbossingInfos().get(i).getEmbosserName());
                                        dto.setEmbossedName(cardDetailsDto.getCardEmbossingInfos().get(i).getEmbosserName());
                                    } else {
                                        CreditCardDto cloneDTO = (CreditCardDto) dto.clone();
                                        cloneDTO.setDesc(cloneDTO.getDesc() + CardConstant.PAD_HYPHEN + cardDetailsDto.getCardEmbossingInfos().get(i).getEmbosserName());
                                        embosserNameList.add(cloneDTO);
                                        cloneDTO.setEmbossedName(cardDetailsDto.getCardEmbossingInfos().get(i).getEmbosserName());
                                    }
                                }
                            } else if (CollectionUtils.isNotEmpty(cardDetailsDto.getCardEmbossingInfos())) {
                                dto.setDesc(dto.getDesc() + CardConstant.PAD_HYPHEN + cardDetailsDto.getCardEmbossingInfos().stream().findFirst().get().getEmbosserName());
                                dto.setEmbossedName(cardDetailsDto.getCardEmbossingInfos().stream().findFirst().get().getEmbosserName());
                            }
                        }
                    }
                }
                if (!embosserNameList.isEmpty()) {
                    cardList.addAll(embosserNameList);
                }
            }
        } catch (BusinessException ex) {
            log.info("getAsyncCreditCardDetails...BusinessException....{}", ex.getErrorCode());
            throw ex;
        } catch (ExecutionException | InterruptedException ex) {
            log.info("getAsyncCreditCardDetails...ExecutionException/InterruptedException....{}", ex);
            throw new TechnicalException(ex);
        }
        return cardList;
    }

    public List<CreditCardDto> getAsyncCreditCardFinanceDetails(List<CreditCardDto> cardList, CreditCardVO creditCardVO) {
        List<CompletableFuture<CreditCardDto>> creditCardFinanceDetailsFutureList = new ArrayList<>();
        try {
            if (CollectionUtils.size(cardList) > 0) {
                for (CreditCardDto dto : cardList) {
                    CompletableFuture<CreditCardDto> creditCardFinanceDetailsFuture = creditCardEnquiryV1SoapGateway.getAsyncCreditCardFinancialDetails(populateCreditCardVO(creditCardVO, dto.getCardNum()));
                    creditCardFinanceDetailsFutureList.add(creditCardFinanceDetailsFuture);
                }
            }

            if (CollectionUtils.isNotEmpty(creditCardFinanceDetailsFutureList)) {
                CompletableFuture<List<CreditCardDto>> creditCardDetailsFuture = allOf(creditCardFinanceDetailsFutureList);
                for (CreditCardDto dto : cardList) {
                    for (CreditCardDto financeDetailsDto : creditCardDetailsFuture.get()) {
                        if (!CardUtil.isEmptyOrNull(dto)
                                && StringUtils.equals(dto.getCardNum(), financeDetailsDto.getCardNum())) {
                            dto.setAgreementStatus(financeDetailsDto.getAgreementStatus());
                            dto.setAgmtStsInd(financeDetailsDto.getAgmtStsInd());
                            dto.setBankChargesRate(financeDetailsDto.getBankChargesRate());
                            dto.setBankChargesAmount(financeDetailsDto.getBankChargesAmount());
                            dto.setCashAdvanceFeeRate(financeDetailsDto.getCashAdvanceFeeRate());
                            dto.setAvlblLimit(financeDetailsDto.getAvlblLimit());
                        }
                    }
                }
            }
        } catch (BusinessException ex) {
            log.info("getAsyncCreditCardFinanceDetails...BusinessException....{}", ex.getErrorCode());
            throw ex;
        } catch (ExecutionException | InterruptedException ex) {
            log.info("getAsyncCreditCardFinanceDetails...ExecutionException/InterruptedException....{}", ex);
            throw new TechnicalException(ex);
        }
        return cardList;
    }

    public List<CreditCardDto> getAsyncComboCardDetails(List<CreditCardDto> cardList, CreditCardVO creditCardVO) {
        String errorCode = null;
        String errorDesc = null;
        List<CompletableFuture<DebitCardDto>> comboCardDetailsFutureList = new ArrayList<>();
        if (CollectionUtils.size(cardList) > 0) {
            try {
                for (CreditCardDto dto : cardList) {
                    CompletableFuture<DebitCardDto> comboCardDetailsFuture = debitCardsV3CSLGateway.getAsyncComboCardDetails(populateCreditCardVO(creditCardVO, dto.getCardNum()));
                    comboCardDetailsFutureList.add(comboCardDetailsFuture);
                }
                if (CollectionUtils.isNotEmpty(comboCardDetailsFutureList)) {
                    CompletableFuture<List<DebitCardDto>> comboCardDetailsFuture = allOf(comboCardDetailsFutureList);
                    for (CreditCardDto dto : cardList) {
                        for (DebitCardDto comboDto : comboCardDetailsFuture.get()) {
                            if (!CardUtil.isEmptyOrNull(dto)
                                    && StringUtils.equals(dto.getCardNum(), comboDto.getCardNum())
                                    && !CardUtil.isEmptyOrNull(comboDto.getCardSubType())
                                    && StringUtils.equals(CardConstant.COMBO_CARD_SUB_TYPE, comboDto.getCardSubType())) {
                                dto.setIsComboFlag(CardConstant.CONS_Y);
                            }
                        }
                    }
                }
            } catch (InterruptedException | ExecutionException e) {
                log.error("getAsyncComboCardDetails Future Exception...{}", e.getLocalizedMessage());
                if (e.getCause() instanceof CSLKatharsisClientException) {
                    errorCode = ((CSLKatharsisClientException) e.getCause()).getErrorData().getCode();
                    errorDesc = ((CSLKatharsisClientException) e.getCause()).getErrorData().getDetail();
                    log.info("CSLKatharsisClientException - errorCode-{}", ((CSLKatharsisClientException) e.getCause()).getErrorData().getCode());
                    log.info("CSLKatharsisClientException - title-{}", ((CSLKatharsisClientException) e.getCause()).getErrorData().getTitle());
                    log.info("CSLKatharsisClientException - detail-{}", ((CSLKatharsisClientException) e.getCause()).getErrorData().getDetail());
                } else if (e.getCause() instanceof BadRequestException) {
                    errorCode = ((BadRequestException) e.getCause()).getErrorData().getCode();
                    errorDesc = ((BadRequestException) e.getCause()).getErrorData().getDetail();
                    log.info("BadRequestException - errorCode-{}", ((BadRequestException) e.getCause()).getErrorData().getCode());
                    log.info("BadRequestException - title-{}", ((BadRequestException) e.getCause()).getErrorData().getTitle());
                    log.info("BadRequestException - detail-{}", ((BadRequestException) e.getCause()).getErrorData().getDetail());
                }

                if ((!CardUtil.isEmptyOrNull(errorCode) && ArrayUtils.contains(CardConstant.COMBO_CARD_ALLOWED_ERROR_CDS, errorCode))
                        || (!CardUtil.isEmptyOrNull(errorDesc) && ArrayUtils.contains(CardConstant.COMBO_CARD_ALLOWED_ERROR_DESCS, StringUtils.lowerCase(errorDesc)))) {
                    log.info("Invalid Card number error code from host");
                } else {
                    throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Combo Card Details Request", "getting exception"));
                }
            }
        }
        return cardList;
    }

    protected <T> CompletableFuture<List<T>> allOf(List<CompletableFuture<T>> futuresList) {
        CompletableFuture<Void> allFuturesResult =
                CompletableFuture.allOf(futuresList.toArray(new CompletableFuture[futuresList.size()]));
        return allFuturesResult.thenApply(v ->
                futuresList.stream().
                        map(future -> future.join()).
                        collect(Collectors.<T>toList())
        );
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
        Map<Object, Boolean> map = new ConcurrentHashMap<>();
        return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
    }

    public List<CreditCardDto> combineNextCreditCardsListByPageIndicator(List<CreditCardDto> creditCards, CreditCardVO creditCardVO) {
        List<CreditCardDto> tmpCreditCards = null;
        CreditCardVO creditCardVO1 = null;
        String startPageRefNum = null;
        try {
            log.info("[combineNextCreditCardsListByPageIndicator Entry]");
            if (!CardUtil.isEmptyOrNull(creditCards) && StringUtils.equals(StringUtils.substring(creditCards.get(0).getStartPageRefNum(), 2, 3), CardConstant.CONS_Y)) {
                tmpCreditCards = new ArrayList<CreditCardDto>();
                startPageRefNum = creditCards.get(0).getStartPageRefNum();
                do {
                    log.info("[combineNextCreditCardsListByPageIndicator startPageRefNum]-{}", startPageRefNum);
                    creditCardVO1 = new CreditCardVO();
                    creditCardVO1.setStartPageRefNumber(startPageRefNum);
                    creditCardVO1.setCustomerId(creditCardVO.getCustomerId());
                    creditCardVO1.setRelId(creditCardVO.getRelId());
                    creditCardVO1.setCustomerType(creditCardVO.getCustomerType());
                    creditCardVO1.setChannelId(creditCardVO.getChannelId());
                    creditCardVO1.setCountryCode(creditCardVO.getCountryCode());
                    creditCardVO1.setCslRequestContext(creditCardVO.getCslRequestContext());
                    creditCardVO1.setCardNoSearch(false);
                    creditCardVO1.setFunctionCd(creditCardVO.getFunctionCd());
                    creditCardVO1.setOperationName(creditCardVO.getOperationName());
                    try {
                        tmpCreditCards = creditCardProfileV1SoapGateway.getCreditCards(creditCardVO1);
                    } catch (Exception e) {
                        log.info("Fetching from 24x7 DB for getCreditCards");
                        tmpCreditCards = creditCardProfileV1SoapGateway.getCreditCardsFromSharedService(creditCardVO1, e, creditCardVO.getCountryCode() + creditCardVO.getRelId() + creditCardVO.getLangCode());
                    }
                    if (!CardUtil.isEmptyOrNull(tmpCreditCards)) {
                        startPageRefNum = tmpCreditCards.get(0).getStartPageRefNum();
                        creditCards.addAll(tmpCreditCards);
                    } else {
                        return creditCards;
                    }
                }
                while (!CardUtil.isEmptyOrNull(tmpCreditCards) && StringUtils.equals(StringUtils.substring(tmpCreditCards.get(0).getStartPageRefNum(), 2, 3), CardConstant.CONS_Y));
            }
        } finally {
            log.debug("[combineNextCreditCardsListByPageIndicator Exit]");
        }
        return creditCards;
    }

    public CreditCardDto getCreditCardLimitBalance(CreditCardVO creditCardVO) {
        CreditCardDto creditCard = null;
        ValidateLimitIncreaseRes validateLimitIncreaseRes = null;
        List<AcctBalType> acctBalType = null;

        log.info("[getCreditCardLimitBalance Entry]");
        // validateCreditCardNo(creditCardVO);
        validateLimitIncreaseRes = creditCardLimitV1SoapGateway.getCreditCardBalanceLimit(creditCardVO);
        if (null != validateLimitIncreaseRes && null != validateLimitIncreaseRes.getValidateLimitIncreaseResPayload()
                && null != validateLimitIncreaseRes.getValidateLimitIncreaseResPayload().getValidateLimitIncreaseRes()
                && null != validateLimitIncreaseRes.getValidateLimitIncreaseResPayload().getValidateLimitIncreaseRes().getValidateLimitIncreaseRs()
                && null != validateLimitIncreaseRes.getValidateLimitIncreaseResPayload().getValidateLimitIncreaseRes().getValidateLimitIncreaseRs()
                .getSCBCLIResultDetails()
                && null != validateLimitIncreaseRes.getValidateLimitIncreaseResPayload().getValidateLimitIncreaseRes().getValidateLimitIncreaseRs()
                .getSCBCLIResultDetails().getCardBal()) {
            acctBalType = validateLimitIncreaseRes.getValidateLimitIncreaseResPayload().getValidateLimitIncreaseRes().
                    getValidateLimitIncreaseRs().getSCBCLIResultDetails().getCardBal();
            List<CardBalanceLimitDto> cardBalanceList = orikaMapper.mapAsList(acctBalType, CardBalanceLimitDto.class);
            if (!CardUtil.isEmptyOrNull(cardBalanceList)) {
                creditCard = new CreditCardDto();
                creditCard.setCardNum(creditCardVO.getCardNo());
                creditCard.setCardID(creditCardVO.getCardNo());
                creditCard.setIsCardHasPartialPayment(null);
                for (CardBalanceLimitDto balanceDto : cardBalanceList) {
                    if (CardConstant.EXISITING_CARD_LIMIT.equalsIgnoreCase(balanceDto.getBalTypeValue())) {
                        creditCard.setExistingLimitDetails(balanceDto);
                    }
                    if (CardConstant.MAXIMUM_CARD_LIMIT.equalsIgnoreCase(balanceDto.getBalTypeValue())) {
                        creditCard.setMaximumLimitDetails(balanceDto);
                    }
                }
            } else {
                throw new BusinessException(CreditCardErrorCode.ERR_CSL_CREDIT_CARD_NO_LIMIT_FOUND);
            }
        } else {
            throw new BusinessException(CreditCardErrorCode.ERR_CSL_CREDIT_CARD_NO_LIMIT_FOUND);
        }

        return creditCard;
    }

    private List<IncludeRelationSpec> getIncludedRelations(QuerySpec querySpec) {
        return querySpec.getIncludedRelations();
    }

    private boolean containsRelation(QuerySpec querySpec, String relationName) {
        return getIncludedRelations(querySpec).stream()
                .anyMatch(relation -> relation.toString().equalsIgnoreCase(relationName));
    }

    private void populateReplacementFileds(List<CreditCardDto> creditCards, CreditCardVO creditCardVO) {
        if (!CardUtil.isEmptyOrNull(creditCardVO)) {
            CreditCardFilterProperties filterProperties = ((CreditCardProperties) getCreditCardPropertiesByCountry(creditCardVO.getCountryCode())).getCreditCardFilters();
            if (!CardUtil.isEmptyOrNull(creditCards)) {
                for (CreditCardDto dto : creditCards) {
                    dto.setCardRplInd(CardUtil.getCardRplC400Ind(dto.getCardNum(), dto.getBlockCode(), dto.getCardValiditySts(), dto.getIsPrimary(), creditCards, dto.getSubProd(), filterProperties));
                }
            }
        }
    }
}
