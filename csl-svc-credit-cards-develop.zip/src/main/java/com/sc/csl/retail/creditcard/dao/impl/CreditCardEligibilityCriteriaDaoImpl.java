package com.sc.csl.retail.creditcard.dao.impl;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;

import lombok.extern.slf4j.Slf4j;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardEligibilityCriteriaDao;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityCriteriaDto;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * Repository to check the eligibility from info fetched from EDMP for IN, MY
 * and SG regions. This uses HBase library to fetch the connection.
 */

@Repository
@Slf4j
public class CreditCardEligibilityCriteriaDaoImpl  extends BaseEDMPDao  implements
		CreditCardEligibilityCriteriaDao {

	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private CardUtil cardUtil;

	@Override
	public void getEligibilityRefreshdate(Map<String, Object> journeyMap, CreditCardFeeWaiverProperties props){
		
		log.info("Entered in getEligibilityRefreshdate()....");
		String tableName = props.getRaRefreshTable();

		String key = CardConstant.KEY_EDMP_ELIGIBILITY_BATCH_DT;
		String format = CardConstant.EDMP_TBL_REFRESH_DATE_FORMAT;
		// Below method will fetch the batch refresh data from EDMP and set it in journeyMap with above mentioned variable - "key"
		getMaxdate(journeyMap, tableName, key, format);
		log.info("Exit from  in getEligibilityRefreshdate()....");
	}
	
	@Override
	public CreditCardEligibilityCriteriaDto getINEligibilityCriteria(
			Map<String, Object> journeyMap, String input, String level, String tableName) {
		log.info("Entered in getINEligibilityCriteria(),  Level ["+level+"], Input ["+ input +"]");
		CreditCardEligibilityCriteriaDto ccEligibilityDto = new CreditCardEligibilityCriteriaDto();
		Connection conn = null;
		Table tab = null;
		SingleColumnValueFilter filter = null;
		try{		
			try {
				conn = fetchEDMPHBaseConnection(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString());
				
				tab = conn.getTable(TableName
						.valueOf(tableName));
				Scan scan = new Scan();
				if (CardConstant.ELIGIBILITY_CARD_LEVEL.equalsIgnoreCase(level)) {
					filter = getSingleColValFilter(CardConstant.COL_FAM_NAME,
							CardConstant.COL_CARD_NUM, input);
				} else if (CardConstant.ELIGIBILITY_CUSTOMER_LEVEL
						.equalsIgnoreCase(level)) {
					filter = getSingleColValFilter(CardConstant.COL_FAM_NAME,
							CardConstant.COL_CUST_ID, input);
				}
	
				scan.setFilter(filter);
				ResultScanner resultScanner = tab.getScanner(scan);
				Iterator<Result> iterator = resultScanner.iterator();
					if (iterator.hasNext()) {
						Result next = iterator.next();
		
						for (Entry<byte[], NavigableMap<byte[], NavigableMap<Long, byte[]>>> columnFamilyMap : next
								.getMap().entrySet()) {
							for (Entry<byte[], NavigableMap<Long, byte[]>> entryVersion : columnFamilyMap
									.getValue().entrySet()) {
								for (Entry<Long, byte[]> entry : entryVersion
										.getValue().entrySet()) {
									String column = Bytes.toString(
											entryVersion.getKey()).trim();
									String value = new String(entry.getValue()).trim();
									// map the data from hBase table to
									// CreditCardEligibilityCriteriaDto
									switch (column) {
									case CardConstant.COL_CARD_NUM:
										ccEligibilityDto.setCardNumber(value);
										break;
									case CardConstant.COL_CARD_TYPE:
										ccEligibilityDto.setCardType(value);
										break;
									case CardConstant.COL_DECILE:
										ccEligibilityDto.setValueToBank(value);
										break;
									case CardConstant.COL_ELIGIBILITY_FLAG:
										ccEligibilityDto
												.setEligibilityStatusOthers(value);
										break;
									case CardConstant.COL_ELIGIBILITY_FLAG_OT:
										ccEligibilityDto.setEligibilityStatusOL(value);
										break;
									case CardConstant.COL_ELIGIBILITY_PER_AF:
										ccEligibilityDto
												.setEligibilityPercentageAF(value);
										break;
									case CardConstant.COL_ELIGIBILITY_PER_IF:
										ccEligibilityDto
												.setEligibilityPercentageIF(value);
										break;
									case CardConstant.COL_ELIGIBILITY_PER_LF:
										ccEligibilityDto
												.setEligibilityPercentageLF(value);
										break;
									case CardConstant.COL_ELIGIBILITY_PER_OL:
										ccEligibilityDto
												.setEligibilityPercentageOL(value);
										break;
									}
								}
							}
						}
						log.info("Fetched Info: " + ccEligibilityDto.toString());
						ccEligibilityDto.setIsObjNull(CardConstant.CONS_N);
					}
				}
			finally{
				tab.close();
				conn.close();
				}
			} catch (Exception e) {
			log.error("Exception Occured in CreditCardEligibilityCriteriaDaoImpl-IN while scanning for data from HBase");
			if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY)){
				log.info("Failed to connect to EDMP - HBASE primary connection. Retrying with DR DB");
				journeyMap.put(CardConstant.KEY_EDMP_CONFIG, CardConstant.KEY_EDMP_HBASE_DR_CONFIG);
				getINEligibilityCriteria(journeyMap, input, level, tableName);
			}
			else if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_DR_CONFIG)){
				log.error("Failed to connect to EDMP - HBASE DR connection...");
				throw new TechnicalException(e);
			}
		}
		return ccEligibilityDto;
	}

	@Override
	public CreditCardEligibilityCriteriaDto getSGEligibilityCriteria(
			Map<String, Object> journeyMap, String input, String level, String tableName) {
		log.info("Entered in getSGEligibilityCriteria(),  Level ["+ level +"], Input ["+ input +"]"); 
		CreditCardEligibilityCriteriaDto ccEligibilityDto = new CreditCardEligibilityCriteriaDto();
		Connection conn = null;
		Table tab = null;
		SingleColumnValueFilter filter = null;
		try {
			try {
				conn = fetchEDMPHBaseConnection(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString());
				tab = conn.getTable(TableName
						.valueOf(tableName));
				Scan scan = new Scan();
				if (CardConstant.ELIGIBILITY_CARD_LEVEL.equalsIgnoreCase(level)) {
					filter = getSingleColValFilter(CardConstant.COL_FAM_NAME,
							CardConstant.COL_SG_CARD_NUM, input);
				} else if (CardConstant.ELIGIBILITY_CUSTOMER_LEVEL
						.equalsIgnoreCase(level)) {
					filter = getSingleColValFilter(CardConstant.COL_FAM_NAME,
							CardConstant.COL_SG_CUST_NUM, input);
				}

				scan.setFilter(filter);
				ResultScanner resultScanner = tab.getScanner(scan);
				Iterator<Result> iterator = resultScanner.iterator();
				if (iterator.hasNext()) {
					Result next = iterator.next();

					for (Entry<byte[], NavigableMap<byte[], NavigableMap<Long, byte[]>>> columnFamilyMap : next
							.getMap().entrySet()) {
						for (Entry<byte[], NavigableMap<Long, byte[]>> entryVersion : columnFamilyMap
								.getValue().entrySet()) {
							for (Entry<Long, byte[]> entry : entryVersion
									.getValue().entrySet()) {
								String column = Bytes.toString(
										entryVersion.getKey()).trim();
								String value = new String(entry.getValue())
										.trim();

								// map the data from hBase table to
								// CreditCardEligibilityCriteriaDto

								switch (column) {
								case CardConstant.COL_SG_LF_ELIGIBLE:
									ccEligibilityDto.setLateFeeEligible(value);
									break;
								case CardConstant.COL_SG_AF_ELIGIBLE:
									ccEligibilityDto
											.setAnnualFeeEligible(value);
									break;
								case CardConstant.COL_SG_AF_NOT_WAIVED:
									ccEligibilityDto
											.setAnnualFeeChargeNotWaived(value);
									break;

								}
							}
						}
					}
					log.info("Fetched Info: " + ccEligibilityDto.toString());
					ccEligibilityDto.setIsObjNull(CardConstant.CONS_N);
				}
			} finally {
				tab.close();
				conn.close();
			}
		} catch (IOException e) {
			log.error("Exception Occured in CreditCardEligibilityCriteriaDaoImpl-SG while scanning for data from HBase");
			if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY)){
				log.info("Failed to connect to EDMP - HBASE primary connection. Retrying with DR DB");
				journeyMap.put(CardConstant.KEY_EDMP_CONFIG, CardConstant.KEY_EDMP_HBASE_DR_CONFIG);
				getSGEligibilityCriteria(journeyMap, input, level, tableName);
			}
			else if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_DR_CONFIG)){
				log.error("Failed to connect to EDMP - HBASE DR connection...");
				throw new TechnicalException(e);
			}
		}

		log.info("Exit from getINEligibilityCriteria()");
		return ccEligibilityDto;
	}

	@Override
	public CreditCardEligibilityCriteriaDto getMYEligibilityCriteria(
			Map<String, Object> journeyMap, String customerId, String tableName) {
		log.info("Enterd in getMYEligibilityCriteria(),  CustomerId ["+customerId+"]");
		CreditCardEligibilityCriteriaDto ccEligibilityDto = new CreditCardEligibilityCriteriaDto();
		Connection conn = null;
		Table tab = null;
		SingleColumnValueFilter filter = null;
		try {
			try {
				conn = fetchEDMPHBaseConnection(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString());
				tab = conn.getTable(TableName
						.valueOf(tableName));
				Scan scan = new Scan();
				filter = getSingleColValFilter(CardConstant.COL_FAM_NAME,
						CardConstant.COL_CARD_NUM, customerId);
				scan.setFilter(filter);
				ResultScanner resultScanner = tab.getScanner(scan);
				Iterator<Result> iterator = resultScanner.iterator();
				if (iterator.hasNext()) {
					Result next = iterator.next();

					for (Entry<byte[], NavigableMap<byte[], NavigableMap<Long, byte[]>>> columnFamilyMap : next
							.getMap().entrySet()) {
						for (Entry<byte[], NavigableMap<Long, byte[]>> entryVersion : columnFamilyMap
								.getValue().entrySet()) {
							for (Entry<Long, byte[]> entry : entryVersion
									.getValue().entrySet()) {
								String column = Bytes.toString(
										entryVersion.getKey()).trim();
								String value = new String(entry.getValue())
										.trim();

								// map the data from hBase table to
								// CreditCardEligibilityCriteriaDto

								switch (column) {
								case CardConstant.COL_MY_X_REMARK:
									ccEligibilityDto.setXRemark(value);
									break;
								}
							}
						}
					}
					log.info("Fetched Info: " + ccEligibilityDto.toString());
					ccEligibilityDto.setIsObjNull(CardConstant.CONS_N);
				}
			} finally {
				tab.close();
				conn.close();

			}
		} catch (IOException e) {
			log.error("Exception Occured in CreditCardEligibilityCriteriaDaoImpl-MY while scanning for data from HBase");
			if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY)){
				log.info("Failed to connect to EDMP - HBASE primary connection. Retrying with DR DB");
				journeyMap.put(CardConstant.KEY_EDMP_CONFIG, CardConstant.KEY_EDMP_HBASE_DR_CONFIG);
				getMYEligibilityCriteria(journeyMap, customerId, tableName);
			}
			else if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_DR_CONFIG)){
				log.error("Failed to connect to EDMP - HBASE DR connection...");
				throw new TechnicalException(e);
			}
		}

		log.info("Exit from getMYEligibilityCriteria()");
		return ccEligibilityDto;
	}

	@Override
	public CreditCardEligibilityCriteriaDto getHKEligibilityCriteria(
			Map<String, Object> journeyMap, String input, String level,
			String tableName) {
		log.info("Enterd in getHKEligibilityCriteria(),  Level ["+level+"], Input ["+ input +"]");
		CreditCardEligibilityCriteriaDto ccEligibilityDto = new CreditCardEligibilityCriteriaDto();
		ccEligibilityDto.setIsObjNull(CardConstant.CONS_Y);
		Connection conn = null;
		Table tab = null;
		SingleColumnValueFilter filter = null;
		try {
			try {
				conn = fetchEDMPHBaseConnection(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString());
				tab = conn.getTable(TableName
						.valueOf(tableName));
				Scan scan = new Scan();
				if (CardConstant.ELIGIBILITY_CARD_LEVEL.equalsIgnoreCase(level)) {
					filter = getSingleColValFilter(CardConstant.COL_FAM_NAME,
							CardConstant.COL_HK_CARD_NUM, input);
				}

				scan.setFilter(filter);
				ResultScanner resultScanner = tab.getScanner(scan);
				Iterator<Result> iterator = resultScanner.iterator();
				if (iterator.hasNext()) {
					ccEligibilityDto.setIsObjNull(CardConstant.CONS_N);
					log.info("getHKEligibilityCriteria() selected Card is eligible");
				}
			} finally {
				tab.close();
				conn.close();
			}
		} catch (IOException e) {
			log.error("Exception Occured in CreditCardEligibilityCriteriaDaoImpl-HK while scanning for data from HBase");
			if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY)){
				log.info("Failed to connect to EDMP - HBASE primary connection. Retrying with DR DB");
				journeyMap.put(CardConstant.KEY_EDMP_CONFIG, CardConstant.KEY_EDMP_HBASE_DR_CONFIG);
				getHKEligibilityCriteria(journeyMap, input, level, tableName);
			}
			else if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_DR_CONFIG)){
				log.error("Failed to connect to EDMP - HBASE DR connection...");
				throw new TechnicalException(e);
			}
		}
		log.info("Exit from getHKEligibilityCriteria()");
		return ccEligibilityDto;
	}

}
