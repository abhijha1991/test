package com.sc.csl.retail.creditcard.service.security;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.dto.customer.CreditCardContact;
import com.sc.csl.retail.creditcard.dto.security.SmsOtp;
import com.sc.csl.retail.creditcard.dto.security.ValidateOtp;
import com.sc.csl.retail.creditcard.exception.CardException;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.csl.CustomerJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.SmsOtpGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ValidateOtpGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;

@Slf4j
@Data
@Service
public class SmsOtpRequiredService {
    private static final String SMS_OTP = "smsOtp";
    private static final String STATUS_CODE_KEY = "statusCode";
    private static final String ERROR_MESSAGE = "errorMessage";

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    private SmsOtpGateway otpGateway;

    @Autowired
    private ValidateOtpGateway validateOtpGateway;

    @Autowired
    private CustomerJsonApiGateway customerJsonApiGateway;

    @Autowired
    CreditCardRepositoryDao ccDao;

    public void otprequired() {
        if (getOTPStatus()) {
            log.info("Deciding : Sending OTP / validating OTP");
            String otpToken = cslRequestContext._otpToken();
            if (null == otpToken) {
                String formattedMobileNo = getOTPMobileNumber();
                this.sendOtp(formattedMobileNo);
            } else {
                this.validateOtp(otpToken);
            }
        } else {
            log.info("OTP functionality status is OFF for Country {} ", cslRequestContext.getCountry());
        }
    }

    private void sendOtp(String phoneNumber) {
        log.info("Sending Otp");
        SmsOtp response = otpGateway.sendOtp(phoneNumber);
        String smsOtpResponse = CSLJsonUtils.toJson(response);
        log.debug("Sms Otp response : {}", smsOtpResponse);
        @SuppressWarnings("unchecked")
        Map<String, Object> smsOtpResponseMap = CSLJsonUtils.parseJson(smsOtpResponse, Map.class);

        if ("100".equals(smsOtpResponseMap.get(STATUS_CODE_KEY))) {
            // @SuppressWarnings("unchecked")
            // Map<String, Object> smsOtpMap = (Map<String, Object>) smsOtpResponseMap.get(SMS_OTP);
            smsOtpResponseMap.remove(STATUS_CODE_KEY);
            smsOtpResponseMap.remove(ERROR_MESSAGE);
            smsOtpResponseMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_REQUIRED);
            throw new CardException(401, CSLJsonUtils.toJson(smsOtpResponseMap));
        } else if (smsOtpResponseMap.containsKey(CardConstant.CS_EXTENDED_ERROR)
                && "1572".equals(smsOtpResponseMap.get(CardConstant.CS_EXTENDED_ERROR))) {
            smsOtpResponseMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_FAILED);
            throw new CardException(401, CSLJsonUtils.toJson(smsOtpResponseMap));
        } else {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put(CardConstant.OTP_TITLE, CardConstant.OTP_FAILED);
            throw new CardException(401, CSLJsonUtils.toJson(errorResponse));
        }
    }

    private void validateOtp(String otpToken) {
        log.info("Validating Otp");
        log.debug("sms validation request : {} ", otpToken);
        ValidateOtp response = validateOtpGateway.validateOtp(constructValidateOtpRequest());
        String strValidateOtpResponse = CSLJsonUtils.toJson(response);
        log.debug(" Sms otp validation response : {}", strValidateOtpResponse);
        @SuppressWarnings("unchecked")
        Map<String, Object> validateOtpResponse = CSLJsonUtils.parseJson(strValidateOtpResponse, Map.class);

        String statusCode = (String) validateOtpResponse.get(STATUS_CODE_KEY);
        if (!"100".equals(statusCode)) {
            log.info("Otp validation is failed");
            @SuppressWarnings("unchecked")
            Map<String, Object> otpTokenMap = CSLJsonUtils.parseJson(strValidateOtpResponse, Map.class);
            otpTokenMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_REQUIRED);
            throw new CardException(401, CSLJsonUtils.toJson(otpTokenMap));
        }
        log.info("Otp validation is success");
    }

    private String getOTPMobileNumber() {
        log.info("Getting mobile number from customer service to send OTP");
        List<CreditCardContact> creditCardContacts = customerJsonApiGateway.getCustomerCCContact(cslRequestContext
                .getRelId());
        for (CreditCardContact ccContact : creditCardContacts) {
            if (CardConstant.CONTACT_TYPE_MOBILE.equals(ccContact.getContactTypeCode())) {
                StringBuilder mobileNo = new StringBuilder(ccContact.getContactDetails());
                return formatMobileNumber(mobileNo);
                // return formatMobileNumber(new StringBuilder("+918807462939"));
            }
        }
        log.warn("There's no mobile number. It's null.");
        throw new BusinessException(CreditCardErrorCode.ERR_OTP_NUMBER_ERROR);
    }

    private String formatMobileNumber(StringBuilder mobileNo) {
        if (mobileNo.charAt(0) == '0') {
            mobileNo.replace(0, 1, "+");
            log.info("Formatting mobile number, removed prefix 0 and added +");
        } else if (mobileNo.charAt(0) != '+') {
            mobileNo.insert(0, "+");
            log.info("Formatting mobile number, removed prefix +");
        }
        return mobileNo.toString();
    }

    private ValidateOtp constructValidateOtpRequest() {
        ValidateOtp validateOtp = new ValidateOtp();
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> otpTokenList = CSLJsonUtils.parseJson(cslRequestContext._otpToken(), ArrayList.class);
        String validateOtpJson = CSLJsonUtils.toJson(otpTokenList.get(0).get(SMS_OTP));
        validateOtp = CSLJsonUtils.parseJson(validateOtpJson, ValidateOtp.class);
        validateOtp.setRelId(cslRequestContext.getRelId());
        validateOtp.setCountry(cslRequestContext.getCountry());
        validateOtp.setRequestId(cslRequestContext.getRequestId());
        validateOtp.setLanguage(cslRequestContext.getLanguage());
        validateOtp.setChannel(cslRequestContext.getChannel());
        return validateOtp;
    }

    /***
     * This method fetches the OTP ON/OFF status from PARAM table. If status is ON, OTP functionality will be enabled
     * otherwise OTP functionality will be skipped.
     * 
     * @return boolean
     */
    private boolean getOTPStatus() {
        boolean otpStatus = false;
        SRParamDto inputParam = new SRParamDto();
        inputParam.setCountryCode(cslRequestContext.getCountry());
        inputParam.setParamId(CardConstant.ID_PARAM_OTP);
        inputParam.setParamKey1(CardConstant.KEY_PARAM_OTP);
        SRParamDto param = CardUtil.loadSrParamByObject(inputParam, ccDao).get(CardConstant.ZERO);
        log.info("OTP Functionality Status in CSL_SR_PARAM_MST : {}", param.getParamData1());
        if (CardConstant.FLAG_ON.equals(param.getParamData1())) {
            otpStatus = true;
        }
        return otpStatus;
    }
}