package com.sc.csl.retail.creditcard.exception;

import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import com.sc.csl.retail.creditcard.helper.CardConstant;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@Getter
@Slf4j 
public enum CardActivationErrorCode implements ErrorCode { 

	CCMS_INVALID_INQUIRY_INPUT("CSL-CC-401",CardConstant.ERROR, "%s - %s"),
	CCMS_SYSTEM_NOT_AVAILABLE("CSL-CC-402",CardConstant.ERROR, "%s - %s"),
	CCMS_ACCT_NOT_FOUND("CSL-CC-403",CardConstant.ERROR, "%s - %s"),
	CCMS_RELATIONSHIP_NO_NOT_FOUND("CSL-CC-404",CardConstant.ERROR, "%s - %s"),
	CCMS_NO_EMBOSSER_NAME_KEY_IN("CSL-CC-405",CardConstant.ERROR, "%s - %s"),
	CCMS_UNMATCHED_EMBOSSER_NAME("CSL-CC-406",CardConstant.ERROR, "%s - %s"),
	CCMS_CARD_NOT_FOUND_IN_CPAFF("CSL-CC-407",CardConstant.ERROR, "%s - %s"),
	CCMS_INV_EMBOSSER_NAME_E11("CSL-CC-408",CardConstant.ERROR, "%s - %s"), 
	CCMS_SUPREL_CUSTOMER_NOT_FOUND("CSL-CC-409",CardConstant.ERROR, "%s - %s"),
	CCMS_INVALID_CARD_NO_INPUT("CSL-CC-410",CardConstant.ERROR, "%s - %s"),
	CCMS_INVALID_INPUT_ID("CSL-CC-411",CardConstant.ERROR, "%s - %s"),
	CCMS_INACTIVE_ACCOUNT("CSL-CC-412",CardConstant.ERROR, "%s - %s"),
	C400_SEVERE_ERROR_WHILE_ADDRESSING_PARAMETER_LIST("CSL-CC-413",CardConstant.ERROR, "%s - %s"),
	C400_INVALID_ERROR_CODE_PARAMETER("CSL-CC-414",CardConstant.ERROR, "%s - %s"),
	C400_INVALID_VALUE_SUPPLIED_IN_PARAMETER("CSL-CC-415",CardConstant.ERROR, "%s - %s"),
	C400_INVALID_CARD_NUMBER("CSL-CC-416",CardConstant.ERROR, "%s - %s"),
	C400_AN_UNEXPECTED_ERROR_OCCURRED_IN_THE_BUSINESS_EVENT("CSL-CC-417",CardConstant.ERROR, "%s - %s"),
	CARDS_SYSTEM_FAILURE("CSL-CC-418",CardConstant.ERROR, "%s - %s"),
	CARD_CONNECTIVITY_FAILURE("CSL-CC-419",CardConstant.ERROR, "%s - %s"),
	CSL_CREDIT_CARD_NO_CONTACT_FOUND("CSL-ERR-422",CardConstant.ERROR,"Card Contact Details Not Available in Card Systems"),
	UAAS_SERVICE_ERROR("CSL-CC-203",CardConstant.ERROR,"%s - %s"),
	
	/**
	 * CSL Internal Validations
	 */
	CSL_CREDIT_CARD_ACTIVE_STATUS("CSL-CC-204",CardConstant.ERROR,"This Card is Not Eligible for Activation"),
	CSL_CREDIT_CARD_INVALID_BIN("CSL-CC-201",CardConstant.ERROR,"Card bin not allowed for Activation"),
	CSL_SERVICE_ERROR("CSL-CC-202",CardConstant.ERROR,"CSL Service Error");

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    CardActivationErrorCode(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

    public static ErrorCode getBusinessErrorCode(String hostErrorCode) {
        ErrorCode errorCode = CardActivationErrorCode.CARDS_SYSTEM_FAILURE;
        try {
            log.debug("[getBusinessErrorCode hostErrorCode : {}", hostErrorCode);
            if (!CardUtil.isEmptyOrNull(hostErrorCode)) {
                errorCode = CardActivationErrorCode.valueOf(hostErrorCode);
            }
        } catch (Exception e) {
            log.error("[getBusinessErrorCode exception : {}", e);
        }
        return errorCode;
    }
}
