package com.sc.csl.retail.creditcard.gateway.csl;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.creditcard.dto.security.EncryptedData;

import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@ConfigurationProperties(prefix = "csl.security.gateway.decryptCard")
public class DecryptGateway extends CSLJsonApiGateway {
  
    public EncryptedData decrypt(EncryptedData request) {
    	log.debug("[DecryptGateway.decrypt Entry]");
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<EncryptedData, String> decryptRepo = katharsisClient.getRepositoryForType(EncryptedData.class);
        log.debug("[DecryptGateway.decrypt Exit]");
        return  decryptRepo.create(request);
    }   
}
