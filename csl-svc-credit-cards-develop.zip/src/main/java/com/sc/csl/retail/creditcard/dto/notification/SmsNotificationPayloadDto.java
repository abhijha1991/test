package com.sc.csl.retail.creditcard.dto.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class SmsNotificationPayloadDto {

    @JsonProperty(value = "mobile-number")
    private String mobileNumber;

    @NotNull(message = "notify-type can not be Null")
    @JsonProperty(value = "notify-type")
    private String notifyType;

    @NotNull(message = "is-encoded can not be Null")
    @JsonProperty(value = "is-encoded")
    private char isEncoded;

    @NotNull(message = "message-content can not be Null")
    @JsonProperty(value = "message-content")
    private String messageContent;

    @NotNull(message = "language can not be Null")
    @JsonProperty(value = "language")
    private String language;

}
