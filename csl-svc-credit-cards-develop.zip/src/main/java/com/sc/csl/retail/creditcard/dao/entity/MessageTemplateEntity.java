package com.sc.csl.retail.creditcard.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import com.sc.csl.retail.core.entity.CSLBaseEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "CSL_CC_MESSAGE_TEMPLATE",uniqueConstraints={@UniqueConstraint(columnNames={"CTRY_CD","ACTION_NAME","LANGUAGE"})})
public class MessageTemplateEntity extends CSLBaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SNO")
	private Long sno;

	@Column(name = "CTRY_CD")
	private String country;

	@Column(name = "ACTION_NAME")
	private String actionName;

	@Column(name = "SMS_FLAG")
	private char sms;

	@Column(name = "EMAIL_FLAG")
	private char email;

	@Column(name = "INBOX_FLAG")
	private char inbox;
	
	@Column(name = "OTP_FLAG")
	private char otp;
	
	@Column(name = "OTP_MESSAGE")
	private String otpMessage;

	@Column(name = "SENDER_EMAIL")
	private String senderEmail;
	
	@Column(name = "SMS_MESSAGE")
	private String smsMessage;
	
	@Column(name = "EMAIL_SUBJECT")
	private String emailSubject;

	@Column(name = "LANGUAGE")
	private String language;

	@Column(name = "IS_ENCODE")
	private char isEncode;
	
	@Lob
	@Column(name = "EMAIL_BODY")
	private byte[] emailBody;
	
	@Column(name = "INBOX_MESSAGE")
	private String inboxMessage;
	
	@Column(name = "INBOX_SUBJECT")
	private String inboxSubject;
	
	@Column(name = "CUSTOMER_DEFAULT_NAME")
	private String customerDefName;

}
