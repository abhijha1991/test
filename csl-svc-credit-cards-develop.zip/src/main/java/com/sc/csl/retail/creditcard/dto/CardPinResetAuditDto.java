package com.sc.csl.retail.creditcard.dto;

import java.util.UUID;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonApiResource(type = "audit")
public class CardPinResetAuditDto extends BaseDto {

	private static final long serialVersionUID = 1L;

	@JsonApiId
	private String id = UUID.randomUUID().toString();
	private String action;
	private String auditInfo;
	private String functionCd;
	private String statusCd;
}
