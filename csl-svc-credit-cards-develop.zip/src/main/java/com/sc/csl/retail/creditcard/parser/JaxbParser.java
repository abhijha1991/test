package com.sc.csl.retail.creditcard.parser;

import java.math.BigInteger;
import java.util.function.Supplier;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;

import com.sun.org.apache.xerces.internal.jaxp.datatype.DatatypeFactoryImpl;

@Slf4j
public class JaxbParser {

    public static final String IND_VALUE_TRUE = "Y";
    public static final String IND_VALUE_FALSE = "N";
    public static final DatatypeFactory FACTORY = new DatatypeFactoryImpl();

    public static XMLGregorianCalendar parseDateTime(String value) {
        if (isBadDate(value)) return null;
        return silent(() -> FACTORY.newXMLGregorianCalendar(value));
    }

    public static XMLGregorianCalendar parseTime(String value) {
        if (isBadDate(value)) return null;
        return silent(() -> FACTORY.newXMLGregorianCalendar(value));
    }

    public static XMLGregorianCalendar parseDate(String value) {
        if (isBadDate(value)) return null;
        return silent(() -> FACTORY.newXMLGregorianCalendar(value));
    }

    public static java.math.BigInteger parseInteger(String value) {
        if (StringUtils.isEmpty(value)) return null;
        if (IND_VALUE_FALSE.equals(value)) return BigInteger.ZERO;
        else if (IND_VALUE_TRUE.equals(value)) return BigInteger.ONE;

        return silent(() ->(javax.xml.bind.DatatypeConverter.parseInteger(value)));
    }

    private static final boolean isBadDate(String value) {
        return (StringUtils.isEmpty(value) || "0".equals(value));
    }

    private static final <T> T silent(Supplier<T> c) {
        try {
            return c.get();
        } catch (Exception e) {
            log.info("PARSE EXCEPTION:", e);
            return null;
        }
    }
}
