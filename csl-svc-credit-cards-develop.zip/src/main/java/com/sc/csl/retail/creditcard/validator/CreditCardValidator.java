package com.sc.csl.retail.creditcard.validator;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.util.CSLAssert;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.post.OtpInfo;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CreditCardValidator {
	
	public void validateRequest(CreditCardVO creditCardVO) {
		if(creditCardVO == null){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST, "validateCountry", "CreditCardVO is null"));
		}
		validateCountry(creditCardVO);
		validateChannel(creditCardVO);

		if(creditCardVO!=null && creditCardVO.getFunctionCd()!=null)
		{
			if(!CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC.equalsIgnoreCase(creditCardVO.getFunctionCd()))
			{
				validateCustomerId(creditCardVO);
				validateCSLHeaderContext(creditCardVO);
			}
		}
		else
		{
			validateCustomerId(creditCardVO);
			validateCSLHeaderContext(creditCardVO);
		}
	}
	
	/**
	 * This method does the validation of data posted from UI layer for CCF.
	 * @param creditCardDto
	 */
	public boolean validateCCFPostServiceRequest(CreditCardDto creditCardDto) {
		log.info("[CreditCardValidator validateCCFPostServiceRequest Entered...] ");
		
	   // ERR_CSL_CREDIT_CARDS_MISSING_FIELDS("ERR_CSL_CREDIT_CARDS_MISSING_FIELDS", "Validation failed", "Missing mandatory field(s) :  %s");
		boolean validateStatus = true;
		
		if (creditCardDto.getPostCreditCards().size() == 0) {
			throw new TechnicalException(TemplateErrorCode.create(
					CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST,
					"validateServiceRequest", "CreditCardDto.postCreditCards is null"));
		}
		
		for(CreditCardDto crDto: creditCardDto.getPostCreditCards()){
				CSLAssert.hasText(crDto.getCardNum(), TemplateErrorCode.create(CreditCardErrorCode
		                .ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "cardNumber"));
				CSLAssert.hasText(crDto.getCardType(), TemplateErrorCode.create(CreditCardErrorCode
		                .ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "cardType"));
				
				if(crDto.getCreditCardEligibility() == null && "REVERSAL".equalsIgnoreCase(creditCardDto.getRequestType())){
					throw new TechnicalException(TemplateErrorCode.create(
							CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST,
							"validateServiceRequest", "CreditCardDto.postCreditCards.creditCardEligibility is null"));
				}else if("REVERSAL".equalsIgnoreCase(creditCardDto.getRequestType())){
					
					CSLAssert.hasText(crDto.getCreditCardEligibility().getCardEligibilityFlag(), TemplateErrorCode.create(CreditCardErrorCode
			                .ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "CreditCardDto.creditCardEligibility.CardEligibilityFlag"));
//					CSLAssert.hasText(crDto.getCreditCardEligibility().getEligibilityOverrideFlag(), TemplateErrorCode.create(CreditCardErrorCode
//			                .ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "CreditCardDto.creditCardEligibility.EligibilityOverrideFlag"));
					for(CreditCardTransactionDto ccTransactionDto:crDto.getCardtransactions()){
						CSLAssert.hasText(ccTransactionDto.getOriginTxnAmt().toString(), TemplateErrorCode.create(CreditCardErrorCode
				                .ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "CreditCardDto.transactions.originalTxnAmt is null"));	
					}
				}
				
				
		}
		
		log.info("[CreditCardValidator validateCCFPostServiceRequest Exit...] ");
		return validateStatus;
	}
	
	private void validateCountry(CreditCardVO creditCardVO) {
		if(StringUtils.isBlank(creditCardVO.getCountryCode()) || !StringUtils.isAlpha(creditCardVO.getCountryCode())){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_INPUT, "validateCountry", "invalid country"));
		}
	}
	
	private void validateChannel(CreditCardVO creditCardVO) {		
		if(StringUtils.isBlank(creditCardVO.getChannelId()) || !StringUtils.isAlpha(creditCardVO.getChannelId())){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_INPUT, "validateChannel", "invalid channel"));
		}
	}
	
	private void validateCSLHeaderContext(CreditCardVO creditCardVO){
		if(creditCardVO == null){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST, "validateCSLHeaderContext", "CreditCardVO is null"));
		}
		
		if(creditCardVO.getCslRequestContext() == null ){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST, "validateCSLHeaderContext", "CSLHeaderContext is null"));
		}
		
		if(StringUtils.isBlank(creditCardVO.getCslRequestContext().getChannel())
				|| StringUtils.isBlank(creditCardVO.getCslRequestContext().getCountry())
				|| StringUtils.isBlank(creditCardVO.getCslRequestContext().getRelId())
				|| StringUtils.isBlank(creditCardVO.getCslRequestContext().getCustomerId())
				){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST, "validateCSLHeaderContext", "CSLHeaderContext is invalid"));
		}
		
		if(!StringUtils.equals(creditCardVO.getCslRequestContext().getRelId(), creditCardVO.getRelId())){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST, "validateCSLHeaderContext", "rel id not match"));
		}
	}
	
	private void validateCustomerId(CreditCardVO creditCardVO){
		if(StringUtils.isBlank(creditCardVO.getRelId()) || !StringUtils.isAlphanumeric(creditCardVO.getRelId())){
			throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID, "validateCustomerId", "invalid relId"));
		}
	}
	
	public void validateCardNo(CreditCardVO creditCardVO){
		if(StringUtils.isBlank(creditCardVO.getCardNo()) || !StringUtils.isNumeric(creditCardVO.getCardNo())){
			throw new BusinessException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO, "validateCardNo", "invalid cardNo"));
		}
	}
	
	public CreditCardDto isCardExistByCustomerId(List<CreditCardDto> creditCardDtos, CreditCardVO creditCardVO){
		CreditCardDto creditCardDto = null;
		if(CollectionUtils.isNotEmpty(creditCardDtos) && creditCardVO != null){
			for(CreditCardDto creditCardDtoTmp : creditCardDtos){
				if(StringUtils.equals(creditCardDtoTmp.getCardNum(), creditCardVO.getCardNo())){
					creditCardDto = creditCardDtoTmp;
				}
			}
		}
		
		if(null == creditCardDto){
			throw new BusinessException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST, "isCardExistInHost", "card details request invalid"));
		}
		return creditCardDto;
	}

	/**
	 * This method does the validation of request payload for pre Login Card
	 * Activation Scenario
	 * 
	 * @param creditCardDto
	 */
	public void validatePreLoginCardActivationRequest(CreditCardDto creditCardDto) {

		if (CardUtil.isEmptyOrNull(creditCardDto.getCardActivationDto())) {
			CSLAssert.notNull(creditCardDto.getCardActivationDto(), TemplateErrorCode
					.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Card Activation Post Request"));
		}
		
			CSLAssert.hasText(creditCardDto.getCountryCode(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Country Code"));
	
	if(ArrayUtils.contains(CardConstant.PRODUCT_DESC_SUFFIX_NA_CTR_CDS,creditCardDto.getCountryCode())){
		CSLAssert.hasText(creditCardDto.getEmbossedName(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Embossed Name"));
	 }	

		CSLAssert.hasText(creditCardDto.getCardActivationDto().getEncData(), TemplateErrorCode
				.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Encrypted Card Number"));

		CSLAssert.hasText(creditCardDto.getCardActivationDto().getKeyIndex(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Key Index"));
	}

	/**
	 * This method does the validation of request payload for SMS Card
	 * Activation Scenario
	 * 
	 * @param creditCardDto
	 */
	public void validateCardActivationSMSRequest(CreditCardDto creditCardDto) {

		CSLAssert.hasText(creditCardDto.getCountryCode(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Country Code"));

		CSLAssert.hasText(creditCardDto.getEmbossedName(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Embossed Name"));

		CSLAssert.hasText(creditCardDto.getContactNumber(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Contact Number"));

		CSLAssert.hasText(creditCardDto.getCardType(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Card Type"));

		CSLAssert.hasText(creditCardDto.getReceiptId(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Receipt Id"));

		CSLAssert.hasText(creditCardDto.getCardNum(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Card Number"));
	}

	/**
	 * 
	 * @param otpInfo
	 */
	public void validateCardActivationOTPBlock(OtpInfo otpInfo) {

		CSLAssert.notNull(otpInfo, TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS,
				"Card Activation OTP Info"));

		CSLAssert.hasText(otpInfo.getEncOtp(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Encrypted OTP"));

		CSLAssert.hasText(otpInfo.getKeyIndex(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Key Index"));

		CSLAssert.hasText(otpInfo.getOtpSn(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "OTP Serial Number"));

		CSLAssert.hasText(otpInfo.getPurpose(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Purpose Code"));
	}
	
	/**
	 * This method does the validation of request payload for Pin Reset 
	 * Activation Scenario
	 * 
	 * @param creditCardDto
	 */
	public void validatePinResetRequest(CreditCardDto creditCardDto) {

		if (CardUtil.isEmptyOrNull(creditCardDto.getPinChangeDto())) {
			CSLAssert.notNull(creditCardDto.getPinChangeDto(), TemplateErrorCode
					.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "PIN RESET Request"));
		}
		
		CSLAssert.hasText(creditCardDto.getCardNum(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Card Number"));
		
		if (ArrayUtils.contains(CardConstant.PRODUCT_DESC_SUFFIX_NA_CTR_CDS, creditCardDto.getCountryCode())) {
			CSLAssert.hasText(creditCardDto.getEmbossedName(),
					TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Embossed Name"));
			
			CSLAssert.hasText(creditCardDto.getPinChangeDto().getSequenceNumber(), TemplateErrorCode
					.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Sequence Number"));
		}	
	
		CSLAssert.hasText(creditCardDto.getPinChangeDto().getEncCardPin(), TemplateErrorCode
				.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Encrypted Card PIN"));
		
		CSLAssert.hasText(creditCardDto.getPinChangeDto().getEncCardInfo(), TemplateErrorCode
				.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Encrypted Card INFO"));

		CSLAssert.hasText(creditCardDto.getPinChangeDto().getPinKeyIndex(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Key Index"));			
				
	}
	
	/**
	 * This method does the validation of OTP payload for Pin Reset & Activation
	 * Scenario
	 * 
	 * @param creditCardDto
	 */
	public void validatePinOTPBlock(CreditCardDto creditCardDto) {
		
		CSLAssert.notNull(creditCardDto.getPinChangeDto().getOtpInfo(), TemplateErrorCode
				.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Card Activation OTP Info"));

		CSLAssert.hasText(creditCardDto.getPinChangeDto().getOtpInfo().getEncOtp(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Encrypted OTP"));

		CSLAssert.hasText(creditCardDto.getPinChangeDto().getOtpInfo().getKeyIndex(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "Key Index"));

		CSLAssert.hasText(creditCardDto.getPinChangeDto().getOtpInfo().getOtpSn(),
				TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_MISSING_FIELDS, "OTP Serial Number"));
	}
}
