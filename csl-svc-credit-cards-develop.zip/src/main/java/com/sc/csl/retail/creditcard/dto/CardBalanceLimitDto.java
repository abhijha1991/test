package com.sc.csl.retail.creditcard.dto;

import lombok.Data;

@Data
public class CardBalanceLimitDto {
   private String balTypeValue;
   private String amount;
   private String curCodeValue;
}
