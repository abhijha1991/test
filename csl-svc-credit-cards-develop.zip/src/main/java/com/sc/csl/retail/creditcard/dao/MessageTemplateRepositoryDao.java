package com.sc.csl.retail.creditcard.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.sc.csl.retail.creditcard.dao.entity.MessageTemplateEntity;

@Repository
public interface MessageTemplateRepositoryDao extends CrudRepository<MessageTemplateEntity, String> {

	@Query("from MessageTemplateEntity CSLMSGTMP where CSLMSGTMP.country = :country and CSLMSGTMP.actionName = :actionName and CSLMSGTMP.language = :language")
	public MessageTemplateEntity getMsgTemplate(@Param("country") String country,
			@Param("actionName") String actionName, @Param("language") String language);
	
	@Query("select CSLMSGTMP.otp,CSLMSGTMP.otpMessage from MessageTemplateEntity CSLMSGTMP where CSLMSGTMP.country = :country and CSLMSGTMP.actionName = :actionName and CSLMSGTMP.language = :language")
	public List<MessageTemplateEntity> getOtpMsgTemplate(@Param("country") String country,
			@Param("actionName") String actionName, @Param("language") String language);

}
