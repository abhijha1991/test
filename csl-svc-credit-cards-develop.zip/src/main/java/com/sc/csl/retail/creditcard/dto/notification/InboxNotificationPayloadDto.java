package com.sc.csl.retail.creditcard.dto.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class InboxNotificationPayloadDto {

    @NotNull(message = "notify-type can not be Null")
    @JsonProperty(value = "notify-type")
    private String notifyType;

    @NotNull(message = "is-encoded can not be Null")
    @JsonProperty(value = "is-encoded")
    private String isEncoded;

    @NotNull(message = "message-from can not be Null")
    @JsonProperty(value = "message-from")
    private String messageFrom;

    @NotNull(message = "language can not be Null")
    @JsonProperty(value = "language")
    private String language;

    @NotNull(message = "message-subject can not be Null")
    @JsonProperty(value = "message-subject")
    private String messageSubject;

    private String reference;

    private String messageCategory;

    private String messageSenderId;

    private String messageBody;

    private String countryGroup;


}
