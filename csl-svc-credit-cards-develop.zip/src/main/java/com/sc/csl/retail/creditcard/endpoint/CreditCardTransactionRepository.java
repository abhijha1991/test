package com.sc.csl.retail.creditcard.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Component
@Slf4j
public class CreditCardTransactionRepository extends ResourceRepositoryBase<CreditCardTransactionDto, String> {

	@Autowired
	private CSLRequestContext cslRequestContext;

	@Autowired
	private CreditCardService creditCardService;

	@Autowired
	private CardUtil cardUtil;

	public CreditCardTransactionRepository() {
		super(CreditCardTransactionDto.class);
	}

	@Override
	public ResourceList<CreditCardTransactionDto> findAll(QuerySpec querySpec) {
		CreditCardVO creditCardVO = null;

		CreditCardTransactionDto creditCardTransactionDto = new CreditCardTransactionDto();
		try {
			log.debug("[findAll Entry]");
			creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
			querySpec = populateQuerySpec(querySpec, creditCardTransactionDto);
			creditCardVO.setCardNo(creditCardTransactionDto.getCardNum());
			return querySpec.apply(creditCardService.findAllCreditCardTransaction(creditCardVO));
		} finally {
			log.debug("[findAll Exit]");
		}
	}

	@Override
	public ResourceList<CreditCardTransactionDto> findAll(Iterable<String> ids, QuerySpec querySpec) {
		ResourceList<CreditCardTransactionDto> creditCardTransactionsResourceList = new DefaultResourceList<>();
		List<CreditCardVO> creditCardVOList = new ArrayList<>();
		Set<String> uniqueCards = new HashSet<>();
		ids.forEach(id-> {
			if(!uniqueCards.contains(id)) {
				CreditCardVO creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
				creditCardVO.setCardNo(id);
				uniqueCards.add(id);
				creditCardVOList.add(creditCardVO);
			}
		});
		if(!creditCardVOList.isEmpty()) {
			List<CreditCardTransactionDto> txn = creditCardService.findProvidedCreditCardTransactions(creditCardVOList,querySpec);
			creditCardTransactionsResourceList.addAll(txn);
		}
		return creditCardTransactionsResourceList;
	}


	public QuerySpec populateQuerySpec(QuerySpec querySpec, CreditCardTransactionDto creditCardTransactionDto) {
		log.info("populateQuerySpec querySpec & CreditCardVO-{}", querySpec,creditCardTransactionDto);

		if(isEmptyOrNull(querySpec)){
			return querySpec;
		}
		if(isEmptyOrNull(creditCardTransactionDto)){
			creditCardTransactionDto = new CreditCardTransactionDto();
		}
		if(!CollectionUtils.isEmpty(querySpec.getFilters())){

			for(FilterSpec filterSpec : querySpec.getFilters()){

				if (filterSpec != null
						&& StringUtils.contains(filterSpec.toString(),
						CardConstant.FILTER_CARD_NO)
						&& StringUtils.isNotBlank((String) filterSpec
						.getValue())) {
					creditCardTransactionDto.setCardNum((String) filterSpec.getValue());
				}
			}

		}

		return querySpec;
	}

	public static boolean isEmptyOrNull(String value) {
		return StringUtils.isBlank(value);
	}

	public static boolean isEmptyOrNull(Object value) {
		return (value == null);
	}
}
