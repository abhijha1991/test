package com.sc.csl.retail.creditcard.dto;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.SerializeType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;

import com.fasterxml.jackson.annotation.JsonProperty;

@Data
@EqualsAndHashCode(callSuper = false)
@JsonApiResource(type = "service-requests")
public class ServiceRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonApiId
	@JsonProperty("receipt-id")
	private String receiptId;
	@JsonProperty("service-number")
	private String serviceNumber;
	@JsonProperty("country-code")
	private String CountryCode;
	@JsonProperty("service-type")
	private String ServiceType;
	@JsonProperty("status")
	private String status = null;
	@JsonProperty("message-Id")
	private String MessageId;
	@JsonProperty("operation-Name")
	private String operationName;
	@JsonProperty("source-system")
	private String sourceSystem;
	@JsonProperty("created-by")
	private String createdBy;
	private HashMap<String, Object> payload = new HashMap<String, Object>();
	@JsonProperty("milestones")
	@JsonApiRelation(serialize = SerializeType.EAGER)
	private List<MilestoneInfoDto> milestoneInfoDtoList = new ArrayList<>();

}