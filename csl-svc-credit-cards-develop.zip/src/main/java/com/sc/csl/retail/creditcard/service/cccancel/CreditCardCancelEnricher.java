package com.sc.csl.retail.creditcard.service.cccancel;

import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelEnricherProperties;
import com.sc.csl.retail.creditcard.config.properties.GenericMappingProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardCancelDto;
import com.sc.csl.retail.creditcard.helper.BeanUtility;
import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * @author 1452875
 * @since Sep 19, 2017
 */
public class CreditCardCancelEnricher {

    public CreditCardCancelDto process(CreditCardCancelDto creditCardCancelDto,
            CreditCardCancelEnricherProperties ccCancelEnricherProp) {
        genericMappingEnrichment(creditCardCancelDto, ccCancelEnricherProp);
        customMappingEnrichment(creditCardCancelDto, ccCancelEnricherProp);
        return creditCardCancelDto;
    }

    /**
     * <pre>
     * Derive value from below possible fields and set the result in the destination property
     * Either source or value fields are required.
     * Possible fields
     *  - sourceField: It can be either direct property or nested property of CreditCardCancelDto instance
     *  - value: Hard coded value
     *  - regEx: Optional, apply regEx on the output of above two fields
     *  - sourceDateFormat: Optional, required if the sourceField is date
     *  - destDateFormat: Optional, required if the sourceField is date
     * </pre>
     */
    private void genericMappingEnrichment(CreditCardCancelDto creditCardCancelDto,
            CreditCardCancelEnricherProperties ccCancelEnricherProp) {
        Map<String, GenericMappingProperties> genericMapping = ccCancelEnricherProp.getGenericMapping();
        if (CardUtil.isEmptyOrNull(genericMapping)) {
            return;
        }

        Set<Map.Entry<String, GenericMappingProperties>> entrySet = genericMapping.entrySet();
        Iterator<Map.Entry<String, GenericMappingProperties>> iter = entrySet.iterator();
        while (iter.hasNext()) {
            Map.Entry<String, GenericMappingProperties> mappingProp = iter.next();
            GenericMappingProperties prop = mappingProp.getValue();
            String value = null;
            if (!StringUtils.isEmpty(prop.getValue())) {
                value = prop.getValue();
            }
            if (!StringUtils.isEmpty(prop.getSourceField())) {
                value = BeanUtility.getProperty(creditCardCancelDto, prop.getSourceField());
            }
            if (!StringUtils.isEmpty(prop.getRegEx()) && !StringUtils.isEmpty(value)) {
                value = null;
                Pattern pattern = Pattern.compile(prop.getRegEx());
                Matcher matcher = pattern.matcher(value);
                if (matcher.find()) {
                    value = matcher.group(0);
                }
            }
            if (!StringUtils.isEmpty(prop.getSourceDateFormat()) && !StringUtils.isEmpty(prop.getDestDateFormat())) {
                Date dateVal = CardUtil.parseDate(value, prop.getSourceDateFormat());
                value = CardUtil.formatDate(dateVal, prop.getDestDateFormat());
            }
            BeanUtility.setProperty(creditCardCancelDto, mappingProp.getKey(), value);
        }
    }

    private void customMappingEnrichment(CreditCardCancelDto creditCardCancelDto,
            CreditCardCancelEnricherProperties ccCancelEnricherProp) {
    }
}
