package com.sc.csl.retail.creditcard.helper;

import com.sc.csl.retail.core.exception.ErrorCode;
import lombok.Getter;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;

@Getter
public enum ErrorConstant implements ErrorCode {

    ERR_GENERIC_EXCEPTION(null,null,null),
    
    ERR_UPDATING_APP_STATUS(null,null,null),
    
    ERR_RETRIEVING_APP_DETAILS(null,null,null),
    ERR_RETRIEVING_CUST_DETAILS(null,null,null),
    
    ERR_INSERTING_APP(null,null,null),
    ERR_RETRIEVING_ACCOUNT_DEATILS(null,null,null),
    ERR_RETRIEVING_PERSONALIZED_SETTINGS(null,null,null),
    
    MULTIPLE_RECORDS_FOUND(null,null,null),
    
    DATA_UPDATE_STATUS(null,null,null),
    APPLICATION_DETAILS_NOT_FOUND(null,null,null),
    APPLICATIONS_DETAILS_NOT_FOUND(null,null,null),
    CUSTOMER_DETAILS_NOT_FOUND(null,null,null),
    ACCOUNT_DETAILS_NOT_FOUND(null,null,null),
    APPLICATION_SUBMITTED(null,null,null),
    PERSONALIZED_SETTINGS_NOT_FOUND(null,null,null),

    ROUTE_NOT_FOUND("CSL-SS-ACCOUNTS-502","No Route Found","Country %s is not allowed to query Account details"),
    //ACCOUNT_DETAILS_NOT_FOUND("CSL-SS-ACCOUNTS-503","No Account Found","Account Details not available"),
    ERR_FETCHING_ACCOUNT("CSL-SS-ACCOUNTS-504","Not able to fetch Account details","Exception while fetching Account details from 24X7"),
    CASA_NO_HEADER("CSL-SS-ACCOUNTS-505","Missing CSL_USER header","Mandatory header is not available"),
    CASA_NO_RELID("CSL-SS-ACCOUNTS-506","Missing RelId","Mandatory RelId is not available"),
    CASA_NO_COUNTRY("CSL-SS-ACCOUNTS-507","Missing country","Mandatory country is not available"),
    CASA_EXCEPTION("CSL-SS-ACCOUNTS-508","Exception Occurred","Reason: %s"),
    CASA_NO_RECORD_EXCEPTION("CSL-SS-ACCOUNTS-509","No Account found","No valid Account found for the provided Rel Id"),
    COUNTRY_NOT_ALLOWED("CSL-SS-510","Country is not allowed","Country %s is not allowed for %s"),
    CUSTOMER_NO_HEADER("CSL-SS-CUSTOMER-505","Missing CSL_USER header","Mandatory header is not available"),
    CUSTOMER_NO_RELID("CSL-SS-CUSTOMER-506","Missing RelId","Mandatory RelId is not available"),
    CUSTOMER_NO_COUNTRY("CSL-SS-CUSTOMER-507","Missing country","Mandatory country is not available"),
    SS_NO_CHANNEL("CSL-SS-511","Missing Channel","Mandatory Channel is not available"),
    SS_EMPTY_PAYMENT("CSL-SS-PAYMENTS-501","Missing Payment Object","Mandatory Payment Object is not available"),
    SS_PAYMENT_EXCEPTION("CSL-SS-PAYMENTS-503","Exception in Payment 247x7","Reason: %s"),
    CUSTOMER_NO_RECORD_EXCEPTION("CSL-SS-CUSTOMER-509","No Customer found","No valid Customer found for the provided " +
            "Rel Id"),
    ERR_FETCHING_CUSTOMER("CSL-SS-CUSTOMER-504","Not able to fetch Customer details","Exception while fetching " +
            "Customer details from 24X7"),
    SS_NO_TRANSACTIONID("CSL-SS-PAYMENTS-502","Missing TransactionId","Mandatory TransactionId is not available"),
    SS_NO_PAYMENT("CSL-SS-PAYMENTS-504","Payment not available","Payment not available"),
    SS_PAYMENT_EXISTS("CSL-SS-PAYMENTS-505","Payment exists with same id","Payment exists with same id"),
    ERR_NO_CUSTID("CSL-SS-CUSTOMER-511","Missing CustId","Mandatory CustomerId is not available"),
    UNSUPPORTED_OPERATION("CSL-SS-CUSTOMER-512","Operation Not Supported","This Operation is not supported"),
       
    ERR_FETCHING_AUDIT("CSL-SS-AUDIT-504","Not able to fetch Audit details","Exception while fetching " +
            "Audit details from 24X7"),
	AUDIT_NO_HEADER("CSL-SS-AUDIT-505","Missing CSL_USER header","Mandatory header is not available"),
	AUDIT_NO_RELID("CSL-SS-AUDIT-506","Missing RelId","Mandatory RelId is not available"),
	AUDIT_NO_COUNTRY("CSL-SS-AUDIT-507","Missing country","Mandatory country is not available"),
	AUDIT_INFO("CSL-SS-AUDIT-508","Missing audit Info","Mandatory Audit Information is not available"),
	AUDIT_INFO_INVALID("CSL-SS-AUDIT-510","Invalid audit Info","Audit Information is not valid"),
	ERR_INSERTING_AUDIT("CSL-SS-AUDIT-509","Unable to insert the record into DB","Exception while insert into Audit details from 24X7"),
	AUDIT_SERVICE_NOT_ALLOWED("CSL-SS-AUDIT-511","Service is not allowed","Service %s is not allowed for %s"),
    CARD_NO_RECORD_EXCEPTION("CSL-SS-CARDS-509","No Account found","No valid Account found for the provided credit card number"),

    // Added for Credit Card service
    ERR_FETCHING_CREDITCARD("CSL-SS-CREDITCARDS-504","Not able to fetch CreditCard details","Error fetching CreditCard Details"),
    CREDITCARD_NO_HEADER("CSL-SS-CREDITCARD-505","Missing CSL_USER header","Mandatory header is not available"),
    CREDITCARD_NO_RELID("CSL-SS-CREDITCARD-506","Missing RelId","Mandatory RelId is not available"),
    CREDITCARD_NO_COUNTRY("CSL-SS-CREDITCARD-507","Missing country","Mandatory country is not available"),
    CREDITCARD_EXCEPTION("CSL-SS-CREDITCARD-508","Exception Occurred","Reason: %s"),
    CREDITCARD_NO_RECORD_EXCEPTION("CSL-SS-CreditCard-509","No Record found","No valid credit card found for the provided Rel Id"),
    UNIT_TRUST_NO_RELID("CSL-SS-UNITTRUST-510","Missing RelId","Mandatory RelId is not available"),
    UNIT_TRUST_NO_COUNTRY("CSL-SS-UNITTRUST-511","Missing country","Mandatory country is not available"),
    ERR_FETCHING_UNIT_TRUST("CSL-SS-UNITTRUSTS-512","Not able to fetch Unit Trusts","Exception while fetching Unit Trusts from 24X7");

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    ErrorConstant(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }
}
