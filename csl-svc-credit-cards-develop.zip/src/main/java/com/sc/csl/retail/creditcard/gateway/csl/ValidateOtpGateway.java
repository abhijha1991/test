package com.sc.csl.retail.creditcard.gateway.csl;

import io.katharsis.repository.ResourceRepositoryV2;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.creditcard.dto.security.ValidateOtp;

/**
 * ValidateOtpGateway.java
 * 
 * 
 * @author 1523165
 * @since Oct 11, 2017
 */
@Component
@ConfigurationProperties(prefix = "csl.security.gateway.validateOtp")
public class ValidateOtpGateway extends CSLJsonApiGateway {

    public ValidateOtp validateOtp(ValidateOtp validateOtp) {
        CSLKatharsisClient katharsisClient = getKatharsisClient();
        ResourceRepositoryV2<ValidateOtp, String> validateOtpRepo = katharsisClient
                .getRepositoryForType(ValidateOtp.class);
        return validateOtpRepo.create(validateOtp);
    }

}
