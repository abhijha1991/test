package com.sc.csl.retail.creditcard.helper;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.RewardPointDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * @author 1553836 Sinha, Shantanu Aug-17
 */
@Slf4j
@Component
public class ReconcileTransaction {

	/**
	 * Merging of Transactions from EDMP and CCMS/C-400 based on the debit and
	 * credit.
	 * 
	 * @param billedtransactionList
	 * @param unBilledtransactionList
	 * @param edmp12MonthTransactions
	 * @param statemantedTransaction
	 * @param creditcardvo
	 * @param journeyMap
	 * @param creditcardDto
	 * @return
	 */
	@Autowired
	private CardUtil cardUtil;
	
	public List<CreditCardTransactionDto> getReconciledTransaction(
			List<CreditCardTransactionDto> unStatementtransactionList,
			List<CreditCardTransactionDto> edmp12MonthTransactions,
			List<CreditCardTransactionDto> statemantedTransaction,
			CreditCardVO creditcardvo, Map<String, Object> journeyMap,
			CreditCardDto creditcardDto) {

		log.info("Entered from getReconciledTransaction() [from EDMP, CCMS - Unbilled/ Billed]..");
		
		List<CreditCardTransactionDto> debitTransactionList = new LinkedList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> creditTransactionList = new LinkedList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> reconciledList = new LinkedList<CreditCardTransactionDto>();

		// get the debit and credit tran code for the selected fee type in UI.
		SRParamDto param = (SRParamDto) journeyMap
				.get(CardConstant.KEY_PARAM_DTO);

		String debitCode = param.getParamData2();
		String debitNarration1 = param.getParamData3();
		String debitNarration2 = CardConstant.PAD_EMPTY;
		if (!CardUtil.isEmptyOrNull(param.getParamData6())) {
			debitNarration2 = param.getParamData6();
		}
		String paymentCreditcode = param.getParamData4();
		String nonpaymentCreditcode = CardConstant.PAD_EMPTY;
		if (!CardUtil.isEmptyOrNull(param.getParamData5())) {
			nonpaymentCreditcode = param.getParamData5();
		}

		String truncCreditNarration = param.getParamData9();

		// Segrigating debit and credit transaction from Edmp transaction
		Iterator<CreditCardTransactionDto> iterator = edmp12MonthTransactions
				.iterator();
		while (iterator.hasNext()) {
			segregatingDebitAndCredit(debitTransactionList,
					creditTransactionList, iterator, debitCode, debitNarration1,debitNarration2,
					paymentCreditcode, nonpaymentCreditcode,
					truncCreditNarration, creditcardDto, creditcardvo,null);
		}

		log.info("Entered from getReconciledTransaction() - EDMP transaction matching completed.");
		
		//updating credit and debit trans list against CCMS statemanted trans.
		if(!CardUtil.isEmptyOrNull(statemantedTransaction)){
			iterator = statemantedTransaction.iterator();
			while (iterator.hasNext()) {
				segregatingDebitAndCredit(debitTransactionList,
						creditTransactionList, iterator, debitCode, debitNarration1,debitNarration2,
						paymentCreditcode, nonpaymentCreditcode,
						truncCreditNarration, creditcardDto, creditcardvo,null);
			}
		}

		log.info("Entered from getReconciledTransaction() - EDMP statemented transaction matching completed.");
		
		//updating credit and debit trans list against CCMS Un-statemented trans.
		if(!CardUtil.isEmptyOrNull(unStatementtransactionList)){
			iterator = unStatementtransactionList.iterator();
			while (iterator.hasNext()) {
				segregatingDebitAndCredit(debitTransactionList,
						creditTransactionList, iterator, debitCode, debitNarration1,debitNarration2,
						paymentCreditcode, nonpaymentCreditcode,
						truncCreditNarration, creditcardDto, creditcardvo,null);
			}
		}
		
		log.info("Entered from getReconciledTransaction() - EDMP Unstatemented transaction matching completed.");
		
		journeyMap.put(CardConstant.CC_DEBT_TRANC_LIST_SIZE,
				debitTransactionList.size());
		journeyMap.put(CardConstant.CC_CRED_TRANC_LIST_SIZE,
				creditTransactionList.size());
		if (debitTransactionList.size() > CardConstant.ZERO) {
			// Check Debit and Credit for IN
			if (creditcardvo.getCountryCode().equals(CardConstant.CONTRY_IN)) {
				reconciledList = checkDebitCreditAvailabilityIN(param,
						debitTransactionList, creditTransactionList, journeyMap);
			}
			// Check Debit and Credit for SG
			if (creditcardvo.getCountryCode().equals(CardConstant.CONTRY_SG)) {
				reconciledList = checkDebitCreditAvailabilitSG(param,
						debitTransactionList, creditTransactionList, journeyMap);
			}
		} else {
			CreditCardTransactionDto creditcardTransDto = new CreditCardTransactionDto();
			creditcardTransDto
					.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT);
			reconciledList.add(creditcardTransDto);
		}
		
		log.info("Exit from getReconciledTransaction.");

		return reconciledList;
	}
	
	public List<CreditCardTransactionDto> getHKReconciledTransaction(
			List<CreditCardTransactionDto> unStatementtransactionList,
			List<CreditCardTransactionDto> edmp12MonthTransactions,
			List<CreditCardTransactionDto> statemantedTransaction,
			CreditCardVO creditcardvo, Map<String, Object> journeyMap,
			CreditCardDto creditcardDto,String feeDesc) {

		log.info("Entered to getHKReconciledTransaction() [from EDMP, CCMS - Unbilled/ Billed]..");
		
		List<CreditCardTransactionDto> debitTransactionList = new LinkedList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> creditTransactionList = new LinkedList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> reconciledList = new LinkedList<CreditCardTransactionDto>();
		Map<String, Object> transDescInput = getTxtCollection(journeyMap);

		
		// Segrigating debit and credit transaction from Edmp transaction
		Iterator<CreditCardTransactionDto> iterator = edmp12MonthTransactions
				.iterator();
		while (iterator.hasNext()) {
			segregatingDebitAndCredit(debitTransactionList,
					creditTransactionList, iterator, null,null, null,
					null, null,
					null, creditcardDto, creditcardvo,transDescInput);
		}

		log.info("Entered to getHKReconciledTransaction() - EDMP transaction matching completed.");
		
		//updating credit and debit trans list against CCMS statemanted trans.
		if(!CardUtil.isEmptyOrNull(statemantedTransaction)){
			iterator = statemantedTransaction.iterator();
			while (iterator.hasNext()) {
				segregatingDebitAndCredit(debitTransactionList,
						creditTransactionList, iterator, null,null, null,
						null, null,
						null, creditcardDto, creditcardvo,transDescInput);
			}
		}

		log.info("Entered to getHKReconciledTransaction() - EDMP statemented transaction matching completed.");
		
		//updating credit and debit trans list against CCMS Un-statemented trans.
		if(!CardUtil.isEmptyOrNull(unStatementtransactionList)){
			iterator = unStatementtransactionList.iterator();
			while (iterator.hasNext()) {
				segregatingDebitAndCredit(debitTransactionList,
						creditTransactionList, iterator, null,null, null,
						null, null,
						null, creditcardDto, creditcardvo,transDescInput);
			}
		}
		
		log.info("Entered to getHKReconciledTransaction() - EDMP Unstatemented transaction matching completed.");
		
		if (debitTransactionList.size() > CardConstant.ZERO) {
			log.info("getHKReconciledTransaction() transDescInput "+transDescInput.toString());
			journeyMap.put("leastDebitDate",transDescInput.get("leastDebitDate"));
			reconciledList = checkDebitCreditAvailabilitHK(creditcardvo,debitTransactionList,creditTransactionList, journeyMap);

			if (reconciledList.size() == CardConstant.ZERO) {
				CreditCardTransactionDto creditcardTransactiondto = new CreditCardTransactionDto();
				creditcardTransactiondto.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED);
				reconciledList.add(creditcardTransactiondto);
			}
		} else {
			log.info("getHKReconciledTransaction() No Debits Found for the card num");
			CreditCardTransactionDto creditcardTransDto = new CreditCardTransactionDto();
			creditcardTransDto
					.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT);
			reconciledList.add(creditcardTransDto);
		}
		
		log.info("Exit from getHKReconciledTransaction()");

		return reconciledList;
	}
	/**
	 * @param debitTransactionList
	 * @param creditTransactionList
	 * @param iterator
	 * @param debitCode
	 * @param debitNarration1
	 * @param paymentCreditcode
	 * @param nonpaymentCreditcode
	 * @param truncCreditNarration
	 * @param creditcardDto
	 * @param creditcardvo
	 */
	@SuppressWarnings("unchecked")
	private void segregatingDebitAndCredit(
			List<CreditCardTransactionDto> debitTransactionList,
			List<CreditCardTransactionDto> creditTransactionList,
			Iterator<CreditCardTransactionDto> iterator, String debitCode,
			String debitNarration1,String debitNarration2, String paymentCreditcode,
			String nonpaymentCreditcode, String truncCreditNarration,
			CreditCardDto creditcardDto, CreditCardVO creditcardvo,Map<String, Object> transDescInput) {

		log.info("Entered in segregatingDebitAndCredit..");
		
		CreditCardTransactionDto creditCardTransactionDto = iterator.next();
		if (creditcardvo.getCountryCode().equalsIgnoreCase(CardConstant.CONTRY_HK)) {
			
			if (((ArrayList<String>)transDescInput.get("debitCodes")).contains(creditCardTransactionDto.getTxnCode())) {
				
				ArrayList<String> listOfNarrations = (ArrayList<String>) transDescInput.get(creditCardTransactionDto.getTxnCode());
				if (isCreditDebitDescMatching(listOfNarrations,creditCardTransactionDto.getDesc(),true)) {
				
					creditCardTransactionDto.setDebitCreditFlag(CardConstant.CC_DEBIT_INDICATOR);
					creditCardTransactionDto.setFeeSubTypeCode(transDescInput.get("narrationMapping").toString());
					Date leastDebitDate = (Date) transDescInput.get("leastDebitDate");
					if (leastDebitDate == null) {
						transDescInput.put("leastDebitDate",creditCardTransactionDto.getTransactionDt());
					} else if (creditCardTransactionDto.getTransactionDt().before(leastDebitDate)) {
						transDescInput.put("leastDebitDate",creditCardTransactionDto.getTransactionDt());
					}		
					debitTransactionList.add(creditCardTransactionDto);
				}
				
			} else if (((ArrayList<String>)transDescInput.get("creditCodes")).contains(creditCardTransactionDto.getTxnCode())) {
				
				ArrayList<String> listOfNarrations = (ArrayList<String>) transDescInput.get(creditCardTransactionDto.getTxnCode());
				if (isCreditDebitDescMatching(listOfNarrations,creditCardTransactionDto.getDesc(),true)) {
					creditCardTransactionDto.setDebitCreditFlag(CardConstant.CC_CREDIT_INDICATOR);
					creditTransactionList.add(creditCardTransactionDto);
				}
			}
			
		} else if (debitCode.equals(creditCardTransactionDto.getTxnCode())
				&& creditCardTransactionDto.getDesc().toUpperCase()
						.contains(debitNarration1.toUpperCase())) {
			creditCardTransactionDto
					.setDebitCreditFlag(CardConstant.CC_DEBIT_INDICATOR);

			if (creditcardDto.getIsPrimary().equalsIgnoreCase(
					CardConstant.CONS_Y)) {
				creditCardTransactionDto
						.setPrimarySuppInd(CardConstant.PRIMARY);
			} else if (creditcardDto.getIsPrimary().equalsIgnoreCase(
					CardConstant.CONS_N)) {
				creditCardTransactionDto
						.setPrimarySuppInd(CardConstant.SUPPLEMENTARY);
			}
			debitTransactionList.add(creditCardTransactionDto);
		}
		else if (!CardUtil.isEmptyOrNull(debitNarration2) && (debitCode.equals(creditCardTransactionDto.getTxnCode())
				&& creditCardTransactionDto.getDesc().toUpperCase()
				.contains(debitNarration2.toUpperCase()))){
			creditCardTransactionDto
					.setDebitCreditFlag(CardConstant.CC_DEBIT_INDICATOR);

			if (creditcardDto.getIsPrimary().equalsIgnoreCase(
					CardConstant.CONS_Y)) {
				creditCardTransactionDto
						.setPrimarySuppInd(CardConstant.PRIMARY);
			} else if (creditcardDto.getIsPrimary().equalsIgnoreCase(
					CardConstant.CONS_N)) {
				creditCardTransactionDto
						.setPrimarySuppInd(CardConstant.SUPPLEMENTARY);
			}
			debitTransactionList.add(creditCardTransactionDto);
		}
		else if ((paymentCreditcode.equals(creditCardTransactionDto
				.getTxnCode()) || (nonpaymentCreditcode
				.equals(creditCardTransactionDto.getTxnCode())))
				&& creditCardTransactionDto.getDesc().toUpperCase()
						.contains(truncCreditNarration)) {
			creditCardTransactionDto
					.setDebitCreditFlag(CardConstant.CC_CREDIT_INDICATOR);
			creditTransactionList.add(creditCardTransactionDto);
		}
		// below block is for Only SG-ANNUAL-FEE Reversal in order to reverse
		// the applicable GST also.
		else if (creditcardvo.getCountryCode().equals(CardConstant.CONTRY_SG)
				&&( (creditcardvo.getFeeType()
						.equalsIgnoreCase(CardConstant.ANNUAL_FEE_BASIC))||(creditcardvo.getFeeType()
						.equalsIgnoreCase(CardConstant.ANNUAL_FEE_SUPP)))) {
			if (creditCardTransactionDto.getTxnCode().equals(
					CardConstant.SG_GST_DEBIT_CODE)
					&& (creditCardTransactionDto.getDesc()
							.contains(CardConstant.SG_GST_DEBT_NARRATION))) {
				creditCardTransactionDto
						.setDebitCreditFlag(CardConstant.CC_DEBIT_INDICATOR);
				if (creditcardDto.getIsPrimary().equalsIgnoreCase(
						CardConstant.CONS_Y)) {
					creditCardTransactionDto
							.setPrimarySuppInd(CardConstant.PRIMARY);
				} else if (creditcardDto.getIsPrimary().equalsIgnoreCase(
						CardConstant.CONS_N)) {
					creditCardTransactionDto
							.setPrimarySuppInd(CardConstant.SUPPLEMENTARY);
				}
				debitTransactionList.add(creditCardTransactionDto);

			} else if (creditCardTransactionDto.getTxnCode().equals(
					CardConstant.SG_GST_CRED_CODE)
					&& (creditCardTransactionDto.getDesc()
							.contains(CardConstant.SG_GST_CRED_NARRATION))) {
				creditCardTransactionDto
						.setDebitCreditFlag(CardConstant.CC_CREDIT_INDICATOR);
				creditTransactionList.add(creditCardTransactionDto);

			}
		}
		
		log.info("Exit from segregatingDebitAndCredit..");
	}

	/**
	 * @param paramDto
	 * @param debitTransactionList
	 * @param creditTransactionList
	 * @param journeyMap
	 * @return
	 */
	private List<CreditCardTransactionDto> checkDebitCreditAvailabilityIN(
			SRParamDto param,
			List<CreditCardTransactionDto> debitTransactionList,
			List<CreditCardTransactionDto> creditTransactionList,
			Map<String, Object> journeyMap) {
		
		log.info("Entered in checkDebitCreditAvailabilityIN.. DbTranList["+debitTransactionList+"] CrTranList["+creditTransactionList+"]");
		
		Iterator<CreditCardTransactionDto> debitIterator = debitTransactionList
				.iterator();
		
		List<CreditCardTransactionDto> reconciledList = new ArrayList<CreditCardTransactionDto>();
		CreditCardTransactionDto debitTranscatioCardTransactionDto = null;
		CreditCardTransactionDto creditTranscatioCardTransactionDto = null;
		CreditCardTransactionDto creditCardTransDto = null;
		BigDecimal newDebitAmount = null;
		boolean flag = true;

		String truncCreditNarration = param.getParamData9();
		String paymentCreditcode = param.getParamData4();
		String nonpaymentCreditcode = param.getParamData5();

		//if((boolean) journeyMap.get(CardConstant.REWARD_POINT_REQUIRED)){
		//pull the reward point detail from db.
		SRParamDto rewardParam = (SRParamDto) journeyMap
				.get(CardConstant.KEY_REWARD_PARAM_DTO);

		String initialReffAmount = CardConstant.PAD_EMPTY;
		String finalReffAmount = CardConstant.PAD_EMPTY;
		String reffRewardPoints = CardConstant.PAD_EMPTY;


		if (rewardParam.getParamData1() != null
				&& !rewardParam.getParamData1()
						.equals(CardConstant.STRING_ZERO)) {
			initialReffAmount = rewardParam.getParamData1();

		}
		if (rewardParam.getParamData2() != null
				&& !rewardParam.getParamData2()
						.equals(CardConstant.STRING_ZERO)) {
			finalReffAmount = rewardParam.getParamData2();

		}
		if (rewardParam.getParamData3() != null
				&& !rewardParam.getParamData3()
						.equals(CardConstant.STRING_ZERO)) {
			reffRewardPoints = rewardParam.getParamData3();

		}

		log.info("Fetched Reward Amount from DB, Start Amount["+initialReffAmount+"] Final ["+finalReffAmount+"] Ref amount["+finalReffAmount+"]");

		journeyMap.put(CardConstant.KEY_REFF_INITIAL_AMT, initialReffAmount);
		journeyMap.put(CardConstant.KEY_REFF_FINAL_AMT, finalReffAmount);
		journeyMap.put(CardConstant.KEY_REFF_REWARD_PTS, reffRewardPoints);
	//	}
		String transactiondate;
		while (debitIterator.hasNext()) {
			debitTranscatioCardTransactionDto = debitIterator.next();
			String[] transactiondatearr = debitTranscatioCardTransactionDto
					.getTxnDate().split("/");
			transactiondate = transactiondatearr[0] + transactiondatearr[1]
					+ transactiondatearr[2].substring(2);
			flag = true;
			Iterator<CreditCardTransactionDto> creditIterator = creditTransactionList
					.iterator();
			while (creditIterator.hasNext()) {
				creditTranscatioCardTransactionDto = creditIterator.next();
				//matching of debit and credit transaction with narratiion and debit date..
				
				if(creditTranscatioCardTransactionDto.getDesc()
						.contains(transactiondate)
						&& (creditTranscatioCardTransactionDto.getDesc()
								.contains(truncCreditNarration))
						&& ((creditTranscatioCardTransactionDto.getTxnCode()
								.equalsIgnoreCase(paymentCreditcode)) || (creditTranscatioCardTransactionDto
								.getTxnCode()
								.equalsIgnoreCase(nonpaymentCreditcode)))) {
					flag = false;
					// amount level validation.
						if(null != debitTranscatioCardTransactionDto.getOriginTxnAmt() && null != creditTranscatioCardTransactionDto
								.getOriginTxnAmt() )
					if ((debitTranscatioCardTransactionDto.getOriginTxnAmt()
							.compareTo(
									creditTranscatioCardTransactionDto
											.getOriginTxnAmt()) == CardConstant.SIZE_ONE)) {
						
						log.info("IN - Partial payment happend for the card....");
						
						newDebitAmount = debitTranscatioCardTransactionDto
								.getOriginTxnAmt().subtract(
										creditTranscatioCardTransactionDto
												.getOriginTxnAmt());
						// balance amount to be debited.
						debitTranscatioCardTransactionDto
								.setActualTxnAmount(newDebitAmount);
						// partial paid case only
						debitTranscatioCardTransactionDto
								.setPartialRevTxnAmt(creditTranscatioCardTransactionDto
										.getOriginTxnAmt());
						debitTranscatioCardTransactionDto
								.setIsPartiallyReversed(CardConstant.CONS_Y);
						debitTranscatioCardTransactionDto
								.setPartialRevTxnDate(creditTranscatioCardTransactionDto
										.getTxnDate());

						reconciledList.add(debitTranscatioCardTransactionDto);
					}
				}
			}
			if (flag) {
				
				log.info("About to check Equivalent Reward point for IN ...");
				//TODO: remove this comment to enable reward point.
//				if((boolean) journeyMap.get(CardConstant.REWARD_POINT_REQUIRED)){
//					RewardPointDto rewardPoint = getEquivalentRewardPoints(
//						debitTranscatioCardTransactionDto, (String)journeyMap.get(CardConstant.KEY_REFF_REWARD_PTS),
//						(String)journeyMap.get(CardConstant.KEY_REFF_FINAL_AMT),journeyMap);
	//				debitTranscatioCardTransactionDto
	//						.setEquivalentRewardPoints(rewardPoint);
//				}
				
				RewardPointDto rewardPoint = getEquivalentRewardPoints(
						debitTranscatioCardTransactionDto, reffRewardPoints,
						finalReffAmount,journeyMap);

				debitTranscatioCardTransactionDto
						.setEquivalentRewardPoints(rewardPoint);
				debitTranscatioCardTransactionDto
						.setActualTxnAmount(debitTranscatioCardTransactionDto
								.getOriginTxnAmt());

				log.info("After checking the Equivalent Reward point for IN ... Reward Point["+rewardPoint+"]");
				
				reconciledList.add(debitTranscatioCardTransactionDto);
			}
		}
		if (reconciledList.size() == CardConstant.ZERO) {
			creditCardTransDto = new CreditCardTransactionDto();
			creditCardTransDto
					.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED);
			reconciledList.add(creditCardTransDto);
		}
		
		log.info("Exit from checkDebitCreditAvailabilityIN..");

		return reconciledList;
	}

	/**
	 * @param debitTranscatioCardTransactionDto
	 * @param requiredRewardPoints
	 * @param toAmount
	 * @param journeyMap 
	 * @return
	 */
	private RewardPointDto getEquivalentRewardPoints(
			CreditCardTransactionDto debitTranscatioCardTransactionDto,
			String requiredRewardPoints, String toAmount,
			Map<String, Object> journeyMap) {
		RewardPointDto rewardPoint = new RewardPointDto();
		if (null != journeyMap.get(CardConstant.OTHER_FEE)) {
			if(!CardConstant.PAD_EMPTY.equals(requiredRewardPoints)){

			rewardPoint.setRewardsPoints(debitTranscatioCardTransactionDto
					.getOriginTxnAmt()
					.multiply(
							BigDecimal.valueOf(Long
									.parseLong(requiredRewardPoints)))
					.toString());
			}
		}

		else {
			rewardPoint.setRewardsPoints(requiredRewardPoints);
		}

		return rewardPoint;
	}

	/**
	 * Reconcilation Process for Singapore
	 * 
	 * @param paramDto
	 * @param debitTransactionList
	 * @param creditTransactionList
	 * @return
	 */
	private List<CreditCardTransactionDto> checkDebitCreditAvailabilitSG(
			SRParamDto paramDto,
			List<CreditCardTransactionDto> debitTransactionList,
			List<CreditCardTransactionDto> creditTransactionList,
			Map<String, Object> journeyMap) {
		List<CreditCardTransactionDto> reconciledList = new ArrayList<CreditCardTransactionDto>();
		BigDecimal totalCreditAmount = BigDecimal.ZERO;
		RewardPointDto rewardPoint = null;

		SRParamDto rewardParam = (SRParamDto) journeyMap
				.get(CardConstant.KEY_REWARD_PARAM_DTO);

		String initialReffAmount = CardConstant.PAD_EMPTY;
		String finalReffAmount = CardConstant.PAD_EMPTY;
		String reffRewardPoints = CardConstant.PAD_EMPTY;

		if (rewardParam.getParamData1() != null
				&& !rewardParam.getParamData1()
						.equals(CardConstant.STRING_ZERO)) {
			initialReffAmount = rewardParam.getParamData1();

		}
		if (rewardParam.getParamData2() != null
				&& !rewardParam.getParamData2()
						.equals(CardConstant.STRING_ZERO)) {
			finalReffAmount = rewardParam.getParamData2();

		}
		if (rewardParam.getParamData3() != null
				&& !rewardParam.getParamData3()
						.equals(CardConstant.STRING_ZERO)) {
			reffRewardPoints = rewardParam.getParamData3();

		}

		journeyMap.put(CardConstant.KEY_REFF_INITIAL_AMT, initialReffAmount);
		journeyMap.put(CardConstant.KEY_REFF_FINAL_AMT, finalReffAmount);
		journeyMap.put(CardConstant.KEY_REFF_REWARD_PTS, reffRewardPoints);

		CreditCardTransactionDto creditcardTransactiondto = new CreditCardTransactionDto();

		Iterator<CreditCardTransactionDto> creditIterator = creditTransactionList
				.iterator();
		boolean validCreditFlag=false;
		// summing up all the credits
		while (creditIterator.hasNext()) {
			validCreditFlag=false;
			creditcardTransactiondto = creditIterator.next();
			for (Iterator<CreditCardTransactionDto> debititer = debitTransactionList.listIterator(); debititer.hasNext(); ) {
				CreditCardTransactionDto cctranDto = debititer.next();
				if(cctranDto.getTransactionDt().before(creditcardTransactiondto.getTransactionDt())){
					validCreditFlag=true;
				}
			}
			if(validCreditFlag)
			totalCreditAmount = totalCreditAmount.add(creditcardTransactiondto
					.getOriginTxnAmt());
		}
		Collections.reverse(debitTransactionList);
		Iterator<CreditCardTransactionDto> debitIterator = debitTransactionList
				.iterator();

		while (debitIterator.hasNext()) {
			creditcardTransactiondto = debitIterator.next();
			if(null != creditcardTransactiondto.getOriginTxnAmt())
			{
				if (totalCreditAmount.compareTo(creditcardTransactiondto
						.getOriginTxnAmt()) >= CardConstant.ZERO) {
					totalCreditAmount = totalCreditAmount
							.subtract(creditcardTransactiondto.getOriginTxnAmt());
					
				} else if (creditcardTransactiondto.getOriginTxnAmt().compareTo(
						totalCreditAmount) > CardConstant.ZERO) {
					creditcardTransactiondto
							.setActualTxnAmount(creditcardTransactiondto
									.getOriginTxnAmt().subtract(totalCreditAmount));
					//below block will be executed only once
					if(totalCreditAmount != BigDecimal.ZERO){
						creditcardTransactiondto.setIsPartiallyReversed(CardConstant.CONS_Y);
						creditcardTransactiondto.setPartialRevTxnAmt(totalCreditAmount);
						creditcardTransactiondto.setPartialRevTxnDate(creditcardTransactiondto.getTxnDate());
					}
					totalCreditAmount = BigDecimal.ZERO;
					//Primary/supp flag removed as per Country Requirement
					/*
					if (creditcardTransactiondto.getDesc().contains("SUPP")) {
						creditcardTransactiondto.setPrimarySuppInd("S");
					} else {
						creditcardTransactiondto.setPrimarySuppInd("P");
					}*/
					rewardPoint = getEquivalentRewardPoints(
							creditcardTransactiondto, reffRewardPoints,
							finalReffAmount, journeyMap);
					creditcardTransactiondto.setEquivalentRewardPoints(rewardPoint);
					reconciledList.add(creditcardTransactiondto);
				}
			}
		}

		if ((reconciledList.size() == CardConstant.ZERO)) {
			creditcardTransactiondto = new CreditCardTransactionDto();
			creditcardTransactiondto
					.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED);
			reconciledList.add(creditcardTransactiondto);
		}
		return reconciledList;
	}

	private List<CreditCardTransactionDto> checkDebitCreditAvailabilitHK(
			CreditCardVO creditcardvo,
			List<CreditCardTransactionDto> debitTransactionList,
			List<CreditCardTransactionDto> creditTransactionList,
			Map<String, Object> journeyMap) {
		List<CreditCardTransactionDto> reconciledList = new ArrayList<CreditCardTransactionDto>();
		BigDecimal totalCreditAmount = BigDecimal.ZERO;
		CreditCardTransactionDto creditcardTransactiondto = new CreditCardTransactionDto();

		Iterator<CreditCardTransactionDto> creditIterator = creditTransactionList
				.iterator();
		Date leastDebitDate = (Date) journeyMap.get("leastDebitDate");
		// summing up all the credits
		while (creditIterator.hasNext()) {
			creditcardTransactiondto = creditIterator.next();
			// Ignore, if Credit Transaction before debit Trasaction
			if (leastDebitDate != null && creditcardTransactiondto.getTransactionDt().before(leastDebitDate)) {
				continue;
			}
			totalCreditAmount = totalCreditAmount.add(creditcardTransactiondto
					.getOriginTxnAmt());
		}
		
		if (debitTransactionList.size() > 1) {
			Collections.sort(debitTransactionList,new TransactionComparator());
		}
		Iterator<CreditCardTransactionDto> debitIterator = debitTransactionList
				.iterator();

		while (debitIterator.hasNext()) {
			creditcardTransactiondto = debitIterator.next();
			if(null != creditcardTransactiondto.getOriginTxnAmt()) {
				if (totalCreditAmount.compareTo(creditcardTransactiondto
						.getOriginTxnAmt()) >= CardConstant.ZERO) {
					totalCreditAmount = totalCreditAmount
							.subtract(creditcardTransactiondto.getOriginTxnAmt());
				} else if (creditcardTransactiondto.getOriginTxnAmt().compareTo(
						totalCreditAmount) > CardConstant.ZERO) {
					creditcardTransactiondto.setPartialRevTxnAmt(totalCreditAmount);
					creditcardTransactiondto
							.setActualTxnAmount(creditcardTransactiondto
									.getOriginTxnAmt().subtract(totalCreditAmount));
					totalCreditAmount = BigDecimal.ZERO;
					reconciledList.add(creditcardTransactiondto);
				}
			}
		}
		return reconciledList;
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> getTxtCollection(Map<String, Object> journeyMap) {
		Map<String, Object> transDescInput = new HashMap<String, Object>();
		ArrayList<String> debitCodes = new ArrayList<>();
		ArrayList<String> creditCodes = new ArrayList<>();
		List<SRParamDto> list = (List<SRParamDto>) journeyMap.get(CardConstant.KEY_PARAM_DTO);
		for (SRParamDto txtCode : list) {
			if (transDescInput.get(txtCode.getParamData2()) == null) {
				ArrayList<String> narrationsToFilter = new ArrayList<>();
				
				String[] searchStr = txtCode.getParamData8().toUpperCase().split("#");
				for (String str : searchStr) {
					narrationsToFilter.add(str);
				}
				debitCodes.add(txtCode.getParamData2());
				creditCodes.add(txtCode.getParamData4());
				transDescInput.put(txtCode.getParamData2(), narrationsToFilter);
				transDescInput.put(txtCode.getParamData4(), narrationsToFilter);
				
				transDescInput.put("debitCodes", debitCodes);
				transDescInput.put("creditCodes", creditCodes);
				transDescInput.put("narrationMapping", txtCode.getParamData7());
				
			}
		}
		return transDescInput;
	}
	
	private boolean isCreditDebitDescMatching(List<String> listOfNarrations,
			String desc,boolean matchAll) {
		
		if (desc == null) return false;
		
		desc = desc.toUpperCase().trim().replaceAll(" ", "");
		for (String creditNarration : listOfNarrations) {
			if (!desc.contains(creditNarration)) {
				return false;
			}
		}
		return true;
	}

}
