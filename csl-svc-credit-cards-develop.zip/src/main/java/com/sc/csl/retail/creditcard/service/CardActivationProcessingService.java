package com.sc.csl.retail.creditcard.service;

import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.StrSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.creditcard.dao.MessageTemplateRepositoryDao;
import com.sc.csl.retail.creditcard.dao.entity.MessageTemplateEntity;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.customer.CreditCardContact;
import com.sc.csl.retail.creditcard.dto.customer.CustomerContact;
import com.sc.csl.retail.creditcard.dto.CardPinResetAuditDto;
import com.sc.csl.retail.creditcard.dto.notification.EmailNotificationPayloadDto;
import com.sc.csl.retail.creditcard.dto.notification.InboxNotificationPayloadDto;
import com.sc.csl.retail.creditcard.dto.notification.NotificationDto;
import com.sc.csl.retail.creditcard.dto.notification.NotificationHeaderDto;
import com.sc.csl.retail.creditcard.dto.notification.SmsNotificationPayloadDto;
import com.sc.csl.retail.creditcard.dto.post.PinChangeDto;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway.PropertyCodes;
import com.sc.csl.retail.creditcard.gateway.csl.CustomerJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.GenerateReceiptNumberGateway;
import com.sc.csl.retail.creditcard.gateway.csl.SharedServiceCSLGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.gateway.jms.NotificationGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.UAASUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CardActivationProcessingService {

	@Autowired
	GenerateReceiptNumberGateway generateReceiptNumberGateway;

	@Autowired
	SharedServiceCSLGateway sharedServiceCSLGateway;

	@Autowired
	private NotificationGateway notificationGateway;

	@Autowired
	private MessageTemplateRepositoryDao notifyMsgTemplateDaoRepository;

	@Autowired
	private CustomerJsonApiGateway customerJsonApiGateway;

	@Autowired
	private UAASUtil uaasUtil;
	
	@Autowired
	private CreditCardV1SoapGateway creditCardV1SoapGateway;
	
	@Autowired
	private CardUtil cardUtil;

	/**
	 * @param CreditCardDto
	 * @param txtInfo
	 *            Insert Audit Details
	 */

	public void insertAuditDetails(CreditCardDto creditCardDto) {
		log.info(" Audit Gateway Entry  -> ");

		String cardActivationFlag = "";

		CardPinResetAuditDto auditDto = new CardPinResetAuditDto();

		StringBuilder auditInfo = new StringBuilder();
		String txnInfo = uaasUtil.getLocalTimeAndDate(creditCardDto.getCountryCode(),CardConstant.TXN_INFO_DATE_FORMAT);

		String errorCode = null;
		if (creditCardDto.getOperationName().equalsIgnoreCase(CardConstant.OPERATION_CC_PINSET)) {
			cardActivationFlag = CardConstant.CONS_N;
			errorCode = (creditCardDto.getStatus() != CardConstant.UAAS_SUCCESS_CODE) ? creditCardDto.getStatus()
					: null;
		} else if (creditCardDto.getOperationName().equalsIgnoreCase(CardConstant.OPERATION_CC_PINACTIV)) {
			cardActivationFlag = CardConstant.CONS_Y;
			errorCode = ((creditCardDto.getStatus() != CardConstant.UAAS_SUCCESS_CODE
					|| !ArrayUtils.contains(CardGatewayConstant.EDMI_SUCCESS_RES_CDS, creditCardDto.getStatus())))
							? creditCardDto.getStatus() : null;
		} else if (creditCardDto.getOperationName().equalsIgnoreCase(CardConstant.OPERATION_CC_ACTIVATION)) {
			cardActivationFlag = CardConstant.CONS_Y;
			errorCode = (!ArrayUtils.contains(CardGatewayConstant.EDMI_SUCCESS_RES_CDS, creditCardDto.getStatus()))
					? creditCardDto.getStatus() : null;
		}

		auditInfo.append(CardConstant.CARD).append(CardConstant.PAD_ASSIGNMENT).append(creditCardDto.getCardNum())
				.append(CardConstant.PAD_SEMICOLON).append(CardConstant.EMBOSSED_NAME)
				.append(CardConstant.PAD_ASSIGNMENT).append(creditCardDto.getEmbossedName() != null ? creditCardDto.getEmbossedName()
						: CardConstant.PAD_EMPTY)
				.append(CardConstant.PAD_SEMICOLON).append(CardConstant.CARD_TYPE).append(CardConstant.PAD_ASSIGNMENT)
				.append(CardConstant.CREDIT).append(CardConstant.PAD_SEMICOLON).append(CardConstant.RECEIPT_NUMBER)
				.append(CardConstant.PAD_ASSIGNMENT).append(creditCardDto.getReceiptId())
				.append(CardConstant.PAD_SEMICOLON).append(CardConstant.ERROR_CODE).append(CardConstant.PAD_ASSIGNMENT)
				.append(errorCode).append(CardConstant.PAD_SEMICOLON).append(CardConstant.ERROR_MESSAGE)
				.append(CardConstant.PAD_ASSIGNMENT).append(creditCardDto.getErrorDescription())
				.append(CardConstant.PAD_SEMICOLON).append(CardConstant.DATE_TIME).append(CardConstant.PAD_ASSIGNMENT)
				.append(txnInfo).append(CardConstant.PAD_SEMICOLON).append(CardConstant.CARD_ACTIVATION_STATUS)
				.append(CardConstant.PAD_ASSIGNMENT).append(cardActivationFlag).append(CardConstant.PAD_SEMICOLON)
				.append(CardConstant.COUNTRY_CODE).append(CardConstant.PAD_SEMICOLON).append(creditCardDto.getCountryCode()).append(CardConstant.PAD_SEMICOLON);
		auditDto.setAuditInfo(auditInfo.toString());
		auditDto.setFunctionCd(creditCardDto.getOperationName());
		auditDto.setAction(errorCode == null ? CardConstant.AUDIT_SUCCESS : CardConstant.AUDIT_FAILURE);
		auditDto.setStatusCd(creditCardDto.getStatus());
		auditDto = sharedServiceCSLGateway.insertAuditDetails(auditDto);
		log.info(" Audit Gateway Exit  -> ");
	}

	/**
	 * @return
	 * @param Country
	 * 
	 *            Generate Receipt Number Based on Country
	 */

	public String generateReceiptNumber() {
		String receiptRsp = null;
		try {
			log.info(" Generate Receipt response entry -> ");
			Response receiptResponse = generateReceiptNumberGateway.generateReceipt();
			receiptRsp = receiptResponse.readEntity(String.class);
			PinChangeDto pinChangeRes = CSLJsonUtils.parseJson(receiptRsp, PinChangeDto.class);
			receiptRsp = pinChangeRes.getReceiptNumber();
			log.info("Generate Receipt response exit -> " + receiptRsp);
		}

		finally {
			log.info("Generate ReceiptNumber Service : generateReceiptNumber -> ");
		}
		return receiptRsp;
	}

	/**
	 * @return
	 * @param Country
	 * @param functionCode
	 * @param language
	 *            Retrieving Notify Message Template Details From DB And Mapping to
	 *            NotifyMsgTemplateEntity
	 */

	@Transactional(readOnly = true)
	public MessageTemplateEntity getMessageTemplate(String country, String functionCode, String language) {

		log.info(" Entered to read message template for notification {} {} {} ", country, functionCode, language);

		MessageTemplateEntity notifyMsgTemplateEntity = null;

		try {

			notifyMsgTemplateEntity = notifyMsgTemplateDaoRepository.getMsgTemplate(country, functionCode, language);
			log.info(" Exiting into getMessageTemplate  Completed ");

			return notifyMsgTemplateEntity;

		} catch (Exception ex) {
			throw ex;
		}
	}

	/**
	 * @return
	 * @param cslRequestContext
	 * @param creditCardDto
	 * @param notifyMsgTemplateEntity
	 *            Setting NotificationDto
	 */

	public void notify(CreditCardDto creditCardDto, MessageTemplateEntity notifyMsgTemplateEntity) {

		log.info(" Enter into notify  -> ");

		String primaryMobileNumber = null;
		String primaryEmail = null;
		if (creditCardDto.getOperationName().equalsIgnoreCase(CardConstant.OPERATION_CC_ACTIVATION)) {

			List<CreditCardContact> creditCardContacts = customerJsonApiGateway
					.getCreditContactWithCardNumber(creditCardDto.getCardNum());

			if (!CardUtil.isEmptyOrNull(creditCardContacts)) {

				Optional<CreditCardContact> phoneNumberContacts = creditCardContacts.stream()
						.filter(m -> m.getContactTypeDesc().equals(CardConstant.CONTACT_TYPE_MOBILE_DESC)).findFirst();
				
				CreditCardContact phoneNumberContact = null;
				
				if(phoneNumberContacts.isPresent()) {
					phoneNumberContact = phoneNumberContacts.get();
				}else {
					log.info("Mobile Element details Not Found ::");
					phoneNumberContact = null;
				}

				primaryMobileNumber = (phoneNumberContact != null) ? phoneNumberContact.getContactDetails() : null;
				
				String telephoneCntryCode=(String)CardUtil.getValueByKey(creditCardV1SoapGateway.getPropertiesByCode(creditCardDto.getCountryCode(),PropertyCodes.INTL_CNTRY_CODES),creditCardDto.getCountryCode());
				
				if (primaryMobileNumber != null) {
					primaryMobileNumber = cardUtil.validateContactNumber(telephoneCntryCode, primaryMobileNumber);
				}
				
				Optional<CreditCardContact> emailContacts = creditCardContacts.stream()
						.filter(m -> m.getContactTypeDesc().equals(CardConstant.CONTACT_TYPE_EMAIL_DESC)).findFirst();
				
				CreditCardContact emailContact = null;
				
				if(emailContacts.isPresent()) {
					emailContact = emailContacts.get();
				}else {
					log.info("EMAIl Element details Not present ::");
					emailContact = null;
				}
				primaryEmail = (emailContact != null) ? emailContact.getCustomerEmail() : null;
			} else {
				log.warn("Couldn't get Contact details from card systems..");
			}
		} else {
			List<CustomerContact> customerContacts = customerJsonApiGateway.getCustomerContact();

			if (!CardUtil.isEmptyOrNull(customerContacts)) {

				Optional<CustomerContact> phoneNumberContacts = customerContacts.stream()
						.filter(m -> m.getContactTypeDesc().equals(CardConstant.CONTACT_TYPE_MOBILE_DESC)).findFirst();
				
				CustomerContact phoneNumberContact = null;
				
				if(phoneNumberContacts.isPresent()) {
					phoneNumberContact = phoneNumberContacts.get();
				}else {
					log.info("Mobile Element details Not Found ::");
					phoneNumberContact = null;
				}

				primaryMobileNumber = (phoneNumberContact != null) ? phoneNumberContact.getContactDetails() : null;
				
				String telephoneCntryCode=(String)CardUtil.getValueByKey(creditCardV1SoapGateway.getPropertiesByCode(creditCardDto.getCountryCode(),PropertyCodes.INTL_CNTRY_CODES),creditCardDto.getCountryCode());
				
				if (primaryMobileNumber != null) {
					
					primaryMobileNumber = cardUtil.validateContactNumber(telephoneCntryCode, primaryMobileNumber);
				}
				
				Optional<CustomerContact> emailContacts = customerContacts.stream()
						.filter(m -> m.getContactTypeDesc().equals(CardConstant.CONTACT_TYPE_EMAIL_DESC)).findFirst();
				
				CustomerContact emailContact = null;
				
				if(emailContacts.isPresent()) {
					emailContact = emailContacts.get();
				}else {
					log.info("EMAIl Element details Not Found ::");
					emailContact = null;
				}
				primaryEmail = (emailContact != null) ? emailContact.getCustomerEmail() : null;
			}
		}

		if (null == notifyMsgTemplateEntity) {
			log.warn("NotifyMsgTemplateEntity can not be empty.Please check ->notifyMsgTemplateDaoRepository.getMsgTemplate() ");
		}

		if (null != notifyMsgTemplateEntity) {

			NotificationDto notificationDto = new NotificationDto();

			// Header
			NotificationHeaderDto notificationHeaderDto = new NotificationHeaderDto();
			notificationHeaderDto.setOperationName(creditCardDto.getOperationName());
			notificationHeaderDto.setChannelId(creditCardDto.getChannel());
			notificationHeaderDto.setCountry(creditCardDto.getCountryCode());
			notificationHeaderDto.setRelationshipNumber(creditCardDto.getRelId());
			notificationHeaderDto.setReceiptId(creditCardDto.getReceiptId());
			notificationDto.setHeaderDto(notificationHeaderDto);

			// SMS
			if (Character.toString(notifyMsgTemplateEntity.getSms()).equalsIgnoreCase(CardConstant.CONS_Y)
					&& !CardUtil.isEmptyOrNull(primaryMobileNumber)) {
				SmsNotificationPayloadDto smsNotificationPayloadDto = new SmsNotificationPayloadDto();
				smsNotificationPayloadDto.setMobileNumber(primaryMobileNumber);
				smsNotificationPayloadDto.setIsEncoded(notifyMsgTemplateEntity.getIsEncode());
				smsNotificationPayloadDto.setLanguage(CardConstant.LANGUAGE_ENG);
				smsNotificationPayloadDto.setMessageContent(getModifiedTemplate(notifyMsgTemplateEntity.getSmsMessage(),creditCardDto));
				smsNotificationPayloadDto.setNotifyType(CardConstant.NOTIFY_TYPE_SMS);
				notificationDto.setSmsPayloadDto(smsNotificationPayloadDto);
			}

			// INBOX
			if (Character.toString(notifyMsgTemplateEntity.getInbox()).equalsIgnoreCase(CardConstant.CONS_Y)) {
				InboxNotificationPayloadDto inboxNotificationPayloadDto = new InboxNotificationPayloadDto();
				inboxNotificationPayloadDto.setReference(creditCardDto.getRelId());
				inboxNotificationPayloadDto.setMessageCategory("3");
				inboxNotificationPayloadDto.setMessageSenderId(creditCardDto.getCustomerId());
				inboxNotificationPayloadDto.setMessageBody(getModifiedTemplate(notifyMsgTemplateEntity.getInboxMessage(),creditCardDto));
				inboxNotificationPayloadDto.setCountryGroup(creditCardDto.getCountryCode());
				inboxNotificationPayloadDto.setNotifyType(CardConstant.NOTIFY_TYPE_INBOX);
				inboxNotificationPayloadDto.setLanguage(CardConstant.LANGUAGE_ENG);
				inboxNotificationPayloadDto.setMessageSubject(notifyMsgTemplateEntity.getInboxSubject());
				notificationDto.setInboxPayloadDto(inboxNotificationPayloadDto);
			}

			// EMAIL
			if (Character.toString(notifyMsgTemplateEntity.getEmail()).equalsIgnoreCase(CardConstant.CONS_Y)
					&& !CardUtil.isEmptyOrNull(primaryEmail)) {
				EmailNotificationPayloadDto emailNotificationPayloadDto = new EmailNotificationPayloadDto();
				emailNotificationPayloadDto.setNotifyType(CardConstant.NOTIFY_TYPE_EMAIL);
				emailNotificationPayloadDto.setIsEncoded(notifyMsgTemplateEntity.getIsEncode());
				emailNotificationPayloadDto.setMessageSubject(notifyMsgTemplateEntity.getEmailSubject());
				emailNotificationPayloadDto.setMessageContent(getModifiedTemplate(getDecodeValue(notifyMsgTemplateEntity.getEmailBody()),creditCardDto));
				emailNotificationPayloadDto.setLanguage(CardConstant.LANGUAGE_ENG);
				emailNotificationPayloadDto.setEmailId(primaryEmail);
				emailNotificationPayloadDto.setSenderEmail(notifyMsgTemplateEntity.getSenderEmail());
				notificationDto.setEmailPayloadDto(emailNotificationPayloadDto);
			}

			if (notificationDto.getSmsPayloadDto()!=null || notificationDto.getInboxPayloadDto() != null || notificationDto.getEmailPayloadDto() !=null) {
				notificationGateway.postNotifyMessage(CSLJsonUtils.toJson(notificationDto));
				log.info("Notification message pushed to MQ Completed-> ");
			} else {
				log.info("Notification message Not pushed to  MQ :: Empty SMS || EMAIL || INBOX ");
			}
		}
		log.info(" Notify  Method Exit -notify()-> ");

	}


	// POST Notification

	public void postNotification(CreditCardDto creditCardDto) {
		
		log.info(" postNotification  Entry -> ");

		if (null != creditCardDto.getCountryCode() && null != creditCardDto.getOperationName()
				&& null != creditCardDto.getLanguage() && StringUtils.isNotBlank(creditCardDto.getCountryCode())
				&& StringUtils.isNotBlank(creditCardDto.getOperationName())
				&& StringUtils.isNotBlank(creditCardDto.getLanguage())) {

			// Get Message template details from DB
			MessageTemplateEntity creditCardNotifyEntity = getMessageTemplate(creditCardDto.getCountryCode(),
					creditCardDto.getOperationName(), creditCardDto.getLanguage());

			notify(creditCardDto, creditCardNotifyEntity);
		}
		
		log.info(" PostNotification Completed -> ");

	}

	/**
	 * 
	 * @param creditCardDto
	 * @param cardInfo
	 * @param txnInfo
	 */
	@Async("threadPoolTaskExecutor")
	public void postProcess(CreditCardDto creditCardDto) {
		log.info(" PostProcess  Entry-> ");
		try {
			insertAuditDetails(creditCardDto);
		} catch (Exception ex) {
			log.error(" Exception In Insert Audit Detaials -->" + ex.getMessage());
		}

		try {
			postNotification(creditCardDto);
		} catch (Exception ex) {
			log.error(" Exception In Post Notification  -->" + ex.getMessage());
		}

		log.info(" PostProcess Completed-> ");
	}

	/**
	 * @return
	 * @param Country
	 * @param functionCode
	 * @param language
	 *            Retrieving OTP Message Template Details From DB
	 */

	@Transactional(readOnly = true)
	public String getOtpMessageTemplateDetail(String country, String functionCode, String language) {

		log.info(" Entered to read OTP message  template for notification {} {} {} ", country, functionCode, language);

		List<MessageTemplateEntity> notifyMsgTemplateEntity = null;
		String otpMessageTemplate = "";

		try {

			notifyMsgTemplateEntity = notifyMsgTemplateDaoRepository.getOtpMsgTemplate(country, functionCode, language);

			@SuppressWarnings("rawtypes")
			Iterator it = notifyMsgTemplateEntity.iterator();
			while (it.hasNext()) {
				Object[] obj = (Object[]) it.next();
				otpMessageTemplate = obj[1].toString();
			}
			log.info(" Exiting into getOtpMessageTemplate  Completed ");

			return otpMessageTemplate;

		} catch (Exception ex) {
			throw ex;
		}
	}
	
	
     //  Modifying Notify Message Template ,Passing CUSTOMER_NAME,CARD_NUMBER,LAST_FOUR_DIGIT_CARD_NUMBER,DATE Dynamically
	
	private String getModifiedTemplate(String message, CreditCardDto creditCardDto) {
		// TODO Auto-generated method stub

		Map<String, String> templateMap = new HashMap<String, String>();
		templateMap.put(CardConstant.CUSTOMER_NAME,
				creditCardDto.getEmbossedName() != null ? creditCardDto.getEmbossedName() : CardConstant.PAD_EMPTY);
		templateMap.put(CardConstant.CARD_NUMBER, creditCardDto.getCardNum());
		templateMap.put(CardConstant.DATE, uaasUtil.getLocalTimeAndDate(creditCardDto.getCountryCode(),CardConstant.MESSAGE_TEMPLATE_DATE_FORMAT_INFO));
		templateMap.put(CardConstant.LAST_FOUR_DIGIT_CARD_NUMBER, getLastFourDigits(creditCardDto.getCardNum()));
		templateMap.put(CardConstant.RECEIPT_ID, creditCardDto.getReceiptId());
		templateMap.put(CardConstant.TODAYS_DATE, uaasUtil.getLocalTimeAndDate(creditCardDto.getCountryCode(),CardConstant.EMAIL_HEADER_DATE_FORMAT_INFO));
		StrSubstitutor sub = new StrSubstitutor(templateMap);
		String modifiedTemplate = sub.replace(message);
		return modifiedTemplate;
	}
	
	
	// Generating  Decode Value for Email
	private String getDecodeValue(byte[] str) {
		//Encode
		 byte[] encoded = Base64.getEncoder().encode(str);
        //Decode
		 byte[] decoded = Base64.getDecoder().decode(encoded);
		return new String(decoded);
	}
	
	// Getting Last Four Digits CardNumber 
	
	private String getLastFourDigits(String cardNumber) {
		String lastFourDigits = cardNumber.substring(cardNumber.length() - 4);
		return lastFourDigits;
	}
	
}
