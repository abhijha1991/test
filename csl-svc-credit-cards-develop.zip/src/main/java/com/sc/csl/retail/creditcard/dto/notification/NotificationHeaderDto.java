package com.sc.csl.retail.creditcard.dto.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class NotificationHeaderDto {


    @NotNull(message = "country can not be Null")
    @JsonProperty(value = "country")
    private String country;

    @NotNull(message = "receipt-id can not be Null")
    @JsonProperty(value = "relationship-number")
    private String relationshipNumber;

    @NotNull(message = "receipt-id can not be Null")
    @JsonProperty(value = "receipt-id")
    private String receiptId;

    @NotNull(message = "channel-id can not be Null")
    @JsonProperty(value = "channel-id")
    private String channelId;

    @NotNull(message = "operation-name can not be Null")
    @JsonProperty(value = "operation-name")
    private String operationName;

}
