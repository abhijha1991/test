package com.sc.csl.retail.creditcard.dto.security;

import lombok.Data;

@Data
public class UAASTransactionInfo {

	private String txnDate;
	private String txnTime;
	private String txnLocalDateTime;

}
