package com.sc.csl.retail.creditcard.exception;

import lombok.Getter;

import org.springframework.stereotype.Component;

@Component
public class CardException extends RuntimeException {

		@Getter
	    private int exceptionId;

	    @Getter
	    private String exceptionMessage;

	    public CardException() {
	    }
	    
	    public CardException(int exceptionId , String exceptionMessage) {
	        this.exceptionId = exceptionId;
	        this.exceptionMessage = exceptionMessage;
	    }


}
