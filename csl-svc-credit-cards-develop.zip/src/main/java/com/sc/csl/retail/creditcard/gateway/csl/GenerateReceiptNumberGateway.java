package com.sc.csl.retail.creditcard.gateway.csl;

import javax.ws.rs.core.Response;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import com.sc.csl.retail.core.gateway.CSLRestGateway;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
@ConfigurationProperties(prefix = "csl.receipt.gateway")
public class GenerateReceiptNumberGateway extends CSLRestGateway {


	@Value("${csl.receipt.gateway.serviceUrl}")
    private String endpoint;
	
	@Value("${csl.receipt.gateway.baseUrl}")
	private String receiptBaseUrl;
	
	public Response generateReceipt() {

		log.info("Entered Generate ReceiptNumber Service....");
		try {
			setBaseUrl(receiptBaseUrl);
			Response response = get(endpoint);
			return response;
		} finally {
			log.info("Exit Generate ReceiptNumberService....");
		}
	}
}
