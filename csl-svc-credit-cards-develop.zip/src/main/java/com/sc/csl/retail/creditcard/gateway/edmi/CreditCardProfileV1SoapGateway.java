package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.creditcard.v1.creditcardprofile.*;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardprofile.*;
import com.sc.csl.retail.cache.annotations.CacheKey;
import com.sc.csl.retail.cache.annotations.CacheResult;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.OfflineDataProperties;
import com.sc.csl.retail.creditcard.dto.CardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.RewardPointDto;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.gateway.csl.CreditCardSharedServiceJsonApiGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;


@Slf4j
public class CreditCardProfileV1SoapGateway extends BaseCreditCardsSoapGateway<CreditCardProfilePortType> {

    @Autowired
    public FreemarkerRenderer renderer;

    @Autowired
    private  OfflineDataProperties offlineDataProperties;

    @Autowired
    private CreditCardSharedServiceJsonApiGateway creditCardSharedServiceJsonApiGateway;

    @Autowired
    private CardUtil cardUtil;
    public CreditCardProfileV1SoapGateway(CSLSoapGatewayProperties creditCardProfileV1SoapGatewayProperties) {
        super(new CreditCardProfile(), CreditCardProfilePortType.class, creditCardProfileV1SoapGatewayProperties);
        setupInterceptors();
    }

    @Async("threadPoolTaskExecutor")
    public CompletableFuture<CreditCardVO> getAsyncCreditCardsList(CreditCardVO creditCardVO) {
        return CompletableFuture.completedFuture(getCreditCardListCreditCardVO(creditCardVO));
    }

    public CreditCardVO getCreditCardListCreditCardVO(CreditCardVO creditCardVO){
        CreditCardVO creditCardVO1 = new CreditCardVO();
        try {
        creditCardVO1.setCreditCards(getCreditCards(creditCardVO));
        } catch(Exception e) {
            log.info("Fetching from 24x7 DB for getCreditCards");
            creditCardVO1.setCreditCards(getCreditCardsFromSharedService(creditCardVO,e,creditCardVO.getCountryCode()+creditCardVO.getLangCode()+creditCardVO.getRelId()));
        }
        return creditCardVO1;
    }

    public List<CreditCardDto> getCreditCards(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = new ArrayList<CreditCardDto>();
        CreditCardDto creditCardDto = null;
        String cardNo = null;
        CreditCardProperties props = null;
        GetCardListing request = null;
        String startPageRefNum = null;
        try {
            log.debug("[getCreditCards Entry]");
            props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
            CardUtil.setGatewayProperties(creditCardVO);
            if (StringUtils.isNotBlank(creditCardVO.getCardNo()) && creditCardVO.isCardNoSearch()) {
                //Used to get the cardlist using cardNumber
                request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_PROFILE_CARD_NUM_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardListUsingCardNumProperties(), creditCardVO)), GetCardListing.class);
            } else if (StringUtils.isNotBlank(creditCardVO.getCustomerId())) {
                if(CardUtil.isEmptyOrNull(creditCardVO.getStartPageRefNumber()) && !CardUtil.isEmptyOrNull(props.getCardListProperties()) && StringUtils.equals(CardConstant.C400, props.getCardListProperties().getCaptureSystem())){
                    creditCardVO.setStartPageRefNumber(CardConstant.DEFAULT_START_PAGE_REF_NUM);
                }
                request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_PROFILE_CARD_LISTING_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardListProperties(), creditCardVO)), GetCardListing.class);
            }
            if (CardUtil.isEmptyOrNull(request)) {
                throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Card List Request", "empty or null"));
            }
            if(creditCardVO.getServiceTimeOut()!=null) {
                setupClientTimeout(creditCardVO.getServiceTimeOut());
            }
            GetCardListingRes response = this.getProxyClient().getCardListing(request.getGetCardListingRequest());
            validateEdmiResponse(creditCardVO, response);
            if(!CardUtil.isEmptyOrNull(response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getDocCtrlOut())
                    && !CardUtil.isEmptyOrNull(response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getDocCtrlOut().getSentPageCount())) {
                startPageRefNum = response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getDocCtrlOut().getSentPageCount();
            }
            for (AcctRecType acctRecType : response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getAcctRec()) {
                if (!CardUtil.isEmptyOrNull(acctRecType) && !CardUtil.isEmptyOrNull(acctRecType.getAcctInfo()) && !CardUtil.isEmptyOrNull(acctRecType.getAcctInfo().getSCBAcctInfo())) {
                    for (SCBCardInfoType sCBCardInfoType : acctRecType.getAcctInfo().getSCBAcctInfo().getSCBCardInfo()) {
                        if (!CardUtil.isEmptyOrNull(sCBCardInfoType) && !CardUtil.isEmptyOrNull(sCBCardInfoType.getSCBCardNum()) && StringUtils.length(sCBCardInfoType.getSCBCardNum()) > 1) {
                            cardNo = sCBCardInfoType.getSCBCardNum();
                            creditCardDto = new CreditCardDto();
                            creditCardDto.setStartPageRefNum(startPageRefNum);
                            creditCardDto.setCountry(creditCardVO.getCountryCode());
                            creditCardDto.setCustomerId(creditCardVO.getCustomerId());
                            creditCardDto.setChannel(creditCardVO.getChannelId());
                            creditCardDto.setRelId(creditCardVO.getRelId());
                            creditCardDto.setCustomerType(creditCardVO.getCustomerType());
                            creditCardDto.setCustBlockCode(acctRecType.getAcctInfo().getSCBCustBlockCode());
                            creditCardDto.setCardID(CardUtil.generateCardId(creditCardDto.getCountry(), cardNo, creditCardDto.getCustomerId()));
                            creditCardDto.setCardNum(cardNo);
                            creditCardDto.setIsComboFlag(CardConstant.CONS_N);
                            creditCardDto.setExpDt(sCBCardInfoType.getSCBExpDt());
                            creditCardDto.setVariant(CardUtil.getCardVariant(sCBCardInfoType.getSCBCardKeys().getSCBCardOrg()));
                            creditCardDto.setFranchise(CardUtil.getCardType(cardNo, props.getCreditCardFilters().getCardTypes()));
                            creditCardDto.setProd(CardUtil.getProductCode(sCBCardInfoType.getSCBCardKeys().getSCBCardType()));
                            creditCardDto.setSubProd(CardUtil.getProductCode(sCBCardInfoType.getSCBCardKeys().getSCBCardType()));
                            creditCardDto.setStatus(CardUtil.setCardStatus(sCBCardInfoType.getSCBCardStatus(), props.getCreditCardFilters().getCardStatus()));
                            creditCardDto.setBlkInd(CardUtil.getCardBlockCodeIndicator(sCBCardInfoType.getSCBBlockCode(), props.getCreditCardFilters().getBlockInds()));
                            creditCardDto.setCardImgName(CardUtil.getProductImage(cardNo, creditCardDto.getSubProd(), props.getProductImages(), props.getProductMappingBinLength()));
                            creditCardDto.setCardType(CardUtil.getCardType(cardNo, props.getCreditCardFilters().getCardTypes()));
                            creditCardDto.setBlockCode(CardUtil.getCardBlockCode(sCBCardInfoType.getSCBBlockCode()));
                            creditCardDto.setCardStatus(StringUtils.equals(CardConstant.C400,response.getHeader().getCaptureSystem())?sCBCardInfoType.getSCBAcknowledgeStatus():sCBCardInfoType.getSCBCardStatus());                            
                            creditCardDto.setCardRplStatus(CardUtil.setCardStatus(sCBCardInfoType.getSCBCardStatus(), props.getCreditCardFilters().getCardStatus()));
                            creditCardDto.setStatementFlagUnmapped(sCBCardInfoType.getSCBStmtchangeFlag());
                            creditCardDto.setStatementFlag(CardUtil.getStatementFlags(sCBCardInfoType.getSCBStmtchangeFlag(), props.getCreditCardFilters().getStatementFlags()));
                            creditCardDto.setIsPrimary(CardConstant.CONS_N);
                            creditCardDto.setOperationName(creditCardVO.getOperationName());
                            creditCardDto.setFunctionCd(creditCardVO.getFunctionCd());
                            creditCardDto.setInclude(creditCardVO.getInclude());
                            if ((StringUtils.isNotBlank(sCBCardInfoType.getSCBCardCat()) && ArrayUtils.contains(CardConstant.CARD_TYPES_PRIMARY, sCBCardInfoType.getSCBCardCat())) || (StringUtils.isNotBlank(sCBCardInfoType.getSCBRelationship()) && ArrayUtils.contains(CardConstant.CARD_TYPES_PRIMARY, sCBCardInfoType.getSCBRelationship()))) {
                                creditCardDto.setIsPrimary(CardConstant.CONS_Y);
                            }
                            creditCardDto.setDesc(CardUtil.getProductDescription(creditCardDto.getSubProd(), cardNo, creditCardDto.getIsPrimary(), props.getProductCodes(), props.getProductMappingBinLength(), props.getCreditCardFilters().getCardTypes(), creditCardVO.getCountryCode()));
                            creditCardDto.setDescCode(CardUtil.getProductDescCode(creditCardDto.getSubProd(), cardNo, props.getProductMappingBinLength()));
                            if (!StringUtils.isEmpty(sCBCardInfoType.getSCBRwdpts())) {
                                RewardPointDto rewardDto = new RewardPointDto();
                                rewardDto.setRewardsPoints(sCBCardInfoType.getSCBRwdpts());
                                creditCardDto.setCardAvailableRewardpoint(rewardDto);
                            }
                            if (sCBCardInfoType.getCardBal() != null && !sCBCardInfoType.getCardBal().isEmpty()) {
                                for (AcctBalType acctBalType : sCBCardInfoType.getCardBal()) {
                                    if (acctBalType.getBalType() != null && CardConstant.CREDIT_LIMIT.equals(acctBalType.getBalType().getBalTypeValues()) && acctBalType.getCurAmt() != null) {
                                        creditCardDto.setAmount(acctBalType.getCurAmt().getAmt());
                                    }
                                }
                            }
                            for (CardPeriodDataType cardPeriodDataType : sCBCardInfoType.getCardPeriodData()) {
                                switch (cardPeriodDataType.getCardAmtType()) {
                                    case CardConstant.STMT_BALANCE:
                                        creditCardDto.setStatementBalance(cardPeriodDataType.getAmt()); break;
                                    case CardConstant.MIN_AMNT_DUE:
                                        creditCardDto.setMinimumAmountDue(cardPeriodDataType.getAmt()); break;
                                    case CardConstant.PAYMENT_DUE_DATE:
                                        if (null != cardPeriodDataType.getEffDt()) {
                                            creditCardDto.setPaymentDueDate(CardUtil.formatDate(CardUtil.parseDate(CardUtil.converDateToString(cardPeriodDataType.getEffDt()), CardConstant.REQ_DATE_FORMAT), CardConstant.DUE_DATE_FORMAT));
                                            creditCardDto.setBalanceDueDate(CardUtil.parseDate(CardUtil.converDateToString(cardPeriodDataType.getEffDt()), CardConstant.REQ_DATE_FORMAT));
                                        }
                                        break;
                                    case CardConstant.CURRENT_BAL:
                                        creditCardDto.setCurrentBalance(cardPeriodDataType.getAmt()); break;
                                }
                            }
                            for (AcctBalType acctBalType : sCBCardInfoType.getCardBal()) {
                                switch (acctBalType.getBalType().getBalTypeValues()) {
                                    case CardConstant.AVLBL_CREDIT:
                                        creditCardDto.setAvlblLimit(acctBalType.getCurAmt().getAmt()); break;
                                    case CardConstant.CREDIT_LIMIT:
                                        creditCardDto.setCreditLimit(acctBalType.getCurAmt().getAmt()); break;
                                    case CardConstant.PERMANENT_CREDIT_LIMIT:
                                        creditCardDto.setPermanentLimit(acctBalType.getCurAmt().getAmt()); break;
                                    default:
                                        break;
                                }
                            }
                            if (acctRecType.getSCBCustKeys() != null && acctRecType.getSCBCustKeys().getSCBCustNum() != null && acctRecType.getSCBCustKeys().getSCBCustOrg() != null) {
                                creditCardDto.setCustomerNumber(String.valueOf(acctRecType.getSCBCustKeys().getSCBCustNum()));
                                creditCardDto.setOrgNum(String.valueOf(acctRecType.getSCBCustKeys().getSCBCustOrg()));
                            }
                            if (!CardUtil.isEmptyOrNull(acctRecType.getAcctInfo().getCurCode()) && !CardUtil.isEmptyOrNull(acctRecType.getAcctInfo().getCurCode().getCurCodeValue())) {
                                creditCardDto.setCurrencyCode(CardUtil.getISOCurrencyCode(acctRecType.getAcctInfo().getCurCode().getCurCodeValue(), getPropertiesByCode(creditCardVO.getCountryCode(),PropertyCodes.CURRENCY_CODES)));
                            }
                            creditCardDto.setCustShortName(acctRecType.getAcctInfo().getSCBShortName());
                            creditCardDto.setIslamicFlag(acctRecType.getAcctInfo().getSCBIslamicFlag());
                            if(!CardUtil.isEmptyOrNull(props.getCreditCardFilters().getActivationStatus())) {
                                creditCardDto.setActivationStatusCode(sCBCardInfoType.getSCBAcknowledgeStatus());
                                creditCardDto.setActivationStatus(CardUtil.setCardStatus(sCBCardInfoType.getSCBAcknowledgeStatus(), props.getCreditCardFilters().getActivationStatus()));
                            }
                            if(!CardUtil.isEmptyOrNull(props.getCreditCardFilters().getCardRplStatusIndActivationStatus()) && !CardUtil.isEmptyOrNull(props.getCreditCardFilters().getCardRplStatusIndStopReasonCodes())) {
                                creditCardDto.setCardRplStatusInd(CardUtil.getCardRplStatusInd(sCBCardInfoType.getSCBAcknowledgeStatus(), sCBCardInfoType.getSCBBlockCode(), props.getCreditCardFilters().getCardRplStatusIndActivationStatus(), props.getCreditCardFilters().getCardRplStatusIndStopReasonCodes()));
                            }
                            if (acctRecType.getAcctInfo() != null && acctRecType.getAcctInfo().getAcctBal() != null) {
                                for (AcctBalType acctBalType : acctRecType.getAcctInfo().getAcctBal()) {
                                    switch (acctBalType.getBalType().getBalTypeValues()) {
                                        case CardConstant.CUSTOMER_CREDIT_LIMIT: creditCardDto.setCustomerCreditLimit(acctBalType.getCurAmt().getAmt());  break;
                                        case CardConstant.CUSTOMER_AVAILABLE_CREDIT_LIMIT: creditCardDto.setCustomerAvailableCreditLimit(acctBalType.getCurAmt().getAmt());  break;
                                        default: break;
                                    }
                                }
                            }
                            creditCards.add(creditCardDto);
                        }
                    }
                }
            }
            populateCreditCardPrimaryStatus(props, creditCards);
            creditCardVO.setCreditCards(creditCards);
            log.info("[getCreditCards resposne.size : {}]", CollectionUtils.size(creditCardVO.getCreditCards()));
            return creditCardVO.getCreditCards();
        } finally {
            log.debug("[getCreditCards Exit]");
        }
    }

    private void validateEdmiResponse(CreditCardVO creditCardVO, GetCardListingRes response) {
        if (CardUtil.isEmptyOrNull(response)) {
            return ;
        }
        validateSCBMLHeader(response.getHeader(), creditCardVO);
        if (!CardUtil.isEmptyOrNull(response.getGetCardListingResPayload())
                && !CardUtil.isEmptyOrNull(response.getGetCardListingResPayload().getGetCardListingRes())
                && !CardUtil.isEmptyOrNull(response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs())) {
            validateResponseCode(response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getSCBRespCode(), response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getSCBRespDesc(), creditCardVO);
        } else {
            return ;
        }
        if (CardUtil.isEmptyOrNull(response.getGetCardListingResPayload().getGetCardListingRes().getGetCardListingRs().getAcctRec())) {
            return ;
        }
    }

    @CacheResult(cacheName = "all-credit-card-cache",timeToLive = 2,timeUnit = TimeUnit.HOURS)
    public List<CreditCardDto> getCreditCardsFromSharedService(CreditCardVO creditCardVO, Throwable exception,@CacheKey String cacheKey) {
        handleException(creditCardVO, exception);
        List<CreditCardDto> creditCards = new ArrayList<>();
        List<CardDto> creditCardsFromSharedService = new ArrayList<>();
        String countryCode = creditCardVO.getCountryCode();
        CreditCardProperties props = getCreditCardPropertiesByCountry(countryCode);
        if (offlineDataProperties.getCreditCardPortfolio().contains(creditCardVO.getCountryCode())) {
            log.info("24x7 Enabled for getCreditCards, country: {}, allowedCountries:{}",
                    countryCode, offlineDataProperties.getCreditCardPortfolio());
            log.debug("[getCreditCardsFromSharedService Entry]");
            creditCardsFromSharedService = creditCardSharedServiceJsonApiGateway
                    .fetchAllCreditCardAccounts();
            creditCardsFromSharedService.forEach(creditCard -> {
                CreditCardDto creditCardDto = getCreditCardDto(creditCardVO, props, creditCard);
                creditCards.add(creditCardDto);
            });
        } else {
            log.info("24x7 not Enabled for getCreditCards, country: {}, allowedCountries:{}",
                    countryCode, offlineDataProperties.getCreditCardPortfolio());
            throw (TechnicalException) exception;
        }
        return creditCards;
    }

    @CacheResult(cacheName = "provided-credit-card-cache",timeToLive = 2,timeUnit = TimeUnit.HOURS)
    public Map<String,CreditCardDto> getProvidedCreditCardsFromSharedService(CreditCardVO creditCardVO, List<String> creditCardList , @CacheKey String cacheKey) {
        Map<String,CreditCardDto> creditCards = new HashMap<>();
        List<CardDto> creditCardsFromSharedService = new ArrayList<>();
        String countryCode = creditCardVO.getCountryCode();
        CreditCardProperties props = getCreditCardPropertiesByCountry(countryCode);
        if (offlineDataProperties.getCreditCardPortfolio().contains(creditCardVO.getCountryCode())) {
            log.info("24x7 Enabled for getCreditCards, country: {}, allowedCountries:{}",
                    countryCode, offlineDataProperties.getCreditCardPortfolio());
            log.debug("[getCreditCardsFromSharedService Entry]");
            creditCardsFromSharedService = creditCardSharedServiceJsonApiGateway
                    .fetchAllProvidedCreditCardAccounts(creditCardList);
            if(creditCardsFromSharedService!=null) {
                creditCardsFromSharedService.forEach(creditCard -> {
                    CreditCardDto creditCardDto = getCreditCardDto(creditCardVO, props, creditCard);
                    creditCards.put(creditCard.getCardNum(), creditCardDto);
                });
            }
        } else {
            log.info("24x7 not Enabled for getCreditCards, country: {}, allowedCountries:{}",
                    countryCode, offlineDataProperties.getCreditCardPortfolio());
        }
        if(creditCards.isEmpty()) {
            return null;
        }
        return creditCards;
    }

    private CreditCardDto getCreditCardDto(CreditCardVO creditCardVO, CreditCardProperties props, CardDto creditCard) {
        String cardNo = creditCard.getCardNum();
        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCountry(creditCardVO.getCountryCode());
        creditCardDto.setCustomerId(creditCardVO.getRelId());
        creditCardDto.setChannel(creditCardVO.getChannelId());
        creditCardDto.setRelId(creditCardVO.getRelId());
        creditCardDto.setCardID(CardUtil.generateCardId(creditCardDto.getCountry(), cardNo, creditCardVO.getRelId()));
        creditCardDto.setCardNum(cardNo);
        creditCardDto.setSubProd(creditCard.getSubProd());
        creditCardDto.setBlockCode(creditCard.getBlockCode());
        creditCardDto.setVariant(creditCard.getOrgCode());
        creditCardDto.setExpDt(creditCard.getExpDt());
        creditCardDto.setFranchise(CardUtil.getCardType(cardNo, props.getCreditCardFilters().getCardTypes()));
        creditCardDto.setProd(CardUtil.getProductCode(creditCard.getCardType()));
        creditCardDto.setCardImgName(CardUtil.getProductImage(cardNo, creditCardDto.getSubProd(), props.getProductImages(), props.getProductMappingBinLength()));
        creditCardDto.setCardType(CardUtil.getCardType(cardNo, props.getCreditCardFilters().getCardTypes()));
        creditCardDto.setStatementFlag(CardUtil.getStatementFlags(creditCard.getStatementFlag(), props.getCreditCardFilters().getStatementFlags()));
        creditCardDto.setAvlblLimit(String.valueOf(creditCard.getAvailableLimit()));
        creditCardDto.setCurrentBalance(String.valueOf(creditCard.getCurrentBalance()));
        creditCardDto.setCreditLimit(String.valueOf(creditCard.getCreditLimit()));
        creditCardDto.setMinimumAmountDue(String.valueOf(creditCard.getMinimumPayment()));
        creditCardDto.setCurrencyCode(creditCard.getCurrencyCode());
        creditCardDto.setStatementBalance(String.valueOf(creditCard.getCurrentBalance()));
        creditCardDto.setBalanceDueDate(creditCard.getBillDueDate());
        creditCardDto.setDesc(creditCard.getAccountDescription());
        creditCardDto.setOrgNum(creditCard.getOrgCode());
        return creditCardDto;
    }


    public CreditCardDto getCardDetails(CreditCardVO creditCardVO) {
        CreditCardDto creditCardDto = null;
        CreditCardProperties props = null;
        GetDetails request = null;
        log.info("[getCardDetails Entry]");
        props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
        CardUtil.setGatewayProperties(creditCardVO);
        request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_PROFILE_CARD_DETAIL_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardDetailsCardProfileProperties(), creditCardVO)), GetDetails.class);

        if (CardUtil.isEmptyOrNull(request)) {
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Card List Request", "empty or null"));
        }
        GetDetailsRes response = this.getProxyClient().getDetails(request.getGetDetailsRequest());

        if (CardUtil.isEmptyOrNull(response)) {
            return new CreditCardDto();
        }
        validateSCBMLHeader(response.getHeader(), creditCardVO);
        if (!CardUtil.isEmptyOrNull(response.getGetDetailsResPayload())
                && !CardUtil.isEmptyOrNull(response.getGetDetailsResPayload().getGetDetailsRes())
                && !CardUtil.isEmptyOrNull(response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs())) {
            validateResponseCode(response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getRespCode(), response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getRespDesc(), creditCardVO);
        } else {
            return new CreditCardDto();
        }
        if (CardUtil.isEmptyOrNull(response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getPartyRec())) {
            return new CreditCardDto();
        }

        creditCardDto = new CreditCardDto();
        for (PartyRecType partyRecType : response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getPartyRec()) {
            for (ContactInformationType contactInformationType : partyRecType.getSCBICMPartyInfo().getContactInformation()) {
                if ("Mobile".equals(contactInformationType.getContactType().getValue())) {
                    creditCardDto.setContactNumber(contactInformationType.getCustomerContactNumber().getValue());
                }
            }
        }

        return creditCardDto;
    }
}	