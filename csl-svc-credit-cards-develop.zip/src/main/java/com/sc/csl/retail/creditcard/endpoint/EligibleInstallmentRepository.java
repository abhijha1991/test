package com.sc.csl.retail.creditcard.endpoint;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.EligibleInstallmentDto;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.ErrorConstant;
import com.sc.csl.retail.creditcard.service.EligibleInstallmentService;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class EligibleInstallmentRepository extends ResourceRepositoryBase<EligibleInstallmentDto, String>
{

@Autowired
private CSLRequestContext cslRequestContext;

@Autowired
private EligibleInstallmentService eligibleInstallmentService;


public EligibleInstallmentRepository() {
        super(EligibleInstallmentDto.class);
        }

    @Override
    public EligibleInstallmentDto findOne(String cardNum, QuerySpec querySpec) {
        try {
            EligibleInstallmentDto eligibleInstallmentDto = new EligibleInstallmentDto();
            eligibleInstallmentDto.setCountry(cslRequestContext.getCountry());
            eligibleInstallmentDto.setCardNum(cardNum);
            populateQuerySpec(querySpec, eligibleInstallmentDto);
            eligibleInstallmentDto = eligibleInstallmentService.getEligiblePlans(eligibleInstallmentDto);
           return eligibleInstallmentDto;
        } finally {
            log.debug("[MailRepository findOne Exit]");
        }
    }

    @Override
    public ResourceList<EligibleInstallmentDto> findAll(QuerySpec querySpec) {
    try {
            log.debug("[MailRepository findAll Entry]");
            throw new BusinessException(ErrorConstant.ERR_FETCHING_ACCOUNT);
        } finally {
            log.debug("[MailRepository findAll Exit]");
        }
    }


    public QuerySpec populateQuerySpec(QuerySpec querySpec, EligibleInstallmentDto eligibleInstallmentDto) {
        log.info("populateQuerySpec querySpec & CreditCardVO-{}", querySpec,eligibleInstallmentDto);

        if(isEmptyOrNull(querySpec)){
            return querySpec;
        }
        if(isEmptyOrNull(eligibleInstallmentDto)){
            eligibleInstallmentDto = new EligibleInstallmentDto();
        }
        if(!CollectionUtils.isEmpty(querySpec.getFilters())){

            for(FilterSpec filterSpec : querySpec.getFilters()){

                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_FUN_CODE)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    eligibleInstallmentDto.setFuncCode((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.INSTALLMENT_AMT)
                        && StringUtils.isNotBlank(String.valueOf((String) filterSpec
                        .getValue()))) {
                    eligibleInstallmentDto.setInstallmentAmt((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.SEQ_NO)
                        && StringUtils.isNotBlank(String.valueOf((String) filterSpec
                        .getValue()))) {
                    eligibleInstallmentDto.setSeqNo((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.TENURES)
                        && StringUtils.isNotBlank(String.valueOf((String)  filterSpec
                        .getValue()))) {
                    eligibleInstallmentDto.setTenure((String) filterSpec.getValue());
                }

            }

        }

        return querySpec;
    }

    public static boolean isEmptyOrNull(String value) {
        return StringUtils.isBlank(value);
    }

    public static boolean isEmptyOrNull(Object value) {
        return (value == null);
    }
}
