package com.sc.csl.retail.creditcard;

import com.sc.csl.retail.cache.config.CacheConfig;
import com.sc.csl.retail.core.CSLSpringBootApplication;
import com.sc.csl.retail.core.config.AsyncConfig;
import com.sc.csl.retail.core.config.AuthConfig;
import com.sc.csl.retail.core.config.DataSourceConfig;
import com.sc.csl.retail.core.config.FreemarkerConfig;
import com.sc.csl.retail.core.config.JmsConfig;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.annotation.Import;
import org.springframework.jms.annotation.EnableJms;


@Slf4j
@SpringBootApplication
@EnableAutoConfiguration
@Import({ FreemarkerConfig.class, DataSourceConfig.class, AuthConfig.class, AsyncConfig.class, CacheConfig.class,JmsConfig.class})
@EnableCircuitBreaker
@EnableJms
public class CreditCardApplication extends CSLSpringBootApplication {

	public static void main(String[] args) throws Exception {
		try {
			log.debug("[CreditCardApplication main Entry]");
			configureApplication(new SpringApplicationBuilder()).run(args);
			log.debug("[Credit Card Entity is started successfully...]");
		} finally {
			log.debug("[CreditCardApplication main Exit]");
		}
    }

    private static SpringApplicationBuilder configureApplication(SpringApplicationBuilder builder) {
        builder.sources(CreditCardApplication.class);
        initBase(builder, "csl-svc-credit-cards");
        return builder;
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return configureApplication(builder);
    }

}
