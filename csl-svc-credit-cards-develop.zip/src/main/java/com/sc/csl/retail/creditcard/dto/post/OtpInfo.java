package com.sc.csl.retail.creditcard.dto.post;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class OtpInfo {

	@JsonProperty("otp-sn")
	private String otpSn;

	@JsonProperty("enc-otp")
	private String encOtp;

	@JsonProperty("key-index")
	private String keyIndex;
	
	private String purpose;

}
