package com.sc.csl.retail.creditcard.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class CreditCardEligibilityCriteriaDto extends BaseDto {

	private static final long serialVersionUID = 1L;

	private String cardNumber;

	private String cardType;

	private String countryCode;

	private String feeType;

	private String customerId;

	private String eligibilityStatusOL;

	private String eligibilityStatusOthers;

	private String eligibilityPercentageAF;

	private String eligibilityPercentageLF;

	private String eligibilityPercentageOL;

	private String eligibilityPercentageIF;

	private String valueToBank;

	private String isCustomerLevel;

	private String isCardLevel;

	private String xRemark;

	private String lateFeeEligible;

	private String annualFeeEligible;

	private String annualFeeChargeNotWaived;
	
	private String isObjNull = "Y";

}
