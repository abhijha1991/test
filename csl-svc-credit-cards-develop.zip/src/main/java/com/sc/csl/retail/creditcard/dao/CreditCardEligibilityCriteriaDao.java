package com.sc.csl.retail.creditcard.dao;

import java.util.Map;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityCriteriaDto;

public interface CreditCardEligibilityCriteriaDao {

	public CreditCardEligibilityCriteriaDto getINEligibilityCriteria(
			Map<String, Object> journeyMap, String input, String level, String tableName);

	public CreditCardEligibilityCriteriaDto getMYEligibilityCriteria(
			Map<String, Object> journeyMap, String customerId, String tableName);

	public CreditCardEligibilityCriteriaDto getSGEligibilityCriteria(
			Map<String, Object> journeyMap, String input, String level, String tableName);

	public void getEligibilityRefreshdate(Map<String, Object> journeyMap,
			CreditCardFeeWaiverProperties props);
	
	public CreditCardEligibilityCriteriaDto getHKEligibilityCriteria(
			Map<String, Object> journeyMap, String input, String level, String tableName);
}
