package com.sc.csl.retail.creditcard.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Data
@EqualsAndHashCode(callSuper=false)
public class CreditCardTransactionsEDMPDto extends BaseDto {

	private static final long serialVersionUID = 5874886117375293695L;

	private String cardNumber;
	
	private String transactionReferenceNo;
	
	private BigDecimal transactionAmount;
	
	private String transactionDesc;
	
	private String transactionCode;
	
	private String transactionDate;
	
	public String toString() {
		return ReflectionToStringBuilder.toString(this,	ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
