package com.sc.csl.retail.creditcard.config.properties;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

/**
 * @author 1452875
 * @since Sep 18, 2017
 */
@Setter
@Getter
@Slf4j
public class GatewayServiceNameProperties {
    private Map<String, String> validationServices = null;
    private Map<String, String> enrichmentServices = null;

    /**
     * Returns validation service flag of a given key(service name)
     */
    public String getValidationService(String key) {
        if (this.validationServices == null) {
            return null;
        }
        String flag = this.validationServices.get(key);
        log.debug("[Key: " + key + "] [Flag Value: " + flag + "]");
        return flag;
    }

    /**
     * Returns enrichment service flag of a given key(service name)
     */
    public String getEnrichmentService(String key) {
        if (this.enrichmentServices == null) {
            return null;
        }
        String flag = this.enrichmentServices.get(key);
        log.debug("[Key: " + key + "] [Flag Value: " + flag + "]");
        return flag;
    }
}
