package com.sc.csl.retail.creditcard.config.properties;

import java.text.MessageFormat;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;

/**
 * @author 1452875
 * @since Dec 4, 2017
 */
@Getter
@Setter
@Slf4j
public class BaseProperties {
    private Map<String, String> alertMessages = null;

    /**
     * Returns alert message of a given key
     */
    public String getAlertMessage(String key, String language) {
        String alertMsg = this.alertMessages.get(MessageFormat.format(key, language.toLowerCase()));
        log.debug("[Key: " + key + "] [Alert Message: " + alertMsg + "]");
        return alertMsg;
    }

    /**
     * Returns alert message of a given key. If value not found then returns default message
     */
    public String getAlertMessage(String key, String defaultKey, String language) {
        String alertMsg = getAlertMessage(key, language);
        if (StringUtils.isBlank(alertMsg)) {
            alertMsg = getAlertMessage(defaultKey, language);
        }
        log.debug("[Key: " + key + "] [Alert Message: " + alertMsg + "]");
        return alertMsg;
    }
}
