package com.sc.csl.retail.creditcard.dao.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;
import java.util.NavigableMap;

import lombok.extern.slf4j.Slf4j;

import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.filter.SubstringComparator;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Repository;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardTransactionEDMPDao;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionsEDMPDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * Repository to fetch the 12 months transaction from EDMP
 */
@Repository
@Slf4j
public class CreditCardTransactionEDMPDaoImpl extends BaseEDMPDao implements
		CreditCardTransactionEDMPDao {

	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private CardUtil cardUtil;

	@Override
	public void getTxnRefreshdate(Map<String, Object> journeyMap, CreditCardFeeWaiverProperties props){
		
		log.info("Enterd in getTxnRefreshdate()....");
		String tableName = props.getTxnRefreshTable();

		String key = CardConstant.KEY_EDMP_TRANC_BATCH_DT;
		String format = CardConstant.EDMP_TBL_REFRESH_DATE_FORMAT;
		// Below method will fetch the batch refresh data from EDMP and set it in journeyMap with above mentioned variable - "key"
		getMaxdate(journeyMap, tableName, key, format);
		log.info("Exit from  in getTxnRefreshdate()....");
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<CreditCardTransactionsEDMPDto> getCreditTransactions(
			CreditCardVO creditCardVO, SRParamDto srParamDto,
			Map<String, Object> journeyMap, CreditCardFeeWaiverProperties props) {

		log.info("Enterd in getCreditTransactions()....");
		List<CreditCardTransactionsEDMPDto> ccedmpDto = new ArrayList<CreditCardTransactionsEDMPDto>();
		Connection conn = null;
		Table tabTxn = null;
		SingleColumnValueFilter singColVaFilter = null;
		RowFilter rowFilter = null;
		Map<String, Object> transDescInput = new HashMap<String, Object>();
		String countryCode = creditCardVO.getCountryCode();
		String cardNumber = creditCardVO.getCardNo();
		String txnTableName = props.getTransactionTable();
		int txnRefCounter = 1;

		// paramData2- debit txn code. paramData3 - Debit Narration, paramData4 - Credit txn Code(Payment Mode for IN.)
		// paramData5- Credit Txn Code(Non Payment Mode), paramData9 - Credit Narration.
		if (CardConstant.CONTRY_IN.equalsIgnoreCase(countryCode)) {
			transDescInput.put(srParamDto.getParamData2(),
					srParamDto.getParamData3());
			transDescInput.put(srParamDto.getParamData4(),
					srParamDto.getParamData9());
			transDescInput.put(srParamDto.getParamData5(),
					srParamDto.getParamData9());
		} else if (CardConstant.CONTRY_SG.equalsIgnoreCase(countryCode)) {
			getSGTrasactionDesc(srParamDto,journeyMap,transDescInput);
		} else if (CardConstant.CONTRY_MY.equalsIgnoreCase(countryCode)) {
			transDescInput.put(srParamDto.getParamData2(),
					srParamDto.getParamData3());
			transDescInput.put(srParamDto.getParamData4(),
					srParamDto.getParamData9());
		} else if (CardConstant.CONTRY_HK.equalsIgnoreCase(countryCode)) {
			getHKTrasactionDesc(journeyMap,transDescInput);
		}
		try {
			conn = fetchEDMPHBaseConnection(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString());
			// Fetch transactions
			for (Map.Entry<String, Object> input : transDescInput.entrySet()) {
				tabTxn = conn.getTable(TableName.valueOf(txnTableName));
				String transactionCode = input.getKey();
				
				// Below filter is used to apply OR condition, while pulling the data from EDMP. If there are 2 conditions with OR, 
				// this will help to pull data, which satisfies either one / both the conditions.
				FilterList filterlist= new FilterList(FilterList.Operator.MUST_PASS_ONE);
				String narration = "";
				String startRow = cardNumber.trim() + transactionCode.trim();
				String endRow = cardNumber.trim()
						+ (Integer.parseInt(transactionCode) + 1);
				Scan scanTxns = new Scan(Bytes.toBytes(startRow),
						Bytes.toBytes(endRow));
				
				rowFilter = getRowFilter(startRow.concat("*"));
				if(CardConstant.CONTRY_HK.equalsIgnoreCase(countryCode)){
					narration = input.getValue().toString();
					singColVaFilter = getSingleColSubStringFilter(
							CardConstant.COL_FAM_NAME, CardConstant.COL_NARRATION,
							new SubstringComparator(narration));
					scanTxns.setFilter(rowFilter).setFilter(singColVaFilter);
				}
				
				// below condition is added for new set of debit narrations for SG. The debit narrations are contained in an arraylist and are passed using an OR condition
				else if(CardConstant.CONTRY_SG.equalsIgnoreCase(countryCode) && transactionCode.equalsIgnoreCase(srParamDto.getParamData2())){
					List<String> debitNarrationList = (List<String>)input.getValue();
					for(String narrStr: debitNarrationList){
						filterlist.addFilter(getSingleColValFilter(
							CardConstant.COL_FAM_NAME, CardConstant.COL_NARRATION,
							new RegexStringComparator(narrStr,Pattern.CASE_INSENSITIVE)));
					}
					scanTxns.setFilter(rowFilter).setFilter(filterlist);
				}
				else{
					narration = input.getValue().toString();
					singColVaFilter = getSingleColValFilter(
							CardConstant.COL_FAM_NAME, CardConstant.COL_NARRATION,
							new RegexStringComparator(narration,Pattern.CASE_INSENSITIVE));
					scanTxns.setFilter(rowFilter).setFilter(singColVaFilter);
				}
				ResultScanner resultScannerTxn = tabTxn.getScanner(scanTxns);
				Iterator<Result> iteratorTxn = resultScannerTxn.iterator();
				while (iteratorTxn.hasNext()) {
					Result next = iteratorTxn.next();
					CreditCardTransactionsEDMPDto ccEligibilityDto = new CreditCardTransactionsEDMPDto();

					for (Entry<byte[], NavigableMap<byte[], NavigableMap<Long, byte[]>>> columnFamilyMap : next
							.getMap().entrySet()) {
						for (Entry<byte[], NavigableMap<Long, byte[]>> entryVersion : columnFamilyMap
								.getValue().entrySet()) {
							for (Entry<Long, byte[]> entry : entryVersion
									.getValue().entrySet()) {
								String column = Bytes.toString(
										entryVersion.getKey()).trim();
								String value = new String(entry.getValue())
										.trim();

								// map the data from hBase table to
								// CreditCardTransactionsEDMPDto

								switch (column) {
								case CardConstant.COL_TXN_IN_ID_ACCT:
									ccEligibilityDto.setCardNumber(value);
									break;
								case CardConstant.COL_TXN_IN_AMNT:
									ccEligibilityDto
											.setTransactionAmount(new BigDecimal(
													value));
									break;
								case CardConstant.COL_TXN_IN_NARRATION_DESC:
									ccEligibilityDto.setTransactionDesc(value);
									break;
								case CardConstant.COL_TXN_IN_REF_NO:
									// Only for MY, the transaction reference number is unique. For other countries it is not guaranteed. 
									if(CardConstant.CONTRY_MY.equalsIgnoreCase(countryCode))
									{
									ccEligibilityDto
											.setTransactionReferenceNo(value);
									}
									break;
								case CardConstant.COL_TXN_IN_TXN:
									ccEligibilityDto.setTransactionCode(value);
									break;
								case CardConstant.COL_TXN_IN_TXN_DATE:
									String formattedDate = cardUtil.formatStringDate(value, CardConstant.TXN_DATE_FORMAT, CardConstant.REQ_DATE_FORMAT);
									ccEligibilityDto.setTransactionDate(formattedDate);
									break;
								}
							}
						}
					}//outer for close.
					
					// Only for MY, the transaction reference number is unique. For other countries it is not guaranteed. 
					// Hence setting an unique number based on card number and a defined counter. 
					if(!CardConstant.CONTRY_MY.equalsIgnoreCase(countryCode)){
						ccEligibilityDto.setTransactionReferenceNo(cardNumber + txnRefCounter);
						txnRefCounter++;
					}
					ccedmpDto.add(ccEligibilityDto);
					log.info("getCreditTransactions() - Fetched Trans from EDMP[" + ccEligibilityDto.toString()+"]");
				}//while close
			}
		} catch (IOException e) {
			// Below condition will check if the currently used connection is a primary one, and set the connection to DR.
			// journeyMap's edmpConfig property is a common one which is used by all the EDMP operations. 
			if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY)){
				log.info("Failed to connect to EDMP - HBASE primary connection. Retrying with DR DB");
				journeyMap.put(CardConstant.KEY_EDMP_CONFIG, CardConstant.KEY_EDMP_HBASE_DR_CONFIG);
				getCreditTransactions(creditCardVO, srParamDto, journeyMap, props);
			}
			else if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_DR_CONFIG)){
				log.error("Failed to connect to EDMP - HBASE DR connection...");
				throw new TechnicalException(e);
			}
		} finally {
			try {
				if(null!=tabTxn)
				tabTxn.close();
				if(null!=conn)
				conn.close();
			} catch (IOException e) {
				log.error("Exception Occured in CreditCardTransactionRepositoryDaoImpl - in finally block, while closing the HBase connection");
				throw new TechnicalException(e);
			}
		}
		log.info("Exit from getCreditTransactions(),  Card Number ["
				+ cardNumber + "]");
		return ccedmpDto;
	}

	@SuppressWarnings("unchecked")
	private void getHKTrasactionDesc(Map<String, Object> journeyMap,Map<String, Object> transDescInput){
		List<SRParamDto> list = (List<SRParamDto>) journeyMap.get(CardConstant.KEY_PARAM_DTO);
		for (SRParamDto txtCode : list) {
			if (transDescInput.get(txtCode.getParamData2()) == null) {
				transDescInput.put(txtCode.getParamData2(), txtCode.getParamData9());
				transDescInput.put(txtCode.getParamData4(), txtCode.getParamData9());
				break;
			}
		}
	}
	
	/*
	 * Below method is used to map credit txn code (paramData4), credit narration(paramData 9) and debit txn code(paramData2) and 
	 * debit narration(paramData3 / paramdata6)
	 */
	private void getSGTrasactionDesc(SRParamDto srParamDto, Map<String, Object> journeyMap,Map<String, Object> transDescInput){
		List<String> debitNarrations = new ArrayList<String>();
		transDescInput.put(srParamDto.getParamData4(),
				srParamDto.getParamData9());
		// For SG alone, for few of the fee types, there will be an additional debit narration(paramData6). The below code is to set the narration when the 
		// field exists in param table. 
		if(!CardUtil.isEmptyOrNull(srParamDto.getParamData6()))
			{
				debitNarrations.add(srParamDto.getParamData6());
				debitNarrations.add(srParamDto.getParamData3());
			}
		else{
				debitNarrations.add(srParamDto.getParamData3());
			}
		transDescInput.put(srParamDto.getParamData2(),
			debitNarrations);
	}
	
}
