package com.sc.csl.retail.creditcard.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
/**
 * @author 1523165
 * @since July 27, 2017
 */
public enum BusinessRuleAlertType {
    INFO("information"), WARN("warning"), ERROR("error");

    private String alertType = null;

}
