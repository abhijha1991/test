package com.sc.csl.retail.creditcard.dto.post;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CCTransactionPostDto {
	
	private String transactionCode;
	private String actualDebitAmout;
	private String transactionAmount;
	private String transactionDesc;
	private String debitTransactionDate;
	private String sequenceNumber;
	private String batchNumber;
	private String equivalentRewardpoint;
	private String feeSubTypeCode;
	
}
