package com.sc.csl.retail.creditcard.dto;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TransactionAsyncDto {

	private String requestType;
	private List<CreditCardTransactionDto> ccmsC400Transactions = null;
	private Map<String,String> eOpsCemsTransactions = null;
}
