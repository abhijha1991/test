package com.sc.csl.retail.creditcard.dto.customer;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author 1452875
 * @since Jun 30, 2017
 */
@Setter
@Getter
@JsonApiResource(type = "contacts")
public class CustomerContact implements Serializable {

    private static final long serialVersionUID = 7058050166460825314L;
    @JsonApiId
    @JsonProperty("contact-type-code")
    private String contactTypeCode = null;
    @JsonProperty("contact-type-desc")
    private String contactTypeDesc = null;
    @JsonProperty("contact-classification")
    private String contactClassification = null;
    @JsonProperty("contact-details")
    private String contactDetails = null;
    @JsonProperty("primary-flag")
    private String primaryFlag = null;
    @JsonProperty("rel-id")
    private String relId = null;
    @JsonProperty("customer-name")
    private String customerName = null;
    @JsonProperty("customer-email")
    private String customerEmail = null;
    @JsonProperty("contact-sequence-number")
    private String contactSequenceNumber = null;    

    @Override
    public String toString() {
        return "[Contact Type Code: " + contactTypeCode + "] [Contact Type Desc: " + contactTypeDesc
                + "] [Classification: " + contactClassification + "] [Contact Details: " + contactDetails
                + "] [Rel ID: " + relId + "]";
    }
}
