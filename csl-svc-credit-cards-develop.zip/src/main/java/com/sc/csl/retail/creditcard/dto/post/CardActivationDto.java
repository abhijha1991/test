package com.sc.csl.retail.creditcard.dto.post;



import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.creditcard.dto.BaseDto;

import io.katharsis.resource.annotations.JsonApiId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class CardActivationDto extends BaseDto{

	private static final long serialVersionUID = -3143638217183034440L;
	@JsonApiId
	private String id;
	
	@JsonProperty("key-index")
	private String keyIndex;
	
	@JsonProperty("enc-data")
	private String encData;
	
	@JsonProperty("otp-info")
	private OtpInfo otpInfo;
	
}
