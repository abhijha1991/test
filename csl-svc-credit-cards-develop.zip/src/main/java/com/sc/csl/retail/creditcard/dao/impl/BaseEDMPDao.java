package com.sc.csl.retail.creditcard.dao.impl;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;

import lombok.extern.slf4j.Slf4j;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.filter.SingleColumnValueFilter;
import org.apache.hadoop.hbase.filter.SubstringComparator;
import org.apache.hadoop.hbase.util.Bytes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * This component is used to make connection with EDMP [Hadoop] system.
 * 
 * @author 1367283
 *
 */
@Slf4j
public class BaseEDMPDao {

	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private CardUtil cardUtil;

	/**
	 * Method uses Hbase api methods to pull the data from HBase env.
	 * 
	 * @param famName
	 * @param column
	 * @param regexStringComparator
	 * @return
	 */
	protected SingleColumnValueFilter getSingleColValFilter(String famName,
			String column, RegexStringComparator regexStringComparator) {

		SingleColumnValueFilter filter = new SingleColumnValueFilter(
				Bytes.toBytes(famName), Bytes.toBytes(column), CompareOp.EQUAL,
				regexStringComparator);
		return filter;
	}
	
	/**
	 * Method uses Hbase api methods to pull the data from HBase env.
	 * 
	 * @param famName
	 * @param column
	 * @param regexStringComparator
	 * @return
	 */
	protected SingleColumnValueFilter getSingleColSubStringFilter(String famName,
			String column, SubstringComparator substringComparator) {

		SingleColumnValueFilter filter = new SingleColumnValueFilter(
				Bytes.toBytes(famName), Bytes.toBytes(column), CompareOp.EQUAL,
				substringComparator);

		return filter;
	}

	/**
	 * Method to fetch the batch refresh date, of table from EDMP.
	 * 
	 * @param journeyMap
	 * @param tableName
	 * @param key
	 * @param format
	 */
	protected void getMaxdate(Map<String, Object> journeyMap, String tableName,
			String key, String format) {
		log.info("Entered getMaxdate()....");
		Connection conn = null;
		String maxdate = null;
		Table tabMaxDate = null;
		try {
			// Fetch the max date of available transactions in EDMP
			if (!journeyMap.containsKey(key)) {
				conn = fetchEDMPHBaseConnection(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString());

				tabMaxDate = conn.getTable(TableName
						.valueOf(CardConstant.TABLE_BATCH_LOAD_DETAILS));
				Scan scanMaxDate = new Scan();

				/*
				 * Date edmpMaxDt = (Date) journeyMap
				 * .get(CardConstant.KEY_EDMP_MAX_TRANC_DT);
				 */
				RowFilter rowFilter = getRowFilter(tableName);
				scanMaxDate.setFilter(rowFilter);
				ResultScanner resultScannerMxDate = tabMaxDate
						.getScanner(scanMaxDate);
				Iterator<Result> iteratorMxDate = resultScannerMxDate
						.iterator();
				if (iteratorMxDate.hasNext()) {
					Result nxt = iteratorMxDate.next();

					for (Entry<byte[], NavigableMap<byte[], NavigableMap<Long, byte[]>>> columnFamMap : nxt
							.getMap().entrySet()) {
						for (Entry<byte[], NavigableMap<Long, byte[]>> entryVsn : columnFamMap
								.getValue().entrySet()) {
							for (Entry<Long, byte[]> entry : entryVsn
									.getValue().entrySet()) {
								String column = Bytes.toString(
										entryVsn.getKey()).trim();
								String value = new String(entry.getValue())
										.trim();
								if (CardConstant.COL_BATCH_REFRESH_DATE
										.equalsIgnoreCase(column)) {
									maxdate = value;
								}
							}
						}
					}
				}
				Date edmpMaxDt = cardUtil.formatDate(format, maxdate);
				log.info("Entered getMaxdate()....edmpMaxDt..."+edmpMaxDt);
				journeyMap.put(key, edmpMaxDt);
			}
		} catch (IOException e) {
			if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY)){
				log.info("Failed to connect to EDMP - HBASE primry connection. Retrying with DR DB");
				journeyMap.put(CardConstant.KEY_EDMP_CONFIG, CardConstant.KEY_EDMP_HBASE_DR_CONFIG);
				getMaxdate(journeyMap, tableName, key, format);
			}
			else if(journeyMap.get(CardConstant.KEY_EDMP_CONFIG).toString().equalsIgnoreCase(CardConstant.KEY_EDMP_HBASE_DR_CONFIG)){
				log.error("Failed to connect to EDMP - HBASE DR connection...");
				throw new TechnicalException(e);
			}
		} finally {
			try {
				if(tabMaxDate != null)tabMaxDate.close();
				if(conn != null)conn.close();
			} catch (IOException e) {
				log.error("Exception Occured in getMaxdate - finaly while closing the table and connection");
				throw new TechnicalException(e);

			}
		}
		log.info("Exit from getMaxdate()....");
	}

	protected RowFilter getRowFilter(String input) {
		RowFilter rowFilter = new RowFilter(CompareOp.EQUAL,
				new RegexStringComparator(input));
		return rowFilter;
	}

	/**
	 * Method to apply singleColumnValue filter for HBase scan
	 * 
	 * @param famName
	 * @param column
	 * @param value
	 * @return
	 */
	protected SingleColumnValueFilter getSingleColValFilter(String famName,
			String column, String value) {
		SingleColumnValueFilter filter = new SingleColumnValueFilter(
				Bytes.toBytes(famName), Bytes.toBytes(column), CompareOp.EQUAL,
				Bytes.toBytes(value));
		return filter;
	}

	/**
	 * Method to fetch the HBase connection
	 * 
	 * @return
	 * @throws IOException
	 */
	protected Connection fetchEDMPHBaseConnection(String config) throws IOException {
		log.info("Entered fetchEDMPHBaseConnection()....");
		CreditCardProperties crProps = getBean(config);
		HashMap<String, String> props = (HashMap<String, String>)crProps.getConfig();
		System.setProperty(CardConstant.HBASE_USER_NAME, crProps.getUserName());
		Configuration conf = HBaseConfiguration.create();
		// to set the connection properties
		for (Map.Entry<String, String> entry : props.entrySet()) {
			conf.set(entry.getKey(), entry.getValue());
		}
		return ConnectionFactory.createConnection(conf);
	}

	/**
	 * Method to fetch the HBase configuration information from yml
	 * 
	 * @return
	 */
	protected CreditCardProperties getBean(String config) {
		CreditCardProperties prop = (CreditCardProperties) applicationContext
				.getBean(config);
		return prop;
	}


}
