package com.sc.csl.retail.creditcard.gateway.csl;

import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;

/**
 * @author 1523165
 * @since July 26, 2017
 */
@Slf4j
@Component
@ConfigurationProperties(prefix = "servicerequest.client.url")
public class ServiceRequestJsonApiGateway extends CSLJsonApiGateway {

	/**
	 * @param serviceRequest
	 * serviceReq
	 */
	public ServiceRequest createServiceRequest(ServiceRequest serviceRequest) {
		log.info("Entered createServiceRequest()....");
		ServiceRequest serviceReq =new ServiceRequest();
		try {
			ResourceRepositoryV2<ServiceRequest, String> serviceRepo = getKatharsisClient()
					.getRepositoryForType(ServiceRequest.class);
			serviceReq = serviceRepo.create(serviceRequest);
		}  finally {
			log.info("[Exit from createServiceRequest...]");
		}
		return serviceReq;
	}
	
	/**
	 * This method pulls the Service Request from EOPS system through 'Service-Request' Entity at Customer level.
	 * 
	 * @param country
	 * @param relId
	 * @param channel
	 * @return
	 */
	public List<ServiceRequest> enquireStatus(String country, String relId, String channel,List<String> serviceTypes) {
		log.info("Entered ServiceRequestJsonApiGateway enquireStatus()....");
		List<String> propertyList = new ArrayList<String>();
		List<String> filterValues = new ArrayList<String>();
		List<FilterSpec> filterSpecList = new ArrayList<FilterSpec>();
		FilterSpec filterSpec = null;
		QuerySpec querySpec = new QuerySpec(ServiceRequest.class);
		
		List<ServiceRequest> serviceReq =null;
		try {
			propertyList = new ArrayList<>();
			filterValues = new ArrayList<>();
			propertyList.add("isCemsRequest");
			filterValues.add("false");
			
			filterSpec = new FilterSpec(propertyList, FilterOperator.EQ, filterValues);
			filterSpecList.add(filterSpec);
			
			if (serviceTypes != null) {
				propertyList = new ArrayList<>();
				filterValues = new ArrayList<>();
				propertyList.add("serviceTypeEN");
				for (String servieType : serviceTypes) {
					filterValues.add(servieType);
				}
				filterSpec = new FilterSpec(propertyList, FilterOperator.EQ, filterValues);
				filterSpecList.add(filterSpec);
			}
			
			querySpec.setFilters(filterSpecList);
			
			ResourceRepositoryV2<ServiceRequest, String> serviceRepo = getKatharsisClient()
					.getRepositoryForType(ServiceRequest.class);
			serviceReq = serviceRepo.findAll(querySpec);
		}  finally {
			log.info("[Exit from ServiceRequestJsonApiGateway enquireStatus...]");
		}
		return serviceReq;
	}

	
}
