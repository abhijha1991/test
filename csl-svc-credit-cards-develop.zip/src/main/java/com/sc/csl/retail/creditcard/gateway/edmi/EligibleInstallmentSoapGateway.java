package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.creditcard.v1.installmentloan.*;
import com.sc.corebanking.creditcard.v1.ws.provider.installmentloan.GetEligibleInstallmentPlan;
import com.sc.corebanking.creditcard.v1.ws.provider.installmentloan.GetEligibleInstallmentPlanRes;
import com.sc.corebanking.creditcard.v1.ws.provider.installmentloan.InstallmentLoanPortType;
import com.sc.corebanking.creditcard.v1.ws.provider.installmentloan.ScbCoreBankingCreditCardInstallmentLoanV1WsProviderV1InstallmentLoan;
import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.EligibleInstallmentDto;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseEligibleInstallmentSoapGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.scbml_1.SCBMLHeaderType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Slf4j
@Service
public class EligibleInstallmentSoapGateway extends BaseEligibleInstallmentSoapGateway<InstallmentLoanPortType> {

    @Autowired
    public FreemarkerRenderer renderer;

    public EligibleInstallmentSoapGateway(CSLSoapGatewayProperties edmiCreditCardInstallmentV1SoapGatewayProperties) {
        super(new ScbCoreBankingCreditCardInstallmentLoanV1WsProviderV1InstallmentLoan(), InstallmentLoanPortType.class, edmiCreditCardInstallmentV1SoapGatewayProperties);
        setupInterceptors();
    }

    public EligibleInstallmentDto getEligiblePlans(EligibleInstallmentDto eligibleInstallmentDto)

    {
        CreditCardProperties props = null;
        EligibleInstallmentDto eligibleInstallmentVO = new EligibleInstallmentDto();
        GetEligibleInstallmentPlan request = null;
        props = getCreditCardPropertiesByCountry(eligibleInstallmentDto.getCountry());
        log.info("[getDelinquencyHistory country config props -> {}", props);
        CardUtil.setEligibleGatewayProperties(eligibleInstallmentDto);
        request = CSLXmlUtils.toObject(
                renderer.render(CardConstant.ELIGIBLE_INSTALLMENT_PLAN_TEMPLATE_NAME,
                        getGatewayEligibleTemplateMap(props.getEligiblePlanProperties(), eligibleInstallmentDto)),
                GetEligibleInstallmentPlan.class);


        if(CardUtil.isEmptyOrNull(request)){
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR,"Card CreditCardTransactions History Request", "empty or null"));
        }
        GetEligibleInstallmentPlanRes response = this.getProxyClient().getEligibleInstallmentPlan(request.getGetEligibleInstallmentPlanRequest());

        if (CardUtil.isEmptyOrNull(response)) {
            return eligibleInstallmentVO;
        }


        EligibleInstallmentvalidateSCBMLHeader(response.getHeader(), eligibleInstallmentDto);
        eligibleInstallmentVO.setStatusCode(response.getGetEligibleInstallmentPlanResPayload().
                getGetEligibleInstallmentPlanRes().getGetEligibleInstallmentPlanRs().getStatus().getStatusCode());
        eligibleInstallmentVO.setStatusDesc(response.getGetEligibleInstallmentPlanResPayload().
                getGetEligibleInstallmentPlanRes().getGetEligibleInstallmentPlanRs().getStatus().getStatusDesc());
        eligibleInstallmentVO.setCardNum(eligibleInstallmentDto.getCardNum());
        eligibleInstallmentVO.setFuncCode(eligibleInstallmentDto.getFuncCode());
        eligibleInstallmentVO.setSeqNo(eligibleInstallmentDto.getSeqNo());
        List<String> tenuresList = new ArrayList<String>();
            for (AcctRecType acctRecType : response.getGetEligibleInstallmentPlanResPayload().getGetEligibleInstallmentPlanRes().getGetEligibleInstallmentPlanRs().getAcctRec()) {

                eligibleInstallmentVO.setEligbileAmount(acctRecType.getAcctInfo().getCreditAcctData()
                        .getLOCLoanData().getLOCLimit().getAmt());
                eligibleInstallmentVO.setMaxEligbileNormalAmount(acctRecType.getAcctInfo().getCreditAcctData()
                        .getLOCLoanData().getSCBMaxEligibleNormalAmt().getAmt());
                eligibleInstallmentVO.setMaxEligbileOverseasAmount(acctRecType.getAcctInfo().getCreditAcctData()
                        .getLOCLoanData().getSCBMaxEligibleOverseasAmt().getAmt());
                eligibleInstallmentVO.setMaxEligbileSpecialAmount(acctRecType.getAcctInfo().getCreditAcctData()
                        .getLOCLoanData().getSCBMaxEligibleSpecialAmt().getAmt());
                for (SCBInstallmentInfoType installmentInfo : acctRecType.getAcctInfo().getSCBInstallmentInfo()) {
                    for (DurationType durationType : installmentInfo.getStmtTimeFrame().getDuration()) {
                        if (durationType.getCount() != null && !durationType.getCount().equalsIgnoreCase("0")) {
                            tenuresList.add(durationType.getCount());
                        }


                        eligibleInstallmentVO.setTenures(tenuresList);
                    }

                }

            }

        return eligibleInstallmentVO;
    }


    public void EligibleInstallmentvalidateSCBMLHeader(SCBMLHeaderType header, EligibleInstallmentDto eligibleInstallmentVO){
        String responseCode = null;
        String responseDesc = null;
        if(CardUtil.isEmptyOrNull(header)){
            return;
        }

        if(!CardUtil.isEmptyOrNull(header.getExceptions())
                && !CardUtil.isEmptyOrNull(header.getExceptions().getException())
                && !CardUtil.isEmptyOrNull(header.getExceptions().getException().get(0).getCode())){
            responseCode = header.getExceptions().getException().get(0).getCode().getValue();
            responseDesc = header.getExceptions().getException().get(0).getDescription();
            log.info("[validateSCBMLHeader (Header) responseCode, responseDesc: {},{}", responseCode, responseDesc);
            validateResponseCode(responseCode, responseDesc, eligibleInstallmentVO);
        }
    }

    public void validateResponseCode(String responseCode, String responseDesc, EligibleInstallmentDto eligibleInstallmentVO){
        log.info("[validateResponseCode (Body) responseCode, responseDesc: {},{}", responseCode, responseDesc);
        if(!ArrayUtils.contains(CardGatewayConstant.EDMI_SUCCESS_RES_CDS, responseCode)){
            throw new BusinessException(TemplateErrorCode.create(CreditCardErrorCode.getBusinessErrorCode((String) CardUtil.getValueByKey(getErrorCodes(eligibleInstallmentVO.getCountry()), responseCode)), responseCode, responseDesc));
        }

        eligibleInstallmentVO.setStatusCode(responseCode);
        eligibleInstallmentVO.setStatusDescription(responseDesc);
    }

}
