package com.sc.csl.retail.creditcard.helper;

public class CardConstant {

	// page
	public static final long DEFAULT_PAGE_LIMIT = 30;
	public static final long DEFAULT_PAGE_START = 0;
	// Operation
	public static final String OPERATION_CC_BLOCK = "CARDBLK";
	public static final String OPERATION_CC_REPLACEMENT = "CARDRPL";
	public static final String OPERATION_CC_CHARGES = "CARDCHARGES";
	public static final String FILTER_CD_OPERATION_NAME = "operationName";
	public static final String INCLUDE_ONLINE = "ONLINE";
	public static final String OPERATION_MOBILE_BALANCE = "MOBILE_BALANCE";
	public static final String HOGAN_CREDIT_CARD_PRODUCT_CODE = "CCA";
	public static final String[] CCMS_ORG_NUMS_HK = {"1","111","300","001","022","22"};

	public static final String CTR_CD_ALL = "ALL";
	public static final String DEFAULT_START_PAGE_REF_NUM = "1";
	public static final String C400 = "C400";

   // filter params
	public static final String FILTER_CARD_NO = "cardNum";
	public static final String FILTER_ORG_NUM = "orgNum";
	public static final String CARD_LIST_FROM_HOGAN_CTRD_CDS[] = {"HK"};
	public static final String COMBO_CARD_ENABLE_CTR_CDS[] = {"NA"};
	public static final String COMBO_CARD_SUB_TYPE = "COM";
	public static final String COMBO_CARD_ALLOWED_ERROR_CDS[] = {"ERR_CSL_DEBIT_CARDS_209", "ERR_CSL_DEBIT_CARDS_213"};
	public static final String COMBO_CARD_ALLOWED_ERROR_DESCS[] = {"invalid card number", "04 - Unable to locate client information"};
    public static final String FILTER_CARD_INCLUDE = "include";


	public static final String PRODUCT_DESC_SUFFIX_NA_CTR_CDS [] = { "HK","SG" };
	public static final String PRODUCT_DESC_DEFAULT = "Credit Card";
	public static final String PRIMARY_CARD_PRODUCT_DESC_SUFFIX = " (P)";
	public static final String SUPPLEMENTARY_CARD_PRODUCT_DESC_SUFFIX = " (S)";
	public static final String PRODUCT_CODE_DEFAULT = "000";
	public static final String PRODUCT_CODE_PREFIX_ZERO = "0";
	public static final String CARD_VARIANT_PREFIX_ZERO = "0";
	public static final int AMEX_CARD_LENGTH = 16;
	public static final int AMEX_CARD_MIN_LENGTH = 15;
	public static final String AMEX_CARD_PREFIX = "0";
	
	public static final String PAD_UNDERSCORE = "_";
	public static final String PAD_HYPHEN="-";
	public static final String PAD_EMPTY = "";
	public static final String PAD_SPACE = " ";
	public static final String PAD_COMMA = ",";
	public static final String PAD_PLUS = "+";
	public static final String PAD_SEMICOLON = ";";
	public static final String PAD_ASSIGNMENT = "=";
	
	public static final String CONS_Y = "Y";
	public static final String CONS_N = "N";
	public static final String PAGE_END = "END";
    public static final String COUNTRY_HK = "HK";
    public static final String OFFLINE = "offline";
	
	public static final String[] CARD_TYPES_PRIMARY = {"P", "Primary"};
	public static final String CARD_IMAGE_DEFAULT = "DEFAULT";
	
	public static final String CARD_BLOCK_CODE_DEFAULT = "_";
	public static final String CARD_BLOCK_CODE_INDICATOR_DEFAULT = "00";
	
	public static final String CARD_TYPE_EXCLUDE_CARD_START_WITH_KEY = "_Exclude_StartWith";

	public static final String GATEWAY_TRACKING_ID_PREFIX = "csl-credit-cards-";
	public static final String TIME_STAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";

	public static final String CARD_PROFILE_CARD_LISTING_TEMPLATE_NAME = "card-profile-card-list.ftl";
	public static final String CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME = "card-enquiry-card-details.ftl";
	public static final String CARD_ENQUIRY_CARD_HISTORY_TEMPLATE_NAME = "card-enquiry-card-history.ftl";
	public static final String CARD_ENQUIRY_FINANCE_TEMPLATE_NAME = "card-enquiry-finance-details.ftl";
	public static final String CARD_CUSTOMER_ENQUIRY_CARD_LIST_TEMPLATE_NAME = "card-customer-enquiry-card-list.ftl";
    public static final String CARD_PROFILE_CARD_NUM_TEMPLATE_NAME = "card-profile-card-num.ftl";
    public static final String CARD_ENQUIRY_CARD_DELINQUENCY_TEMPLATE_NAME = "card-enquiry-card-delinquency.ftl";
    public static final String CARD_ENQUIRY_CARD_FINANCIAL_DETAILS_TEMPLATE_NAME = "card-enquiry-card-financial-details.ftl";
    public static final String CARD_PROFILE_CARD_DETAIL_TEMPLATE_NAME = "card-profile-card-detail.ftl";
    public static final String CARD_LIMIT_BALANCE_DETAILS_TEMPLATE_NAME = "card-limit-balance-details.ftl";
    public static final String CARD_STATUS_UPDATE_TEMPLATE_NAME = "card-update-Status.ftl";
    public static final String SMS_CARD_ACTIVATION_TEMPLATE_NAME = "sms-card-activation.ftl";
	public static final String CARD_ENQUIRY_FINANCE_CTR_CDS[] = {"AE"};
	public static final String CARD_ENQUIRY_FINANCE_OPERATION_NAMES[] = { OPERATION_CC_BLOCK, OPERATION_CC_REPLACEMENT, OPERATION_CC_CHARGES};
	//CC FEE WAIVER
	public static final String CONTRY_IN = "IN";
	public static final String CONTRY_SG = "SG";
	public static final String CONTRY_MY = "MY";
	public static final String CONTRY_HK = "HK";
 	public static final String CONTRY_CN = "CN";
 	public static final String CONTRY_AF = "AF";
 	public static final String CONTRY_NG = "NG";
 	public static final String CONTRY_AE = "AE";
 	public static final String CONTRY_KE = "KE";
 	public static final String CONTRY_GH = "GH";
 	public static final String CONTRY_BW = "BW";
 	public static final String CONTRY_ZM = "ZM";
 	
	public static final String FILTER_ACTIVE_CARDS = "activeCards";
	public static final String FILTER_ELIGIBLE_FEEWAIVER = "eligibleFeeWaiver";
	public static final String FILTER_FEE_TYPE = "feeType";
	public static final String FILTER_SR_NAME = "srName";
	public static final String ID_PARAM_ELIG_CARD = "I0004";
	public static final String ID_PARAM_I0004 = "I0004";
	public static final String ID_PARAM_RECONCILATIONPARAMS = "I0002";
	public static final String ID_PARAM_I0003 = "I0003";
	public static final String CC_DEBIT_INDICATOR="D";
	public static final String CC_CREDIT_INDICATOR="c";
	public static final String CC_DEBT_TRANC_LIST_SIZE="DEBT_TRANC_LIST" ;
	public static final String CC_CRED_TRANC_LIST_SIZE="CREDIT_TRANC_LIST";
	public static final String CC_FEE_WAIVER_ERR_CD_NO_DEBIT="1000";
	public static final String CC_FEE_WAIVER_MSG_CD_NO_DEBIT="No fee debited in the last 12 months";
	public static final String CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED="2000";
	public static final String CC_FEE_WAIVER_ERR_MSG_ALL_TRANC_PROCESSED="Fee waiver has already been processed";
	public static final String CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS="3000";
	public static final String CC_FEE_WAIVER_ERR_MSG_NO_ACTIVE_CARDS="You do not have any eligible Credit Card(s) to initiate the request.";
	public static final String CC_FEE_WAIVER_ERR_CD_CARD_NOT_ELIGIBLE="4000";
	public static final String CC_FEE_WAIVER_ERR_MSG_CARD_NOT_ELIGIBLE="Selected card is not eigible for selected type of fee waiver";
	public static final String CC_FEE_WAIVER_ERR_CD_CUST_NOT_ELIGIBLE="5000";
	public static final String CC_FEE_WAIVER_ERR_HK_CD_CUST_NOT_ELIGIBLE="7000";
	public static final String CC_FEE_WAIVER_ERR_MSG_CUST_NOT_ELIGIBLE="You are not eligible for waiver on the fee type selected";
	public static final String CC_FEE_WAIVER_ERR_CD_DUPLICATE="6000";
	public static final String CC_FEE_WAIVER_ERR_MSG_DUPLICATE="Request for the selected Fee type has already been placed.";
	public static final String CC_FEE_WAIVER_ERR_HK_COMMON_CD = "8000";
	public static final String KEY_ELIGIBLE_FEE_TYPE="eligibleFeeTypes";
	public static final String KEY_DELIQUENCY_BLOCK_CODES= "deliquencycardBlockCodes";
	public static final String KEY_CARD_DETAILS="card_Details";
	public static final String KEY_PARAM_DTO="paramDto";
	public static final String KEY_REWARD_PARAM_DTO="rewardPointConvRatio";
	public static final String KEY_CC_LIST="Credit_Reward_List";
	public static final String KEY_EXCLUTION_CARD_TYPES="execusionCardTypes";
	public static final String KEY_EXCLUTION_BLOCK_CODES="exclusionBlockCodes";
	public static final String KEY_OVERALL_REWARD_PTS="overAllrewardpoints";
	public static final String KEY_REFF_REWARD_PTS="reffRewardPoints";
	public static final String KEY_REFF_INITIAL_AMT="initialReffAmount";
	public static final String KEY_REFF_FINAL_AMT="finalReffAmount";
	public static final String KEY_EDMP_CONFIG = "edmpConfig";
	public static final String KEY_EDMP_HBASE_CONFIG_PRIMARY = "HBaseConfig";
	public static final String KEY_EDMP_HBASE_DR_CONFIG = "HBaseDRConfig";
	public static final String FUNC_CD_U="U";
	public static final String FUNC_CD_B="B";
	public static final String FUNC_CD_LPA = "LPA2";
	public static final String STMT_CD_01="01";
	public static final int SIZE_ONE=1;
	public static final int ZERO=0;
	public static final String START_PAGE_01 = "0001";
	public static final String KEY_EDMP_TRANC_BATCH_DT="edmptransactionbatchdate";
	public static final String KEY_EDMP_ELIGIBILITY_BATCH_DT="edmpeligibilitybatchdate";
	public static final String STRING_ZERO="0";
	public static final String CONS_YES = "Yes";
	public static final String CONS_NO = "No";
	public static final String SERVICETYPE = "FEEWPROC";
	public static final String ENTITYTYPE = "05";
	public static final String SOURCEFLAG = "IBK";
	public static final String AGENTID = "T01";
	public static final String FUNCTIONCODE = "MA";
	public static final String REQUESTTYPE = "NSTP";
	public static final String OPERATIONNAME = "FEEWREQ";
	public static final String DATE_FORMAT="yyyy-MM-dd";
	public static final String EDMP_TBL_REFRESH_DATE_FORMAT = "yyyyMMdd";
	public static final String TXN_DATE_FORMAT = "ddMMyyyy";
	public static final String PRIMARY="P";
	public static final String SUPPLEMENTARY="S";
	public static final String SERVICEREQUEST = "serviceRequests";
	public static final String INIT = "INIT";
	public static final String CC_FEE_WAIVER="CCFEEW";
	public static final String CC_FEE_TYPE = "FEE_TYPE";
	public static final String CC_REWARD_PT = "REWRD_PNT";
    public static final String OPERATION_CC_FEE_WAIVER = "FEEWREQ";
    public static final String COUNTRY_REWARD_ENABLED="CNTY_REWRD_ENABLED";
    public static final String CC_UI_FEETYPE = "UI_FEE_TYPE";
    public static final String EOPS_SR = "Eops";
    public static final String CEMS_SR = "Cems";

	public static final String HBASE_USER_NAME = "HADOOP_USER_NAME";
	//Eligibility Criteria
		public static final String FEE_TYPE_AF = "ANNUAL_FEE";
		public static final String FEE_TYPE_LF = "LATE_PAYMENT";
		public static final String FEE_TYPE_OL = "OVER_LIMIT";
		public static final String FEE_TYPE_IF = "INTEREST";
		public static final String TABLE_BATCH_LOAD_DETAILS = "SJAPP:sj_srv_refresh_sts";
		public static final String ELIGIBILITY_FAM_NAME = "GCF";
		public static final String COL_CARD_NUM = "C_ACCT_NO";
		public static final String COL_CUST_ID = "C_CUST";
		public static final String COL_NARRATION = "C_NARRATION";
		public static final String COL_CARD_TYPE = "CT";
		public static final String COL_FAM_NAME = "GCF";
		public static final String COL_DECILE = "C_DECILE";
		public static final String KEY_ELIGIBILITY = "Eligibility";
		public static final String KEY_ELIGIBILITY_PERCENTAGE = "EligibilityPercentage";
		public static final String KEY_VALUE_TO_BANK_IN = "valueToBank";
		public static final String VERY_HIGH_VTB_CAPPED_AMNT_IN = "3000";
		public static final String OTHER_VTB_CAPPED_AMNT_IN = "1500";
		public static final String COL_ELIGIBILITY_FLAG = "F_WAIVER_OTH";
		public static final String COL_ELIGIBILITY_FLAG_OT = "F_WAIVER_OVER_LMT";
		public static final String COL_ELIGIBILITY_PER_AF = "P_WAIVER_ANNUAL_FEES";
		public static final String COL_ELIGIBILITY_PER_IF = "P_WAIVER_INTEREST_CHARGE";
		public static final String COL_ELIGIBILITY_PER_LF = "P_WAIVER_LATE_FEES";
		public static final String COL_ELIGIBILITY_PER_OL = "P_WAIVER_OVER_LIMIT";
		public static final String ELIGIBILITY_CARD_LEVEL = "Card";
		public static final String ELIGIBILITY_CUSTOMER_LEVEL = "Customer";
		public static final String ELIGIBILITY_MY_XREMARK_VAL_Y = "Transactor";
		public static final String ELIGIBILITY_MY_XREMARK_VAL_N = "Revolver";
		public static final String VALUE_VERYHIGH = "a.VeryHIGH";
		public static final String COL_SG_CUST_NUM = "CUSTOMER_ID";
		public static final String COL_SG_CARD_NUM = "CACCT";
		public static final String COL_SG_LF_ELIGIBLE = "F_LATE_FEE_ELIGIBLE";
		public static final String COL_SG_AF_ELIGIBLE = "F_ANNUAL_FEE_ELIGIBLE";
		public static final String COL_SG_AF_NOT_WAIVED = "F_ANNFEECHRG_NOT_WAV";
		public static final String COL_MY_CUST_ID = "ID_CUST_EXT";
		public static final String COL_MY_X_REMARK = "X_REMARK";
	    public static final String CARD_DETAIL = "cardDetail";
	    public static final String COL_HK_CARD_NUM = "CAACT";
	    public static final String COL_HK_AF_ELIGIBLE = "F_ANNUAL_FEE_ELIGIBLE";
		public static final String COL_HK_AF_NOT_WAIVED = "F_ANNFEECHRG_NOT_WAV";
		public static final String LANG_CH_TRADITIONAL="ZH_HK";
		public static final String LANG_CH_SIMPLIFIED="ZH_CN";


	//Transactions from EDMP
	public static final String COL_TXN_IN_ID_ACCT = "ID_ACCT";
	public static final String COL_TXN_IN_TXN = "C_TRANSACTION";
	public static final String COL_TXN_IN_TXN_DATE = "D_TRANSACTION";
	public static final String COL_TXN_IN_AMNT = "A_TRANSACTION";
	public static final String COL_TXN_IN_NARRATION_DESC = "C_NARRATION";
	public static final String COL_TXN_IN_REF_NO = "C_REF_NO";
	public static final String ENCRYPT = "encrypt";
	public static final String DECRYPT = "decrypt";
	public static final String COL_BATCH_REFRESH_DATE = "REFRESH_MTH";
	public static final String CCMS_DATE_FORMAT1 = "yyyy-MM-dd";
	public static final String SG_GST_DEBT_NARRATION="GST - ANNUAL FEE ADJ";
	public static final String SG_GST_CRED_NARRATION="GST - ANNUAL FEE RE";
	public static final String SG_GST_CRED_CODE="22";
	public static final String SG_GST_DEBIT_CODE="60";
	public static final String ANNUAL_FEE_BASIC="ANNUAL_FEE_BASIC";
	public static final String ANNUAL_FEE_SUPP="ANNUAL_FEE_SUPP";
	public static final String EXCLUTION_CC_TYPES = "execusionCardTypes";
	public static final String UNPROCESSED_CREDIT_TRANC = "ccmsunprocessedcredittransactions";
	public static final String UNPROCESSED_DEBIT_TRANC = "ccmsunprocesseddebittransactions";
	public static final String ID_PARAM_I0006 ="I0006";
    public static final String CARD_NO_MASK_REQ="CARD_NO_MASK_REQ";


	//Credit Balance Refund related constants:
	public static final String AVLBL_CREDIT = "CardAvailableCredit";
    public static final String CREDIT_LIMIT = "CreditLimit";
	public static final String PERMANENT_CREDIT_LIMIT = "CardPermanentCredit Limit";
	public static final String CUSTOMER_AVAILABLE_CREDIT_LIMIT = "CustomerAvailableCredit";
	public static final String CUSTOMER_CREDIT_LIMIT = "CustomerCreditLimit";
    public static final String STMT_BALANCE = "StatementBal";
    public static final String MIN_AMNT_DUE = "MinimumAmount";
    public static final String PAYMENT_DUE_DATE = "PaymentDueDate";
    public static final String CURRENT_BAL = "CurrentBalance";
	public static final String EXCESS_AMT_CALC_LOGIC_CCMS = "CCMS_Logic";
    public static final String EXCESS_AMT_CALC_LOGIC_C400 = "C400_Logic";
    public static final String FLAG_YES = "yes";
    public static final String FLAG_NO = "no";
    public static final String FLAG_CBR_CR = "C";
    public static final String FLAG_CBR_DR = "D";
    public static final String FILTER_CREDIT_BAL_REFUND = "yes";
    public static final String BEAN_ID_CREDIT_BAL_REFUND_VALIDATION = "creditBalRefundValidationProperties{0}";
    public static final String MIN_ELIGIBLE_REFUND_AMOUNT_NOT_AVAILABLE = "{0}.amountnoteligibleforrefund";
    public static final String FILTER_ELIGIBLE_FOR_CREDIT_BAL_REFUND = "eligibleForCreditBalRefund";
	public static final String FILTER_REQUEST_TYPE = "requestType";
	public static final String ALERT_NO_EXCESS_AMOUNT_CARD = "{0}.noexcessamountcard";
	public static final String ALERT_NO_VALID_CARDS_FOUND ="{0}.novalidcardsfound";
	public static final String ALERT_DUPLICATE_CBR_REQUEST = "{0}.duplicatecbrrequest";

	public static final String CCMS_DATE_FORMAT = "yyyy/MM/dd";
	public static final String REQ_DATE_FORMAT = "dd/MM/yyyy";
	public static final String DUE_DATE_FORMAT = "dd MMM yyyy";

    // Credit Card Cancellation
    public static final String FILTER_CC_CANCEL = "yes";
    public static final String BEAN_ID_CC_CANCEL_ENRICHER = "creditCardCancelRequestEnricher{0}";
    public static final String REASON_CODE = "reasonCode";
    public static final String BEAN_ID_CC_CANCEL_VALIDATOR = "creditCardCancelRequestValidator{0}";
    public static final String OPERATION_CC_CANCEL = "CCCANCEL";
    public static final String PROP_CC_CANCEL_MSG_BAL_INELIGIBLE = "{0}.ineligibleBalance";
    public static final String ERROR_CD_CC_CANCEL_INELIGIBLE_CARD = "ERR_CCC_001";

	// Credit Card Fee
	public static final String CASH_ADVANCE_FEE = "CashAdvanceFeeParm";
	public static final String BANK_CHARGES = "BankChargesParm";
    public static final String CARD_AVAILABLE_CASH = "AvailableCash";

    /**
     * PROPERTIES CONSTANTS
     */
    // Services
    public static final String PROP_SERVICE_CC_GET_FINANCIAL_DETAIL = "getCCFinancialDetails";
	public static final String TRANSACTION = "transaction";
	public static final String FUNCTION_CD = "functionCd";
	public static final String TXN_TYPE = "txnType";
	public static final String FUNCTION_CODE_CCPROFILE_USING_CC = "CardListUsingCCNum";
//SMS OTP constants :
    public static final String SMS_OTP_REQUIRED = "yes";
    public static final String OTP_REQUIRED = "OTP Required";
    public static final String OTP_FAILED = "OTP Failed";
    public static final String OTP_TITLE = "OTP_TITLE";
    public static final String OTP_VALIDATION_FAILED = "OTP_VALIDATION_FAILED";
    public static final String CONTACT_TYPE_MOBILE = "M";
    public static final String CS_EXTENDED_ERROR = "extendedError";
    public static final String ID_PARAM_OTP = "I0005";
    public static final String KEY_PARAM_OTP = "OTP";
    public static final String FLAG_ON = "ON";

	public static final String FILTER_FUN_CODE = "funcCode";
	public static final String INSTALLMENT_AMT = "installmentAmt";
	public static final String SEQ_NO = "seqNo";
	public static final String TENURES = "tenure";
	public static final String ELIGIBLE_INSTALLMENT_PLAN_TEMPLATE_NAME = "eligible-installment-plan.ftl";
	public static final String PAGE_NUMBER = "0001";
	public static final String ELIGIBLE_TRANSACTION = "eligible-plans";
	public static final String OTHER_FEE = "OTHER_FEE";
	public static final String REWARD_POINT_REQUIRED = "rewardpointrequired";
   // Validate Credit Card Limit Increase
    public static final String FILTER_CARD_LIMIT = "validateLimit";
    public static final String EXISITING_CARD_LIMIT = "ExistingCrLimit";
    public static final String MAXIMUM_CARD_LIMIT = "MaximumCrLimit";

    /**
     * PinChange & Card Activation constants
     */
    public static final String[] CARDS_NOT_AVAILABLE_REDIRECT_SS = {"-1","10004","11111","20023","21003","10006","11111","10005","10007","80604","80611","99999"};    // Post Login Pin Reset
 	
    /**
     * Operation Names
     */
    public static final String OPERATION_CC_PINSET = "CCPINSET";
 	public static final String OPERATION_CC_ACTIVATION = "CCACTV";
 	public static final String OPERATION_CC_PINACTIV = "CCPINACTV";
 	public static final String OPERATION_CC_SMSACTV = "CCSMSACTV";


   // Added for time zone based on countries
 	public static final String NG_TIMEZONEID = "Africa/Lagos";
 	public static final String AE_TIMEZONEID = "Asia/Dubai";
 	public static final String KE_TIMEZONEID = "Africa/Nairobi";
 	public static final String GH_TIMEZONEID = "Africa/Accra";
 	public static final String BW_TIMEZONEID = "Africa/Gaborone";
 	public static final String ZM_TIMEZONEID = "Africa/Harare";
 	public static final String HK_TIMEZONEID = "Asia/Hong_Kong";
 	public static final String SG_TIMEZONEID = "Asia/Singapore";
 	public static final String IN_TIMEZONEID = "Asia/Kolkata";
 	public static final String VN_TIMEZONEID = "Asia/Ho_Chi_Minh";
 	public static final String MY_TIMEZONEID = "Asia/Kuala_Lumpur";
 	public static final String CN_TIMEZONEID = "Asia/Shanghai";
 	
 	// UAAS service constants 
 	public static final String UAAS_TXN_TIME_STAMP_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
 	public static final String UAAS_TXN_DATE_FORMAT = "yyyy-MM-dd";
 	public static final String UAAS_TXN_TIME_FORMAT = "HH:mm:ss.SSS";
 	public static final String BEAN_ID_UAAS_PROPERTY = "uaasProperties{0}";
 	
 	//Receipt Number Service Code
 	public static final String PINSET_RECEIPT_SERVICE_CODE = "003";
 	
 	// PinSet audit info constants
 	public static final String CARD = "Card";
 	public static final String EMBOSSED_NAME = "EmbossedName";
 	public static final String CARD_TYPE = "CardType";
 	public static final String CREDIT = "CREDIT";
 	public static final String RECEIPT_NUMBER = "ReceiptNumber";
 	public static final String ERROR_CODE = "Errorcode";
 	public static final String ERROR_MESSAGE = "ErrorMessage";
 	public static final String CHANNEL_FLAG = "ChannelFlag";
 	public static final String DATE_TIME = "DateTime";
 	public static final String AUDIT_SUCCESS = "SUCCESS";
 	public static final String AUDIT_FAILURE = "FAIL";
 	public static final String CARD_ACTIVATION_STATUS = "CardActivationStatus";
 	public static final String COUNTRY_CODE = "countryCode";
 	
 	
 	public static final String CCMS_COUNTRY_LIST = "SG,MY,IN,HK";

 	public static final String ENG_LANG_CODE = "en";

 	public static final String SERVICE_TIMEOUT = "10000";
 	
 	public static final String CONTACT_TYPE_EMAIL = "E";
 	
 	public static final String UAAS_SUCCESS_CODE = "100";
    public static final String DEFAULT_CHANNEL = "IBNK";
    public static final String ERROR = "Error";
    
    // Beans
 	public static final String BEAN_ID_NOTIFY_CONFIG = "getNotifyConfig{0}";

 	// Notification Constants
 	public static final String NOTIFY_TYPE_SMS = "SMS";
 	public static final String NOTIFY_TYPE_EMAIL = "EMAIL";
 	public static final String NOTIFY_TYPE_INBOX = "INBOX";
 	public static final String MSG_FROM = "SCB Bank";
 	public static final String MBNK_CHANNEL_ID = "MBNK";
 	public static final String TASKID = "TASKID";

 	// Language
 	public static final String LANGUAGE_ENG = "ENG";

 	// Utility constants
 	public static final String NEW_LINE = "\n";
 	public static final String FILTER_CCCONTACT_USING_CC = "cardContactUsingCardNum";
 	public static final String FILTER_CONTACT_TYPE_SPEC = "contactTypeDesc";
 	public static final String FILTER_CONTACT_CLASSIFY_SPEC = "contactClassification";
 	
 	public static final String CONTACT_TYPE_MOBILE_DESC = "Mobile";
 	public static final String CONTACT_TYPE_EMAIL_DESC = "Email";
 	
 	public static final String IVR_CHANNEL_ID = "IVR";
 	
 	public static final String CUSTOMER_NAME = "customerName";
 	public static final String CARD_NUMBER = "cardnumber";
 	public static final String LAST_FOUR_DIGIT_CARD_NUMBER = "lastFourCardDigits";
 	public static final String RECEIPT_ID = "receiptId";
 	public static final String DATE = "date";
 	public static final String EMAIL_HEADER_DATE_FARMAT = "MMMMM dd, yyyy hh:mm:ss a";
 	public static final String TODAYS_DATE = "todaysDate";
 	public static final String MESSAGE_TEMPLATE_DATE_FORMAT = "DD-MMM-YYYY";
	public static final String TXN_INFO_DATE_FORMAT= "txnInfoDateFormate";
	public static final String MESSAGE_TEMPLATE_DATE_FORMAT_INFO= "messageTemplateDateFormate";
	public static final String EMAIL_HEADER_DATE_FORMAT_INFO= "emailHeaderDateFormate";
 	
 	
 	
}
