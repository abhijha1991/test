package com.sc.csl.retail.creditcard.dto;

import lombok.Data;

@Data
public class CardInfo {

    private String cardType;
    private String encCardPin;
    private String keyIndex;
    private String cardSequenceNo;
    private String encCardInfo;
    private String txnRefNo;
    private String cardActivationFlag;
    
}
