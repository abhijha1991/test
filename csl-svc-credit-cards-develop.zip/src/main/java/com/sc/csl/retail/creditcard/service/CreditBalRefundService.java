package com.sc.csl.retail.creditcard.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditBalRefundProperties;
import com.sc.csl.retail.creditcard.dto.BusinessRuleAlert;
import com.sc.csl.retail.creditcard.dto.BusinessRuleAlertType;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * @author 1523165
 * @since Jul 21, 2017
 */
@Slf4j
@Setter
@Service
public class CreditBalRefundService {

    @Autowired
    private CSLRequestContext cslRequestContext;
    @Autowired
    private CreditCardService creditCardService;
    @Autowired
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
    @Autowired
    private CardUtil cardUtil;
    @Autowired
    ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
    boolean valideFromCardsFound = false;

    /**
     * Method validates all accounts for a relID and validates whether the account is eligible for credit balance refund
     * request.
     * 
     * @param creditCardList
     *            - List of CreditCards.
     * @param creditCardVO
     *            - card VO
     * @return eligibleCreditbalRefundCards - eligible cards for CBR request.
     */
    public List<CreditCardDto> validateCreditBalRefundEligibility(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCardList = null;
        List<CreditCardDto> eligibleCreditbalRefundCards = null;
        List<CreditCardDto> eligibleFromCards = null;
        List<CreditCardDto> eligibleToCards = null;
        CreditBalRefundProperties cbrProperties = null;
        BigDecimal totalExcessAmount = BigDecimal.ZERO;
        CreditCardDto ccAlertDto = null;
        creditCardList = creditCardService.getAllCreditCards(creditCardVO);

        log.debug("[Customer ID: " + cslRequestContext.getRelId() + "] [Country: " + cslRequestContext.getCountry()
                + "] [No of CreditCards: " + creditCardList.size() + "]");
        eligibleCreditbalRefundCards = new ArrayList<CreditCardDto>();
        eligibleFromCards = new ArrayList<CreditCardDto>();
        eligibleToCards = new ArrayList<CreditCardDto>();

        cbrProperties = getCbrPropertiesBean();

        for (CreditCardDto creditCardDto : creditCardList) {

            creditCardVO.setCardNo(creditCardDto.getCardNum());

            /*creditCardDto = getCardDetailsAndDelinquency(creditCardVO, creditCardDto, eligibleFromCards,
                    eligibleToCards, cbrProperties);*/

            totalExcessAmount = getExcessAmountAndCardEligibility(creditCardDto, eligibleFromCards, eligibleToCards,
                    cbrProperties, totalExcessAmount, creditCardVO);

        }
        // Duplicate CBR Request check for From-Cards :
        duplicateCBRRequestCheck(eligibleFromCards, cbrProperties);

        eligibleCreditbalRefundCards.addAll(eligibleFromCards);
        eligibleCreditbalRefundCards.addAll(eligibleToCards);
        log.debug("[Customer ID: " + cslRequestContext.getRelId() + "] [Country: " + cslRequestContext.getCountry()
                + "] [No of CreditCards: " + creditCardList.size()
                + "] [No of credit balance refund From-CreditCards: " + eligibleFromCards.size()
                + "] [No of credit balance refund To-CreditCards: " + eligibleToCards.size()
                + "] [No of credit balance refund CreditCards: " + eligibleCreditbalRefundCards.size() + "]");

        // If Customer does not have any excess amount to refund:
        if (totalExcessAmount.compareTo(BigDecimal.ZERO) != 1 && eligibleToCards.size() > 0) {
            eligibleCreditbalRefundCards = new ArrayList<CreditCardDto>();
            ccAlertDto = new CreditCardDto();
            ccAlertDto.setCardID("ALERT_NO_EXCESS_AMOUNT_CARD");
            ccAlertDto.addAlert(new BusinessRuleAlert(BusinessRuleAlertType.ERROR, null, CardUtil
                    .formatMessage(cbrProperties.getAlertMessage(CardConstant.ALERT_NO_EXCESS_AMOUNT_CARD,
                            cslRequestContext.getLanguage()))));
            ccAlertDto.setEligibleForCreditBalRefund(CardConstant.FLAG_YES);
            eligibleCreditbalRefundCards.add(ccAlertDto);
            return eligibleCreditbalRefundCards;
        }
        // If No Valid From-Cards found:
        if (!valideFromCardsFound) {
            eligibleCreditbalRefundCards = new ArrayList<CreditCardDto>();
            ccAlertDto = new CreditCardDto();
            ccAlertDto.setCardID("ALERT_NO_VALID_CARDS_FOUND");
            ccAlertDto.addAlert(new BusinessRuleAlert(BusinessRuleAlertType.ERROR, null, CardUtil
                    .formatMessage(cbrProperties.getAlertMessage(CardConstant.ALERT_NO_VALID_CARDS_FOUND,
                            cslRequestContext.getLanguage()))));
            ccAlertDto.setEligibleForCreditBalRefund(CardConstant.FLAG_YES);

            eligibleCreditbalRefundCards.add(ccAlertDto);
            return eligibleCreditbalRefundCards;
        }
        return eligibleCreditbalRefundCards;
    }

    /**
     * Method returns Credit Card data validating the rules for Credit Balance Refund for requested Credit card.
     * 
     * @param creditCardVO
     *            - CreditCardVO.
     * @param cardNum
     *            - String
     * @return ccgetDetailsDto - credit card data for CBR request.
     */
    public CreditCardDto validateOneCardCreditBalRefund(CreditCardVO creditCardVO, String cardNum) {
        List<CreditCardDto> creditCardList = null;
        CreditCardDto ccgetDetailsDto = null;
        BigDecimal totalExcessAmount = BigDecimal.ZERO;
        CreditBalRefundProperties cbrProperties = null;
        List<CreditCardDto> eligibleFromCards = null;
        List<CreditCardDto> eligibleToCards = null;

        creditCardList = creditCardService.getAllCreditCards(creditCardVO);

        eligibleFromCards = new ArrayList<CreditCardDto>();
        eligibleToCards = new ArrayList<CreditCardDto>();
        cbrProperties = getCbrPropertiesBean();

        for (CreditCardDto creditCardDto : creditCardList) {
            if (creditCardDto.getCardNum().equals(cardNum)) {

                /*ccgetDetailsDto = getCardDetailsAndDelinquency(creditCardVO, creditCardDto, eligibleFromCards,
                        eligibleToCards, cbrProperties);*/
                totalExcessAmount = getExcessAmountAndCardEligibility(creditCardDto, eligibleFromCards,
                        eligibleToCards, cbrProperties, totalExcessAmount, creditCardVO);
                ccgetDetailsDto = creditCardDto;
                break;
            }
        }
        return ccgetDetailsDto;
    }

    /**
     * Method validates whether the card is eligible for to-card of Credit balance refund(CBR) request.
     * 
     * @param creditCardDto
     *            - card entity.
     * @param cbrProperties
     *            - input parameters from YAML file.
     * @return boolean - eligibility.
     */
    public boolean isValidFromCardForCreditBalRefund(CreditCardDto creditCardDto,
            CreditBalRefundProperties cbrProperties, CreditCardVO creditCardVO) {
        log.info("[ From card Eligibility Validation Starts. Card Number :{} ]", creditCardDto.getCardNum());
        CreditCardDto ccgetDelinquencyHistoryDto = new CreditCardDto();
        // First Digit of AccountNumber Validation:
        if (!CardUtil.isValueInList(cbrProperties.getEligibleFromCardFirstDigitOfAccNumber(), creditCardDto
                .getCardNum().substring(0, 1), true)) {
            log.info("[ First Digit of AccountNumber Validation failed : EligibleFromCardFirstDigitOfAccNumber-{}",
                    cbrProperties.getEligibleFromCardFirstDigitOfAccNumber());
            return false;
        }
        // CardHolder Status Validation:
        if (CardUtil.isValueInList(cbrProperties.getIneligibleFromCardCardHolderStatus(),
                creditCardDto.getCardStatus(), false)) {
            log.info("[ CardHolder Status Validation: Card Status-{} IneligibleFromCardCardHolderStatus-{}",
                    creditCardDto.getCardStatus(), cbrProperties.getIneligibleFromCardCardHolderStatus());
            return false;
        }
        // In-Eligible Card BlockCode Validation:
        if (CardUtil.isValueInList(cbrProperties.getIneligibleFromCardBlockCode(), creditCardDto.getBlockCode(), false)) {

            // In-Eligible Customer BlockCode Validation:
            if (CardUtil.isValueInList(cbrProperties.getIneligibleFromCardCustomerBlockCode(),
                    creditCardDto.getCustBlockCode(), false)) {
                log.info(
                        "[ In-Eligible Customer BlockCode Validation failed: cust BlockCode -{} IneligibleFromCardCustomerBlockCode-{} ]",
                        creditCardDto.getCustBlockCode(), cbrProperties.getIneligibleFromCardCustomerBlockCode());
                return false;
            }
        }
        // Eligible Card and Customer BlockCode Validation:
        if (!CardUtil.isValueInList(cbrProperties.getEligibleFromCardBlockCode(), creditCardDto.getBlockCode(), true)) {

            // Eligible Customer BlockCode Validation:
            if (!CardUtil.isValueInList(cbrProperties.getEligibleFromCardCustomerBlockCode(),
                    creditCardDto.getCustBlockCode(), true)) {
                log.info(
                        "[ Eligible Customer BlockCode Validation failed: cust BlockCode -{} EligibleFromCardCustomerBlockCode-{} ]",
                        creditCardDto.getCustBlockCode(), cbrProperties.getEligibleFromCardCustomerBlockCode());
                return false;
            }
        }
        // DelinquencyHistory Validation:
        if (CardConstant.FLAG_YES.equals(cbrProperties.getDelinquencyCheckApplicable())) {
            log.info("[ getDelinquencyHistory service Inquiry Starts..]");
            ccgetDelinquencyHistoryDto = creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO);
            creditCardDto.setDelinquencyAmount(ccgetDelinquencyHistoryDto.getDelinquencyAmount());// delinquency amount
            if (new BigDecimal(creditCardDto.getDelinquencyAmount()).compareTo(BigDecimal.ZERO) == 1){
                log.info("[ DelinquencyHistory Validation failed: DelinquencyAmount{} ]",
                        creditCardDto.getDelinquencyAmount());
                return false;
            }
        }
        creditCardDto.setSpecialBlockCodes(cbrProperties.getSpecialBlockCodes());
        creditCardDto.setBalanceRefundFlag(CardConstant.FLAG_CBR_DR);
        log.info("[ From card Eligibility Validation Ends. Card Number :{} ]", creditCardDto.getCardNum());
        return true;
    }

    /**
     * Method validates whether the card is eligible for from-card of Credit balance refund(CBR) request.
     * 
     * @param creditCardDto
     *            - card entity.
     * @param cbrProperties
     *            - input parameters from YAML file.
     * @return boolean - eligibility.
     */
    public boolean isValidToCardForCreditBalRefund(CreditCardDto creditCardDto,
            CreditBalRefundProperties cbrProperties, CreditCardVO creditCardVO) {
        log.info("[ To card Eligibility Validation Starts. Card Number :{} ]", creditCardDto.getCardNum());
        boolean isInvalidBlockCodeFlag = false;
        CreditCardDto ccgetDelinquencyHistoryDto = new CreditCardDto();
        // OutStandingBalance Availability Validation :

        // AccountNumber Validation:
        if (!CardUtil.isValueInList(cbrProperties.getEligibleToCardFirstDigitOfAccNumber(), creditCardDto.getCardNum()
                .substring(0, 1), true)) {
            log.info("[ First Digit of AccountNumber Validation failed : EligibleToCardFirstDigitOfAccNumber-{}",
                    cbrProperties.getEligibleToCardFirstDigitOfAccNumber());
            return false;
        }
        // CardHolder Status Validation:
        if (!CardUtil.isValueInList(cbrProperties.getEligibleToCardCardHolderStatus(), creditCardDto.getCardStatus(),
                true)) {
            log.info("[ CardHolder Status Validation: Card Status-{} EligibleToCardCardHolderStatus-{}",
                    creditCardDto.getCardStatus(), cbrProperties.getEligibleToCardCardHolderStatus());
            return false;
        }
        // In-eligible Card BlockCode Validation:
        if (CardUtil.isValueInList(cbrProperties.getIneligibleToCardBlockCode(), creditCardDto.getBlockCode(), false)) {
            // In-eligible Customer BlockCode Validation:
            if (CardUtil.isValueInList(cbrProperties.getIneligibleToCardCustomerBlockCode(),
                    creditCardDto.getCustBlockCode(), false)) {
                // return false;
                isInvalidBlockCodeFlag = true;
            }
        }
        // Eligible Card BlockCode Validation:
        if (!CardUtil.isValueInList(cbrProperties.getEligibleToCardBlockCode(), creditCardDto.getBlockCode(), true)) {

            // Eligible Customer BlockCode Validation:
            if (!CardUtil.isValueInList(cbrProperties.getEligibleToCardCustomerBlockCode(),
                    creditCardDto.getCustBlockCode(), true)) {
                // return false;
                isInvalidBlockCodeFlag = true;
            }
        }
        if (CardConstant.FLAG_YES.equals(cbrProperties.getDelinquencyCheckApplicable())) {
            log.info("[ getDelinquencyHistory service Inquiry Starts..]");
            ccgetDelinquencyHistoryDto = creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO);
            creditCardDto.setDelinquencyAmount(ccgetDelinquencyHistoryDto.getDelinquencyAmount());// delinquency amount
        }
        // DelinquencyHistory Validation:
        if (!CardUtil.isEmptyOrNull(creditCardDto.getDelinquencyAmount())
                && new BigDecimal(creditCardDto.getDelinquencyAmount()).compareTo(BigDecimal.ZERO) > 0) {
            creditCardDto.setDelinquencyFlag(CardConstant.CONS_Y);
        } else {
            creditCardDto.setDelinquencyFlag(CardConstant.CONS_N);
        }
        // Logic for To card validation based on current balance/Block code and Delinquency flag
        // (Valid Block Code and Current Balance>0)
        // OR
        // (card in Delinquency Bucket and Current Balance>0)
        if (new BigDecimal(creditCardDto.getCurrentBalance()).compareTo(BigDecimal.ZERO) < 1) {
            log.info("[ CurrentBalance Validation failed: currentBalance{} ]", creditCardDto.getCurrentBalance());
            return false;
        }
        if (CardConstant.FLAG_YES.equals(cbrProperties.getNoBlockCodeCheckForToCard())) {
            isInvalidBlockCodeFlag = true;
        }
        if (isInvalidBlockCodeFlag && CardConstant.CONS_N.equalsIgnoreCase(creditCardDto.getDelinquencyFlag())) {
            log.info("[ Delinquency Validation failed: DelinquencyFlag{} ]", creditCardDto.getDelinquencyFlag());
            return false;
        }

        creditCardDto.setBalanceRefundFlag(CardConstant.FLAG_CBR_CR);
        log.info("[ To card Eligibility Validation Ends. Card Number :{} ]", creditCardDto.getCardNum());
        return true;
    }

    /**
     * Method validates whether the credit card has the excess amount to refund.
     * 
     * @param creditCardDto
     *            - card entity.
     * @param cbrProperties
     *            - input parameters from YAML file.
     * @return boolean - eligibility.
     */
    public boolean excessAmountValidation(CreditCardDto creditCardDto, CreditBalRefundProperties cbrProperties) {
        boolean validcard = false;
        boolean isAmountCalulated = false;
        BigDecimal excessAmount = BigDecimal.ZERO;
        creditCardDto.setExcessAmount(excessAmount.toPlainString());
        switch (cbrProperties.getExcessAmountCalculationLogic()) {
        case CardConstant.EXCESS_AMT_CALC_LOGIC_CCMS: // excessAmount = avlblLimit - creditLimit.
            excessAmount = excessAmount.add(new BigDecimal(creditCardDto.getAvlblLimit())).subtract(
                    new BigDecimal(creditCardDto.getCreditLimit()));
            // creditCardDto.setExcessAmount(excessAmount.toPlainString());
            creditCardDto.setExcessAmount(excessAmount.setScale(2, BigDecimal.ROUND_HALF_EVEN).toPlainString());
            isAmountCalulated = true;
            break;
        case CardConstant.EXCESS_AMT_CALC_LOGIC_C400: // excessAmount = creentBalance.
            excessAmount = excessAmount.add(new BigDecimal(creditCardDto.getCurrentBalance()));
            // creditCardDto.setExcessAmount(excessAmount.toPlainString());
            creditCardDto.setExcessAmount(excessAmount.setScale(2, BigDecimal.ROUND_HALF_EVEN).toPlainString());
            isAmountCalulated = true;
            break;
        default:
            break;
        }
        if (isAmountCalulated) {
            // Excess balance availability Check for a From-card : Eligibility :-> ExcessBalance>0
            if (excessAmount.compareTo(BigDecimal.ZERO) == 1) {
                validcard = true;
                creditCardDto.setBalanceRefundFlag(CardConstant.FLAG_CBR_DR);
                // Minimum amount availability Check
                if (!CardUtil.isEmptyOrNull(cbrProperties.getEligibleMinimumRefundAmount())
                        && excessAmount.compareTo(new BigDecimal(cbrProperties.getEligibleMinimumRefundAmount())) != 1) {
                    creditCardDto.addAlert(new BusinessRuleAlert(BusinessRuleAlertType.ERROR, null, CardUtil
                            .formatMessage(cbrProperties.getAlertMessage(
                                    CardConstant.MIN_ELIGIBLE_REFUND_AMOUNT_NOT_AVAILABLE,
                                    cslRequestContext.getLanguage()), creditCardDto.getCurrencyCode(), cbrProperties
                                    .getEligibleMinimumRefundAmount())));
                }
            }
            // Excess balance availability Check for a To-card : Eligibility :-> ExcessBalance<=0:
            else {
                validcard = true;
                creditCardDto.setBalanceRefundFlag(CardConstant.FLAG_CBR_CR);
            }
        }
        log.info("[ excessAmountValidation : excessAmount on the card {}]", creditCardDto.getCardNum() + " - "
                + creditCardDto.getExcessAmount());
        return validcard;
    }

    /**
     * Method returns the bean of CreditBalRefundProperties from spring applicationContext
     * 
     * @return CreditBalRefundProperties - bean.
     */
    private CreditBalRefundProperties getCbrPropertiesBean() {
        return (CreditBalRefundProperties) cardUtil.getCreditCardPropertiesBean().getCreditBalRefundProperties();
    }

    /**
     * Method retrieves the values from CreditCard Enquire Gateway and retrieve the value for Delinquency History.
     * 
     * @param creditCardDto
     *            - card entity.
     * @param eligibleFromCards
     *            - List of CreditCardDto.
     * @param eligibleToCards
     *            - List of CreditCardDto.
     * @param cbrProperties
     *            - input parameters from YAML file.
     * @return CreditCardDto - creditCardDto.
     */
    /*private CreditCardDto getCardDetailsAndDelinquency(CreditCardVO creditCardVO, CreditCardDto creditCardDto,
            List<CreditCardDto> eligibleFromCards, List<CreditCardDto> eligibleToCards,
            CreditBalRefundProperties cbrProperties) {

        CreditCardDto ccgetDetailsDto = new CreditCardDto();
        CreditCardDto ccgetDelinquencyHistoryDto = new CreditCardDto();

        ccgetDetailsDto = creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO);

        creditCardDto.setCardStatus(ccgetDetailsDto.getCardStatus());// For CardHolder Status
        creditCardDto.setDesc(ccgetDetailsDto.getDesc());// For Card Category
        creditCardDto.setProd(ccgetDetailsDto.getProd());// For productCode
        creditCardDto.setCardType(ccgetDetailsDto.getCardType());// For CardType

        if (CardConstant.FLAG_YES.equals(cbrProperties.getDelinquencyCheckApplicable())) {
            ccgetDelinquencyHistoryDto = creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO);
            creditCardDto.setDelinquencyAmount(ccgetDelinquencyHistoryDto.getDelinquencyAmount());// delinquency amount
        }

        return creditCardDto;
    }*/

    /**
     * Method validates whether the credit card has the excess amount If excess Amount is available on the card it is
     * eligible for Transfer the refund(From Card List) otherwise the card is eligible for taking the refund(To Card
     * list).
     * 
     * @param creditCardDto
     *            - card entity.
     * @param eligibleFromCards
     *            - List of CreditCardDto.
     * @param eligibleToCards
     *            - List of CreditCardDto.
     * @param cbrProperties
     *            - input parameters from YAML file.
     * @param totalExcessAmount
     *            - BigDecimal
     * @return BigDecimal - totalExcessAmount.
     */
    private BigDecimal getExcessAmountAndCardEligibility(CreditCardDto creditCardDto,
            List<CreditCardDto> eligibleFromCards, List<CreditCardDto> eligibleToCards,
            CreditBalRefundProperties cbrProperties, BigDecimal totalExcessAmount, CreditCardVO creditCardVO) {
        if (excessAmountValidation(creditCardDto, cbrProperties)) {
            switch (creditCardDto.getBalanceRefundFlag()) {
            case CardConstant.FLAG_CBR_DR:
                totalExcessAmount = totalExcessAmount.add(new BigDecimal(creditCardDto.getExcessAmount()));
                if (isValidFromCardForCreditBalRefund(creditCardDto, cbrProperties, creditCardVO)) {
                    creditCardDto.setEligibleForCreditBalRefund(CardConstant.FLAG_YES);
                    eligibleFromCards.add(creditCardDto);
                    valideFromCardsFound = true;
                }
                break;
            case CardConstant.FLAG_CBR_CR:
                if (isValidToCardForCreditBalRefund(creditCardDto, cbrProperties, creditCardVO)) {
                    creditCardDto.setEligibleForCreditBalRefund(CardConstant.FLAG_YES);
                    eligibleToCards.add(creditCardDto);
                }
                break;
            }
        }
        return totalExcessAmount;
    }

    /**
     * This method will check for duplicate CBR request and add the alert message.
     * 
     * @param cardList
     * @param cbrProperties
     */
    @SuppressWarnings("unchecked")
    private void duplicateCBRRequestCheck(List<CreditCardDto> cardList, CreditBalRefundProperties cbrProperties) {
        List<ServiceRequest> serviceRequestList = null;
        if (CollectionUtils.isNotEmpty(cardList)
                && CardConstant.FLAG_YES.equals(cbrProperties.getDuplicateCBRCheckApplicable())) {
            serviceRequestList = serviceRequestJsonApiGateway.enquireStatus(cslRequestContext.getCountry(),
                    cslRequestContext.getRelId(), cslRequestContext.getChannel(),null);
            for (CreditCardDto ccdto : cardList) {
                mainLoop: for (ServiceRequest serviceRequestObj : serviceRequestList) {
                    String subServiceType = serviceRequestObj.getServiceType();
                    if ("Credit Balance Refund Request".equalsIgnoreCase(subServiceType)) {
                        List<LinkedHashMap<String, String>> info = (List<LinkedHashMap<String, String>>) serviceRequestObj
                                .getPayload().get("products");
                        for (LinkedHashMap<String, String> detMap : info) {
                            String cardNumber = detMap.get("accountNumber");
                            String status = detMap.get("status");
                            if (cardNumber.equals(ccdto.getCardNum())
                                    && (StringUtils.isEmpty(status) || "PROCESSING".equalsIgnoreCase(status))) {
                                log.info("[Duplicate CBR Request found for CardNumber : {} ]", cardNumber);
                                ccdto.addAlert(new BusinessRuleAlert(BusinessRuleAlertType.ERROR,
                                        "ALERT_DUPLICATE_CBR_REQUEST", cbrProperties.getAlertMessage(
                                                CardConstant.ALERT_DUPLICATE_CBR_REQUEST,
                                                cslRequestContext.getLanguage())));
                                break mainLoop;
                            }
                        }
                    }
                }

            }
        }

    }
}
