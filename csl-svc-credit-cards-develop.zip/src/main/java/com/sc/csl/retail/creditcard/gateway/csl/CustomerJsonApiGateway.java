package com.sc.csl.retail.creditcard.gateway.csl;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.CSLKatharsisClientException;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.creditcard.dto.customer.CreditCardContact;
import com.sc.csl.retail.creditcard.dto.customer.Customer;
import com.sc.csl.retail.creditcard.dto.customer.CustomerContact;
import com.sc.csl.retail.creditcard.helper.CardConstant;

import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.RelationshipRepositoryV2;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ConfigurationProperties(prefix = "csl.customer.gateway")
public class CustomerJsonApiGateway extends CSLJsonApiGateway {

	/**
	 * 
	 * @param relId
	 * @return
	 */
	public List<CreditCardContact> getCustomerCCContact(String relId) {
		RelationshipRepositoryV2<Customer, String, CreditCardContact, String> customerContactRepo = getKatharsisClient()
				.getRepositoryForType(Customer.class, CreditCardContact.class);
		List<CreditCardContact> ccContacts = customerContactRepo.findManyTargets(relId, "cccontacts", null);
		return ccContacts;
	}

	/**
	 * 
	 * @param cardNumber
	 * @return
	 */
	public List<CreditCardContact> getCreditContactWithCardNumber(String cardNumber) {
		ResourceRepositoryV2<CreditCardContact, String> creditCardContactRepo = getKatharsisClient()
				.getRepositoryForType(CreditCardContact.class);
		QuerySpec creditCardContactSpec = new QuerySpec(CreditCardContact.class);
		creditCardContactSpec.addFilter(
				new FilterSpec(Arrays.asList(CardConstant.FILTER_CCCONTACT_USING_CC), FilterOperator.EQ, cardNumber));
		List<CreditCardContact> ccContacts = creditCardContactRepo.findAll(creditCardContactSpec);
		return ccContacts;
	}

	/**
	 * 
	 * @return
	 */
	public List<CustomerContact> getCustomerContact() {
		List<CustomerContact> customerContacts = null;
		CSLKatharsisClient katharsisClient = getKatharsisClient();
		try {
			ResourceRepositoryV2<CustomerContact, String> customerContactRepo = katharsisClient
					.getRepositoryForType(CustomerContact.class);
			QuerySpec querySpec = new QuerySpec(CustomerContact.class);
			log.info("Customer Contact query spec::" + querySpec.toString());
			customerContacts = customerContactRepo.findAll(querySpec);
			log.info("Customer contact Details " + customerContacts);
		} catch (CSLKatharsisClientException ex) {
			log.error(ex.getMessage());
		} catch (Exception ex) {
			log.error(ex.getMessage());
		}
		return customerContacts;
	}

}