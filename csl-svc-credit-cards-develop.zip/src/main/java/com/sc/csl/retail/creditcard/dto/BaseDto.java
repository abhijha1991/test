package com.sc.csl.retail.creditcard.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@Getter
@Setter
public class BaseDto implements Serializable {

    private static final long serialVersionUID = -9212478054904426781L;
    @JsonIgnore
    private String country;
    @JsonIgnore
    private String channel;
    @JsonProperty("rel-id")
    private String relId;
    @JsonProperty("customer-id")
    private String customerId;
    @JsonProperty("customer-type")
    private String customerType;
    @JsonProperty("error-code")
    private String errorCode = null;
    @JsonProperty("error-description")
    private String errorDescription = null;
    // POSTING RELATED FIELDS
    @JsonProperty("operation-name")
    private String operationName = null;
    private String serviceType = null;
    private String targetProcessID = null;
    private String status = null;
    private String createdBy = null;
    private String updatedBy = null;
    private CustomerDto customerDetails;
    @JsonIgnore
    private String startPageRefNum;
}
