package com.sc.csl.retail.creditcard.service.cccancel;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelValidationProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.BaseService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * @author 1452875
 * @since Dec 4, 2017
 */
public class CreditCardCancelValidator extends BaseService {

    @Autowired
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;

    public boolean isValidCreditCard(CreditCardVO creditCardVO, CreditCardDto creditCardDto,
            CreditCardCancelProperties ccCancelProperties) {
        CreditCardCancelValidationProperties ccCancelValidationProperties = ccCancelProperties.getValidation();
        if (!isEligibleByGeneralDetail(creditCardVO, creditCardDto, ccCancelProperties)) {
            return false;
        }
        if (!isEligibleByFinancialDetail(creditCardVO, creditCardDto, ccCancelProperties)) {
            return false;
        }
        // Eligible for display on screen, validate whether eligible for cancellation (grey out ineligible cards)
        validateEligiblility(creditCardDto, ccCancelValidationProperties);
        return true;
    }

    protected boolean isEligibleByGeneralDetail(CreditCardVO creditCardVO, CreditCardDto creditCardDto,
            CreditCardCancelProperties ccCancelProperties) {
        CreditCardCancelValidationProperties ccCancelValidationProperties = ccCancelProperties.getValidation();
        // Credit Card Provider
        if (!isEligibleProvider(creditCardDto, ccCancelValidationProperties)) {
            return false;
        }
        // Card Block Code
        if (!CardUtil.isValueInList(ccCancelValidationProperties.getEligibleBlockCode(), creditCardDto.getBlockCode(),
                true)
                || CardUtil.isValueInList(ccCancelValidationProperties.getIneligibleBlockCode(),
                        creditCardDto.getBlockCode(), false)) {
            return false;
        }
        return true;
    }

    protected boolean isEligibleByFinancialDetail(CreditCardVO creditCardVO, CreditCardDto creditCardDto,
            CreditCardCancelProperties ccCancelProperties) {
        if (isValidationServiceEnabled(ccCancelProperties.getService(),
                CardConstant.PROP_SERVICE_CC_GET_FINANCIAL_DETAIL)) {
            CreditCardCancelValidationProperties ccCancelValidationProperties = ccCancelProperties.getValidation();

            // GET FINANCIAL DETAILS
            CreditCardVO creditCardFinDetailVO = new CreditCardVO();
            creditCardFinDetailVO.setCardNo(creditCardDto.getCardNum());
            creditCardFinDetailVO.setChannelId(creditCardVO.getChannelId());
            creditCardFinDetailVO.setCountryCode(creditCardVO.getCountryCode());

            CreditCardDto financialDetail = creditCardEnquiryV1SoapGateway
                    .getCreditCardFinancialDetails(creditCardFinDetailVO);
            creditCardDto.setCollateralCode(financialDetail.getCollateralCode());
            creditCardDto.setOutstandingBalance(financialDetail.getOutstandingBalance());
            creditCardDto.setOverrideCode(financialDetail.getOverrideCode());
            creditCardDto.setAgreementStatus(financialDetail.getAgreementStatus());

            // VALIDATION
            // Override Code
            if (CardUtil.isValueInList(ccCancelValidationProperties.getIneligibleOverrideCode(),
                    creditCardDto.getOverrideCode(), false)) {
                return false;
            }
            // Agreement Status
            if (CardUtil.isValueInList(ccCancelValidationProperties.getIneligibleAgreementStatus(), creditCardDto
                    .getAgreementStatus().toString(), true)) {
                return false;
            }
        }
        return true;
    }

    private boolean isEligibleProvider(CreditCardDto creditCardDto,
            CreditCardCancelValidationProperties ccCancelValidationProperties) {
        if (StringUtils.isBlank(ccCancelValidationProperties.getEligibleCreditCardServiceProvider())) {
            return true;
        }
        Pattern pattern = Pattern.compile(ccCancelValidationProperties.getEligibleCreditCardServiceProvider());
        Matcher matcher = pattern.matcher(creditCardDto.getCardNum());
        return matcher.matches();
    }

    private void validateEligiblility(CreditCardDto creditCardDto,
            CreditCardCancelValidationProperties ccCancelValidationProperties) {
        validateGeneralDetail(creditCardDto, ccCancelValidationProperties);
        validateFinancialDetail(creditCardDto, ccCancelValidationProperties);
    }

    protected void validateGeneralDetail(CreditCardDto creditCardDto,
            CreditCardCancelValidationProperties ccCancelValidationProperties) {
        // Do nothing. Country specific implementation
    }

    protected void validateFinancialDetail(CreditCardDto creditCardDto,
            CreditCardCancelValidationProperties ccCancelValidationProperties) {
        // Do nothing. Country specific implementation
    }
}
