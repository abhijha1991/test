package com.sc.csl.retail.creditcard.gateway.csl;

import io.katharsis.repository.ResourceRepositoryV2;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.security.SmsOtp;
import com.sc.csl.retail.creditcard.helper.CardUtil;

@Component
@ConfigurationProperties(prefix = "csl.security.gateway.sendOtp")
public class SmsOtpGateway extends CSLJsonApiGateway {

    @Autowired
    CSLRequestContext cslRequestContext;

    @Autowired
    CardUtil cardUtil;

    private static String MASK_MOBILE_REGEX = ".(?!.{0,2}$)";

    public SmsOtp sendOtp(String mobileNumber) {
        SmsOtp smsOtp = new SmsOtp();
        smsOtp.setMobile(mobileNumber);
        smsOtp.setMsgTemplate(getOtpMessageTemplate());
        ResourceRepositoryV2<SmsOtp, String> sendOtpRepo = getKatharsisClient().getRepositoryForType(SmsOtp.class);
        SmsOtp smsOtpResponse = sendOtpRepo.create(smsOtp);
        smsOtpResponse.setRelId(cslRequestContext.getRelId());
        smsOtpResponse.setMobile(maskMobileNumber(mobileNumber));
        return smsOtpResponse;
    }
    
    public SmsOtp sendOtp(String mobileNumber,String message) {
        SmsOtp smsOtp = new SmsOtp();
        smsOtp.setMobile(mobileNumber);
        smsOtp.setMsgTemplate(message);
        ResourceRepositoryV2<SmsOtp, String> sendOtpRepo = getKatharsisClient().getRepositoryForType(SmsOtp.class);
        SmsOtp smsOtpResponse = sendOtpRepo.create(smsOtp);
        smsOtpResponse.setRelId(cslRequestContext.getRelId());
        smsOtpResponse.setMobile(maskMobileNumber(mobileNumber));
        return smsOtpResponse;
    }

    String maskMobileNumber(final String mobileNumber) {
        return StringUtils.replaceAll(mobileNumber, MASK_MOBILE_REGEX, "x");
    }

    String getOtpMessageTemplate() {
        String messageTemplate = cardUtil.getCreditCardPropertiesBean().getOtpMsgTemplate();
        if (messageTemplate != null)
            return messageTemplate;
        throw new TechnicalException("OTP messageTemplate not configured for " + cslRequestContext.getCountry());
    }

}
