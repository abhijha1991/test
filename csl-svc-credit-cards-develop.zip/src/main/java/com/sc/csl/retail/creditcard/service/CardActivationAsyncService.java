package com.sc.csl.retail.creditcard.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CardActivationAsyncService {
	
	@Autowired
	private CreditCardV1SoapGateway creditCardV1SoapGateway;
	
	@Async("threadPoolTaskExecutor")
	public void processSMSActivation(CSLAsyncRequestContext context,CreditCardVO creditCardVO){
		creditCardV1SoapGateway.updateCardStatus(creditCardVO);
	}

}
