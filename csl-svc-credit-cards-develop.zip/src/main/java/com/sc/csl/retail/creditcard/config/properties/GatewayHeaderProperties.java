package com.sc.csl.retail.creditcard.config.properties;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import lombok.Data;

@Data
public class GatewayHeaderProperties {
	
	// header
	private String messageVersion;
	private String captureSystem;

	// pay load
	private String payLoadVersion;
	private String orgNum;
	private String entityType;
	private String sourceFlag;
	private String cardList;
	private String funcCode;
	private String recType;
	private String cardOrg;
	private String daysToFetch;
	private String subFuncCode;
	private String reasonCode;
	private String recTypeForSMSACT;
	private String funcCodeForSMSACT;

	public String toString() {
		return ReflectionToStringBuilder.toString(this,	ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
