package com.sc.csl.retail.creditcard.dto.customer;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiRelation;
import io.katharsis.resource.annotations.JsonApiResource;
import io.katharsis.resource.annotations.LookupIncludeBehavior;
import io.katharsis.resource.annotations.SerializeType;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.sc.csl.retail.creditcard.dto.BaseDto;

/**
 * @author 1481163
 * @since sep 10, 2017
 */
@ToString
@Setter
@Getter
@JsonApiResource(type = "customers")
public class Customer extends BaseDto {

    private static final long serialVersionUID = 1304704621386853756L;
    @JsonApiId
    private String relId = null;
    
    @JsonApiRelation(lookUp = LookupIncludeBehavior.AUTOMATICALLY_ALWAYS, serialize = SerializeType.LAZY, opposite = "customer")
    private List<CreditCardContact> cccontacts = new ArrayList<CreditCardContact>();
    
}
