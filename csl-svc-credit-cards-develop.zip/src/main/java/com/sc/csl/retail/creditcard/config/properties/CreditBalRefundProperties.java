/**
 * CreditBalRefundProperties.java / July 10, 2017 / CSL-SVC-CREDIT-CARDS-1.0.0
 */
package com.sc.csl.retail.creditcard.config.properties;

import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * CreditBalRefundProperties.java
 * 
 * <pre>
 * 
 * </pre>
 * 
 * @author 1523165
 * @since July 10, 2017
 * @version CSL-SVC-CREDIT-CARDS-1.0.0
 */
@ToString
@Getter
@Setter
public class CreditBalRefundProperties {

    private String eligibleFromCardFirstDigitOfAccNumber = null;
    private String eligibleToCardFirstDigitOfAccNumber = null;
    private String ineligibleFromCardFirstDigitOfAccNumber = null;
    private String ineligibleToCardFirstDigitOfAccNumber = null;

    private String eligibleFromCardBlockCode = null;
    private String eligibleToCardBlockCode = null;
    private String ineligibleFromCardBlockCode = null;
    private String ineligibleToCardBlockCode = null;
    private String ineligibleFromCardCustomerBlockCode = null;
    private String ineligibleToCardCustomerBlockCode = null;
    private String eligibleFromCardCustomerBlockCode = null;
    private String eligibleToCardCustomerBlockCode = null;

    private String eligibleFromCardCardHolderStatus = null;
    private String eligibleToCardCardHolderStatus = null;
    private String ineligibleFromCardCardHolderStatus = null;
    private String ineligibleToCardCardHolderStatus = null;
    
    private String specialBlockCodes = null;

    private String excessAmountCalculationLogic = null;

    private String delinquencyCheckApplicable = null;

    private String eligibleMinimumRefundAmount = null;

    private Map<String, String> alertMessages = null;
    
    private String noBlockCodeCheckForToCard = null;
    
    private String duplicateCBRCheckApplicable = null;

    /**
     * Returns alert message of a given key
     */
    public String getAlertMessage(String key, String language) {
        String alertMsg = this.alertMessages.get(CardUtil.formatMessage(key, language));
        return alertMsg;
    }

}
