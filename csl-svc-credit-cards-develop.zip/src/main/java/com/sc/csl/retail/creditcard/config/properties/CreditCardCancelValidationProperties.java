package com.sc.csl.retail.creditcard.config.properties;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 1554149
 * @since Sep 18, 2017
 */
@Getter
@Setter
public class CreditCardCancelValidationProperties extends BaseProperties {
    private String eligibleCreditCardServiceProvider = null;
    private String eligibleCreditCardStatusCode = null;
    private String eligibleBlockCode = null;
    private String ineligibleBlockCode = null;
    private String ineligibleOverrideCode = null;
    private String ineligibleCollateralCode = null;
    private String eligibleInstallmentStatusCode = null;
    private String ineligibleComboCardFlag = null;
    private String eligibleBalTransferAccountNumber = null;
    private String ineligibleBalTransferBlockCode = null;
    private String ineligibleSanctionedBlockCode = null;
    private String ineligibleReasonCode = null;
    private String ineligibleAgreementStatus = null;
}
