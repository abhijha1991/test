package com.sc.csl.retail.creditcard.config.properties;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 1554149
 * @since Sep 18, 2017
 */
@Getter
@Setter
public class CreditCardCancelProperties {
    private CreditCardCancelValidationProperties validation = null;
    private CreditCardCancelEnricherProperties enricher = null;
    private GatewayServiceNameProperties service = null;
}
