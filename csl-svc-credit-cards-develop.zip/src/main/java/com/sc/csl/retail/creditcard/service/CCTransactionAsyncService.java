package com.sc.csl.retail.creditcard.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.dto.Spv1ServiceRequestInfo;
import com.sc.csl.retail.creditcard.dto.TransactionAsyncDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestSPV1Gateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;

@Slf4j
@Service
public class CCTransactionAsyncService {

	@Autowired
	private CreditCardService creditCardService;
	
	@Autowired
	protected ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
	
	@Autowired
	private ServiceRequestSPV1Gateway statusEnquiryCEMSGateway;
	
	@Async("threadPoolTaskExecutor")
	public CompletableFuture<TransactionAsyncDto> getAsyncTransactionList(
			CreditCardVO creditcardvo, String requestType) {
		return CompletableFuture.completedFuture(getCreditCardTransactions(creditcardvo,requestType));
	}

	public TransactionAsyncDto getCreditCardTransactions(CreditCardVO creditcardvo,
			String requestType) {
		
		log.info("CCTransactionAsyncService getCreditCardTransactions Request Type : "+requestType);
		
		TransactionAsyncDto transactionAsyncDto = new TransactionAsyncDto();
		transactionAsyncDto.setRequestType(requestType);
		List<CreditCardTransactionDto> ccmsC400Transactions = null;
		//to get the transaction from CCMS / C400 system.
		try{
			ccmsC400Transactions = creditCardService
					.findCreditCardTransactions(creditcardvo);
		}
		//To Handle the business exceptions when there is no transaction available
		catch(BusinessException ex){
			ccmsC400Transactions=new ArrayList<CreditCardTransactionDto>();
			log.info("No Transactions found in CCMS System");
		}
		log.info("CCTransactionAsyncService getCreditCardTransactions ccmsC400Transactions : "+ccmsC400Transactions);
		transactionAsyncDto.setCcmsC400Transactions(ccmsC400Transactions);
		return transactionAsyncDto;
	}
	
	@Async("threadPoolTaskExecutor")
	public CompletableFuture<TransactionAsyncDto> getAsyncEopsCemsServiceReqList(
			CreditCardVO creditcardvo, String requestType, List<String> feeTypes) {
		return CompletableFuture.completedFuture(fetchServiceRequestFromEopsCems(creditcardvo, requestType, feeTypes));
	}
	
	/**
	 * This method returns Services Request from Eops and Cems system.
	 * 
	 * @param creditcardvo
	 * @param cardNumbersArray
	 * @param requestType
	 * @return
	 */
	public TransactionAsyncDto fetchServiceRequestFromEopsCems(CreditCardVO creditcardvo, String requestType, List<String> feeTypes) {
		
		log.info("CCTransactionAsyncService fetchServiceRequestFromEopsCems Request Type : "+requestType);
		TransactionAsyncDto transactionAsyncDto = new TransactionAsyncDto();
		transactionAsyncDto.setRequestType(requestType);
		Map<String, String> cardStatusMap = new HashMap<String,String>();
		
		if(transactionAsyncDto.getRequestType().equals(CardConstant.EOPS_SR)) {
			cardStatusMap = fetchServiceRequestFromEops(creditcardvo, feeTypes);
		}
		else if(transactionAsyncDto.getRequestType().equals(CardConstant.CEMS_SR)) {
			cardStatusMap = fetchServiceRequestFromCems(creditcardvo, feeTypes);
			
		}
			
		log.info("CCTransactionAsyncService fetchServiceRequestFromEopsCems cardStatusMap : "+cardStatusMap);
		if (cardStatusMap == null) cardStatusMap = new HashMap<String,String>(); 
		transactionAsyncDto.setEOpsCemsTransactions(cardStatusMap);
		return transactionAsyncDto;
		
	}
	
	/**
	 * This method pulls the Pending Services Request for a customer from Eops sytem.
	 * The result will be used to validate the duplication of the selected fee type [Customer id, Card No, Fee type, Status {Pending}].
	 * 
	 * @param creditcardvo
	 * @param cardNumbersArray
	 * @param feeTypes
	 * @return cardStatusMap
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> fetchServiceRequestFromEops(CreditCardVO creditcardvo, List<String> feeTypes) {
		
		log.info("[CCTransactionAsyncService fetchServiceRequestFromEops Entered...] [FeeType:"+"]"+creditcardvo.getFeeType());
		Map<String, String> cardStatusMap = new HashMap<String, String>();
		List<String> serviceTypes = new ArrayList<>();
        serviceTypes.add("Credit Card Fee Waiver");
		List<ServiceRequest> serviceReq = serviceRequestJsonApiGateway.enquireStatus(creditcardvo.getCountryCode(), creditcardvo.getRelId(),
				creditcardvo.getChannelId(),serviceTypes);
		if(!CardUtil.isEmptyOrNull(serviceReq)) {
			serviceReq.forEach(serviceRequestObj -> {
	            String subServiceType = serviceRequestObj.getServiceType();
	    		log.info("[CreditCardFeeWaiverService fetchServiceRequestFromEops ] [Service Type:"+subServiceType+"]" );
	            //if("Credit Card Fee Waiver Request".equalsIgnoreCase(subServiceType)){
	                  List<LinkedHashMap<String, String>> info = (List<LinkedHashMap<String, String>>) serviceRequestObj.getPayload().get("products");
	                  for (LinkedHashMap<String, String> detMap : info) {
	                         String cardNumber = detMap.get("accountNumber");
	                         //String feeTypeRsp = detMap.get("productType");
	                         String status = detMap.get("status");
	                         //if(CardUtil.isEmptyOrNull(status) && feeTypes.contains(feeTypeRsp)) {
	                         if(CardUtil.isEmptyOrNull(status)) {
	                                   cardStatusMap.put(cardNumber, "PENDING");
	                         }
	                  }
	            //}
	
			});
		}
		log.info("[CCTransactionAsyncService fetchServiceRequestFromEops Status Details["+ cardStatusMap +"]");
		log.info("[CCTransactionAsyncService fetchServiceRequestFromEops Exit...] ");
		return cardStatusMap;
	}
	
	/**
	 * This method pulls the Pending Services Request for a customer from Cems sytem.
	 * The result will be used to validate the duplication of the selected fee type.
	 * 
	 * @param creditcardvo
	 * @param cardNumbersArray
	 * @param feeTypes
	 * @return cardStatusMap
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> fetchServiceRequestFromCems(CreditCardVO creditcardvo, List<String> feeTypes) {
		
		log.info("[CCTransactionAsyncService fetchServiceRequestFromEops Entered...] [FeeType:"+"]"+creditcardvo.getFeeType());
		Map<String, String> cardStatusMap = new HashMap<String, String>();
		List<Spv1ServiceRequestInfo> serviceList = statusEnquiryCEMSGateway.getServiceRequests(creditcardvo.getRelId(), creditcardvo.getCountryCode());
		if(!CardUtil.isEmptyOrNull(serviceList)) {
			serviceList.forEach(serviceRequestObj -> {
	                  List<LinkedHashMap<String, String>> info = (List<LinkedHashMap<String, String>>) serviceRequestObj.getPayload().get("products");
	                  for (LinkedHashMap<String, String> detMap : info) {
	                         String cardNumber = detMap.get("accountNumber");
	                         for (int i = 1;i<=4;i++) {
	                        	String creditNarration = detMap.get("waivReq"+i);
	                        	if(CardUtil.isEmptyOrNull(creditNarration)) continue;
	                 			if (creditNarration.toUpperCase().contains(feeTypes.get(0))) {
	                 				 cardStatusMap.put(cardNumber, "PENDING");
	                 				 break;
	                 			}
	                         }
	                  }
			});
		}
		log.info("[CCTransactionAsyncService fetchServiceRequestFromCems Status Details["+ cardStatusMap +"]");
		log.info("[CCTransactionAsyncService fetchServiceRequestFromCems Exit...] ");
		return cardStatusMap;
	}
}
