package com.sc.csl.retail.creditcard.helper;

import java.util.Comparator;

import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;

public class TransactionComparator implements Comparator<CreditCardTransactionDto> {

	private String sortOrder;
	
	public TransactionComparator() {}
	
	public TransactionComparator(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	
	@Override
	public int compare(CreditCardTransactionDto o1, CreditCardTransactionDto o2) {
		
		if ("DSC".equalsIgnoreCase(this.sortOrder)) {
			return o2.getTransactionDt().compareTo(o1.getTransactionDt());
		} else {
			return o1.getTransactionDt().compareTo(o2.getTransactionDt());
		}
	}

}
