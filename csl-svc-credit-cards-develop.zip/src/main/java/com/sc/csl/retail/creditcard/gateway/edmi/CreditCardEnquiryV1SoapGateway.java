package com.sc.csl.retail.creditcard.gateway.edmi;


import com.sc.corebanking.creditcard.v1.creditcardenquiry.*;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.*;
import com.sc.csl.retail.cache.annotations.CacheKey;
import com.sc.csl.retail.cache.annotations.CacheResult;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.*;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.gateway.csl.CreditCardSharedServiceJsonApiGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.IncludeRelationSpec;
import io.katharsis.queryspec.QuerySpec;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import static com.sc.csl.retail.creditcard.helper.CardConstant.*;

@Slf4j
public class CreditCardEnquiryV1SoapGateway extends BaseCreditCardsSoapGateway<CreditCardEnquiryPortType> {

    @Autowired
    public FreemarkerRenderer renderer;
    @Autowired
    private MapperFacade orikaMapper;

    @Autowired
    private CSLRequestContext cslRequestContext;

    @Autowired
    private CreditCardSharedServiceJsonApiGateway creditCardSharedServiceJsonApiGateway;

    @Value("${card.currency.logicalname}")
    private String logicalName;

    @Value("${card.currency.devicegroup}")
    private String deviceGroup;

    public CreditCardEnquiryV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardEnquiryV1SoapGatewayProperties) {
        super(new ScbCoreBankingCreditCardCreditCardEnquiryV1WsProviderV1CreditCardEnquiry(), CreditCardEnquiryPortType.class, edmiCreditCardEnquiryV1SoapGatewayProperties);
        setupInterceptors();
    }

    @Async("threadPoolTaskExecutor")
    public CompletableFuture<CreditCardDto> getAsyncCreditCard(CreditCardVO creditCardVO) {
        return CompletableFuture.completedFuture(getCreditCard(creditCardVO));
    }

    @Async("threadPoolTaskExecutor")
    public CompletableFuture<CreditCardDto> getAsyncCreditCardFinancialDetails(CreditCardVO creditCardVO) {
        return CompletableFuture.completedFuture(getCreditCardFinancialDetails(creditCardVO));
    }

    public CreditCardDto getCreditCard(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = new ArrayList<CreditCardDto>();
        CreditCardDto creditCardDto = null;
        String cardNo = null;
        CardRecType cardRecType = null;
        CreditCardProperties props = null;
        GetDetails request = null;
        try {
            log.debug("[getCreditCard Entry]");
            props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
            CardUtil.setGatewayProperties(creditCardVO);
            request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardDetailsProperties(), creditCardVO)), GetDetails.class);
            if (CardUtil.isEmptyOrNull(request)) {
                throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Card Details Request", "empty or null"));
            }
            if (creditCardVO.getServiceTimeOut() != null) {
                setupClientTimeout(creditCardVO.getServiceTimeOut());
            }
            GetDetailsRes response = this.getProxyClient().getDetails(request.getGetDetailsRequest());
            if (CardUtil.isEmptyOrNull(response)) {
                return new CreditCardDto();
            }
            validateSCBMLHeader(response.getHeader(), creditCardVO);

            if (!CardUtil.isEmptyOrNull(response.getGetDetailsResPayload())
                    && !CardUtil.isEmptyOrNull(response.getGetDetailsResPayload().getGetDetailsRes())
                    && !CardUtil.isEmptyOrNull(response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs())) {
                validateResponseCode(response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getSCBRespCode(), response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getSCBRespDesc(), creditCardVO);
            } else {
                return new CreditCardDto();
            }
            if (CardUtil.isEmptyOrNull(response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getCardRec())) {
                return new CreditCardDto();
            }
            cardRecType = response.getGetDetailsResPayload().getGetDetailsRes().getGetDetailsRs().getCardRec().get(0);
            creditCardDto = new CreditCardDto();
            creditCardDto.setCountry(creditCardVO.getCountryCode());
            creditCardDto.setCustomerId(creditCardVO.getCustomerId());
            creditCardDto.setChannel(creditCardVO.getChannelId());
            creditCardDto.setRelId(creditCardVO.getRelId());
            creditCardDto.setCustomerType(creditCardVO.getCustomerType());
            cardNo = CardConstant.PAD_EMPTY + cardRecType.getCardInfo().getCardNum();
            if (StringUtils.isNotBlank(cardNo) && StringUtils.length(cardNo) > 1) {
                creditCardDto.setCardNum(cardNo);
                creditCardDto.setCardID(CardUtil.generateCardId(creditCardDto.getCountry(), cardNo, creditCardDto.getCustomerId()));
                creditCardDto.setExpDt(cardRecType.getCardInfo().getExpDt());
                creditCardDto.setFranchise(CardUtil.getCardType(cardNo, props.getCreditCardFilters().getCardTypes()));
                creditCardDto.setProd(CardUtil.getProductCode(cardRecType.getCardInfo().getSCBProductType()));
                creditCardDto.setSubProd(CardUtil.getProductCode(cardRecType.getCardInfo().getSCBProductType()));
                creditCardDto.setDesc(CardUtil.getProductDescription(creditCardDto.getSubProd(), cardNo, cardRecType.getCardInfo().getCardType(), props.getProductCodes(), props.getProductMappingBinLength(), props.getCreditCardFilters().getCardTypes(), creditCardVO.getCountryCode()));
                creditCardDto.setDescCode(CardUtil.getProductDescCode(creditCardDto.getSubProd(), cardNo, props.getProductMappingBinLength()));
                creditCardDto.setStatus(CardUtil.setCardStatus(cardRecType.getCardStatus().getCardStatusCode(), props.getCreditCardFilters().getCardStatus()));
                creditCardDto.setBlkInd(CardUtil.getCardBlockCodeIndicator(CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType.getCardInfo().getSCBCardBlock().getSCBBlockCode(), props.getCreditCardFilters().getBlockInds()));
                creditCardDto.setCardImgName(CardUtil.getProductImage(cardNo, creditCardDto.getSubProd(), props.getProductImages(), props.getProductMappingBinLength()));
                creditCardDto.setCardType(CardUtil.getCardType(cardNo, props.getCreditCardFilters().getCardTypes()));
                creditCardDto.setCustShortName(cardRecType.getCardInfo().getName());
                creditCardDto.setBlockCode(CardUtil.getCardBlockCode(CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType.getCardInfo().getSCBCardBlock().getSCBBlockCode()));
                creditCardDto.setStatus(CardUtil.setCardStatus(cardRecType.getCardStatus().getCardStatusCode(), props.getCreditCardFilters().getCardStatus()));
                creditCardDto.setCardStatus(cardRecType.getCardStatus().getCardStatusCode());
                creditCardDto.setCardValiditySts(cardRecType.getCardStatus().getSCBCardValiditySts());
                creditCardDto.setActivationStatus(StringUtils.equals(CardConstant.C400, response.getHeader().getCaptureSystem()) ? cardRecType.getCardInfo().getActivationInd() : cardRecType.getCardStatus().getCardStatusCode());
                if(StringUtils.equals(CardConstant.C400, response.getHeader().getCaptureSystem()) && !CardUtil.isEmptyOrNull(cardRecType.getCardEnvr().getPartyKeys().getPartyId())) {
                creditCardDto.setRelId(cardRecType.getCardEnvr().getPartyKeys().getPartyId());
                }
                List<CardEmbossingInfoDto> cardEmbossingInfoDtos = new ArrayList<>();
                for (SCBCardEmbossingLineType embossingLineType : cardRecType.getCardInfo().getSCBCardEmbossingGroup().getSCBCardEmbossingLine()) {
                    if (!CardUtil.isEmptyOrNull(embossingLineType.getSCBEmbosserName())) {
                        CardEmbossingInfoDto cardEmbossingInfoDto = new CardEmbossingInfoDto();
                        cardEmbossingInfoDto.setCardSequenceNum(embossingLineType.getSCBCardSeqNum());
                        cardEmbossingInfoDto.setEmbosserName(embossingLineType.getSCBEmbosserName());
                        cardEmbossingInfoDto.setIssueNum(embossingLineType.getSCBIssueNum());
                        cardEmbossingInfoDtos.add(cardEmbossingInfoDto);
                    }
                }
                creditCardDto.setCardEmbossingInfos(cardEmbossingInfoDtos);

                creditCardDto.setCardRplStatus(CardUtil.setCardStatus(cardRecType.getCardStatus().getCardStatusCode(), props.getCreditCardFilters().getCardStatus()));
                creditCardDto.setCardExpired(CardUtil.isCardExpired(props.getCreditCardFilters().getExpiryDateFrmt(), cardRecType.getCardInfo().getExpDt()));

                //Fix: if the property does added in yml [Eg: for MY] then throwing expception.
                if (!CardUtil.isEmptyOrNull(props.getCreditCardFilters().getBlockCodeDateBlockCodes()) && !CardUtil.isEmptyOrNull(props.getCreditCardFilters().getBlockCodeDateDays())) {
                    creditCardDto.setBlkCdDtRplPeriod(CardUtil.getBlockCodeDateReplacementPeriod(props
                            .getCreditCardFilters().getBlockCodeDateBlockCodes(), props.getCreditCardFilters()
                            .getBlockCodeDateDays(), CardUtil
                            .isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType
                            .getCardInfo().getSCBCardBlock().getSCBBlockCode(), CardUtil.isEmptyOrNull(cardRecType
                            .getCardInfo().getSCBCardBlock()) ? null : cardRecType.getCardInfo().getSCBCardBlock()
                            .getSCBBlockCodeDate()));
                } else {
                    creditCardDto.setBlkCdDtRplPeriod(CardConstant.CONS_Y);
                }
                if (!CardUtil.isEmptyOrNull(props.getCreditCardFilters())) {
                    String embossDate = null;
                    XMLGregorianCalendar xferEffDate = null;
                    if (!CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardEmbossingGroup())) {
                        embossDate = (CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardEmbossingGroup().getSCBLastRequestDate()) ? null : cardRecType.getCardInfo().getSCBCardEmbossingGroup().getSCBLastRequestDate());
                    }
                    if (!CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardXferUpgrade())) {
                        xferEffDate = (CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardXferUpgrade().getSCBCardXferEffDt()) ? null : cardRecType.getCardInfo().getSCBCardXferUpgrade().getSCBCardXferEffDt());
                    }
                    creditCardDto.setCardRplTrnEffDate(CardUtil.getCardReplacementTransferEffectiveDate(props.getCreditCardFilters(),
                            CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType.getCardInfo().getSCBCardBlock().getSCBBlockCode(), xferEffDate, embossDate));
                } else {
                    creditCardDto.setCardRplTrnEffDate(CardConstant.CONS_Y);
                }

                creditCardDto.setAltBlockCode(CardUtil.getCardBlockCode(CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType.getCardInfo().getSCBCardBlock().getSCBALTBlockCode()));
                if (!CardUtil.isEmptyOrNull(props.getCreditCardFilters().getBlockCodesForAltBlockCodeCheck()) && !CardUtil.isEmptyOrNull(props.getCreditCardFilters().getAltBlockCodes())) {
                    creditCardDto.setCardRplAltBlockCode(CardUtil.getAltBlockCodeFlags(props.getCreditCardFilters()
                                    .getBlockCodesForAltBlockCodeCheck(), props.getCreditCardFilters().getAltBlockCodes(),
                            CardUtil.isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType
                                    .getCardInfo().getSCBCardBlock().getSCBALTBlockCode(), CardUtil
                                    .isEmptyOrNull(cardRecType.getCardInfo().getSCBCardBlock()) ? null : cardRecType
                                    .getCardInfo().getSCBCardBlock().getSCBBlockCode()));
                } else {
                    creditCardDto.setCardRplAltBlockCode(CardConstant.CONS_Y);
                }
                creditCards.add(creditCardDto);
            }
            if (CollectionUtils.isEmpty(creditCards)) {
                return new CreditCardDto();
            }
            populateCreditCardPrimaryStatus(props, creditCards);
            creditCardVO.setCreditCards(creditCards);
            log.info("[getCreditCard resposne.size : {}]", CollectionUtils.size(creditCardVO.getCreditCards()));
            return creditCardVO.getCreditCards().get(0);
        } finally {
            log.debug("[getCreditCards Exit]");
        }
    }

    public List<CreditCardTransactionDto> getCreditCardTransactions(CreditCardVO creditCardVO) {
        List<CreditCardTransactionDto> creditCardTransactions = new ArrayList<CreditCardTransactionDto>();
        String cardNo = null;
        CreditCardProperties props = null;
        GetTransactionHistory request = null;
        try {
            log.debug("[getCreditCardTransactions Entry]");

            props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
            CardUtil.setGatewayProperties(creditCardVO);
            creditCardVO.setNoOfDaysToFetchTransactions(props.getCardHistoryProperties().getDaysToFetch());
            request = CSLXmlUtils.toObject(renderer.render(CardConstant.CARD_ENQUIRY_CARD_HISTORY_TEMPLATE_NAME, getGatewayTemplateMap(props.getCardHistoryProperties(), creditCardVO)), GetTransactionHistory.class);
            if (CardUtil.isEmptyOrNull(request)) {
                throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Card CreditCardTransactions History Request", "empty or null"));
            }
            GetTransactionHistoryRes response = this.getProxyClient().getTransactionHistory(request.getGetTransactionHistoryRequest());
            if (CardUtil.isEmptyOrNull(response)) {
                return creditCardTransactions;
            }
            validateSCBMLHeader(response.getHeader(), creditCardVO);
            if (!CardUtil.isEmptyOrNull(response.getGetTransactionHistoryResPayload())
                    && !CardUtil.isEmptyOrNull(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes())
                    && !CardUtil.isEmptyOrNull(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs())) {
                validateResponseCode(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getSCBRespCode(), response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getSCBRespDesc(), creditCardVO);
            } else {
                return creditCardTransactions;
            }
            if (CardUtil.isEmptyOrNull(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getAcctStmtRec())) {
                return creditCardTransactions;
            }

            for (AcctStmtRecType acctRecType : response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getAcctStmtRec()) {
                int count = 0;
                //for All transactions [Billed/ UnBilled/ Summary]
                if (acctRecType.getAcctStmtInfo().getAcctKeys() != null) {

                    if ((CardConstant.PAD_EMPTY + acctRecType.getAcctStmtInfo().getAcctKeys().getCardKeys()) != null) {
                        log.debug("[CreditCardTransactions {billed/ unbilled} available..... ]");

                        cardNo = CardConstant.PAD_EMPTY + acctRecType.getAcctStmtInfo().getAcctKeys().getCardKeys().getCardNum();

                        if ("S".equalsIgnoreCase(creditCardVO.getFunctionCd())) {
                            CreditCardTransactionDto creditCardTransactionDto = new CreditCardTransactionDto();
                            if (acctRecType.getAcctStmtInfo().getCreditStmtData().getDueDt() != null) {
                                creditCardTransactionDto.setPaymentDueDate(CardUtil.converDateToString(acctRecType.getAcctStmtInfo()
                                        .getCreditStmtData().getDueDt()));
                            }
                            if (acctRecType.getAcctStmtInfo().getEffDt() != null) {
                                creditCardTransactionDto.setStatementDate(CardUtil.converDateToString(acctRecType.getAcctStmtInfo()
                                        .getEffDt()));
                            }
                            creditCardTransactionDto.setCardNum(cardNo);
                            creditCardTransactionDto.setFunctionCd(creditCardVO.getFunctionCd());
                            creditCardTransactionDto.setFunctionType(creditCardVO.getFunctionType());
                            creditCardTransactions.add(creditCardTransactionDto);
                        } else {
                            for (AcctTrnRefType acctTrnRefType : acctRecType.getAcctStmtInfo().getAcctTrnRef()) {
                                if (StringUtils.isNotBlank(cardNo) && StringUtils.length(cardNo) > 1) {
                                    CreditCardTransactionDto creditCardTransactionDto = new CreditCardTransactionDto();
                                    if (!CardUtil.isEmptyOrNull(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getDocCtrlOut())) {
                                        creditCardTransactionDto.setSendPageCount(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getDocCtrlOut().getSentPageCount());
                                    }
                                    creditCardTransactionDto.setCountry(creditCardVO.getCountryCode());
                                    creditCardTransactionDto.setChannel(creditCardVO.getChannelId());
                                    creditCardTransactionDto.setCustomerId(creditCardVO.getRelId());
                                    creditCardTransactionDto.setRelId(creditCardVO.getRelId());
                                    creditCardTransactionDto.setCustomerType(creditCardVO.getCustomerType());
                                    creditCardTransactionDto.setCardNum(cardNo);
                                    creditCardTransactionDto.setFunctionType(creditCardVO.getFunctionType());
                                    creditCardTransactionDto.setDesc(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getRefData().getRefDesc());
                                    creditCardTransactionDto.setFunctionCd(creditCardVO.getFunctionCd());
                                    creditCardTransactionDto.setPageNum(creditCardVO.getStartPageNumber());
                                    creditCardTransactionDto.setEffDt(CardUtil.converDateToString(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getEffDt()));
                                    creditCardTransactionDto.setPosting_Date(CardUtil.converDateToString(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getPostedDt()));
                                    creditCardTransactionDto.setLocalCurrencyAmount(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getTotalCurAmt().getAmt());
                                    creditCardTransactionDto.setDesc(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getRefData().getRefDesc());
                                    creditCardTransactionDto.setTransactionId(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getRefData().getRefIdent());
                                    if (creditCardVO.getCountryCode() != null & creditCardVO.getCountryCode().equalsIgnoreCase("HK")) {
                                        creditCardTransactionDto.setLocalCurrency("HKD");
                                    }
                                    creditCardTransactionDto.setTransactionCode(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getSCBTrnCode());
                                    creditCardTransactionDto.setTxnRefNo(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getRefData().getRefIdent());

                                    if (!props.getTransactionTypeIndicators().isEmpty() &&
                                            StringUtils.isNotEmpty(creditCardTransactionDto.getTransactionCode()) &&
                                            props.getTransactionTypeIndicators().containsKey(creditCardTransactionDto.getTransactionCode())
                                            ) {
                                        creditCardTransactionDto.setCreditDebitTransactionIndicator(creditCardTransactionDto.getTransactionCode());
                                    } else {
                                        creditCardTransactionDto.setCreditDebitTransactionIndicator("");
                                        log.info("Unable to find the creditdebit tranaction indicator for transaction code " + creditCardTransactionDto.getTransactionCode());
                                    }

                                    creditCardTransactionDto.setPostedDate(CardUtil.converDateToString(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getPostedDt()));
                                    creditCardTransactionDto.setOriginTxnAmt(new BigDecimal(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getTotalCurAmt().getAmt()));
                                    creditCardTransactionDto.setTxnCurr(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getCompositeCurAmt().getCurAmt().getCurCode().getCurCodeValue());
                                    if (!CardConstant.TRANSACTION.equalsIgnoreCase(creditCardVO.getFunctionType()) && null != acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getPostedDt()) {
                                        creditCardTransactionDto.setTxnDate(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getPostedDt().toString());
                                        creditCardTransactions.add(creditCardTransactionDto);
                                    } else if (CardConstant.TRANSACTION.equalsIgnoreCase(creditCardVO.getFunctionType())) {
                                        creditCardTransactionDto.setTxnDate(String.valueOf(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getPostedDt()));
                                        creditCardTransactions.add(creditCardTransactionDto);
                                    }
                                }
                            }
                        }
                    }
                } else if (acctRecType.getAcctStmtInfo().getAcctTrnRef() != null) { //for LPA2 transactions.

                    log.debug("[CreditCardTransactions {LPA2} available..... ]");

                    List<AcctTrnRefType> AcctTrnReflist = acctRecType.getAcctStmtInfo().getAcctTrnRef();
                    Iterator<AcctTrnRefType> acctTrnReflistitr = AcctTrnReflist.iterator();

                    while (acctTrnReflistitr.hasNext()) {
                        AcctTrnRefType acctTrnRefType = acctTrnReflistitr.next();
                        CreditCardTransactionDto creditCardTransactionDto = new CreditCardTransactionDto();

                        if (!CardUtil.isEmptyOrNull(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getDocCtrlOut())) {
                            creditCardTransactionDto.setSendPageCount(response.getGetTransactionHistoryResPayload().getGetTransactionHistoryRes().getGetTransactionHistoryRs().getDocCtrlOut().getSentPageCount());
                        }

                        creditCardTransactionDto.setCardNum(acctTrnRefType.getAcctTrnRec().getAcctTrnEnvr().getCardKeys().getCardNum().toString());
                        creditCardTransactionDto.setTxnCode(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getSCBTrnCode());
                        //creditCardTransactionDto.setTxnDate(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getEffDt().toString());
                        if (null != acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getRefData()) {
                            creditCardTransactionDto.setDesc(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getRefData().getRefDesc());
                        }
                        creditCardTransactionDto.setOriginTxnAmt(new BigDecimal(acctTrnRefType.getAcctTrnRec().getAcctTrnInfo().getTotalCurAmt().getAmt()));
                        creditCardTransactions.add(creditCardTransactionDto);
                        log.debug("[CreditCardTransactions {LPA2} added ..... ] [Card no:" + creditCardTransactionDto.getCardNum() + "] Txn code[" + creditCardTransactionDto.getTxnCode() + "]"
                                + " Desc [ " + creditCardTransactionDto.getDesc() + "] Amt [" + creditCardTransactionDto.getOriginTxnAmt() + "]");
                    }
                }
            }
            if (CollectionUtils.isEmpty(creditCardTransactions)) {
                return creditCardTransactions;
            }

            creditCardVO.setCreditCardTransactions(creditCardTransactions);
            log.info("[getCreditCardTransactions resposne.size : {}]", CollectionUtils.size(creditCardVO.getCreditCardTransactions()));
            return creditCardVO.getCreditCardTransactions();
        } finally {
            log.debug("[getCreditCardTransactions Exit]");
        }
    }

    public CreditCardDto getDelinquencyHistory(CreditCardVO creditCardVO) {
        List<CreditCardDto> creditCards = new ArrayList<CreditCardDto>();
        CreditCardDto creditCardDto = null;
        String cardNo = null;
        CreditCardProperties props = null;
        GetDelinquencyHistory request = null;
        AcctRecType acctRecType = null;
        try {
            log.debug("[getDelinquencyHistory Entry]");
            log.info("[getDelinquencyHistory creditCardVO: {}", creditCardVO);
            props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
            log.info("[getDelinquencyHistory country config props -> {}", props);
            CardUtil.setGatewayProperties(creditCardVO);
            request = CSLXmlUtils.toObject(
                    renderer.render(CardConstant.CARD_ENQUIRY_CARD_DELINQUENCY_TEMPLATE_NAME,
                            getGatewayTemplateMap(props.getCardDelinquencyProperties(), creditCardVO)),
                    GetDelinquencyHistory.class);
            if (CardUtil.isEmptyOrNull(request)) {
                throw new TechnicalException(TemplateErrorCode.create(
                        CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "Card DelinquencyHistory Request",
                        "empty or null"));
            }

            GetDelinquencyHistoryRes response = this.getProxyClient().getDelinquencyHistory(
                    request.getGetDelinquencyHistoryRequest());
            if (CardUtil.isEmptyOrNull(response)) {
                return new CreditCardDto();
            }
            validateSCBMLHeader(response.getHeader(), creditCardVO);

            if (!CardUtil.isEmptyOrNull(response.getGetDelinquencyHistoryResPayload())
                    && !CardUtil.isEmptyOrNull(response.getGetDelinquencyHistoryResPayload()
                    .getGetDelinquencyHistoryRes())
                    && !CardUtil.isEmptyOrNull(response.getGetDelinquencyHistoryResPayload()
                    .getGetDelinquencyHistoryRes().getGetDelinquencyHistoryRs())) {
                validateResponseCode(response.getGetDelinquencyHistoryResPayload().getGetDelinquencyHistoryRes()
                        .getGetDelinquencyHistoryRs().getSCBRespCode(), response.getGetDelinquencyHistoryResPayload()
                        .getGetDelinquencyHistoryRes().getGetDelinquencyHistoryRs().getSCBRespDesc(), creditCardVO);
            } else {
                return new CreditCardDto();
            }
            if (CardUtil.isEmptyOrNull(response.getGetDelinquencyHistoryResPayload().getGetDelinquencyHistoryRes()
                    .getGetDelinquencyHistoryRs().getAcctRec())) {
                return new CreditCardDto();
            }

            acctRecType = response.getGetDelinquencyHistoryResPayload().getGetDelinquencyHistoryRes()
                    .getGetDelinquencyHistoryRs().getAcctRec().get(0);
            creditCardDto = new CreditCardDto();
            creditCardDto.setCountry(creditCardVO.getCountryCode());
            creditCardDto.setCustomerId(creditCardVO.getCustomerId());
            creditCardDto.setChannel(creditCardVO.getChannelId());
            creditCardDto.setRelId(creditCardVO.getRelId());
            creditCardDto.setCustomerType(creditCardVO.getCustomerType());
            cardNo = CardConstant.PAD_EMPTY + acctRecType.getAcctEnvr().getCardKeys().getCardNum();

            if (StringUtils.isNotBlank(cardNo) && StringUtils.length(cardNo) > 1) {
                creditCardDto.setCardID(CardUtil.generateCardId(creditCardDto.getCountry(), cardNo,
                        creditCardDto.getCustomerId()));
                creditCardDto.setCardNum(cardNo);

                orikaMapper.map(acctRecType, creditCardDto);

                creditCards.add(creditCardDto);
            }

            if (CollectionUtils.isEmpty(creditCards)) {
                return new CreditCardDto();
            }

            creditCardVO.setCreditCards(creditCards);
            log.info("[getDelinquencyHistory creditCardVO: {}", creditCardVO);
            return creditCardVO.getCreditCards().get(0);

        } finally {
            log.debug("[getDelinquencyHistory Exit]");
        }
    }

    public CreditCardDto getCreditCardFinancialDetails(CreditCardVO creditCardVO) {
        try {
            log.debug("[getCreditCardFinancialDetails Entry]");
            CreditCardProperties props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
            CardUtil.setGatewayProperties(creditCardVO);
            GetFinancialDetails request = CSLXmlUtils.toObject(renderer.render(
                    CardConstant.CARD_ENQUIRY_CARD_FINANCIAL_DETAILS_TEMPLATE_NAME,
                    getGatewayTemplateMap(props.getCardFinancialDetailsProperties(), creditCardVO)),
                    GetFinancialDetails.class);
            GetFinancialDetailsRes response = this.getProxyClient().getFinancialDetails(
                    request.getGetFinancialDetailsRequest());
            validateSCBMLHeader(response.getHeader(), creditCardVO);

            if (!CardUtil.isEmptyOrNull(response.getGetFinancialDetailsResPayload())
                    && !CardUtil.isEmptyOrNull(response.getGetFinancialDetailsResPayload().getGetFinancialDetailsRes())
                    && !CardUtil.isEmptyOrNull(response.getGetFinancialDetailsResPayload().getGetFinancialDetailsRes()
                    .getGetFinancialDetailsRs())) {
                validateResponseCode(response.getGetFinancialDetailsResPayload().getGetFinancialDetailsRes()
                        .getGetFinancialDetailsRs().getSCBRespCode(), response.getGetFinancialDetailsResPayload()
                        .getGetFinancialDetailsRes().getGetFinancialDetailsRs().getSCBRespDesc(), creditCardVO);
            } else {
                return new CreditCardDto();
            }

            if (CardUtil.isEmptyOrNull(response.getGetFinancialDetailsResPayload().getGetFinancialDetailsRes()
                    .getGetFinancialDetailsRs().getAcctRec())) {
                return new CreditCardDto();
            }
            List<AcctRecType> accRecList = response.getGetFinancialDetailsResPayload().getGetFinancialDetailsRes()
                    .getGetFinancialDetailsRs().getAcctRec();
            CreditCardDto creditCardDto = new CreditCardDto();
            if (!CardUtil.isEmptyOrNull(accRecList)) {
                AcctRecType accRec = accRecList.get(0);
                AcctInfoType accInfo = accRec.getAcctInfo();
                if (accInfo != null) {
                    if (!CardUtil.isEmptyOrNull(accInfo.getSCBCreditAcct())) {
                        SCBCreditAcctType creditAcctType = accInfo.getSCBCreditAcct();
                        creditCardDto.setCollateralCode(creditAcctType.getSCBCollateralCode());
                    }
                    if (!CardUtil.isEmptyOrNull(accInfo.getSCBAcctInfo())) {
                        creditCardDto.setAgreementStatus(accInfo.getSCBAcctInfo().getSCBAgreementSts());
                        creditCardDto.setAgmtStsInd(CardUtil.getAgreementStatusIndicator(accInfo.getSCBAcctInfo().getSCBAgreementSts(), props.getCreditCardFilters().getAgmtStsInds()));
                    }
                    if (!CardUtil.isEmptyOrNull(accInfo.getAcctPricing())) {
                        FeeType cashAdvfee = accInfo.getAcctPricing().get(0).getFee()
                                .stream()
                                .filter(feeType -> feeType.getFeeType().equals(CASH_ADVANCE_FEE))
                                .findFirst()
                                .orElse(new FeeType());
                        FeeType bankChargesfee = accInfo.getAcctPricing().get(0).getFee()
                                .stream()
                                .filter(feeType -> feeType.getFeeType().equals(BANK_CHARGES))
                                .findFirst()
                                .orElse(new FeeType());
                        creditCardDto.setCashAdvanceFeeRate(new BigDecimal(cashAdvfee.getRate()));
                        creditCardDto.setBankChargesAmount(new BigDecimal(bankChargesfee.getCurAmt().getAmt()));
                        creditCardDto.setBankChargesRate(new BigDecimal(bankChargesfee.getRate()));
                    }
                    if (!CardUtil.isEmptyOrNull(accInfo.getAcctBal())) {
                        String cashLimit = accInfo.getAcctBal()
                                .stream()
                                .filter(acctBalType -> acctBalType.getBalType().getBalTypeValues().equals(CARD_AVAILABLE_CASH))
                                .map(AcctBalType::getCurAmt)
                                .map(CurAmtType::getAmt)
                                .findFirst()
                                .orElse("0.00");
                        creditCardDto.setAvlblLimit(cashLimit);
                    }
                    if (!CardUtil.isEmptyOrNull(accInfo.getSCBOverRide())) {
                        creditCardDto.setOverrideCode(accInfo.getSCBOverRide().getSCBOverrideCode());
                    }
                    if (null != accInfo.getAcctBal()) {
                        for (AcctBalType acctBalType : accInfo.getAcctBal()) {
                            switch (acctBalType.getBalType().getBalTypeValues()) {
                            case "SettlementAmt":
                                creditCardDto.setOutstandingBalance(CardUtil.toBigDecimal(acctBalType.getCurAmt().getAmt()));
                                break;
                            default:
                                break;
                            }
                        }
                    }

                    creditCardDto.setCardNum(creditCardVO.getCardNo());
                }
            }
            return creditCardDto;
        } finally {
            log.debug("[getCreditCardFinancialDetails Exit]");
        }
    }

    @CacheResult(cacheName = "one-credit-card-cache", timeToLive = 2, timeUnit = TimeUnit.HOURS)
    public CreditCardDto findOneCreditCardInfoFromDB(CreditCardVO creditCardVO, Throwable exception, @CacheKey String cacheKey) {
        handleException(creditCardVO, exception);
        CardDto cardDto = Optional.ofNullable(creditCardSharedServiceJsonApiGateway.fetchOneCreditCardAccount(creditCardVO.getCardNo(), null)).orElse(new CardDto());
        log.info("24x7 Account Response:{}", cardDto);
        return getCreditCardDto(creditCardVO, cardDto);
    }

    public List<CreditCardTransactionDto> fetchCreditCardTransactions(CreditCardVO creditCardVO) {

        List<IncludeRelationSpec> includedRelations = new ArrayList<>();
        List<String> includeProperty = new ArrayList<>();
        includeProperty.add("cardtransactions");
        IncludeRelationSpec include = new IncludeRelationSpec(includeProperty);
        includedRelations.add(include);
        QuerySpec querySpec = new QuerySpec(CardDto.class);
        querySpec.setIncludedRelations(includedRelations);
        CardDto cardDto = Optional.ofNullable(creditCardSharedServiceJsonApiGateway.fetchOneCreditCardAccount(creditCardVO.getCardNo(), querySpec)).orElse(new CardDto());
        log.info("24x7 Account Response:{}", cardDto);
        CreditCardDto creditCardDto = getCreditCardDto(creditCardVO, cardDto);
        List<CreditCardTransactionDto> creditCardTransactions = new ArrayList<>();
        List<CreditCardTransactionDto> ssCreditCardTransactions = cardDto.getCardtransactions();
        if (ssCreditCardTransactions != null && !ssCreditCardTransactions.isEmpty()) {
            ssCreditCardTransactions.forEach(transaction -> {
                CreditCardTransactionDto transactionDto = orikaMapper.map(transaction, CreditCardTransactionDto.class);
                transactionDto.setTransactionDate(CardUtil.convertStringToDate(transaction.getTxnDate()));
                transactionDto.setTransactionCurrencyCode(cardDto.getCurrencyCode());
                creditCardTransactions.add(transactionDto);
            });
        }
        creditCardDto.setCardtransactions(creditCardTransactions);
        return creditCardTransactions;
    }

    public List<CreditCardTransactionDto> fetchProvidedCredidCardTransactions(List<String> creditCards, QuerySpec querySpec, Map<String, CreditCardDto> creditCardDtoMap) {
        if(creditCards.size()==1) {
            creditCards.add(creditCards.get(0));
        }
        List<Transaction> ccTxnFromSS = creditCardSharedServiceJsonApiGateway.fetchAllProvidedCreditCardTransactions(creditCards, querySpec);
        Map<String , String> currencyCodeAndDesc = creditCardSharedServiceJsonApiGateway.getCurrencyCodeDescriptions(logicalName,deviceGroup);
        List<CreditCardTransactionDto> creditCardTransactionsList = new ArrayList<>();
        CreditCardProperties props = getCreditCardPropertiesByCountry(cslRequestContext.getCountry());
        Map<String, String> typeIndicators = props.getTransactionTypeIndicators();
        ccTxnFromSS.forEach(cctxn -> {
            CreditCardTransactionDto creditCardTransactions = orikaMapper.map(cctxn, CreditCardTransactionDto.class);
            if (currencyCodeAndDesc.containsKey(cctxn.getTransactionCurrencyCode())) {
                creditCardTransactions.setTransactionCurrencyCode(currencyCodeAndDesc.get(cctxn.getTransactionCurrencyCode()));
            } else {
                creditCardTransactions.setTransactionCurrencyCode(creditCardDtoMap.get(cctxn.getAccountNo()).getCurrencyCode());
            }
            if (typeIndicators.containsKey(creditCardTransactions.getCreditDebitTransactionIndicator())) {
                creditCardTransactions.setCreditDebitTransactionIndicator(typeIndicators.get(creditCardTransactions.getCreditDebitTransactionIndicator()));
            }
            creditCardTransactionsList.add(creditCardTransactions);
        });
        return creditCardTransactionsList;
    }

    public static CreditCardDto getCreditCardDto(CreditCardVO creditCardVO, CardDto creditCard) {
        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCountry(creditCardVO.getCountryCode());
        creditCardDto.setCustomerId(creditCardVO.getRelId());
        creditCardDto.setChannel(creditCardVO.getChannelId());
        creditCardDto.setRelId(creditCardVO.getRelId());
        creditCardDto.setCardID(CardUtil.generateCardId(creditCardDto.getCountry(), creditCardVO.getCardNo(), creditCardVO.getRelId()));
        creditCardDto.setCardNum(creditCardVO.getCardNo());
        creditCardDto.setSubProd(creditCard.getSubProd());
        creditCardDto.setBlockCode(creditCard.getBlockCode());
        creditCardDto.setVariant(creditCard.getOrgCode());
        creditCardDto.setExpDt(creditCard.getExpDt());
        creditCardDto.setProd(CardUtil.getProductCode(creditCard.getCardType()));
        creditCardDto.setAvlblLimit(String.valueOf(creditCard.getAvailableLimit()));
        creditCardDto.setCurrentBalance(String.valueOf(creditCard.getCurrentBalance()));
        creditCardDto.setCreditLimit(String.valueOf(creditCard.getCreditLimit()));
        creditCardDto.setMinimumAmountDue(String.valueOf(creditCard.getMinimumPayment()));
        creditCardDto.setCurrencyCode(creditCard.getCurrencyCode());
        creditCardDto.setDesc(creditCard.getAccountDescription());
        return creditCardDto;
    }


    @Async("threadPoolTaskExecutor")
    public CompletableFuture<List<CreditCardTransactionDto>> getUnBilledTransactions(CreditCardVO creditCardVO) {
        creditCardVO.setFunctionCd(CardConstant.FUNC_CD_U);
        creditCardVO.setStartPageNumber(CardConstant.START_PAGE_01);
        return CompletableFuture.completedFuture(getTransactions(creditCardVO, CardConstant.FUNC_CD_U));
    }

    public List<CreditCardTransactionDto> getBilledTransactions(CreditCardVO creditCardVO) {
        creditCardVO.setFunctionCd(CardConstant.FUNC_CD_B);
        creditCardVO.setStartPageNumber(CardConstant.START_PAGE_01);
        return getTransactions(creditCardVO, CardConstant.FUNC_CD_B);
    }


    private List<CreditCardTransactionDto> getTransactions(CreditCardVO creditCardVO, String transactionType) {
        List<CreditCardTransactionDto> creditCardEdmiTransactions = null;
        List<CreditCardTransactionDto> validTransactions = new ArrayList<>();
        try {
            creditCardEdmiTransactions = getCreditCardTransactions(creditCardVO);

            if (creditCardEdmiTransactions != null) {
                for (CreditCardTransactionDto creditCardTransactionDto : creditCardEdmiTransactions) {
                    creditCardTransactionDto.setTransactionType(transactionType);
                    if (isCurrentDayTransaction(creditCardTransactionDto.getTransactionDate())) {
                        validTransactions.add(creditCardTransactionDto);
                    }
                }
                if (CollectionUtils.isNotEmpty(creditCardEdmiTransactions)) {
                    creditCardVO.setStartPageNumber(creditCardEdmiTransactions.get(0).getSendPageCount());
                }
            }
        } catch (Exception e) {
            log.error("Error while getting CreditCardTransactions from EDMI :: {} ", e.getMessage());
        }

        return validTransactions;
    }

    private boolean isCurrentDayTransaction(Date transactionEffectiveDate) {
        try {
            return transactionEffectiveDate != null && transactionEffectiveDate.equals(new Date());
        } catch (IllegalArgumentException ex) {
            log.error("Error while validating the transaction Date :: {} , {}  ", transactionEffectiveDate, ex.getMessage());
            return false;
        }
    }

}
