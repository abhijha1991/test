package com.sc.csl.retail.creditcard.orika.mapping;

import com.sc.corebanking.creditcard.v1.creditcardenquiry.AcctPeriodDataType;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactions;
import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import net.rakugakibox.spring.boot.orika.OrikaMapperFactoryConfigurer;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * CreditCardMapping.java
 * 
 * <pre>
 * 
 * </pre>
 * 
 * @author 1523166
 * @since Aug 04, 2017
 * @version CSL-SVC-CREDIT-CARDS-1.0.0
 */
@Component
public class CreditCardMapping implements OrikaMapperFactoryConfigurer {

    @Override
    public void configure(MapperFactory orikaMapperFactory) {
        orikaMapperFactory
        .classMap(com.sc.csl.retail.creditcard.dto.CreditCardDto.class,
                com.sc.csl.retail.creditcard.dto.post.CCFeeWaiverPostDto.class)
                .field("channel", "channelId")
                .field("requestType", "requestType").field("reason", "reason")
                .field("feeType", "feeType")
                .field("frontlineNotes", "frontlineNotes")
                .field("postCreditCards","creditcard").register();
        
        orikaMapperFactory
	        .classMap(com.sc.csl.retail.creditcard.dto.CreditCardDto.class,
	                com.sc.csl.retail.creditcard.dto.post.CreditCardPostDto.class)
					.field("creditCardEligibility.cardEligibilityFlag", "cardEligibilityStatus")
					.field("creditCardEligibility.eligibilityOverrideFlag", "eligibilityOverrideFlag")
					.field("cardNum","cardNumber")
					.field("rewardpointdemption", "rewardPointRequired")
					.field("blockCode","blockCode")
					.field("cardType","cardType")
					.field("currencyCode","cardCurrency")
					.field("cardtransactions", "transaction")
	                .register();
        
        orikaMapperFactory
        .classMap(com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto.class,
                com.sc.csl.retail.creditcard.dto.post.CCTransactionPostDto.class)
                .field("txnCode", "transactionCode")
                .field("actualTxnAmount", "actualDebitAmout").field("originTxnAmt", "transactionAmount")
                .field("desc", "transactionDesc").field("txnDate","debitTransactionDate").
                field("equivalentRewardPoints.rewardsPoints","equivalentRewardpoint").
                field("feeSubTypeCode", "feeSubTypeCode").register();
        
        orikaMapperFactory
        .classMap(com.sc.csl.retail.creditcard.dto.CreditCardTransactionsEDMPDto.class,
                com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto.class)
                .field("cardNumber", "cardNum").field("transactionReferenceNo", "txnRefNo")
                .field("transactionAmount", "originTxnAmt").field("transactionDesc", "desc")
                .field("transactionCode", "txnCode")
                .field("transactionDate", "txnDate").register();
        // Credit Card DelinquencyHistory
        orikaMapperFactory
                .classMap(com.sc.corebanking.creditcard.v1.creditcardenquiry.AcctRecType.class,
                        com.sc.csl.retail.creditcard.dto.CreditCardDto.class)
                .customize(new DelinquencyHistoryToCardMapper()).register();

        //ValidateLimit Increase
        orikaMapperFactory.classMap(com.sc.corebanking.creditcard.v1.creditcardlimit.AcctBalType.class,
                com.sc.csl.retail.creditcard.dto.CardBalanceLimitDto.class)
                .field("balType.balTypeValues", "balTypeValue")
                .field("curAmt.amt", "amount").register();

        orikaMapperFactory.classMap(com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto.class,
                CreditCardTransactions.class)
                .field("txnRefNo", "transactionApprovalSequenceNumber")
                .field("creditDebitTransactionIndicator", "creditDebitTransactionIndicator")
                .field("actualTxnAmount", "transactionAmount")
                .field("transactionCurrencyCode", "transactionCurrencyCode")
                .field("transactionDate", "transactionEffectiveDate")
                .field("refDesc", "transactionDescription")
                .field("cardNum", "accountNo").register();

        orikaMapperFactory.classMap(com.sc.csl.retail.creditcard.dto.Transaction.class,
                CreditCardTransactionDto.class)
                .field("transactionApprovalSequenceNumber", "txnRefNo")
                .field("creditDebitTransactionIndicator", "creditDebitTransactionIndicator")
                .field("transactionAmount", "actualTxnAmount")
                .field("transactionCurrencyCode", "transactionCurrencyCode")
                .field("transactionEffectiveDate", "transactionDate")
                .field("transactionDescription", "refDesc")
                .field("accountNo", "cardNum").register();
    }
}

class DelinquencyHistoryToCardMapper
        extends
        CustomMapper<com.sc.corebanking.creditcard.v1.creditcardenquiry.AcctRecType, com.sc.csl.retail.creditcard.dto.CreditCardDto> {

    public void mapAtoB(com.sc.corebanking.creditcard.v1.creditcardenquiry.AcctRecType acctRecType,
            com.sc.csl.retail.creditcard.dto.CreditCardDto creditCardDto, MappingContext context) {
        BigDecimal totalDelinquencyAmount = BigDecimal.ZERO;
        for (AcctPeriodDataType acctPeriodDataType : acctRecType.getAcctInfo().getAcctPeriodData()) {
            switch (acctPeriodDataType.getAcctAmtType()) {
            case "DelqCycle 1":
                creditCardDto.setDelinquencyCycle1Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 2":
                creditCardDto.setDelinquencyCycle2Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 3":
                creditCardDto.setDelinquencyCycle3Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 4":
                creditCardDto.setDelinquencyCycle4Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 5":
                creditCardDto.setDelinquencyCycle5Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 6":
                creditCardDto.setDelinquencyCycle6Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 7":
                creditCardDto.setDelinquencyCycle7Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            case "DelqCycle 8":
                creditCardDto.setDelinquencyCycle8Amt(acctPeriodDataType.getAmt());
                totalDelinquencyAmount = totalDelinquencyAmount.add(new BigDecimal(acctPeriodDataType.getAmt()));
                break;
            }
        }
        creditCardDto.setDelinquencyAmount(totalDelinquencyAmount.toPlainString());
    }
}
