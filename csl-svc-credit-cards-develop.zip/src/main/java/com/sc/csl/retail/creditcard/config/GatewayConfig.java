package com.sc.csl.retail.creditcard.config;

import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardCustomerEnquiryV5SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardLimitV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardProfileV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.EligibleInstallmentSoapGateway;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {
	
	@Bean
    @ConfigurationProperties(prefix = "edmi.soap.creditCard.profile.v1")
    public CSLSoapGatewayProperties edmiCreditCardProfileV1SoapGatewayProperties() {
        return new CSLSoapGatewayProperties();
    }    
	
	@Bean
    @ConfigurationProperties(prefix = "edmi.soap.creditCard.updatestatus.v1")
    public CSLSoapGatewayProperties edmiCreditCardV1SoapGatewayProperties() {
        return new CSLSoapGatewayProperties();
    }
	
	
	@Bean
    @ConfigurationProperties(prefix = "edmi.soap.creditCard.enquiry.v1")
    public CSLSoapGatewayProperties edmiCreditCardEnquiryV1SoapGatewayProperties() {
        return new CSLSoapGatewayProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "edmi.soap.creditCard.customer.enquiry.v5")
    public CSLSoapGatewayProperties edmiCreditCardCustomerEnquiryV5SoapGatewayProperties() {
        return new CSLSoapGatewayProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "edmi.soap.creditCard.installment.plan")
    public CSLSoapGatewayProperties edmiCreditCardInstallmentV1SoapGatewayProperties() {
        return new CSLSoapGatewayProperties();
    }
    @Bean
    @ConfigurationProperties(prefix = "edmi.soap.creditCard.limit.v1")
    public CSLSoapGatewayProperties edmiCreditCardLimitV1SoapGatewayProperties() {
        return new CSLSoapGatewayProperties();
    }

    @Bean
    public CreditCardV1SoapGateway edmiCreditCardV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardV1SoapGatewayProperties) {
        return new CreditCardV1SoapGateway(edmiCreditCardV1SoapGatewayProperties);
    }
    
    @Bean
    public CreditCardProfileV1SoapGateway edmiCreditCardProfileV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardProfileV1SoapGatewayProperties) {
        return new CreditCardProfileV1SoapGateway(edmiCreditCardProfileV1SoapGatewayProperties);
    }
    
    @Bean
    public CreditCardEnquiryV1SoapGateway edmiCreditCardEnquiryV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardEnquiryV1SoapGatewayProperties) {
        return new CreditCardEnquiryV1SoapGateway(edmiCreditCardEnquiryV1SoapGatewayProperties);
    }

    @Bean
    public CreditCardCustomerEnquiryV5SoapGateway edmiCreditCardCustomerEnquiryV5SoapGateway(CSLSoapGatewayProperties edmiCreditCardCustomerEnquiryV5SoapGatewayProperties) {
        return new CreditCardCustomerEnquiryV5SoapGateway(edmiCreditCardCustomerEnquiryV5SoapGatewayProperties);
    }

    @Bean
    public EligibleInstallmentSoapGateway edmiCreditCardInstallmentV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardInstallmentV1SoapGatewayProperties) {
        return new EligibleInstallmentSoapGateway(edmiCreditCardInstallmentV1SoapGatewayProperties);
    }
    
    @Bean
    public CreditCardLimitV1SoapGateway edmiCreditCardLimitV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardLimitV1SoapGatewayProperties) {
        return new CreditCardLimitV1SoapGateway(edmiCreditCardLimitV1SoapGatewayProperties);
    }
}
