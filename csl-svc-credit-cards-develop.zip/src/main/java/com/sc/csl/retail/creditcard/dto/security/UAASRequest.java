package com.sc.csl.retail.creditcard.dto.security;



import com.sc.csl.retail.creditcard.dto.CardInfo;

import lombok.Data;

@Data
public class UAASRequest {

	private UAASUserInfo user;
	private CardInfo cardInfo;
	private UAASTransactionInfo txnInfo;
	private UAASOtpInfo otpInfo;
	private ClientInfo clientInfo;

}
