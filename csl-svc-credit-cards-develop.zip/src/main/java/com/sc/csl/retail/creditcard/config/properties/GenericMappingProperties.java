package com.sc.csl.retail.creditcard.config.properties;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 1452875
 * @since Sep 19, 2017
 */
@Getter
@Setter
public class GenericMappingProperties {
    private String sourceField = null;
    private String value = null;
    private String regEx = null;
    private String sourceDateFormat = null;
    private String destDateFormat = null;
}
