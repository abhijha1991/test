package com.sc.csl.retail.creditcard.config.properties;

import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter

public class CreditCardFeeWaiverProperties{
	
	private String activeStatusCode;
	private String blockCode;
	private Map<String,String> inEligCardTypeForFeeTypes;
	private Map<String,Object> rewardPoint;
	private Map<String,String> raEligibilityCriteria;
	private Map<String,String> frontlineUserType;
	private String eligibiltityTable;
	private String transactionTable;
	private String creditTransactionsCodes;
	private String txnRefreshTable;
	private String raRefreshTable;
	private String localCurrency;
	private List<String> idparams;
	private Map<String,String> errorCodesAndDesc;
	private String eopsDuplicateChekRequired;
	private String ccmsDuplicateChekRequired;
	private String cemsDuplicateChekRequired;
}
