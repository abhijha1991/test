package com.sc.csl.retail.creditcard.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author 1523165
 * @since July 27, 2017
 */
@ToString
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BusinessRuleAlert implements Serializable {

    private static final long serialVersionUID = -8237872198582818370L;
    private BusinessRuleAlertType type;
    private String code;
    private String message;
}
