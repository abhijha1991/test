package com.sc.csl.retail.creditcard.config;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.creditcard.service.cccancel.CreditCardCancelEnricher;

/**
 * @author 1452875
 * @since Sep 20, 2017
 */
@Component
public class EnricherServiceConfig {

    @Bean
    public CreditCardCancelEnricher creditCardCancelRequestEnricherAE() {
        return new CreditCardCancelEnricher();
    }

    @Bean
    public CreditCardCancelEnricher creditCardCancelRequestEnricherSG() {
        return new CreditCardCancelEnricher();
    }
}
