package com.sc.csl.retail.creditcard.gateway.csl;

import com.sc.csl.retail.cache.annotations.CacheResult;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.creditcard.dto.CardDto;
import com.sc.csl.retail.creditcard.dto.ReferenceDataDto;
import com.sc.csl.retail.creditcard.dto.Transaction;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import io.katharsis.errorhandling.exception.KatharsisMappableException;
import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.IncludeRelationSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
@Component
@ConfigurationProperties(prefix = "jsonapi.gateway.sharedservice.creditcard")
public class CreditCardSharedServiceJsonApiGateway extends CSLJsonApiGateway {

    @Autowired
    private MapperFacade orikaMapper;


    public List<CardDto> fetchAllCreditCardAccounts() {
        try {
            ResourceRepositoryV2<CardDto, String> creditCardRepo = getKatharsisClient().getRepositoryForType(CardDto.class);
            QuerySpec querySpec = new QuerySpec(CardDto.class);
            List<CardDto> cardDtoListFromSS = creditCardRepo.findAll(querySpec);
            List<CardDto> cardDtoList = new ArrayList<>();
            cardDtoListFromSS.forEach(cardDtoFromSS -> {
                cardDtoFromSS.setCardtransactions(null);
                CardDto accDto = orikaMapper.map(cardDtoFromSS,CardDto.class);
                cardDtoList.add(accDto);
            });
            return cardDtoList;
        } catch (KatharsisMappableException e) {
            log.error("Exception occurred while calling 24x7 Credit Card Service {} ", e.getMessage());
            //throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION,e.getErrorData().getDetail()));
            return null;
        } catch (Exception e) {
            log.error("Exception occurred while calling 24x7 Credit Card Service {}", e.getMessage());
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION, CreditCardErrorCode.ERR_24x7_EXCEPTION));
        }
    }

    public List<CardDto> fetchAllProvidedCreditCardAccounts(List<String> creditCards) {
        try {
            ResourceRepositoryV2<CardDto, String> creditCardRepo = getKatharsisClient().getRepositoryForType(CardDto.class);
            QuerySpec querySpec = new QuerySpec(CardDto.class);
            List<CardDto> cardDtoListFromSS = creditCardRepo.findAll(creditCards,querySpec);
            List<CardDto> cardDtoList = new ArrayList<>();
            cardDtoListFromSS.forEach(cardDtoFromSS -> {
                cardDtoFromSS.setCardtransactions(null);
                CardDto accDto = orikaMapper.map(cardDtoFromSS,CardDto.class);
                cardDtoList.add(accDto);
            });
            return cardDtoList;
        } catch (KatharsisMappableException e) {
            log.error("Exception occurred while calling 24x7 fetchAllProvidedCreditCardAccounts Service {} ", e.getMessage());
            //throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION,e.getErrorData().getDetail()));
            return null;
        } catch (Exception e) {
            log.error("Exception occurred while calling 24x7 fetchAllProvidedCreditCardAccounts Service {}", e.getMessage());
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION, CreditCardErrorCode.ERR_24x7_EXCEPTION));
        }
    }

    public CardDto fetchOneCreditCardAccount(String cardNo,QuerySpec querySpec) {
        try {
            ResourceRepositoryV2<CardDto, String> creditCardRepo = getKatharsisClient().getRepositoryForType(CardDto.class);
            CardDto dto = creditCardRepo.findOne(cardNo, querySpec);
            CardDto cardDto = orikaMapper.map(dto,CardDto.class);
            return cardDto;
        } catch (KatharsisMappableException e) {
            log.error("Exception occurred while calling 24x7 Credit Card Service {} ", e.getMessage());
            //throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION, e.getErrorData().getDetail()));
            return null;
        } catch (Exception e) {
            log.error("Exception occurred while calling 24x7 Credit Card Service {}", e.getMessage());
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION, CreditCardErrorCode.ERR_24x7_EXCEPTION));
        }
    }

    private List<IncludeRelationSpec> getIncludedRelations(QuerySpec querySpec) {
        return querySpec.getIncludedRelations();
    }

    private boolean containsRelation(QuerySpec querySpec, String relationName) {
        return getIncludedRelations(querySpec).stream()
                .anyMatch(relation  -> relation.toString().equalsIgnoreCase(relationName));
    }


    public List<Transaction> fetchAllProvidedCreditCardTransactions(List<String> creditCards, QuerySpec querySpec) {
        try {
            QuerySpec newQuerySpec = new QuerySpec(Transaction.class);
            newQuerySpec.setFilters(querySpec.getFilters());
            ResourceRepositoryV2<Transaction, String> creditCardRepo = getKatharsisClient().getRepositoryForType(Transaction.class);
            List<Transaction> ccTxnFromSS = creditCardRepo.findAll(creditCards,newQuerySpec);
            return ccTxnFromSS;

        } catch (KatharsisMappableException e) {
            log.error("Exception occurred while calling 24x7 fetchAllProvidedCreditCardAccounts Service {} ", e.getMessage());
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION,e.getErrorData().getDetail()));
        } catch (Exception e) {
            log.error("Exception occurred while calling 24x7 fetchAllProvidedCreditCardAccounts Service {}", e.getMessage());
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_24x7_EXCEPTION, CreditCardErrorCode.ERR_24x7_EXCEPTION));
        }
    }


    @CacheResult(timeUnit = TimeUnit.HOURS,cacheName = "currency-code-desc" ,timeToLive = 8)
    public Map<String,String> getCurrencyCodeDescriptions(String logicalName, String deviceGroup) {
        QuerySpec querySpec = new QuerySpec(ReferenceDataDto.class);
        querySpec.addFilter(new FilterSpec(Arrays.asList("logicalName"), FilterOperator.EQ,logicalName));
        querySpec.addFilter(new FilterSpec(Arrays.asList("deviceGroup"), FilterOperator.EQ, deviceGroup));
        ResourceRepositoryV2<ReferenceDataDto, String> creditCardRepo = getKatharsisClient().getRepositoryForType(ReferenceDataDto.class);
        List<ReferenceDataDto> referenceDataFromSS = creditCardRepo.findAll(querySpec);
        Map<String,String> currencyCodeAndDesc = new HashMap<>();
        referenceDataFromSS.forEach(referenceDataDto -> currencyCodeAndDesc.put(referenceDataDto.getRefId(),referenceDataDto.getRefValue()));
        return currencyCodeAndDesc;
    }
}

