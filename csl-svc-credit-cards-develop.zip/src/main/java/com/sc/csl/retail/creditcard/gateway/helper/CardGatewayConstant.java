package com.sc.csl.retail.creditcard.gateway.helper;

public class CardGatewayConstant {

	public static final String EDMI_SUCCESS_RES_CDS [] = {"00000", "YES","ED00000"};
}
