package com.sc.csl.retail.creditcard.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 1452875
 * @since Sep 20, 2017
 */
@Getter
@Setter
public class CustomerDto {
    private String relationshipNo;
    private String relationshipType;
}
