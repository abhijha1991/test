package com.sc.csl.retail.creditcard.service;

import java.util.HashMap;
import java.util.Map;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.GatewayServiceNameProperties;
import com.sc.csl.retail.creditcard.dto.BaseDto;
import com.sc.csl.retail.creditcard.dto.CustomerDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.helper.CardUtil;

/**
 * @author 1452875
 * @since Sep 20, 2017
 */
@Slf4j
public class BaseService {
    @Autowired
    protected CSLRequestContext cslRequestContext;
    @Autowired
    protected ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
    @Autowired
    private ApplicationContext context;

    @Autowired
    private Map<String, CreditCardProperties> creditCardProperties;

    /**
     * Method returns a instance of a properties bean, where the configuration required for business validation is being
     * maintained
     */
    protected CreditCardProperties getCreditCardPropertiesBean() {
        if (CardUtil.isEmptyOrNull(cslRequestContext.getCountry())) {
            return null;
        }
        String beanId = cslRequestContext.getCountry().toUpperCase();
        log.debug("[Country: " + cslRequestContext.getCountry() + "] [Bean ID: " + beanId + "]");
        return (CreditCardProperties) getBean(beanId);
    }

    protected Object getBean(String beanId) {
        return context.getBean(beanId);
    }

    /**
     * Returns true, if the validation service is enabled for a country. So that system be able to restrict unwanted hit
     * to TP system
     */
    protected boolean isValidationServiceEnabled(GatewayServiceNameProperties serviceNameProp, String serviceName) {
        return "yes".equals(serviceNameProp.getValidationService(serviceName));
    }

    /**
     * Returns true, if the service is enabled for a country. So that system be able to restrict unwanted hit to TP
     * system
     */
    protected boolean isEnrichmentServiceEnabled(GatewayServiceNameProperties serviceNameProp, String serviceName) {
        return "yes".equals(serviceNameProp.getEnrichmentService(serviceName));
    }

    protected ServiceRequest getServiceRequestPayload(BaseDto baseDto, String serviceType) {
        CustomerDto customerDetails = new CustomerDto();
        customerDetails.setRelationshipNo(cslRequestContext.getRelId());
        customerDetails.setRelationshipType(cslRequestContext.getCustomerType());
        baseDto.setCustomerDetails(customerDetails);

        HashMap<String, Object> payload = new HashMap<String, Object>();
        payload.put("serviceRequests", baseDto);

        ServiceRequest serviceRequest = new ServiceRequest();
        serviceRequest.setServiceType(serviceType);
        serviceRequest.setStatus("INIT");
        serviceRequest.setPayload(payload);
        serviceRequest.setCreatedBy(cslRequestContext.getOperatorId());
        return serviceRequest;
    }

    public CreditCardProperties getCreditCardPropertiesByCountry(String countryCode){
        CreditCardProperties countryProp = (CreditCardProperties) CardUtil.getValueByKey(creditCardProperties, StringUtils.upperCase(countryCode));
        if(CardUtil.isEmptyOrNull(countryProp)){
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR,"Country Mapping Properties", "Not Found"));
        }
        return countryProp;
    }

    public void handleException(CreditCardVO creditCardVO, Throwable exception){
        if(!CardUtil.isEmptyOrNull(creditCardVO)
                && !CardUtil.isEmptyOrNull(creditCardVO.getInclude())
                && StringUtils.equalsIgnoreCase(CardConstant.INCLUDE_ONLINE, creditCardVO.getInclude())) {
            if (!CardUtil.isEmptyOrNull(exception)) {
                if (exception instanceof BusinessException) {
                    throw (BusinessException) exception;
                } else if (exception instanceof TechnicalException) {
                    throw (TechnicalException) exception;
                } else {
                    throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "handleException", "General Exception"));
                }
            }
        }
    }
}
