package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Data
@NoArgsConstructor
@JsonApiResource(type = "debit-cards")
public class DebitCardDto extends BaseDto {

    private static final long serialVersionUID = 5874886117375293696L;
    @JsonApiId
    private String id;
    @JsonProperty("card-num")
    private String cardNum;
    private String status;
    @JsonProperty("card-type")
    private String cardType;
    @JsonProperty("card-sub-type")
    private String cardSubType;
    @JsonIgnore
    private String statusCode;
    @JsonIgnore
    private String statusDescription;

    public String toString() {
        return ReflectionToStringBuilder.toString(this,	ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
