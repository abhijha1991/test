package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.sc.csl.retail.creditcard.dto.post.CardActivationDto;
import com.sc.csl.retail.creditcard.dto.post.PinChangeDto;

import io.katharsis.resource.annotations.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Data
@ToString
@NoArgsConstructor
@JsonApiResource(type = "credit-cards")
public class CreditCardDto extends BaseDto implements Cloneable {

    private static final long serialVersionUID = 5874886117375293695L;

    @JsonApiId
    private String cardID;
    private String variant;
    private String franchise;
    private String prod;
    @JsonProperty("sub-prod")
    private String subProd;
    @JsonProperty("act-type")
    private String acType;
    @JsonProperty("card-num")
    private String cardNum;
    @JsonProperty("desc")
    private String desc;
    @JsonProperty("desc-code")
    private String descCode;
    @JsonProperty("exp-dt")
    private String expDt;
    @JsonProperty("primary-flag")
    private String isPrimary;
    @JsonProperty("card-image-name")
    private String cardImgName;
    @JsonProperty("currency-code")
    private String currencyCode;
    @JsonProperty("cust-short-name")
    private String custShortName;
    @JsonProperty("islamic-flag")
    private String islamicFlag;
    private String status;
    @JsonProperty("card-type")
    private String cardType;
    @JsonProperty("blk-ind")
    private String blkInd;
    @JsonProperty("block-code")
    private String blockCode;
    @JsonProperty("card-status")
    private String cardStatus;
    @JsonProperty("blkcd-dt-rpl-period")
    private String blkCdDtRplPeriod;
    @JsonProperty("card-expired")
    private String cardExpired;
    @JsonProperty("card-rpl-trans-eff-dt")
    private String cardRplTrnEffDate;
    @JsonProperty("card-rpl-status")
    private String cardRplStatus;
    @JsonProperty("statement-flag")
    private String statementFlag;
    @JsonProperty("statement-flag-unmapped")
    private String statementFlagUnmapped;
    @JsonProperty("alt-block-code")
    private String altBlockCode;
    @JsonProperty("card-rpl-alt-block-code")
    private String cardRplAltBlockCode;
    @JsonProperty("combo-flag")
    private String isComboFlag;
	@JsonProperty("agreement-status")
	private BigInteger agreementStatus;
    @JsonProperty("agmt-sts-ind")
    private String agmtStsInd;
    @JsonProperty("active-cards")
    private String activeCards;
    @JsonProperty("fee-type")
    private String feeType;
	@JsonProperty("eligible-fee-waiver")
	private String uiEligibleFeeWaiver="No";
	@JsonIgnore
	private String eligibleFeeWaiver;
    @JsonProperty("collateral-code")
    private String collateralCode;
    @JsonProperty("active-bal-transfer-acc-flag")
    private String activeBalTransferAccFlag;
	@JsonProperty("card-eligibility")
    private CreditCardEligibilityDto creditCardEligibility;
    @JsonProperty("available-customer-rewardpoint")
    private String availableCustomerRewardpoints;
    @JsonProperty("card-available-reward-point")
    private RewardPointDto cardAvailableRewardpoint;
    @JsonProperty("is-card-partial-payment")
    private String isCardHasPartialPayment = "N";
    private String srName;
    private String rewardpointdemption;
    @JsonProperty("eligible-credit-cards")
    private List<CreditCardDto> eligibleCreditCards;
    @JsonProperty("credit-card-request")
    private List<CreditCardDto> postCreditCards;
    private List<CreditCardCancelDto> creditCardCancelRequests = null;
    @JsonProperty("request-type")
    private String requestType;
    @JsonProperty("reason")
    private String reason;
    @JsonProperty("amount")
    private String amount;
    @JsonIgnore
    private String eligibleForCreditBalRefund;
    @JsonProperty("balance-refundflag")
    private String balanceRefundFlag;
    @JsonProperty("excess-amount")
    private String excessAmount;
    @JsonProperty("available-limit")
    private String avlblLimit;
    @JsonProperty("credit-limit")
    private String creditLimit;
    @JsonProperty("permanent-credit-limit")
    private String permanentLimit;
    @JsonProperty("customer-credit-limit")
    private String customerCreditLimit;
    @JsonProperty("customer-available-credit-limit")
    private String customerAvailableCreditLimit;
    @JsonProperty("current-balance")
    private String currentBalance;
    @JsonProperty("delinquency-amount")
    private String delinquencyAmount;
    @JsonProperty("delinquency-cycle1-amount")
    private String delinquencyCycle1Amt;
    @JsonProperty("delinquency-cycle2-amount")
    private String delinquencyCycle2Amt;
    @JsonProperty("delinquency-cycle3-amount")
    private String delinquencyCycle3Amt;
    @JsonProperty("delinquency-cycle4-amount")
    private String delinquencyCycle4Amt;
    @JsonProperty("delinquency-cycle5-amount")
    private String delinquencyCycle5Amt;
    @JsonProperty("delinquency-cycle6-amount")
    private String delinquencyCycle6Amt;
    @JsonProperty("delinquency-cycle7-amount")
    private String delinquencyCycle7Amt;
    @JsonProperty("delinquency-cycle8-amount")
    private String delinquencyCycle8Amt;
    @JsonProperty("delinquency-flag")
    private String delinquencyFlag;
    @JsonProperty("statement-balance")
    private String statementBalance;
    @JsonProperty("minimum-amountdue")
    private String minimumAmountDue;
    @JsonProperty("customer-blockcode")
    private String custBlockCode;
    @JsonProperty("payment-duedate")
    private String paymentDueDate;
    @JsonProperty("balance-duedate")
    private Date balanceDueDate;
    private String cardNumbers;
    @JsonIgnore
    private String include;
//    @JsonIgnore
    private String validateLimit;
    @JsonProperty("existing-credit-limit")
    private CardBalanceLimitDto existingLimitDetails;
    @JsonProperty("maximum-credit-limit")
    private CardBalanceLimitDto maximumLimitDetails;
    @JsonProperty("contact-number")
    private String contactNumber;
    @JsonProperty("cust-num")
    private String customerNumber;
    @JsonProperty("special-blocks")
    private String specialBlockCodes;
    @JsonProperty("org-num")
    private String orgNum;
    @JsonProperty("outstanding-balance")
    private BigDecimal outstandingBalance;
    @JsonProperty("override-code")

    private String overrideCode;
    @JsonIgnore
    private String reasonCode;

    private String functionCd;
    private String txnType;
    private String funcCode;
    private String seqNo;
    @JsonProperty("cash-advance-fee-rate")
    private BigDecimal cashAdvanceFeeRate;
    @JsonProperty("bank-charges-rate")
    private BigDecimal bankChargesRate;
    @JsonProperty("bank-charges-amount")
    private BigDecimal bankChargesAmount;
    @JsonIgnore
    private String eligibleForCreditCardCancel;  
    @JsonIgnore
    private String otpRequired;

    // Alert Message
    @JsonProperty("alerts")
    private Set<BusinessRuleAlert> alerts = null;

    /**
     * Add alert message in list
     */
    public void addAlert(BusinessRuleAlert alert) {
        if (this.alerts == null) {
            this.alerts = new LinkedHashSet<BusinessRuleAlert>();
        }
        this.alerts.add(alert);
    }

    @JsonApiRelation(serialize = SerializeType.LAZY,lookUp = LookupIncludeBehavior.AUTOMATICALLY_WHEN_NULL,opposite = "creditCardDto")
    @JsonProperty("cardtransactions")
	private List<CreditCardTransactionDto> cardtransactions;

    @JsonProperty("balances")
    @JsonApiRelation(serialize = SerializeType.LAZY)
    private EligibleInstallmentDto balances;

	@JsonProperty("receipt-id")
	private String receiptId;
	@JsonProperty("frontline-notes")
	private String frontlineNotes;
	//user selected value.
	@JsonProperty("basic-verification")
	private String basicVerification;
	@JsonProperty("addn-verification")
	private String addnVerification;
	@JsonProperty("frtln-user-type")
	private String frontLineUserType;
    @JsonProperty("card-embossing-infos")
    private List<CardEmbossingInfoDto> cardEmbossingInfos;
    @JsonProperty("pin-change")
    private PinChangeDto pinChangeDto;
    @JsonProperty("card-activation")
    private CardActivationDto cardActivationDto;
    
	@JsonProperty("embossed-name")
	private String embossedName;
    
	@JsonProperty("country-code")
	private String countryCode;

	
    @JsonProperty("activation-status")
    private String activationStatus;
    @JsonProperty("activation-status-code")
    private String activationStatusCode;
    @JsonProperty("card-rpl-status-ind")
    private String cardRplStatusInd;
    @JsonProperty("card-rpl-ind")
    private String cardRplInd;
    @JsonProperty("card-validity-status")
    private BigInteger cardValiditySts;
    @JsonProperty("is-mask-card-no")
    private String isMaskCardNo;
    
    private String language;

    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
