package com.sc.csl.retail.creditcard.config.properties;

import java.util.HashMap;
import java.util.Map;

import lombok.Data;
import lombok.ToString;

@ToString
@Data
public final class CreditCardProperties {

    private Map<String, String> errorCodes = new HashMap<String, String>();
    private Map<String, String> currencyCodes = new HashMap<String, String>();
    private Map<String, String> cardActivationErrorCodes = new HashMap<String, String>();
    private Map<String, String> uaasErrorCodes = new HashMap<String, String>();
    private Map<String, String> intlCountryCodes = new HashMap<String, String>();
    
    private GatewayHeaderProperties cardListProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardDetailsProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardListUsingCardNumProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardDetailsCardProfileProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardHistoryProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardDelinquencyProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardFinancialDetailsProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardUpdateStatusProperties = new GatewayHeaderProperties();
    private int productMappingBinLength = 0;
    private Map<String, String> productCodes = new HashMap<String, String>();
    private Map<String, String> config = new HashMap<String, String>();
    private String userName;
    private Map<String, String> productImages = new HashMap<String, String>();
    private CreditCardFilterProperties creditCardFilters = new CreditCardFilterProperties();
    private CreditCardFeeWaiverProperties creditCardFeeWaiverProps = new CreditCardFeeWaiverProperties();
    private CreditBalRefundProperties creditBalRefundProperties = new CreditBalRefundProperties();
    private CreditCardCancelProperties creditCardCancelProps = new CreditCardCancelProperties();
    private GatewayHeaderProperties eligiblePlanProperties = new GatewayHeaderProperties();
    private GatewayHeaderProperties cardLimitProperties = new GatewayHeaderProperties();
    private String otpMsgTemplate;
    
    private Map<String, String> transactionTypeIndicators = new HashMap<>();
    private CardActivationValidationProperties creditCardActivationProps = new CardActivationValidationProperties();
}
