package com.sc.csl.retail.creditcard.dto.security;

import org.apache.commons.lang3.StringUtils;

import lombok.Data;
@Data
public class UAASUserInfo {

    private String appId;
    private String groupId;
    private String userId;
    private String clientRequestId;
    private String apiKey;
  
    
    public void setClientRequestId(String clientRequestId) {
        this.clientRequestId = StringUtils.truncate(clientRequestId,35);
    }
}
