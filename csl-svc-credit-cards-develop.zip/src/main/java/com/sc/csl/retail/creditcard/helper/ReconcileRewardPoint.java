package com.sc.csl.retail.creditcard.helper;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.webmethods.jms.log.Log;
/**
 * @author 1553836
 * Sinha, Shantanu
 * Aug-17
 */
@Component
public class ReconcileRewardPoint {

	@Autowired
	private CreditCardService creditCardService;

	/**
	 * This method is used to fetch the customer level and card level reward
	 * point for all the countries
	 * 
	 * @param creditcardDto
	 * @param creditcardvo
	 * @param reconciledTransactionList
	 * @param journeyMap
	 * @param props
	 */
	@SuppressWarnings("unchecked")
	public void reconcileRewardPoint(CreditCardDto creditcardDto,
			CreditCardVO creditcardvo,
			List<CreditCardTransactionDto> reconciledTransactionList,
			Map<String, Object> journeyMap, CreditCardFeeWaiverProperties props) {
		Log.info("[reconcileRewardPoint-ENTRY]");
		List<CreditCardDto> creditCardList = null;

		if (null == journeyMap.get(CardConstant.KEY_CC_LIST)) {
			creditCardList = getAllCreditCardAndRewardPoints(creditcardvo,
					journeyMap);
		} else if (null != journeyMap.get(CardConstant.KEY_CC_LIST)) {
			creditCardList = (List<CreditCardDto>) journeyMap
					.get(CardConstant.KEY_CC_LIST);
		}
		double overAllrewardpoints = new Integer(0);
		if (journeyMap.get(CardConstant.KEY_OVERALL_REWARD_PTS) == null) {
			Iterator<CreditCardDto> creditcardListiterator = creditCardList
					.iterator();
			while (creditcardListiterator.hasNext()) {
				CreditCardDto creditcrddto = creditcardListiterator.next();
				if (!props.getRewardPoint()
						.get(CardConstant.KEY_EXCLUTION_BLOCK_CODES).toString()
						.contains("'"+creditcrddto.getBlockCode()+"'")) {
					overAllrewardpoints = overAllrewardpoints
							+ Double.parseDouble(creditcrddto
									.getCardAvailableRewardpoint()
									.getRewardsPoints());
				}
				journeyMap.put(CardConstant.KEY_OVERALL_REWARD_PTS,
						overAllrewardpoints);
			}
			if (journeyMap.put(CardConstant.KEY_OVERALL_REWARD_PTS,
					overAllrewardpoints) != null) {
				creditcardDto.setAvailableCustomerRewardpoints((journeyMap
						.get(CardConstant.KEY_OVERALL_REWARD_PTS).toString()));
			} else {
				creditcardDto.setAvailableCustomerRewardpoints(Integer
						.toString(CardConstant.ZERO));
			}

		}
		Log.info("[reconcileRewardPoint-EXIT]");

	}

	/**
	 * This method is to fetch the card level Reward points all all the cards
	 * for CCMS/C400
	 * 
	 * @param creditcardvo
	 * @param journeyMap
	 * @return list of CreditCArd with reward points
	 */
	public List<CreditCardDto> getAllCreditCardAndRewardPoints(
			CreditCardVO creditcardvo, Map<String, Object> journeyMap) {
		Log.info("[getAllCreditCardAndRewardPoints-ENTRY]");
		List<CreditCardDto> creditCardList = null;
		// pull all the cards at customer level from either ccms/ c400
		creditCardList = creditCardService.getAllCreditCards(creditcardvo);
		journeyMap.put(CardConstant.KEY_CC_LIST, creditCardList);
		Log.info("[getAllCreditCardAndRewardPoints-EXIT]");
		return creditCardList;
	}
}
