package com.sc.csl.retail.creditcard.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactions;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class TransactionRepository extends ResourceRepositoryBase<CreditCardTransactions, String>  {

    @Autowired
    private CardUtil cardUtil;

    @Autowired
    private CSLRequestContext cslRequestContext;


    @Autowired
    private CreditCardService creditCardService;

    public TransactionRepository() {
        super(CreditCardTransactions.class);

    }

    @Override
    public ResourceList<CreditCardTransactions> findAll(QuerySpec querySpec) {
        return null;
    }

/*    @Override
    public ResourceList<CreditCardTransactions> findAll(Iterable<String> ids, QuerySpec querySpec) {
        ResourceList<CreditCardTransactions> creditCardTransactionsResourceList = new DefaultResourceList<>();
        List<CreditCardVO> creditCardVOList = new ArrayList<>();
        ids.forEach(id-> {
            CreditCardVO creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
            creditCardVO.setCardNo(id);
            creditCardVOList.add(creditCardVO);
        });
        if(!creditCardVOList.isEmpty()) {
            List<CreditCardTransactions> txn = creditCardService.findProvidedCreditCardTransactions(creditCardVOList,querySpec);
            creditCardTransactionsResourceList.addAll(txn);
        }
        return creditCardTransactionsResourceList;
    }*/


}
