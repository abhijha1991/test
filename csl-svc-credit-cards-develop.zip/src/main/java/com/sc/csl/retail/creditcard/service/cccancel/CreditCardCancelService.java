package com.sc.csl.retail.creditcard.service.cccancel;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelEnricherProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelValidationProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardCancelDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.EncryptionDecryptionHelper;
import com.sc.csl.retail.creditcard.service.BaseService;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * @author 1554149
 * @since Sep 18, 2017
 */
@Slf4j
@Setter
@Service
public class CreditCardCancelService extends BaseService {
    @Autowired
    private CreditCardService creditCardService;
    @Autowired
    private EncryptionDecryptionHelper encryptDecryptHelper;

    public List<CreditCardDto> getEligibleCreditCards(CreditCardVO creditCardVO) {
        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setReasonCode(creditCardVO.getReasonCode());
        creditCardDto.setOperationName(creditCardVO.getOperationName());
        List<CreditCardDto> result = new ArrayList<CreditCardDto>();
        List<CreditCardDto> eligibleCreditCards = new ArrayList<CreditCardDto>();
        List<CreditCardDto> creditCardList = creditCardService.getAllCreditCards(creditCardVO);
        log.debug("[Customer ID: " + cslRequestContext.getRelId() + "] [Country: " + cslRequestContext.getCountry()
                + "] [No of Credit Cards: " + creditCardList.size() + "]");

        CreditCardCancelProperties ccCancelProperties = getCreditCardCancelPropertiesBean();
        // Credit Card Cancel - Eligibility Validator
        String beanId = MessageFormat.format(CardConstant.BEAN_ID_CC_CANCEL_VALIDATOR, cslRequestContext.getCountry()
                .toUpperCase());
        CreditCardCancelValidator validator = (CreditCardCancelValidator) getBean(beanId);

        for (CreditCardDto creditCard : creditCardList) {
            creditCard.setReasonCode(creditCardVO.getReasonCode());
            creditCard.setLanguage(cslRequestContext.getLanguage());

            if (StringUtils.isEmpty(creditCardDto.getIsComboFlag())
                    && CardConstant.CONS_Y.equals(creditCard.getIsComboFlag())) {
                // Set flag in root tag
                creditCardDto.setIsComboFlag(creditCard.getIsComboFlag());
            }
            // Balance Transfer Account
            if (!CardConstant.CONS_Y.equals(creditCardDto.getActiveBalTransferAccFlag())
                    && isActiveBalanceTransferAccount(creditCard, ccCancelProperties.getValidation())) {
                // Set flag in root tag
                creditCardDto.setActiveBalTransferAccFlag(CardConstant.CONS_Y);
            }

            if (validator.isValidCreditCard(creditCardVO, creditCard, ccCancelProperties)) {
                String encryptedCardNumber = encryptDecryptHelper.performEncryptDecrypt(6, 4, creditCard.getCardNum(),
                        CardConstant.ENCRYPT, creditCardVO.getCustomerId());
                creditCard.setCardNum(encryptedCardNumber);
                eligibleCreditCards.add(creditCard);
            }
        }
        creditCardDto.setEligibleCreditCards(eligibleCreditCards);
        result.add(creditCardDto);
        return result;
    }

    /**
     * <pre>
     * Method does below thing
     *  - Data Enrichment
     *  - Post to eOps via Service Request Entity
     *  - Sends Unique Reference No to UI
     * </pre>
     */
    public CreditCardDto requestCreditCardCancellation(CreditCardDto creditCardDto) {
        if (CardUtil.isEmptyOrNull(creditCardDto.getCreditCardCancelRequests())) {
            throw new BusinessException(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_REQUEST);
        }
        log.debug("[Operation: " + creditCardDto.getOperationName() + "] [Credit Card Details: "
                + creditCardDto.getCreditCardCancelRequests() + "] [Customer ID: " + cslRequestContext.getRelId()
                + "] [Country: " + cslRequestContext.getCountry() + "]");
        CreditCardCancelEnricherProperties ccCancelEnricherProperties = getCreditCardCancelPropertiesBean()
                .getEnricher();

        for (CreditCardCancelDto creditCardCancelDto : creditCardDto.getCreditCardCancelRequests()) {
            enrichCreditCardCancelRequest(creditCardCancelDto, ccCancelEnricherProperties);
        }
        // POST - CC CANCELLATION REQUEST
        log.debug("[Post Credit Card Cancellation Request] [Credit Card Details: "
                + creditCardDto.getCreditCardCancelRequests() + "] [Customer ID: " + cslRequestContext.getRelId()
                + "] [Country: " + cslRequestContext.getCountry() + "]");
        creditCardDto.setTargetProcessID(ccCancelEnricherProperties.getProcessId());
        ServiceRequest serviceRequest = getServiceRequestPayload(creditCardDto,
                ccCancelEnricherProperties.getServiceType());
        serviceRequest = serviceRequestJsonApiGateway.createServiceRequest(serviceRequest);
        return creditCardDto;
    }

    private boolean isActiveBalanceTransferAccount(CreditCardDto creditCardDto,
            CreditCardCancelValidationProperties ccCancelValidationProperties) {
        if (StringUtils.isBlank(ccCancelValidationProperties.getEligibleBalTransferAccountNumber())
                || StringUtils.isBlank(ccCancelValidationProperties.getIneligibleBalTransferBlockCode())) {
            return false;
        }
        Pattern pattern = Pattern.compile(ccCancelValidationProperties.getEligibleBalTransferAccountNumber());
        Matcher matcher = pattern.matcher(creditCardDto.getCardNum());
        if (matcher.matches()) {
            // Balance Transfer Account found, check the status
            return !CardUtil.isValueInList(ccCancelValidationProperties.getIneligibleBalTransferBlockCode(),
                    creditCardDto.getBlockCode());
        }
        return false;
    }

    /**
     * Data enrichment, invoke enrichment service. Most of the countries will follow the generic approach. If country
     * specific logic is required, then we can have a country specific class and implement that particular logic alone.
     */
    private void enrichCreditCardCancelRequest(CreditCardCancelDto creditCardCancelDto,
            CreditCardCancelEnricherProperties ccCancelEnricherProperties) {
        // Data Enrichment
        String beanId = MessageFormat.format(CardConstant.BEAN_ID_CC_CANCEL_ENRICHER, cslRequestContext.getCountry()
                .toUpperCase());
        CreditCardCancelEnricher enricher = (CreditCardCancelEnricher) getBean(beanId);
        enricher.process(creditCardCancelDto, ccCancelEnricherProperties);
    }

    private CreditCardCancelProperties getCreditCardCancelPropertiesBean() {
        return getCreditCardPropertiesBean().getCreditCardCancelProps();
    }
}
