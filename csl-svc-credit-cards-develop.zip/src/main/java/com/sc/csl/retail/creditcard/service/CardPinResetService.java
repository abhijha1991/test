package com.sc.csl.retail.creditcard.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.customer.CustomerContact;
import com.sc.csl.retail.creditcard.dto.post.OtpInfo;
import com.sc.csl.retail.creditcard.dto.post.PinChangeDto;
import com.sc.csl.retail.creditcard.dto.security.SmsOtp;
import com.sc.csl.retail.creditcard.dto.security.UAASRequest;
import com.sc.csl.retail.creditcard.exception.CardActivationErrorCode;
import com.sc.csl.retail.creditcard.exception.CardException;
import com.sc.csl.retail.creditcard.exception.UAASErrorCode;
import com.sc.csl.retail.creditcard.gateway.csl.CustomerJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.SmsOtpGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.UAASUtil;
import com.sc.csl.retail.creditcard.service.security.UAASServiceGateway;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import io.katharsis.repository.response.HttpStatus;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CardPinResetService {

	@Autowired
	private UAASUtil uaasUtil;

	@Autowired
	private CSLRequestContext cslRequestContext;

	@Autowired
	UAASServiceGateway uaasServiceGateway;

	@Autowired
	private CreditCardValidator cardValidator;

	@Autowired
	private CardActivationProcessingService cardProcessingService;

	@Autowired
	private CreditCardV1SoapGateway creditCardV1SoapGateway;
	
	@Autowired
	private CardUtil cardUtil;
	
	@Autowired
	private CustomerJsonApiGateway customerGateway;

	@Autowired
	private SmsOtpGateway smsOtpGateway;

	private static final String[] PINCHNG_RESP_CODES = { "1212", "1318", "1320", "1032", "1034", "1225", "1252",
			"1344" };

	private static final String STATUS_CODE_KEY = "statusCode";
	private static final String ERROR_MESSAGE = "errorMessage";
	private static final String RELID = "relId";
	
	/**
	 * Used to convert updatePin CSL format to UAAS format and getting response
	 * from gateway
	 */
	public CreditCardDto updatePin(CreditCardDto creditCardDto) {

		cardValidator.validatePinResetRequest(creditCardDto);

		validate2FA(creditCardDto);
		
		UAASRequest uaasRequest = uaasUtil.prepareUAASPinSetRequest(creditCardDto, cslRequestContext);
		

		Map<String, UAASRequest> requestMap = new HashMap<>();
		requestMap.put("request", uaasRequest);

		Response uaasResponse = null;
		try {
			uaasResponse = uaasServiceGateway.updatePin(CSLJsonUtils.toJson(requestMap));
		} catch (Exception ex) {
			throw new TechnicalException(TemplateErrorCode.create(UAASErrorCode.UAAS_CONNECTION_ERROR,
					"UAAS Service Error", ex.getMessage()));
		}

		String uaasResponseStr = uaasResponse.readEntity(String.class);

		if (CardUtil.isEmptyOrNull(uaasResponseStr)) {
			throw new TechnicalException(TemplateErrorCode.create(UAASErrorCode.UAAS_CONNECTION_ERROR,
					"UAAS Service Error", "Empty UAAS Response"));
		}
		PinChangeDto pinChangeRes = CSLJsonUtils.parseJson(uaasResponseStr, PinChangeDto.class);

		log.info("Pin Change  UAAS Response -> " + pinChangeRes);

		Map<String, String> uaasErrorCodeMap = uaasUtil.getUAASErrorCodes();

		boolean isCardActivationSuccessful = true;

		if (!CardUtil.isEmptyOrNull(uaasErrorCodeMap)
				&& pinChangeRes.getStatusCode().equalsIgnoreCase(CardConstant.UAAS_SUCCESS_CODE)) {

			CreditCardVO cardActivationResponse = null;
			if (creditCardDto.getOperationName().equalsIgnoreCase(CardConstant.OPERATION_CC_PINACTIV)
					&& CardConstant.CCMS_COUNTRY_LIST.contains(cslRequestContext.getCountry())) {
				
				cardActivationResponse = creditCardV1SoapGateway.updateCardStatus(cardUtil.populateCreditCardVO(cslRequestContext));
				if (cardActivationResponse != null) {
					isCardActivationSuccessful = ArrayUtils.contains(CardGatewayConstant.EDMI_SUCCESS_RES_CDS,
							cardActivationResponse.getStatusCode());
					log.info("Card Activation {} with Status {}", isCardActivationSuccessful,
							cardActivationResponse.getStatusCode());
				}
			}
			String receiptNum = getReceiptNumber();
			if (isCardActivationSuccessful) {			
				creditCardDto.setReceiptId(receiptNum);
				creditCardDto.setStatus((cardActivationResponse != null) ? cardActivationResponse.getStatusCode()
						: pinChangeRes.getStatusCode());
				creditCardDto.setErrorDescription((cardActivationResponse != null)
						? cardActivationResponse.getStatusDescription() : pinChangeRes.getErrorMessage());
				log.debug("Pin Change  ReceiptNUmber Response -> ");
				
				// setting below fields for post process
				creditCardDto.setCountryCode(cslRequestContext.getCountry());
				creditCardDto.setChannel(cslRequestContext.getChannel());
				creditCardDto.setRelId(cslRequestContext.getRelId());
				creditCardDto.setLanguage(cslRequestContext.getLanguage());
				creditCardDto.setCustomerId(cslRequestContext.getUaas2id());

				cardProcessingService.postProcess(creditCardDto);
			}else{
				creditCardDto.setReceiptId(receiptNum);
				creditCardDto.setStatus(cardActivationResponse.getStatusCode());
				creditCardDto.setErrorDescription(cardActivationResponse.getStatusDescription());
				creditCardDto.setCountryCode(cslRequestContext.getCountry());
				cardProcessingService.insertAuditDetails(creditCardDto);
			}
		} else if (ArrayUtils.contains(PINCHNG_RESP_CODES, pinChangeRes.getStatusCode())) {
			String receiptNum = getReceiptNumber();
			creditCardDto.setReceiptId(receiptNum);
			creditCardDto.setStatus(pinChangeRes.getStatusCode());
			creditCardDto.setErrorDescription(pinChangeRes.getErrorMessage());
			creditCardDto.setCountryCode(cslRequestContext.getCountry());
			cardProcessingService.insertAuditDetails(creditCardDto);
		} else {
			if ("400".equals(pinChangeRes.getStatusCode())) {
				throw new BusinessException(TemplateErrorCode.create(UAASErrorCode.UAAS_BAD_REQUEST, "UAAS Bad Request",
						pinChangeRes.getErrorMessage()));
			} else {
				String errorCode = (String) CardUtil.getValueByKey(uaasErrorCodeMap, pinChangeRes.getStatusCode());
				throw new BusinessException(TemplateErrorCode.create(UAASErrorCode.getBusinessErrorCode(errorCode),
						pinChangeRes.getStatusCode(), pinChangeRes.getErrorMessage()));
			}
		}
		return getResponseDto(creditCardDto);
	}

	private String getReceiptNumber() {
		return cardProcessingService.generateReceiptNumber();
	}

	private CreditCardDto getResponseDto(CreditCardDto creditCardDto) {
		CreditCardDto responseDto = new CreditCardDto();
		responseDto.setReceiptId(creditCardDto.getReceiptId());
		responseDto.setStatus(creditCardDto.getStatus());
		responseDto.setErrorDescription(creditCardDto.getErrorDescription());
		return responseDto;
	}
	
	private void validate2FA(CreditCardDto creditCardDto) {

		if (StringUtils.isNotBlank(cslRequestContext._otpToken())) {
			creditCardDto.getPinChangeDto().setOtpInfo(constructOtpInfo());
			cardValidator.validatePinOTPBlock(creditCardDto);
		} else {
			List<CustomerContact> customerContacts = null;
			try {
				customerContacts = customerGateway.getCustomerContact();
			} catch (Exception ex) {
				if (!(ex instanceof TechnicalException) && !(ex instanceof BusinessException)) {
					throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
				} else {
					throw ex;
				}
			}

			if (CardUtil.isEmptyOrNull(customerContacts)) {
				throw new BusinessException(CardActivationErrorCode.CSL_CREDIT_CARD_NO_CONTACT_FOUND);
			}

			
			Optional<CustomerContact> customerContactOptional = customerContacts.stream()
					.filter(m -> m.getContactClassification().equals(CardConstant.CONTACT_TYPE_MOBILE)).findFirst();
					
			CustomerContact customerContact = null;
			if (customerContactOptional.isPresent()) {
				customerContact = customerContactOptional.get();
			} else {
				throw new BusinessException(CardActivationErrorCode.CSL_CREDIT_CARD_NO_CONTACT_FOUND);
			}

			String contactNumber = customerContact.getContactDetails();

			String messageTemplate = cardProcessingService.getOtpMessageTemplateDetail(
					cslRequestContext.getCountry() != null ? cslRequestContext.getCountry()
							: creditCardDto.getCountryCode(),
					creditCardDto.getOperationName(), cslRequestContext.getLanguage() != null
							? cslRequestContext.getLanguage() : CardConstant.ENG_LANG_CODE);// loaded
																							// from
																							// DB
			SmsOtp smsOtp = null;
			try {
				smsOtp = smsOtpGateway.sendOtp(contactNumber, messageTemplate);
			} catch (Exception ex) {
				if (ex instanceof TechnicalException) {
					throw new TechnicalException(TemplateErrorCode.create(UAASErrorCode.UAAS_CONNECTION_ERROR,
							"UAAS Service Error", ex.getMessage()));
				} else {
					throw new TechnicalException(CardActivationErrorCode.CSL_SERVICE_ERROR);
				}
			}

			Map<String, Object> otpResponseMap = CSLJsonUtils.convertValue(smsOtp, Map.class);
			if (CardConstant.UAAS_SUCCESS_CODE.equals(smsOtp.getStatusCode())) {
				otpResponseMap.remove(STATUS_CODE_KEY);
				otpResponseMap.remove(ERROR_MESSAGE);
				otpResponseMap.remove(RELID);
				otpResponseMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_REQUIRED);
			} else {
				otpResponseMap.put(CardConstant.OTP_TITLE, CardConstant.OTP_FAILED);
			}
			throw new CardException(HttpStatus.UNAUTHORIZED_401, CSLJsonUtils.toJson(otpResponseMap));
		}
	}

	private OtpInfo constructOtpInfo() {
		OtpInfo otpInfo = new OtpInfo();
		@SuppressWarnings({ "unchecked", "deprecation" })
		List<Map<String, Object>> otpTokenList = CSLJsonUtils.parseJson(cslRequestContext._otpToken(), ArrayList.class);
		String otpBlockJson = CSLJsonUtils.toJson(otpTokenList.get(0).get("smsOtp"));
		otpInfo = CSLJsonUtils.parseJson(otpBlockJson, OtpInfo.class);
		return otpInfo;
	}

}
