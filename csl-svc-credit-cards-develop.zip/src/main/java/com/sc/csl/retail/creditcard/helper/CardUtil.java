package com.sc.csl.retail.creditcard.helper;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.EligibleInstallmentDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CardUtil {

	@Autowired
	private CSLRequestContext cslRequestContext;

	@Autowired
	private ApplicationContext applicationContext;

	@Value("${application.service.gateway.timeout}")
	private String serviceTimeOut;
	
    private static final String PREFIX_WHITE_LIST = "W";
    private static final String PREFIX_BLACK_LIST = "B";

    public static boolean isEmptyOrNull(String value) {
        return StringUtils.isBlank(value);
    }

    public static boolean isEmptyOrNull(Object value) {
        return (value == null);
    }

    public static boolean isEmptyOrNull(Map<?, ?> value) {
        return (value == null || value.isEmpty());
    }

    public static boolean isEmptyOrNull(List<?> value) {
        return (value == null || value.isEmpty());
    }

    public static Object getValueByKey(Map<?, ?> value, String key) {
        if (!isEmptyOrNull(value) && !isEmptyOrNull(key) && value.containsKey(key)) {
            return value.get(key);
        }
        return null;
    }

    public static boolean isRegexMatch(String regex, String input) {
        boolean isMatch = true;

        String matchType = StringUtils.substring(regex, 0, 1);
        regex = StringUtils.substring(regex, 2);
        Pattern pattern = Pattern.compile(regex);
        boolean isPatternMatch = pattern.matcher(input).matches();
        if ((PREFIX_WHITE_LIST.equals(matchType) && !isPatternMatch) || (PREFIX_BLACK_LIST.equals(matchType) && isPatternMatch)) {
            isMatch = false;
        }

        return isMatch;
    }

    public static String getProductCode(String productCode) {
        if (isEmptyOrNull(productCode)) {
            productCode = CardConstant.PRODUCT_CODE_DEFAULT;
        } else {
            if (StringUtils.length(productCode) < 3) {
                productCode = StringUtils.leftPad(productCode, 3, CardConstant.PRODUCT_CODE_PREFIX_ZERO);
            }
        }
        return productCode;
    }

    public static String getProductDescription(String productCode, String cardNo, String cardType, Map<String, String> productCodeMap, int productMappingBinLength, Map<String, String> cardTypeMap, String countryCode) {
        String productDesc = CardConstant.PRODUCT_DESC_DEFAULT;;
        if (!isEmptyOrNull(productCodeMap)) {
            if(!isEmptyOrNull(cardNo) && StringUtils.length(cardNo) == CardConstant.AMEX_CARD_MIN_LENGTH){
                cardNo = StringUtils.leftPad(cardNo, CardConstant.AMEX_CARD_LENGTH, CardConstant.AMEX_CARD_PREFIX);
            }
            if(productMappingBinLength > 0 && !isEmptyOrNull(cardNo) && StringUtils.length(cardNo) >= productMappingBinLength){
                productCode = productCode + CardConstant.PAD_UNDERSCORE + StringUtils.substring(cardNo,0, productMappingBinLength);
            }
            productDesc = (String) getValueByKey(productCodeMap, productCode);
            if (isEmptyOrNull(productDesc)) {
                productDesc = getOriginalCardType(cardNo, cardTypeMap) + CardConstant.PAD_SPACE + CardConstant.PRODUCT_DESC_DEFAULT;
            }

            if (!isEmptyOrNull(cardType) && !ArrayUtils.contains(CardConstant.PRODUCT_DESC_SUFFIX_NA_CTR_CDS, countryCode)) {
                if (StringUtils.equals(CardConstant.CONS_Y, cardType)) {
                    productDesc = productDesc + CardConstant.PRIMARY_CARD_PRODUCT_DESC_SUFFIX;
                } else {
                    productDesc = productDesc + CardConstant.SUPPLEMENTARY_CARD_PRODUCT_DESC_SUFFIX;
                }
            }
        }
        return productDesc;
    }

    public static String getProductDescCode(String productCode, String cardNo, int productMappingBinLength) {
        String productDescCode = CardConstant.PRODUCT_DESC_DEFAULT;;
        if (!isEmptyOrNull(productCode)) {
            if(!isEmptyOrNull(cardNo) && StringUtils.length(cardNo) == CardConstant.AMEX_CARD_MIN_LENGTH){
                cardNo = StringUtils.leftPad(cardNo, CardConstant.AMEX_CARD_LENGTH, CardConstant.AMEX_CARD_PREFIX);
            }
            if(productMappingBinLength > 0 && !isEmptyOrNull(cardNo) && StringUtils.length(cardNo) >= productMappingBinLength){
                productDescCode = StringUtils.substring(cardNo,0, productMappingBinLength)+ productCode;
            }
        }
        return productDescCode;
    }

    public static String getProductImage(String cardNo, String productCode, Map<String, String> productImageMap, int productMappingBinLength) {
        String cardImg = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(productCode) || !isEmptyOrNull(cardNo)) {
            if(StringUtils.length(cardNo) == CardConstant.AMEX_CARD_MIN_LENGTH){
                cardNo = StringUtils.leftPad(cardNo, CardConstant.AMEX_CARD_LENGTH, CardConstant.AMEX_CARD_PREFIX);
            }
            if(productMappingBinLength > 0 && !isEmptyOrNull(cardNo) && StringUtils.length(cardNo) >= productMappingBinLength){
                productCode = productCode + CardConstant.PAD_UNDERSCORE + StringUtils.substring(cardNo,0, productMappingBinLength);
            }
            cardImg = (String) getValueByKey(productImageMap, productCode);
            if (isEmptyOrNull(cardImg)) {
                cardImg = StringUtils.upperCase(CardConstant.CARD_IMAGE_DEFAULT + CardConstant.PAD_UNDERSCORE + StringUtils.substring(cardNo, 0, 1));
                cardImg = (String) getValueByKey(productImageMap, cardImg);
                if (isEmptyOrNull(cardImg)) {
                    cardImg = CardConstant.PAD_EMPTY;
                }
            }
        }
        return cardImg;
    }

    public static String getCardBlockCode(String blockCode) {
        String res = StringUtils.EMPTY;
        if (!isEmptyOrNull(blockCode)) {
            res = blockCode;
        }
        return res;
    }

    private static String getKeyRegexMatchBySearchStr(String searchStr, Map<String, String> maps) {
        for (Map.Entry<String, String> entry : maps.entrySet()) {
            if (!isEmptyOrNull(entry.getValue())
                    && StringUtils.startsWithAny(entry.getValue(), PREFIX_WHITE_LIST, PREFIX_BLACK_LIST)
                    && CardUtil.isRegexMatch(entry.getValue(), searchStr)) {
                return entry.getKey();
            }
        }
        return CardConstant.PAD_EMPTY;
    }

    public static String getCardType(String cardNo, Map<String, String> cardTypes) {
        String cardType = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(cardNo) && !isEmptyOrNull(cardTypes)) {
            cardType = getKeyRegexMatchBySearchStr(StringUtils.substring(cardNo, 0, 1), cardTypes);
            if (!isEmptyOrNull(cardType)
                    && cardTypes.containsKey(cardType + CardConstant.CARD_TYPE_EXCLUDE_CARD_START_WITH_KEY)
                    && !isEmptyOrNull(cardTypes.get(cardType + CardConstant.CARD_TYPE_EXCLUDE_CARD_START_WITH_KEY))) {
                if (StringUtils.startsWithAny(cardNo, StringUtils.split(cardTypes.get(cardType + CardConstant.CARD_TYPE_EXCLUDE_CARD_START_WITH_KEY), CardConstant.PAD_COMMA))) {
                    cardType = CardConstant.PAD_EMPTY;
                }
            }
        }
        return cardType;
    }
    
    public static String getOriginalCardType(String cardNo, Map<String, String> cardTypes) {
        String cardType = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(cardNo) && !isEmptyOrNull(cardTypes)) {
            cardType = getKeyRegexMatchBySearchStr(StringUtils.substring(cardNo, 0, 1), cardTypes);
        }
        return cardType;
    }

    public static String getCardBlockCodeIndicator(String blockCode, Map<String, String> blockInds) {
        String blkInd = CardConstant.CARD_BLOCK_CODE_INDICATOR_DEFAULT;
        if (!isEmptyOrNull(blockInds)) {
            if (isEmptyOrNull(blockCode)) {
                blockCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
            }
            blkInd = getKeyRegexMatchBySearchStr(blockCode, blockInds);
        }
        return blkInd;
    }

    public static String getAgreementStatusIndicator(BigInteger agmtSts, Map<String, String> agmtStsInds) {
        String blkInd = CardConstant.CARD_BLOCK_CODE_INDICATOR_DEFAULT;
        if (!isEmptyOrNull(agmtStsInds) && !isEmptyOrNull(agmtSts)) {
            blkInd = getKeyRegexMatchBySearchStr(agmtSts + CardConstant.PAD_EMPTY, agmtStsInds);
        }
        return blkInd;
    }
    public static String setCardStatus(String cardStatus, Map<String, String> cardStatusMap) {
        String res = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(cardStatus) && !isEmptyOrNull(cardStatusMap)) {
            res = getKeyRegexMatchBySearchStr(cardStatus, cardStatusMap);
        }
        return res;
    }

    public static void setGatewayProperties(CreditCardVO creditCardVO) {
        creditCardVO.setTrackingId(CardConstant.GATEWAY_TRACKING_ID_PREFIX + UUID.randomUUID().toString());
        creditCardVO.setMessageTimestamp(getCurrentDateTime());
        log.info("[setGatewayProperties creditCardVO.trackingId: {}", creditCardVO.getTrackingId());
    }

    public static XMLGregorianCalendar toGetXMLGregorianCalendar() {
        XMLGregorianCalendar date2 = null;
        try {
            GregorianCalendar c = new GregorianCalendar();
            c.setTime(new Date());
            date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
        } catch (Exception e) {
            throw new TechnicalException(TemplateErrorCode.create(CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_GENERAL_ERROR, "toGetXMLGregorianCalendar", "Invalid Date"));
        }
        return date2;
    }

    public static String getCurrentDateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CardConstant.TIME_STAMP_FORMAT);
        return now.format(formatter);
    }

    public CreditCardVO populateCreditCardVO(CSLRequestContext cslRequestContext) {
        log.info("Entered in populateCreditCardVO cslRequestContext-{}", cslRequestContext);
        CreditCardVO creditCardVO = new CreditCardVO();
        if (!isEmptyOrNull(cslRequestContext)) {
            log.debug("[populateCreditCardVO cslRequestContext - RelId, customerId, customerType] : {},{},{}", cslRequestContext.getRelId(), cslRequestContext.getCustomerId(), cslRequestContext.getCustomerType());
            creditCardVO.setCslRequestContext(cslRequestContext);
            creditCardVO.setChannelId(cslRequestContext.getChannel());
            creditCardVO.setCountryCode(cslRequestContext.getCountry());
            creditCardVO.setRequestId(cslRequestContext.getRequestId());
            creditCardVO.setSessionId(cslRequestContext.getUaas2id());
            creditCardVO.setRelId(cslRequestContext.getRelId());
            creditCardVO.setCustomerType(cslRequestContext.getCustomerType());
            creditCardVO.setCustomerId(cslRequestContext.getCustomerId());
            creditCardVO.setLangCode(cslRequestContext.getLanguage());
            log.info("populateCreditCardVO creditCardVO-{}", creditCardVO);
        }
        return creditCardVO;
    }

    public CreditCardDto populateCreditCardDTO(CSLRequestContext cslRequestContext, CreditCardDto cardDto) {
        log.info("Entered in populateCreditCardDTO cslRequestContext-{}", cslRequestContext);
        
        if (!isEmptyOrNull(cslRequestContext)) {
            log.debug("[populateCreditCardDTO cslRequestContext - RelId, customerId, customerType] : {},{},{}", cslRequestContext.getRelId(), cslRequestContext.getCustomerId(), cslRequestContext.getCustomerType());
            
            cardDto.setChannel(cslRequestContext.getChannel());
            cardDto.setCountry(cslRequestContext.getCountry());
            cardDto.setRelId(cslRequestContext.getRelId());
            cardDto.setCustomerType(cslRequestContext.getCustomerType());
            cardDto.setCustomerId(cslRequestContext.getCustomerId());
            log.info("populateCreditCardDTO creditCardDTO-{}", cardDto);
        }
        
        log.info("Exit from populateCreditCardDTO...... ");
        return cardDto;
    }

    
	public QuerySpec populateQuerySpec(QuerySpec querySpec, CreditCardVO creditCardVO) {
		log.info("populateQuerySpec querySpec & CreditCardVO-{}", querySpec,creditCardVO);
		if(isEmptyOrNull(querySpec)){
			return querySpec;
		}
		if(isEmptyOrNull(creditCardVO)){
			creditCardVO = new CreditCardVO();
		}
		processFilterSpec(querySpec.getFilters() != null ? querySpec.getFilters() : Collections.emptyList(), creditCardVO);
		return querySpec;
	}
	
	private void processFilterSpec(List<FilterSpec> filterList, CreditCardVO creditCardVO){
		if(!CollectionUtils.isEmpty(filterList)){
			for(FilterSpec filterSpec : filterList){

				if (filterSpec != null
						&& StringUtils.contains(filterSpec.toString(),
								CardConstant.FILTER_ACTIVE_CARDS)
						&& StringUtils.isNotBlank((String) filterSpec
								.getValue())) {
					creditCardVO.setActiveCards((String) filterSpec.getValue());
				}
				
				if (filterSpec != null
						&& StringUtils.contains(filterSpec.toString(),
								CardConstant.FILTER_ELIGIBLE_FEEWAIVER)
						&& StringUtils.isNotBlank((String) filterSpec
								.getValue())) {
					creditCardVO.setEligibleFeeWaiver((String) filterSpec
							.getValue());
				}
				
				if (filterSpec != null
						&& StringUtils.contains(filterSpec.toString(),
								CardConstant.FILTER_FEE_TYPE)
						&& StringUtils.isNotBlank((String) filterSpec
								.getValue())) {
					creditCardVO.setFeeType((String) filterSpec.getValue());
				}
				if (filterSpec != null
						&& StringUtils.contains(filterSpec.toString(),
								CardConstant.FILTER_SR_NAME)
						&& StringUtils.isNotBlank((String) filterSpec
								.getValue())) {
					creditCardVO.setSrName((String) filterSpec.getValue());
				}
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_CARD_NO)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setCardNo((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                                CardConstant.FILTER_ELIGIBLE_FOR_CREDIT_BAL_REFUND)
                        && !isEmptyOrNull((String) filterSpec.getValue())) {
                    creditCardVO.setEligibleForCreditBalRefund((String) filterSpec.getValue());
                }

                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_REQUEST_TYPE)
                        && !isEmptyOrNull((String) filterSpec.getValue())) {
                    creditCardVO.setRequestType((String) filterSpec.getValue());
                }

                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_ORG_NUM)
                        && !isEmptyOrNull((String) filterSpec.getValue())) {
                    creditCardVO.setOrgNum((String) filterSpec.getValue());
                }


                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_CARD_NO)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setCardNo((String) filterSpec.getValue());

                }

                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FUNCTION_CD)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setFunctionCd((String) filterSpec.getValue());


                }



                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.TXN_TYPE)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setFunctionType((String) filterSpec.getValue());

                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_CD_OPERATION_NAME)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setOperationName((String) filterSpec.getValue());
                }
                
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.REASON_CODE)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setReasonCode((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        		"otpRequired")
                        && !isEmptyOrNull((String) filterSpec.getValue())) {
                    creditCardVO.setOtpRequired((String) filterSpec.getValue());
                }

                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_FUN_CODE)
                        && StringUtils.isNotBlank((String) filterSpec
                        .getValue())) {
                    creditCardVO.setFuncCode((String) filterSpec.getValue());
                }

                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.SEQ_NO)
                        && StringUtils.isNotBlank(String.valueOf((String) filterSpec
                        .getValue()))) {
                    creditCardVO.setSeqNo((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_CARD_LIMIT)
                        && StringUtils.isNotBlank((String) filterSpec.getValue())) {
                    creditCardVO.setCardBalanceLimit((String) filterSpec.getValue());
                }
                if (filterSpec != null
                        && StringUtils.contains(filterSpec.toString(),
                        CardConstant.FILTER_CARD_INCLUDE)
                        && !isEmptyOrNull((String) filterSpec.getValue())) {
                    creditCardVO.setInclude((String) filterSpec.getValue());
                }
                if(filterSpec!=null && (StringUtils.contains(filterSpec.toString(),CardConstant.OPERATION_CC_BLOCK)
                        || StringUtils.contains(filterSpec.toString(),CardConstant.OPERATION_CC_REPLACEMENT))) {
                    creditCardVO.setServiceTimeOut(getServiceSpecificTimeOut());
                }
                if(filterSpec!=null && (StringUtils.contains(filterSpec.toString(),CardConstant.OPERATION_MOBILE_BALANCE))) {
                    creditCardVO.setMobileBalance(Boolean.TRUE);
                }
			}
		}
		log.info("processFilterSpec creditCardVO-{}", creditCardVO);
	}

	private Long getServiceSpecificTimeOut() {
	    try{
	        return Long.valueOf(serviceTimeOut);
        } catch (NumberFormatException e) {
	        log.error("Error while getting the service timeout {} ",serviceTimeOut);
	        return 10000L;
        }
    }

    public static String generateCardId(String countryCode, String cardNo, String customerId) {
        String res = null;
        if (!isEmptyOrNull(countryCode)
                && !isEmptyOrNull(cardNo)
                && !isEmptyOrNull(customerId)) {
            res = countryCode + customerId + StringUtils.substring(cardNo, StringUtils.length(cardNo) - 4) + RandomUtils.nextLong(100000, 999999);
        }
        return res;
    }

    public static String isCardExpired(String expiryFrmt, String expDateStr) {
        String res = CardConstant.CONS_N;
        SimpleDateFormat simpleDateFormat = null;
        Date currentDate = null;
        Date expiryDate = null;
        String currentDateStr = null;
        try {
            if (!isEmptyOrNull(expDateStr) && !isEmptyOrNull(expiryFrmt)) {
                expDateStr = StringUtils.leftPad(expDateStr, StringUtils.length(expiryFrmt), CardConstant.AMEX_CARD_PREFIX);
                simpleDateFormat = new SimpleDateFormat(expiryFrmt);
                expiryDate = simpleDateFormat.parse(expDateStr);
                currentDate = new Date();
                currentDateStr = simpleDateFormat.format(currentDate);
                currentDate = simpleDateFormat.parse(currentDateStr);
                if (expiryDate.before(currentDate) && !DateUtils.isSameDay(expiryDate, currentDate)) {
                    res = CardConstant.CONS_Y;
                }
            }
        } catch (Exception e) {
            log.error("isCardExpired Exception..{}", e);
            res = CardConstant.CONS_N;
        }
        return res;
    }

    public static String getBlockCodeDateReplacementPeriod(String blockCodeDateBlockCodes, int noOfDays, String blockCode, XMLGregorianCalendar blockCodeDate) {
        String res = CardConstant.CONS_Y;
        Date currentDate = null;
        Date calBlkDate = null;
        if (!isEmptyOrNull(blockCode)
                && !isEmptyOrNull(blockCodeDate)
                && !isEmptyOrNull(blockCodeDateBlockCodes)
                && CardUtil.isRegexMatch(blockCodeDateBlockCodes, blockCode)) {
            currentDate = new Date();
            calBlkDate = DateUtils.addDays(blockCodeDate.toGregorianCalendar().getTime(), noOfDays);
            if (currentDate.before(calBlkDate)) {
                res = CardConstant.CONS_Y;
            } else if(DateUtils.isSameDay(calBlkDate, currentDate)){
                res = CardConstant.CONS_Y;
            }else{
                res = CardConstant.CONS_N;
            }
        }
        return res;
    }

    public static String getCardReplacementTransferEffectiveDate(CreditCardFilterProperties filterProperties, String blockCode, XMLGregorianCalendar cardTransferDate, String embossingLastReqeustDateStr) {
        Date currentDate = null;
        Date embossingLastReqeustDate = null;
        SimpleDateFormat simpleDateFormat = null;
	    String res = CardConstant.CONS_Y;
	    try {
            if (isEmptyOrNull(blockCode)) {
                blockCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
            }
            if (!isEmptyOrNull(blockCode)
                    && !isEmptyOrNull(filterProperties)) {
                if (!isEmptyOrNull(filterProperties.getTransferEffectiveDateBlockCodes())
                        && isRegexMatch(filterProperties.getTransferEffectiveDateBlockCodes(), blockCode)){
                    if(isEmptyOrNull(cardTransferDate)) {
                        res = CardConstant.CONS_Y;
                    }else{
                        res = CardConstant.CONS_N;
                    }
                }else{
                    log.info("getCardReplacementTransferEffectiveDate embossingLastReqeustDateStr-{}", embossingLastReqeustDateStr);
                    if (!isEmptyOrNull(embossingLastReqeustDateStr)
                            && !isEmptyOrNull(filterProperties.getEmbossingLastRequestDateFormat())
                            && !isEmptyOrNull(filterProperties.getEmbossingLastRequestNoOfDays())) {
                        currentDate = new Date();
                        simpleDateFormat = new SimpleDateFormat(filterProperties.getEmbossingLastRequestDateFormat());
                        embossingLastReqeustDate = simpleDateFormat.parse(embossingLastReqeustDateStr);
                        embossingLastReqeustDate = DateUtils.addDays(embossingLastReqeustDate, filterProperties.getEmbossingLastRequestNoOfDays());
                        log.info("getCardReplacementTransferEffectiveDate currentDate,embossingLastReqeustDate-{},{}", currentDate,embossingLastReqeustDate);
                        if (embossingLastReqeustDate.before(currentDate)) {
                            res = CardConstant.CONS_Y;
                        } else if (DateUtils.isSameDay(embossingLastReqeustDate, currentDate)) {
                            res = CardConstant.CONS_Y;
                        } else {
                            res = CardConstant.CONS_N;
                        }
                    }
                }
            }
        }catch (Exception e){
            log.error("getCardReplacementTransferEffectiveDate Exception..{}", e);
            res = CardConstant.CONS_N;
        }
        return res;
    }

    public static String getPrimaryCardStatusForSupplCardStatus(String allowedPrimaryCardStatus, List<CreditCardDto> cardList, Map<String, String> cardStatusMap) {
        String res = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(cardList)
                && !isEmptyOrNull(cardStatusMap)
                && !isEmptyOrNull(allowedPrimaryCardStatus)) {
            for (CreditCardDto dto : cardList) {
                if (StringUtils.equals(CardConstant.CONS_Y, dto.getIsPrimary()) && isRegexMatch(allowedPrimaryCardStatus, dto.getCardStatus())) {
                    res = getKeyRegexMatchBySearchStr(dto.getCardStatus(), cardStatusMap);
                    break;
                }
            }
        }
        return res;
    }

    public static String getStatementFlags(String statementFlag, Map<String, String> statementFlagsMap) {
        String res = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(statementFlag) && !isEmptyOrNull(statementFlagsMap)) {
            res = getKeyRegexMatchBySearchStr(statementFlag, statementFlagsMap);
        }
        return res;
    }

    public static String getISOCurrencyCode(String currencyCode, Map<String, String> currencyCodesMap) {
        String res = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(currencyCode) && !isEmptyOrNull(currencyCodesMap)) {
            res = (String) getValueByKey(currencyCodesMap, currencyCode);
        }
        if(currencyCodesMap.containsValue(currencyCode)){
            res = currencyCode;
        }
        return res;
    }

    public static String getAltBlockCodeFlags(String blockCodesForAltBlockCodeCheck, String allowedAltBlockCodes, String altBlockCode, String blockCode) {
        String res = CardConstant.CONS_Y;
        if (isEmptyOrNull(blockCode)) {
            blockCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
        }
        if (isEmptyOrNull(altBlockCode)) {
            altBlockCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
        }
        if (!isEmptyOrNull(blockCodesForAltBlockCodeCheck)
                && !isEmptyOrNull(allowedAltBlockCodes)
                && !isEmptyOrNull(altBlockCode)
                && !isEmptyOrNull(blockCode)
                && CardUtil.isRegexMatch(blockCodesForAltBlockCodeCheck, blockCode)) {
            if (!CardUtil.isRegexMatch(allowedAltBlockCodes, altBlockCode)) {
                res = CardConstant.CONS_N;
            }
        }
        return res;
    }

    public static String getCardVariant(String cardOrg) {
        if (isEmptyOrNull(cardOrg)) {
            cardOrg = CardConstant.PRODUCT_CODE_DEFAULT;
        } else {
            if (StringUtils.length(cardOrg) < 3) {
                cardOrg = StringUtils.leftPad(cardOrg, 3, CardConstant.CARD_VARIANT_PREFIX_ZERO);
            }
        }
        return cardOrg;
    }
	/**
	 * 
	 * Method returns a instance of a properties bean, where the configuration
	 * required for business validation is being
	 * 
	 * maintained
	 */
	public CreditCardProperties getCreditCardPropertiesBean() {
		if (CardUtil.isEmptyOrNull(cslRequestContext.getCountry())) {
			return null;
		}
		String beanId = cslRequestContext.getCountry().toUpperCase();
		log.debug("[Country: " + cslRequestContext.getCountry()
				+ "] [Bean ID: " + beanId + "]");
		return (CreditCardProperties) applicationContext.getBean(beanId);
	}
	/**
	* This method used to set the where condition values into the query
	* @param param
	* @param dao 
	* @return
	*/
	public static List<SRParamDto> loadSrParamByObject(SRParamDto param,
			CreditCardRepositoryDao dao) {
		
		log.info("[loadSrParamByObject Started] [Param 1 :"+param.getParamKey1()+"] [Param 2:"+param.getParamKey2()+"] [Param 3:"+param.getParamKey3()+"]");
		
		String countryCode = param.getCountryCode();

		String paramId = param.getParamId();

		String paramKey1 = (param.getParamKey1() != null && param
				.getParamKey1().trim().length() > 0) ? param.getParamKey1()
				: "*";

		String paramKey2 = (param.getParamKey2() != null && param
				.getParamKey2().trim().length() > 0) ? param.getParamKey2()
				: "*";

		String paramKey3 = (param.getParamKey3() != null && param
				.getParamKey3().trim().length() > 0) ? param.getParamKey3()
				: "*";

		String paramKey4 = (param.getParamKey4() != null && param
				.getParamKey4().trim().length() > 0) ? param.getParamKey4()
				: "*";

		String paramKey5 = (param.getParamKey5() != null && param
				.getParamKey5().trim().length() > 0) ? param.getParamKey5()
				: "*";

		String paramKey6 = (param.getParamKey6() != null && param
				.getParamKey6().trim().length() > 0) ? param.getParamKey6()
				: "*";

		String paramKey7 = (param.getParamKey7() != null && param
				.getParamKey7().trim().length() > 0) ? param.getParamKey7()
				: "*";

		String paramKey8 = (param.getParamKey8() != null && param
				.getParamKey8().trim().length() > 0) ? param.getParamKey8()
				: "*";

		String paramKey9 = (param.getParamKey9() != null && param
				.getParamKey9().trim().length() > 0) ? param.getParamKey9()
				: "*";

		String paramKey10 = (param.getParamKey10() != null && param
				.getParamKey10().trim().length() > 0) ? param.getParamKey10()
				: "*";
				log.info("[param1 "+paramKey1+"]");
				log.info("[param2 "+paramKey2+"]");
				log.info("[param3 "+paramKey3+"]");
				log.info("[param5 "+paramKey5+"]");
				log.info("[param6 "+paramKey6+"]");
				log.info("[param9 "+paramKey9+"]");

		List<SRParamDto> list = dao.getSrParam(countryCode, paramId, paramKey1,
				paramKey2, paramKey3, paramKey4, paramKey5, paramKey6,
				paramKey7, paramKey8, paramKey9, paramKey10);
		
		log.info("[loadSrParamByObject Exit]");
		

		return list != null ? list : null;

	}
	/**
	 * 
	 * @param format
	 * @param date
	 * @return
	 */
	public Date formatDate(String format, String date) {
		DateFormat formatter = new SimpleDateFormat(format.toString());
		Date returnDate = null;
		try {
			if (!isEmptyOrNull(date)) {
				returnDate = (formatter.parse(date));
			}
		} catch (ParseException e) {
			log.error(e.getMessage());
		}
		return returnDate;

	}

    public static Date parseDate(String dateStr, String format) {
        try {
            if (StringUtils.isEmpty(dateStr) || StringUtils.isEmpty(format)) {
                return null;
            }
            SimpleDateFormat dateFormat = new SimpleDateFormat(format);
            return dateFormat.parse(dateStr);
        } catch (ParseException ex) {
            throw new TechnicalException(ex.getMessage());
        }
    }

    public static String formatDate(Date date, String format) {
        if (null == date || StringUtils.isEmpty(format)) {
            return null;
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

    /**
     * This methods finds whether the given value is in the comma separated list
     * @param valueList
     * @param value
     * @param skipIfNull
     * @return boolean
     */
    public static boolean isValueInList(String valueList, String value, boolean skipIfNull) {
        if (isEmptyOrNull(valueList)) {
            return skipIfNull;
        } else {
            return isValueInList(valueList, value);
        }
    }

    /**
     * Returns true if the given value is in the propValue (Comma separated)
     */
    public static boolean isValueInList(String valueList, String value) {
        return valueList.indexOf("'" + value + "'") != -1;
    }

    public static String formatMessage(String message, String... args) {
        return MessageFormat.format(message, (Object[]) args);
    }



    public static String converDateToString(XMLGregorianCalendar XMLDate) {
        String formatDate = CardConstant.PAD_EMPTY;
        if (!isEmptyOrNull(XMLDate)) {
            DateFormat formatter = new SimpleDateFormat(CardConstant.REQ_DATE_FORMAT);
            Date date = XMLDate.toGregorianCalendar().getTime();
            formatDate  = formatter.format(date);
        }
        return formatDate;
    }

    public static Date convertCalendarToDate(XMLGregorianCalendar XMLDate) {
        return (!isEmptyOrNull(XMLDate))? XMLDate.toGregorianCalendar().getTime() : null;
    }

    public static Date convertStringToDate(String date) {
        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return (!isEmptyOrNull(date)) ? formatter.parse(date) : null;
        } catch (ParseException ex) {
            return null;
        }
    }

   /*
    * Format the date and return it as String object.
    * 
     * @param txnDate
    * @param fromFormat
    * @param toFormat
    * @return
    */
    public  String formatStringDate(String txnDate, String fromFormat, String toFormat) {
    	String date =""; 

    	SimpleDateFormat sdf = new SimpleDateFormat(fromFormat);
    	SimpleDateFormat sdf1 = new SimpleDateFormat(toFormat);
    	try {
    		Date dt = sdf.parse(txnDate);
    		date = sdf1.format(dt);
    	} catch (ParseException e) {
    		log.info("Exception occured while doing date conversion..."+e);
    	}

    	return date;
    }

    public static void setEligibleGatewayProperties(EligibleInstallmentDto eligibleInstallmentDto) {
        eligibleInstallmentDto.setTrackingId(CardConstant.GATEWAY_TRACKING_ID_PREFIX + UUID.randomUUID().toString());
        eligibleInstallmentDto.setMessageTimestamp(getCurrentDateTime());
        log.info("[setGatewayProperties creditCardVO.trackingId: {}", eligibleInstallmentDto.getTrackingId());
    }
    public static String getCardRplStatusInd(String activationStatus, String stopReasonCode, String allowedActivationStatusRegix, String allowedStopReasonCodeRegix) {
        String res = CardConstant.CONS_Y;
        log.info("[getCardRplStatusInd: activationStatus, stopReasonCode, allowedActivationStatusRegix, allowedStopReasonCodeRegix - {},{},{},{}", activationStatus, stopReasonCode, allowedActivationStatusRegix, allowedStopReasonCodeRegix);
        if (!isEmptyOrNull(allowedActivationStatusRegix) && !isEmptyOrNull(allowedStopReasonCodeRegix)
                && StringUtils.startsWithAny(allowedActivationStatusRegix, PREFIX_WHITE_LIST, PREFIX_BLACK_LIST)
                && StringUtils.startsWithAny(allowedStopReasonCodeRegix, PREFIX_WHITE_LIST, PREFIX_BLACK_LIST)) {
            if (isEmptyOrNull(stopReasonCode)) {
                stopReasonCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
            }
            if(CardUtil.isRegexMatch(allowedStopReasonCodeRegix, stopReasonCode)){
                if(CardUtil.isRegexMatch(allowedActivationStatusRegix, activationStatus)) {
                    res = CardConstant.CONS_Y;
                }else{
                    res = CardConstant.CONS_N;
                }
            }else{
                res = CardConstant.CONS_Y;
            }
        }
        return res;
    }

    public static String getCardRplC400Ind(String cardNo, String stopReasonCode, BigInteger cardStatusCode, String isPrimary, List<CreditCardDto> cardList, String productCode, CreditCardFilterProperties filterProps) {
        String res = CardConstant.CONS_N;
        int i=0;
        if (isEmptyOrNull(stopReasonCode)) {
            stopReasonCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
        }
        log.info("[getCardRplC400Ind: cardNo, stopReasonCode, cardStatusCode, isPrimary, productCode - {},{},{},{},{},{}", cardNo, stopReasonCode, cardStatusCode, isPrimary, productCode);
        if (!isEmptyOrNull(filterProps) && !isEmptyOrNull(stopReasonCode) && !isEmptyOrNull(cardStatusCode) && !isEmptyOrNull(cardNo)) {
            if (!isEmptyOrNull(isPrimary) && StringUtils.equals(CardConstant.CONS_Y, isPrimary)) {
                log.info("getCardRplC400Ind if....");
                if (!isEmptyOrNull(filterProps.getCardRplIndActPrimaryStopReasonCodes())
                        && !isEmptyOrNull(filterProps.getCardRplIndActPrimaryCardStatus())
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndActPrimaryStopReasonCodes(), stopReasonCode)
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndActPrimaryCardStatus(), String.valueOf(cardStatusCode))) {
                log.info("getCardRplC400Ind if....1");
                    res = CardConstant.CONS_Y;
                } else if (!isEmptyOrNull(filterProps.getCardRplIndInActPrimaryStopReasonCodes())
                        && !isEmptyOrNull(filterProps.getCardRplIndInActPrimaryCardStatus())
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndInActPrimaryStopReasonCodes(), stopReasonCode)
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndInActPrimaryCardStatus(), String.valueOf(cardStatusCode))
                        && !isEmptyOrNull(filterProps.getCardRplIndInActPrimaryActiveAgreementSts())
                        && !isEmptyOrNull(filterProps.getCardRplIndInActPrimaryActiveCardStatus())
                        && !isEmptyOrNull(filterProps.getCardRplIndInActPrimaryActiveStopReasonCodes())) {
                log.info("getCardRplC400Ind if....2");
                    res = CardConstant.CONS_Y;
                    for(CreditCardDto dto : cardList){
                        if (isEmptyOrNull(dto.getBlockCode())) {
                            stopReasonCode = CardConstant.CARD_BLOCK_CODE_DEFAULT;
                        }
                        if(!StringUtils.equals(cardNo, dto.getCardNum())
                                && StringUtils.equals(CardConstant.CONS_Y, dto.getIsPrimary())
                                && StringUtils.equals(productCode, dto.getSubProd())
                                && !isEmptyOrNull(dto.getAgreementStatus())
                                && CardUtil.isRegexMatch(filterProps.getCardRplIndInActPrimaryActiveAgreementSts(), dto.getAgreementStatus().toString())
                                && !isEmptyOrNull(dto.getCardValiditySts())
                                && CardUtil.isRegexMatch(filterProps.getCardRplIndInActPrimaryActiveCardStatus(), String.valueOf(dto.getCardValiditySts()))
                                && !isEmptyOrNull(stopReasonCode)
                                && CardUtil.isRegexMatch(filterProps.getCardRplIndInActPrimaryActiveStopReasonCodes(), stopReasonCode)) {
                log.info("getCardRplC400Ind if....3");
                            res = CardConstant.CONS_N;
                        }
                    }
                }
            } else {
                log.info("getCardRplC400Ind else....");
                if (!isEmptyOrNull(filterProps.getCardRplIndActSupStopReasonCodes())
                        && !isEmptyOrNull(filterProps.getCardRplIndActSupCardStatus())
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndActSupStopReasonCodes(), stopReasonCode)
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndActSupCardStatus(), String.valueOf(cardStatusCode))) {
                    log.info("getCardRplC400Ind else....1");
                    res = CardConstant.CONS_Y;
                } else if (!isEmptyOrNull(filterProps.getCardRplIndInActSupStopReasonCodes())
                        && !isEmptyOrNull(filterProps.getCardRplIndInActSupCardStatus())
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndInActSupStopReasonCodes(), stopReasonCode)
                        && CardUtil.isRegexMatch(filterProps.getCardRplIndInActSupCardStatus(), String.valueOf(cardStatusCode))) {
                    log.info("getCardRplC400Ind else....2");
                    res = CardConstant.CONS_Y;
                }
            }
        }
        return res;
    }

    public CreditCardProperties getCreditCardPropertiesBean(String propertyKey) {
		if (CardUtil.isEmptyOrNull(propertyKey)) {
			return null;
		}
		String beanId = propertyKey.toUpperCase();
		return (CreditCardProperties) applicationContext.getBean(beanId);
	}
    
    public static List<SRParamDto> loadSrParamListByObject(
			List<Serializable> ids, CreditCardRepositoryDao ccDao) {
		Iterable<SRParamDto> dataList = ccDao.findAll(ids);
		List<SRParamDto> list = Lists.newArrayList(dataList);
		return list;
	}
    
  
    
    /**
     * Mobile number formatter for contact fetched from Credit Card
     * @param mobileNo
     * @return
     */
	public static String formatCCMobileNumber(String mobileNo) {
		if (!mobileNo.startsWith(CardConstant.PAD_PLUS)) {
			mobileNo = CardConstant.PAD_PLUS + mobileNo;
		}
		return mobileNo;
	}

    public static BigDecimal toBigDecimal(String value) {
        if (StringUtils.isEmpty(value)) {
            return null;
        }

        if (value.endsWith("-")) {
            value = "-" + value.substring(0, value.length() - 1);
        }
        return new BigDecimal(value);
    }

	
	public String validateContactNumber(String mobileCntryCode,String contactNumber) {
		contactNumber = contactNumber.replaceAll("[^+0-9]", "");
					
		if (contactNumber.substring(0, 1).compareTo("0") == 0 && contactNumber.substring(1, 2).compareTo("0") != 0) {
	        contactNumber = "+" + mobileCntryCode + contactNumber.substring(1); // e.g. 0172 12 34 567 -> + (country_code) 172 12 34 567
	    }
		
		if (contactNumber.substring(0, mobileCntryCode.length()).compareTo(mobileCntryCode) == 0) {
	        contactNumber = "+" + contactNumber; // e.g. 60172 12 34 567 -> +60172 12 34 567
	    }
		
		if (contactNumber.substring(0, mobileCntryCode.length()).compareTo(mobileCntryCode) != 0 && contactNumber.substring(0, 1).compareTo("+") != 0) {
	        contactNumber = "+" +mobileCntryCode+contactNumber; // e.g. 60172 12 34 567 -> +60172 12 34 567
	    }
		return contactNumber;
	}

}