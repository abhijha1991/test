package com.sc.csl.retail.creditcard.exception;

import static com.sc.csl.retail.core.exception.CSLErrorCodeUtil.convertToString;
import com.sc.csl.retail.core.exception.ErrorCode;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import com.sc.csl.retail.creditcard.helper.CardConstant;
@Getter
@Slf4j
public enum UAASErrorCode implements ErrorCode {
	
    PIN_RESET_FAILED("CSL-CC-301", CardConstant.ERROR, "%s - %s"),
    PIN_RESET_REQUEST_FAILED("CSL-CC-302", CardConstant.ERROR, "%s - %s"),
    KEY_NOT_FOUND("CSL-CC-303", CardConstant.ERROR, "%s - %s"),
    ENCRYPTION_OR_DECRYPTION_ERROR("CSL-CC-304", CardConstant.ERROR, "%s - %s"),
    PIN_RESET_REQUEST_TIMED_OUT("CSL-CC-305", CardConstant.ERROR, "%s - %s"),
    QUERY_FAILED("CSL-CC-306", CardConstant.ERROR, "%s - %s"),   
    DATABASE_SQL_ERROR("CSL-CC-307", CardConstant.ERROR, "%s - %s"),
    PIN_BLOCK_GENERATION_FAILED("CSL-CC-308", CardConstant.ERROR, "%s - %s"),
    INVALID_TRANSACTION_REFERENCE_NUMBER("CSL-CC-309", CardConstant.ERROR, "%s - %s"),
    INVALID_PARAMETER("CSL-CC-310", CardConstant.ERROR, "%s - %s"),
    DATE_OR_TIME_FORMATE_INVALID("CSL-CC-311", CardConstant.ERROR, "%s - %s"),
    MAX_RETRY_LIMIT_REACHED("CSL-CC-312", CardConstant.ERROR, "%s - %s"),
    INVALID_RANDOM_CHALLENGE("CSL-CC-313", CardConstant.ERROR, "%s - %s"),
    RANDOM_CHALLENGE_EXPIRED("CSL-CC-314", CardConstant.ERROR, "%s - %s"),
    HASH_FAILURE("CSL-CC-315", CardConstant.ERROR, "%s - %s"),    
	ERR_CSL_CREDIT_CARDS_SECUIRTY_ERROR("CSL-CC-316", CardConstant.ERROR,"Security Error"),	
	UAAS_CONNECTION_ERROR("CSL-CC-317",CardConstant.ERROR,"%s -%s"),
	UAAS_BAD_REQUEST("CSL-CC-318",CardConstant.ERROR,"%s -%s");

    private String code;
    private String title;
    private String description;

    public String toString() {
        return convertToString(this);
    }

    UAASErrorCode(String code, String title, String description) {
        this.code = code;
        this.title = title;
        this.description = description;
    }

    public static ErrorCode getBusinessErrorCode(String hostErrorCode) {
        ErrorCode errorCode = UAASErrorCode.ERR_CSL_CREDIT_CARDS_SECUIRTY_ERROR;
        try {
            log.debug("[getBusinessErrorCode hostErrorCode : {}", hostErrorCode);
            if (!CardUtil.isEmptyOrNull(hostErrorCode)) {
                errorCode = UAASErrorCode.valueOf(hostErrorCode);
            }
        } catch (Exception e) {
            log.error("[getBusinessErrorCode exception : {}", e);
        }
        return errorCode;
    }
}
