package com.sc.csl.retail.creditcard.dto;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreditCardEligibilityDto {
	
	private String cardEligibilityFlag;
	
	private String eligibleReversalCapAmount;
	
	private BigDecimal percentageEligible;
	
	private String eligibilityOverrideFlag = "";

}
