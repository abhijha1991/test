package com.sc.csl.retail.creditcard.endpoint;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.exception.CreditCardErrorCode;
import com.sc.csl.retail.creditcard.gateway.CreditCardRestGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.CCFeeWaiverAsyncService;
import com.sc.csl.retail.creditcard.service.CardActivationService;
import com.sc.csl.retail.creditcard.service.CardPinResetService;
import com.sc.csl.retail.creditcard.service.CreditBalRefundService;
import com.sc.csl.retail.creditcard.service.CreditCardFeeWaiverService;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.service.EligibleInstallmentService;
import com.sc.csl.retail.creditcard.service.cccancel.CreditCardCancelService;
import com.sc.csl.retail.creditcard.service.security.SmsOtpRequiredService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryBase;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class CreditCardRepository extends ResourceRepositoryBase<CreditCardDto, String> {

    @Autowired
    private CSLRequestContext cslRequestContext;
    @Autowired
    private CreditCardService creditCardService;
    @Autowired
    private CreditCardFeeWaiverService creditCardFeeWaiverService;
    @Autowired
    private CreditBalRefundService creditBalRefundService;
    @Autowired
    private CreditCardCancelService creditCardCancelService;
    @Autowired
    private CardUtil cardUtil;
    @Autowired
    CreditCardRestGateway creditCardRestGateway;
    @Autowired
    SmsOtpRequiredService smsOtpRequiredService;
    @Autowired
    private EligibleInstallmentService eligibleInstallmentService;
    
    @Autowired
	private CCFeeWaiverAsyncService ccFeeWaiverAsyncService;
    
    @Autowired
   	private CardPinResetService cardPinResetService;
    
    @Autowired
	private CardActivationService creditCardActivation;    

    public CreditCardRepository() {
        super(CreditCardDto.class);
    }

    @Override
    public ResourceList<CreditCardDto> findAll(QuerySpec querySpec) {
        CreditCardVO creditCardVO = null;
        try {
            log.debug("[CreditCardRepository findAll Entry....]");
            creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
            querySpec = cardUtil.populateQuerySpec(querySpec, creditCardVO);
            creditCardVO.setStartPageNumber(CardConstant.START_PAGE_01);
            if ((CardConstant.CC_FEE_WAIVER.equalsIgnoreCase(creditCardVO.getSrName()) || CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO
                    .getEligibleFeeWaiver())) && ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditCardVO.getCountryCode())) {
    	
            	log.info("CreditCardRepository findAll Entry HK");
               if (CardConstant.IVR_CHANNEL_ID.equalsIgnoreCase(creditCardVO.getChannelId())) {
          		  return querySpec.apply(ccFeeWaiverAsyncService.getCreditcardTransactionsForIVR(creditCardVO));
               } else if (CardConstant.CC_FEE_WAIVER.equalsIgnoreCase(creditCardVO.getSrName()) && CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO.getActiveCards())) {
		            return querySpec.apply(ccFeeWaiverAsyncService.findAllCreditCard(creditCardVO));
		    	} else {
		    		return querySpec.apply(creditCardFeeWaiverService.getCreditcardTransactions(creditCardVO));
		    	}
		    	
            } else if (CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO
                    .getActiveCards())
                    && (CardConstant.CC_FEE_WAIVER
                    .equalsIgnoreCase(creditCardVO.getSrName()))) {
                return querySpec.apply(creditCardFeeWaiverService
                        .getAllActiveCreditCards(creditCardVO));
            } else if (CardConstant.FILTER_CREDIT_BAL_REFUND
                    .equalsIgnoreCase(creditCardVO.getEligibleForCreditBalRefund())) {
                return querySpec.apply(creditBalRefundService
                        .validateCreditBalRefundEligibility(creditCardVO));
            } else if (CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO
                    .getEligibleFeeWaiver())) {
                return querySpec.apply(creditCardFeeWaiverService
                        .getCreditcardTransactionsAndRewardPoint(creditCardVO));
            } else if (CardConstant.OPERATION_CC_CANCEL.equalsIgnoreCase(creditCardVO
                    .getOperationName())) {
                return querySpec.apply(creditCardCancelService.getEligibleCreditCards(creditCardVO));
            } else if (CardConstant.TRANSACTION.equalsIgnoreCase(creditCardVO.getFunctionType())) {
                return querySpec.apply(creditCardService
                        .getCreditCardTransaction(creditCardVO));
            } else if(CardConstant.ELIGIBLE_TRANSACTION.equalsIgnoreCase(creditCardVO.getFunctionType())) {
                return querySpec.apply(eligibleInstallmentService.getEligiblePlans1(creditCardVO));
            }else if (CardConstant.SMS_OTP_REQUIRED.equals(creditCardVO.getOtpRequired())) {
                smsOtpRequiredService.otprequired();
                return querySpec.apply(new ArrayList<CreditCardDto>());
            } else {
                return querySpec.apply(creditCardService
                        .findAllCreditCard(creditCardVO));
            }
        } finally {
            log.debug("[findAll Exit]");
        }
    }

    @Override
    public CreditCardDto findOne(String id, QuerySpec querySpec) {
        CreditCardVO creditCardVO = null;
        try {
            log.debug("[CreditCardRepository findOne Entry]");
            log.info("[findOne] [Id: {}]", id);
            creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
            querySpec = cardUtil.populateQuerySpec(querySpec, creditCardVO);
            creditCardVO.setCardNo(id);
            if (CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO
                    .getEligibleFeeWaiver()) && ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditCardVO.getCountryCode())) {
    	
            	log.info("CreditCardRepository findOne Entry HK");
            	List<CreditCardDto> returnList = creditCardFeeWaiverService.getCreditcardTransactions(creditCardVO);
            	return returnList.get(CardConstant.SIZE_ONE);
		    	
            } else if (CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO
                    .getEligibleFeeWaiver())) {
                List<CreditCardDto> returnList = creditCardFeeWaiverService
                        .getCreditcardTransactionsAndRewardPoint(creditCardVO);
                return returnList.get(CardConstant.SIZE_ONE);
            } else if (CardConstant.FILTER_CREDIT_BAL_REFUND.equals(creditCardVO.getEligibleForCreditBalRefund())) {
                return creditBalRefundService.validateOneCardCreditBalRefund(creditCardVO, id);
            } else if (CardConstant.CARD_DETAIL.equals(creditCardVO.getRequestType())) {
                creditCardVO.setCustNum(id);
                creditCardVO.setCardNo(StringUtils.EMPTY);
                return creditCardService.getCardDetail(creditCardVO);
            } else if (CardConstant.OFFLINE.equals(creditCardVO.getRequestType())) {
                return creditCardRestGateway.getOfflineCreditCardDetails(creditCardVO);
            } else if (CardConstant.CONS_YES.equalsIgnoreCase(creditCardVO.getCardBalanceLimit())) {
                return creditCardService.getCreditCardLimitBalance(creditCardVO);
            } else {
                return creditCardService.findOneCreditCard(creditCardVO);
            }
        } finally {
            log.debug("[CreditCardRepository findOne Exit]");
        }
    }

    @SuppressWarnings("unchecked")
    @Override
    public CreditCardDto create(CreditCardDto creditCardDto) {


        log.debug("[CreditCardRepository create Entered]");
        if (StringUtils.isEmpty(creditCardDto.getOperationName())) {
            log.error("Posting operation can not be empty.");
            throw new BusinessException(CreditCardErrorCode.ERR_CSL_NO_POSTING_SERVICE);
        }
        switch (creditCardDto.getOperationName()) {
            case CardConstant.OPERATION_CC_CANCEL:
                return creditCardCancelService.requestCreditCardCancellation(creditCardDto);
            case CardConstant.OPERATION_CC_FEE_WAIVER:
                ServiceRequest servicereq = new ServiceRequest();
                if (creditCardDto.getPostCreditCards() != null) {
                    servicereq = creditCardFeeWaiverService.createServiceRequest(creditCardDto);
                }
                if (!CardUtil.isEmptyOrNull(servicereq)) {
                    creditCardDto.setReceiptId(servicereq.getReceiptId());
                }
                return creditCardDto;
            case CardConstant.OPERATION_CC_PINSET:
            case CardConstant.OPERATION_CC_PINACTIV:
    			return cardPinResetService.updatePin(creditCardDto);                				
            default:
                log.error("Posting operation not available. [Operation Name: " + creditCardDto.getOperationName() + "]");
                throw new BusinessException(CreditCardErrorCode.ERR_CSL_NO_POSTING_SERVICE);
        }

    }
    
    @SuppressWarnings("unchecked")
	@Override
	public CreditCardDto save(CreditCardDto creditCardDto) {

		log.debug("[CreditCardRepository save Entered]");
		if (StringUtils.isEmpty(creditCardDto.getOperationName())) {
			log.error("Patching operation can not be empty.");
			throw new BusinessException(CreditCardErrorCode.ERR_CSL_NO_POSTING_SERVICE);
		}
		switch (creditCardDto.getOperationName()) {
		case CardConstant.OPERATION_CC_ACTIVATION:
			return creditCardActivation.activateCard(creditCardDto);
		case CardConstant.OPERATION_CC_SMSACTV:		
			 return creditCardActivation.activateCardForSMS(creditCardDto);		
		default:
			log.error("Patching operation not available. [Operation Name: " + creditCardDto.getOperationName() + "]");
			throw new BusinessException(CreditCardErrorCode.ERR_CSL_NO_POSTING_SERVICE);
		}
	}

    @Override
    public ResourceList<CreditCardDto> findAll(
            Iterable<String> creditcardnumber, QuerySpec querySpec) {
        CreditCardVO creditCardVO = null;
        log.debug("[FindAll Iterable Entry]");
        log.info("[FindAll Iterable Header] : {}]", creditcardnumber);
        creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
        querySpec = cardUtil.populateQuerySpec(querySpec, creditCardVO);
        for (Object cardNumber : creditcardnumber) {
            creditCardVO.setCardNo(cardNumber.toString());
        }
        return querySpec.apply(creditCardService
                .findAllCreditCard(creditCardVO));
    }
}
