package com.sc.csl.retail.creditcard.dto.notification;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class NotificationDto extends NotificationBaseDto {

    @NotNull(message = "header can not be Null")
    @JsonProperty(value = "header")
    private NotificationHeaderDto headerDto;

    @JsonProperty(value = "sms-payload")
    private SmsNotificationPayloadDto smsPayloadDto;

    @JsonProperty(value = "email-payload")
    private EmailNotificationPayloadDto emailPayloadDto;

    @JsonProperty(value = "inbox-payload")
    private InboxNotificationPayloadDto inboxPayloadDto;
}
