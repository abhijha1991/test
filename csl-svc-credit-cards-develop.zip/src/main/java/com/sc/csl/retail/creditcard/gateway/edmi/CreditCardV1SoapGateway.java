package com.sc.csl.retail.creditcard.gateway.edmi;

import java.util.Date;
import java.util.Map;

import javax.xml.ws.WebServiceException;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.sc.corebanking.creditcard.v1.ws.provider.creditcard.CreditCardPortType;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcard.ScbCoreBankingCreditCardCreditCardV1WsProviderV1CreditCard;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcard.UpdateStatus;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcard.UpdateStatusRes;
import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.exception.TemplateErrorCode;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.security.EncryptedData;
import com.sc.csl.retail.creditcard.exception.CardActivationErrorCode;
import com.sc.csl.retail.creditcard.exception.UAASErrorCode;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.gateway.csl.DecryptGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.UAASUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CreditCardV1SoapGateway extends BaseCreditCardsSoapGateway<CreditCardPortType> {

	@Autowired
	public FreemarkerRenderer renderer;

	@Autowired
	DecryptGateway decryptGateway;

	@Autowired
	private CardUtil cardUtil;

	@Autowired
	protected CSLRequestContext cslRequestContext;

	@Autowired
	private UAASUtil uaasUtil;

	public CreditCardV1SoapGateway(CSLSoapGatewayProperties edmiCreditCardV1SoapGatewayProperties) {
		super(new ScbCoreBankingCreditCardCreditCardV1WsProviderV1CreditCard(), CreditCardPortType.class,
				edmiCreditCardV1SoapGatewayProperties);
		setupInterceptors();
	}

	/*
	 * CreditCard.updateStatus service to activate the card For CCMS
	 * FunctionCode =33 For C400 RecordType =004
	 */
	public CreditCardVO updateCardStatus(CreditCardVO creditCardVO) {
		CreditCardProperties props = null;
		UpdateStatus request = null;
		Date date = null;
		try {
			log.debug("[Credit Card updateStatus Entry]");
			date = new Date();
			log.info("start time...{}", date);
			props = getCreditCardPropertiesByCountry(creditCardVO.getCountryCode());
			CardUtil.setGatewayProperties(creditCardVO);

			if (StringUtils.isNotBlank(creditCardVO.getCardNo())) {
				request = CSLXmlUtils.toObject(
						renderer.render(StringUtils.equals(CardConstant.OPERATION_CC_ACTIVATION, creditCardVO.getOperationName())?
								CardConstant.CARD_STATUS_UPDATE_TEMPLATE_NAME:CardConstant.SMS_CARD_ACTIVATION_TEMPLATE_NAME,
								getGatewayTemplateMap(props.getCardUpdateStatusProperties(), creditCardVO)),
						UpdateStatus.class);
			}

			if (CardUtil.isEmptyOrNull(request)) {
				throw new TechnicalException(TemplateErrorCode.create(CardActivationErrorCode.CARDS_SYSTEM_FAILURE,
						"Update Status Request", "empty or null"));
			}
			UpdateStatusRes response = null;
			try {
				response = this.getProxyClient().updateStatus(request.getUpdateStatusRequest());
			} catch (WebServiceException ex) {
				throw new TechnicalException(TemplateErrorCode.create(CardActivationErrorCode.CARD_CONNECTIVITY_FAILURE,
						"EDMI Service Error", ex.getMessage()));
			}
			validateResponse(creditCardVO, response);
			

			/**
			 * cardRecType =
			 * response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs().getCardRec();
			 * cardNo = CardConstant.PAD_EMPTY +
			 * cardRecType.getCardInfo().getCardNum(); if
			 * (StringUtils.isNotBlank(cardNo) && StringUtils.length(cardNo) >
			 * 1) { creditCardDto.setCardNum(cardNo);
			 * creditCardDto.setStatus(CardUtil.setCardStatus(cardRecType.getCardStatus().getCardStatusCode(),
			 * props.getCreditCardFilters().getCardStatus()));
			 * creditCardDto.setCardStatus(cardRecType.getCardStatus().getCardStatusCode());
			 * }
			 **/
			log.info("Credit Card updateStatus Service - start & end time...{},{}", date, new Date());
			return creditCardVO;
		} finally {
			log.debug("[UpdateStatus Exit]");
		}
	}

	private void validateResponse(CreditCardVO creditCardVO, UpdateStatusRes response) {
		String responseCode=null;
		String responseDesc=null;
		String captureSystem=response.getHeader().getCaptureSystem();
		
		if (CardUtil.isEmptyOrNull(response)) {
			throw new TechnicalException(TemplateErrorCode.create(CardActivationErrorCode.CARDS_SYSTEM_FAILURE,
					"Update Status Request", "empty or null"));
		}
		validateSCBMLHeader(response.getHeader(), creditCardVO);
		if (!CardUtil.isEmptyOrNull(response.getUpdateStatusResPayload())
				&& !CardUtil.isEmptyOrNull(response.getUpdateStatusResPayload().getUpdateStatusRes())
				&& !CardUtil
						.isEmptyOrNull(response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs())
				&& (!CardUtil.isEmptyOrNull(response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs()
						.getSCBRespCode()) || !CardUtil.isEmptyOrNull(response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs().getStatus().getStatusCode() ))) {
			
			//Tags for Response Code is different for CCMS and C400,hence taking from respective fields
			if(StringUtils.equals(CardConstant.C400,captureSystem)){				
				responseCode=response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs().getSCBRespCode();
				responseDesc=response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs().getSCBRespDesc();				
			}else {				
				responseCode=response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs().getStatus().getStatusCode();
				responseDesc=response.getUpdateStatusResPayload().getUpdateStatusRes().getUpdateStatusRs().getStatus().getStatusDesc();				
			}
			
			validateCardActivaionResponse(responseCode,responseDesc,creditCardVO);
			
		} else {
			throw new BusinessException(TemplateErrorCode.create(CardActivationErrorCode.CARDS_SYSTEM_FAILURE,
					"General Error", "Card Activation empty Response"));
		}
	}

	public void validateCardActivaionResponse(String responseCode, String responseDesc, CreditCardVO creditCardVO) {
		log.info("[validateResponseCode (Body) responseCode, responseDesc: {},{}", responseCode, responseDesc);
		if (!ArrayUtils.contains(CardGatewayConstant.EDMI_SUCCESS_RES_CDS, responseCode)) {
			throw new BusinessException(
					TemplateErrorCode.create(
							CardActivationErrorCode.getBusinessErrorCode(
									(String) CardUtil.getValueByKey(getPropertiesByCode(creditCardVO.getCountryCode(),
											PropertyCodes.ACTIVATION_ERROR_CODES), responseCode)),
							responseCode, responseDesc));
		}

		creditCardVO.setStatusCode(responseCode);
		creditCardVO.setStatusDescription(responseDesc);
	}

	public String getDecryptedCardNumber(CreditCardDto ccActivationDto) {

		EncryptedData creditCardDecryptRequest = uaasUtil.constructCardDecryptRequest(ccActivationDto);

		EncryptedData response = decryptGateway.decrypt(creditCardDecryptRequest);

		if (!CardConstant.UAAS_SUCCESS_CODE.equals(response.getStatusCode())) {
			Map<String, String> errorCodeMap = uaasUtil.getUAASErrorCodes();
			String errorCode = (String) CardUtil.getValueByKey(errorCodeMap, response.getStatusCode());
			throw new BusinessException(TemplateErrorCode.create(UAASErrorCode.getBusinessErrorCode(errorCode),
					response.getStatusCode(), response.getErrorMessage()));
		}
		return response.getDecData();
	}

}
