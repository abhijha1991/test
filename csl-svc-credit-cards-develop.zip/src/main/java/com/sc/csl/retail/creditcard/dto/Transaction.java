package com.sc.csl.retail.creditcard.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@JsonApiResource(type = "transactions")
public class Transaction implements Serializable {

    @JsonApiId
    private String transactionApprovalSequenceNumber;

    @JsonProperty("credit-debit-transaction-indicator")
    private String creditDebitTransactionIndicator;
    @JsonProperty("transaction-amount")
    private String transactionAmount;
    @JsonProperty("transaction-currency-code")
    private String transactionCurrencyCode;
    @JsonProperty("transaction-date")
    private Date transactionEffectiveDate;

    @JsonProperty("transaction-description")
    private String transactionDescription;

    @JsonProperty("from-account")
    private String accountNo;


    @JsonProperty("org-code")
    private String orgCode;


    private String fromDate;

    private String toDate;
}
