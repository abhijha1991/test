package com.sc.csl.retail.creditcard.config;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.sc.csl.retail.creditcard.service.cccancel.AECreditCardCancelValidator;
import com.sc.csl.retail.creditcard.service.cccancel.CreditCardCancelValidator;

/**
 * @author 1452875
 * @since Dec 4, 2017
 */
@Component
public class ValidatorServiceConfig {

    @Bean
    public CreditCardCancelValidator creditCardCancelRequestValidatorAE() {
        return new AECreditCardCancelValidator();
    }
}
