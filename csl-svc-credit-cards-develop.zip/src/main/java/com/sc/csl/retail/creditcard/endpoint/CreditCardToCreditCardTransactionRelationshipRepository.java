package com.sc.csl.retail.creditcard.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.RelationshipRepositoryV2;
import io.katharsis.resource.list.ResourceList;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class CreditCardToCreditCardTransactionRelationshipRepository 
implements RelationshipRepositoryV2<CreditCardDto, String, CreditCardTransactionDto, String> {

	@Autowired
	private CSLRequestContext cslRequestContext;
	
	@Autowired
	private CreditCardService creditCardService;

	@Autowired
	private CardUtil cardUtil;

	@Override
	public Class<CreditCardDto> getSourceResourceClass() {
		return CreditCardDto.class;
	}

	@Override
	public Class<CreditCardTransactionDto> getTargetResourceClass() {
		return CreditCardTransactionDto.class;
	}

	@Override
	public void setRelation(CreditCardDto card, String targetId, String fieldName) {
		log.info("setRelation card,targetId,fieldName -{},{},{}", card, targetId, fieldName);
	}

	@Override
	public void setRelations(CreditCardDto card, Iterable<String> targetIds, String fieldName) {
		log.info("setRelations card,targetIds,fieldName -{},{},{}", card, targetIds, fieldName);
	}

	@Override
	public void addRelations(CreditCardDto source, Iterable<String> targetIds, String fieldName) {
		log.info("addRelations source,targetIds,fieldName -{},{},{}", source, targetIds, fieldName);
	}

	@Override
	public void removeRelations(CreditCardDto source, Iterable<String> targetIds, String fieldName) {
		log.info("removeRelations source,targetIds,fieldName -{},{},{}", source, targetIds, fieldName);
	}

	@Override
	public CreditCardTransactionDto findOneTarget(String id, String fieldName, QuerySpec querySpec) {
		return null;
	}
	
	
	@Override
	public ResourceList<CreditCardTransactionDto> findManyTargets(String sourceId, String fieldName, QuerySpec querySpec) {
		CreditCardVO creditCardVO = null;
		try{
			log.debug("[findManyTargets Entry]");
			log.info("findManyTargets sourceId,fieldName-{},{}", sourceId, fieldName);
			creditCardVO = cardUtil.populateCreditCardVO(cslRequestContext);
			creditCardVO.setCardNo(creditCardService.getCreditCardFromCardId(sourceId,creditCardVO));
			List<CreditCardTransactionDto> transactionDto = creditCardService.findAllCreditCardTransaction(creditCardVO);
			if(!transactionDto.isEmpty()) {
				querySpec.setLimit(Long.valueOf(transactionDto.size()));
			}
			return querySpec.apply(transactionDto);
		} finally {
			log.debug("[findManyTargets Exit]");
		}
	}
}