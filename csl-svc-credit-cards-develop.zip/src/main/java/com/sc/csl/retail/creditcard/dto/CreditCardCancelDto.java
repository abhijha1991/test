package com.sc.csl.retail.creditcard.dto;

/**
 * @author 1452875
 * @since Sep 20, 2017
 */
public class CreditCardCancelDto {

}
