package com.sc.csl.retail.creditcard.dto.security;

import io.katharsis.resource.annotations.JsonApiId;
import io.katharsis.resource.annotations.JsonApiResource;
import lombok.Data;

@Data
@JsonApiResource(type = "validate-otp")
public class ValidateOtp {
    @JsonApiId
    private String requestId;

    private String encOtp;
    private String otpSn;
    private String purpose;
    private String keyIndex;

    private String relId;
    private String country;
    private String language;
    private String channel;

    private String statusCode;
    private String errorMessage;
}
