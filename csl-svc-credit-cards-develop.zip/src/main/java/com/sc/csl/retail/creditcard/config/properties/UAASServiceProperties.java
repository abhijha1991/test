package com.sc.csl.retail.creditcard.config.properties;

import lombok.Data;

@Data
public class UAASServiceProperties {

	private String apiKey = null;
	private String appId = null;

}
