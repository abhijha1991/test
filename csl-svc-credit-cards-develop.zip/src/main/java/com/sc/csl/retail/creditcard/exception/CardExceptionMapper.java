package com.sc.csl.retail.creditcard.exception;

import com.sc.csl.retail.core.util.CSLJsonUtils;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import io.katharsis.errorhandling.ErrorData;
import io.katharsis.errorhandling.ErrorResponse;
import io.katharsis.errorhandling.mapper.ExceptionMapper;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class CardExceptionMapper implements ExceptionMapper<CardException> {

    @Override
    public ErrorResponse toErrorResponse(CardException e) {
        @SuppressWarnings("unchecked")
		Map<String, Object> smsOtp = CSLJsonUtils.parseJson(e.getExceptionMessage() , Map.class);
        String errMessage = (String) smsOtp.get(CardConstant.OTP_TITLE);
        smsOtp.remove(CardConstant.OTP_TITLE);

        ErrorResponse errorResponse = ErrorResponse.builder()
                .setStatus(e.getExceptionId())
                .setSingleErrorData(ErrorData.builder()
                        .setTitle(errMessage)
                        .setId(String.valueOf(e.getExceptionId()))
                        .setMeta(smsOtp)
                        .build())
                .build();
        return errorResponse;
    }
    @Override
    public CardException fromErrorResponse(ErrorResponse errorResponse) {
        return new CardException();
    }

    @Override
	public boolean accepts(ErrorResponse errorResponse) {
		return false;
	}
}
