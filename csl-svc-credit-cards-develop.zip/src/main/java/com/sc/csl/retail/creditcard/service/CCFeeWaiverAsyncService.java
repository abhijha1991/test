package com.sc.csl.retail.creditcard.service;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardEligibilityCriteriaDao;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dao.CreditCardTransactionEDMPDao;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.dto.TransactionAsyncDto;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CCFeeWaiverEligibilityUtility;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.EncryptionDecryptionHelper;
import com.sc.csl.retail.creditcard.helper.ReconcileTransaction;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

@Slf4j
@Service
public class CCFeeWaiverAsyncService {
	
	@Autowired
	private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
	
	@Autowired
	private CreditCardService creditCardService;

	@Autowired
	private CreditCardEligibilityCriteriaDao eligibilityDao;
	
	@Autowired
	private CreditCardTransactionEDMPDao transDao;
	
	@Autowired
	private CreditCardFeeWaiverService creditCardFeeWaiverService;
	
	@Autowired
	private ReconcileTransaction reconcileTransaction;
	
	@Autowired
	private EncryptionDecryptionHelper encryptDecryptHelper;
	
	@Autowired
	private CardUtil cardUtil;
	
	@Autowired
	private CCTransactionAsyncService transactionAsyncService;
	
	@Autowired
	private CreditCardRepositoryDao ccDao;
	
	@Autowired
	private CCFeeWaiverEligibilityUtility ccFeeWaiverEligibilityUtility;
	
	
	@Async("threadPoolTaskExecutor")
	public CompletableFuture<CreditCardDto> getAsyncTransactionList(
			CreditCardVO creditcardvo, String cardNumbers,List<CreditCardDto> creditCardListing,Map<String,
			Map<String, String>> cardStatusMap,String feeDesc,String isCardMaskingRequired) {
		return CompletableFuture.completedFuture(getCreditCardTransactionList(creditcardvo,cardNumbers,creditCardListing,
				cardStatusMap,feeDesc,isCardMaskingRequired));
	}

	@SuppressWarnings("unchecked")
	public CreditCardDto getCreditCardTransactionList(CreditCardVO creditcardvo,
			String cardNumbers,List<CreditCardDto> creditCardListing,Map<String, Map<String, String>> cardStatusMap,
			String feeDesc,String isCardMaskingRequired) {
		
		log.info("CCFeeWaiverAsyncService getCreditCardTransactionList Entry");
		List<CreditCardTransactionDto> unBilledtransactionList = null;
		List<CreditCardTransactionDto> reconciledTransactionList = null;
		List<CreditCardTransactionDto> edmp12MonthTransactions = null;
		List<CreditCardTransactionDto> statemantedTransaction = null;
		List<CreditCardTransactionDto> ccmsC400Transactions = null;
		List<CreditCardTransactionDto> eligibilityList = null;
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		CreditCardDto creditcardDto = new CreditCardDto();
		journeyMap.put(CardConstant.KEY_EDMP_CONFIG,CardConstant.KEY_EDMP_HBASE_CONFIG_PRIMARY);
		journeyMap.put(CardConstant.REWARD_POINT_REQUIRED, false);
		
		// To fetch the card related details form CCMS/C400 [GetDetail - CC Enquiry]
		creditcardDto = creditCardEnquiryV1SoapGateway.getCreditCard(creditcardvo);
		journeyMap.put(CardConstant.KEY_CARD_DETAILS, creditcardDto);
		
		creditcardDto.setCardNum(creditcardvo.getCardNo());
		creditcardDto.setEligibleFeeWaiver(creditcardvo.getEligibleFeeWaiver());
		creditcardDto.setFeeType(creditcardvo.getFeeType());
		creditcardDto.setCardNumbers(cardNumbers);
		creditcardvo.setCardType(creditcardDto.getDesc());
		creditcardDto.setIsMaskCardNo(isCardMaskingRequired);
		creditcardDto.setCurrencyCode(creditcardvo.getTxtCurrCode());
		
		CreditCardFeeWaiverProperties props = cardUtil.getCreditCardPropertiesBean(
				creditcardvo.getCountryCode()).getCreditCardFeeWaiverProps();
		
		if(CardUtil.isEmptyOrNull(cardStatusMap.get(CardConstant.EOPS_SR).get(creditcardvo.getCardNo())) && 
				CardUtil.isEmptyOrNull(cardStatusMap.get(CardConstant.CEMS_SR).get(creditcardvo.getCardNo()))){
			
			if(StringUtils.length(creditcardvo.getCardNo()) == CardConstant.AMEX_CARD_MIN_LENGTH){
				creditcardvo.setCardNo(StringUtils.leftPad(creditcardvo.getCardNo(), CardConstant.AMEX_CARD_LENGTH, 
						CardConstant.AMEX_CARD_PREFIX));
	        }
			ccFeeWaiverEligibilityUtility.getEligibilityDetails(journeyMap, creditcardvo, creditcardDto, props);
			String hasEligibility = (String) journeyMap.get(CardConstant.KEY_ELIGIBILITY);
			log.info("CCFeeWaiverAsyncService getCreditCardTransactionList hasEligibility : "+hasEligibility);
			if (hasEligibility != null && hasEligibility.equalsIgnoreCase(CardConstant.CONS_Y)) {
			
				transDao.getTxnRefreshdate(journeyMap, props);
				Date edmpTransactionrefreshDate = (Date) journeyMap
						.get(CardConstant.KEY_EDMP_TRANC_BATCH_DT);
				
				//to pull the latest eligibility loaded date from EDMP.
				eligibilityDao.getEligibilityRefreshdate(journeyMap, props);
				Date edmpRAEligibilityRefreshDate = (Date) journeyMap
						.get(CardConstant.KEY_EDMP_ELIGIBILITY_BATCH_DT);
				
				//to pull the fee type related description [Narration, Tran code] and other detail from DB.
				List<SRParamDto> param = (List<SRParamDto>) getHKTxnDetails(creditcardvo.getCountryCode(), 
						creditcardvo.getFeeType(),props.getIdparams());
				journeyMap.put(CardConstant.KEY_PARAM_DTO, param);
				
				//to fetch unprocessed transactions from CCMS
				creditCardFeeWaiverService.fetchUnprocessedCCMSTransactions(props,creditcardvo,journeyMap);
				List<CreditCardTransactionDto> unprocessedTransactions = (List<CreditCardTransactionDto>) journeyMap.get(CardConstant.UNPROCESSED_CREDIT_TRANC);
		
				if(unprocessedTransactions.isEmpty()) {
						//to get the transactions from EDMP for the selected fee type.
						
						edmp12MonthTransactions = creditCardFeeWaiverService.findAllTransactionsFromEDMP(
								creditcardvo, creditcardDto, journeyMap, props);
						
						log.info("CCFeeWaiverAsyncService List of transactions [From EDMP] ["+edmp12MonthTransactions+"]  for the selected Fee type  ["+creditcardvo.getFeeType()+"]");
						try {
							TransactionAsyncDto transactionAsyncDto = transactionAsyncService.getCreditCardTransactions(populateCreditCardVO(creditcardvo,
									CardConstant.START_PAGE_01,CardConstant.FUNC_CD_U,CardConstant.CONS_Y), "U");
			                ccmsC400Transactions = transactionAsyncDto.getCcmsC400Transactions();
				        } catch(Exception ex){
				        	throw new TechnicalException(ex);
				        }
						
						unBilledtransactionList = new LinkedList<CreditCardTransactionDto>();
						eligibilityList = new ArrayList<CreditCardTransactionDto>();
						log.info("CCFeeWaiverAsyncService Date pulled from EDMP - Tran Batch Dt["+edmpTransactionrefreshDate+"] RA Refresh Dt["+edmpRAEligibilityRefreshDate+"]");
						log.info("CCFeeWaiverAsyncService List of transactions from CCMS / C400 ["+ccmsC400Transactions+"]  UnBilled ["+unBilledtransactionList+"] ");
						
						statemantedTransaction = creditCardFeeWaiverService.validateCCSystemTransactions(
								creditcardvo, unBilledtransactionList,
								statemantedTransaction, ccmsC400Transactions,
								eligibilityList, true,
								edmpTransactionrefreshDate,
								edmpRAEligibilityRefreshDate,null);
						
						//actual debit and credit recon. process.
						reconciledTransactionList = reconcileTransaction
								.getHKReconciledTransaction(unBilledtransactionList,
										edmp12MonthTransactions,
										statemantedTransaction, creditcardvo,
										journeyMap, creditcardDto,feeDesc);
						
						log.info("CCFeeWaiverAsyncService List of transactions from CCMS / C400 - Recon Tran List ["+reconciledTransactionList+"] Stmt Trans ["+statemantedTransaction+"]");
						
						//building error messages.
						if ((reconciledTransactionList.size() == CardConstant.SIZE_ONE)
								&& (!CardUtil.isEmptyOrNull(reconciledTransactionList.get(CardConstant.ZERO).getErrorCode()))) {
		
							log.info("[CCFeeWaiverAsyncService getCreditcardTransactionsAndRewardPoint() - No data validation ...] ");
		
							if (reconciledTransactionList.get(CardConstant.ZERO).getErrorCode().equalsIgnoreCase(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT)) {
								creditCardFeeWaiverService.setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT,
										getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_DEBIT,creditcardvo.getLangCode(),props.getErrorCodesAndDesc()));
								creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_NO);
							}
							else if (reconciledTransactionList.get(0).getErrorCode().equalsIgnoreCase(CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED)) {
								creditCardFeeWaiverService.setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED,
										getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_CD_ALL_TRANC_PROCESSED,creditcardvo.getLangCode(),props.getErrorCodesAndDesc()));
								creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_NO);
							}
						}else {
							log.info("[CCFeeWaiverAsyncService getCreditcardTransactionsAndRewardPoint() - about to do the Eligibility...] ");
							
							creditCardFeeWaiverService.checkEligibilityandRewardPoint(reconciledTransactionList,eligibilityList, journeyMap, creditcardDto,creditcardvo, props);
							creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_YES);
						}
				} else {
						log.info("CCFeeWaiverAsyncService Duplicate Unprocessed transaction found in CCMS ["+creditcardvo.getCardType()+"]");
						creditCardFeeWaiverService.setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_DUPLICATE,
								getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_CD_DUPLICATE,creditcardvo.getLangCode(),props.getErrorCodesAndDesc()));
						creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_NO);
				}
			} else {
				log.info("CCFeeWaiverAsyncService Eligibilty Validation Card is not Eligibile");
				creditCardFeeWaiverService.setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_HK_CD_CUST_NOT_ELIGIBLE,
						getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_HK_CD_CUST_NOT_ELIGIBLE,creditcardvo.getLangCode(),props.getErrorCodesAndDesc()));
				creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_NO);
			}
		} else {

			log.info("[CCFeeWaiverAsyncService getCreditcardTransactions ] [Customer Id: "
					+ creditcardvo.getCustomerId() + "] [Eops/Cems - Duplicate transaction found ] [Card No"+creditcardvo.getCardNo()+"]");
			creditCardFeeWaiverService.setErrorMessage(creditcardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_DUPLICATE,
					getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_CD_DUPLICATE,creditcardvo.getLangCode(),props.getErrorCodesAndDesc()));
			creditcardDto.setUiEligibleFeeWaiver(CardConstant.CONS_NO);
		
		}

		if(CardConstant.CONS_Y.equalsIgnoreCase(isCardMaskingRequired)){
			String encryptedCardNum = encryptDecryptHelper
					.performEncryptDecrypt(6, 4, creditcardDto.getCardNum(),
							CardConstant.ENCRYPT, creditcardvo.getCustomerId());
			creditcardDto.setCardNum(encryptedCardNum);
		}
		log.info("CCFeeWaiverAsyncService getCreditCardTransactionList Exit");
		journeyMap = null;
		return creditcardDto;
	}
	
	public CreditCardVO populateCreditCardVO(CreditCardVO creditCardVO, String pageNo,String funcionCD,String nav){
        CreditCardVO creditCardVOTmp = new CreditCardVO();
        creditCardVOTmp.setCustomerId(creditCardVO.getCustomerId());
        creditCardVOTmp.setRelId(creditCardVO.getRelId());
        creditCardVOTmp.setCustomerType(creditCardVO.getCustomerType());
        creditCardVOTmp.setChannelId(creditCardVO.getChannelId());
        creditCardVOTmp.setCountryCode(creditCardVO.getCountryCode());
        creditCardVOTmp.setCardNo(creditCardVO.getCardNo());
        creditCardVOTmp.setFeeType(creditCardVO.getFeeType());
        creditCardVOTmp.setEligibleFeeWaiver(creditCardVO.getEligibleFeeWaiver());
        creditCardVOTmp.setStartPageNumber(pageNo);
		creditCardVOTmp.setFunctionCd(funcionCD);
		creditCardVOTmp.setNavIndicator(nav);
		creditCardVOTmp.setTxtCurrCode(creditCardVO.getTxtCurrCode());
        return creditCardVOTmp;
    }
	
	protected <T> CompletableFuture<List<T>> allOf(List<CompletableFuture<T>> futuresList) {
        CompletableFuture<Void> allFuturesResult =
                CompletableFuture.allOf(futuresList.toArray(new CompletableFuture[futuresList.size()]));
        return allFuturesResult.thenApply(v ->
                futuresList.stream().
                        map(future -> future.join()).
                        collect(Collectors.<T>toList())
        );
    }
	

	public SRParamDto getHKUITxnDetails(String countryCode,String feeType){
        SRParamDto inputParam = new SRParamDto();
        log.info("[getHKUITxnDetails-ENTRY]" + "[FeeType]"
                     + feeType);
        inputParam.setCountryCode(countryCode);
        inputParam.setParamId(CardConstant.ID_PARAM_RECONCILATIONPARAMS);
        inputParam.setParamKey1(CardConstant.CC_UI_FEETYPE);
        inputParam.setParamKey2(feeType);
        List<SRParamDto> paramList= CardUtil.loadSrParamByObject(inputParam, ccDao);
        inputParam = paramList.get(CardConstant.ZERO);
        log.info("[getHKUITxnDetails-Exit]" + inputParam.toString());
        return inputParam;
	}
	
	public List<SRParamDto> getHKTxnDetails(String countryCode,String feeType,List<String> paramIds){
		List<Serializable> ids = new ArrayList<>();
		for (String id : paramIds) {
			ids.add(id);
		}
        List<SRParamDto> paramList= CardUtil.loadSrParamListByObject(ids, ccDao);
        log.info("[getHKTxnDetails size : ]" +paramList.size());
        return paramList;
	}
	
	@SuppressWarnings("static-access")
	public List<CreditCardDto> findAllCreditCard(CreditCardVO creditCardVO) {

		log.info("CCFeeWaiverAsyncService findAllCreditCard Entry");
		
		final List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
		List<CreditCardDto> creditcardDtolist = creditCardService
				.findAllCreditCard(creditCardVO);
		CreditCardProperties ccProps = cardUtil.getCreditCardPropertiesBean();
		String isCardMaskingRequired = creditCardFeeWaiverService.getCardMaskRequiredStatus(creditCardVO.getCountryCode());
		creditcardDtolist
				.forEach(creditCardDto -> {
					if (creditCardDto.getIsPrimary() != null && 
							creditCardDto.getIsPrimary().equalsIgnoreCase(CardConstant.CONS_Y)) {
						creditCardDto.setCustomerId(creditCardVO.getCustomerId());
						creditCardDto.setActiveCards(creditCardVO.getActiveCards());
						creditCardDto.setSrName(creditCardVO.getSrName());
						creditCardDto.setIsMaskCardNo(isCardMaskingRequired);
						if(cardUtil.isEmptyOrNull(creditCardDto.getCardType())) {
							creditCardDto.setCardType(CardUtil.getOriginalCardType(creditCardDto.getCardNum(), ccProps.getCreditCardFilters().getCardTypes()));
					    }
						if(CardConstant.CONS_Y.equalsIgnoreCase(isCardMaskingRequired)){
							String encryptedCardNumber = encryptDecryptHelper
									.performEncryptDecrypt(6, 4,
											creditCardDto.getCardNum(),
											CardConstant.ENCRYPT,
											creditCardVO.getCustomerId());
							creditCardDto.setCardNum(encryptedCardNumber);
					    }
						creditCardDto.setIsPrimary(null);
						validateBusinessRulesHK(creditCardDto, creditCardVO,
								activeCreditCardList,ccProps.getCreditCardFeeWaiverProps());
					}

				});

		if (activeCreditCardList.isEmpty()) {
			CreditCardDto returnCreditCardDto = new CreditCardDto();
			returnCreditCardDto.setCustomerId(creditCardVO.getCustomerId());
			returnCreditCardDto.setActiveCards(creditCardVO.getActiveCards());
			returnCreditCardDto.setSrName(creditCardVO.getSrName());
			returnCreditCardDto.setErrorCode(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS);
			returnCreditCardDto.setErrorDescription(getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS,
					creditCardVO.getLangCode(),ccProps.getCreditCardFeeWaiverProps().getErrorCodesAndDesc()));
			activeCreditCardList.add(returnCreditCardDto);
		}

		log.info("[CCFeeWaiverAsyncService findAllCreditCard Exit][ activeCreditCardList size] "
				+ activeCreditCardList.size());

		return activeCreditCardList;
	}
	
	private List<CreditCardDto> validateBusinessRulesHK(
			CreditCardDto creditCardDto, CreditCardVO creditCardVO,
			List<CreditCardDto> activeCreditCardList,CreditCardFeeWaiverProperties props) {
		
		log.info("CCFeeWaiverAsyncService validateBusinessRulesHK Card Status : "+creditCardDto.getCardStatus());
		log.info("CCFeeWaiverAsyncService validateBusinessRulesHK Block Code :"+creditCardDto.getBlockCode());
		if (props.getActiveStatusCode().contains(creditCardDto.getCardStatus())
				&& (CardUtil.isEmptyOrNull(creditCardDto.getBlockCode()) || props.getBlockCode().contains(creditCardDto.getBlockCode()))) {
			activeCreditCardList.add(creditCardDto);
		}
		return activeCreditCardList;
	}
	
	/**
	 * This method returns Services Request status for a customer from Eops and Cems system and the status will be used for checking duplicate request for the requested fee types.
	 * 
	 * @param creditcardvo
	 * @return
	 */
	public Map<String, Map<String, String>> getEopsCemsSRStatus(CreditCardVO creditcardvo) {
		
		log.info("CCFeeWaiverAsyncService getEopsCemsSRStatus Entered... ");
		List<CompletableFuture<TransactionAsyncDto>> creditCardsFutureList = new ArrayList<>();
		Map<String, Map<String, String>> cardStatusMap = new HashMap<String, Map<String,String>>();
		List<String> feeTypes = new ArrayList<String>();
		CreditCardFeeWaiverProperties props = cardUtil.getCreditCardPropertiesBean(
				creditcardvo.getCountryCode()).getCreditCardFeeWaiverProps();
		List<SRParamDto> paramDtoList = getHKTxnDetails(creditcardvo.getCountryCode(), creditcardvo.getFeeType(),props.getIdparams());
		for(SRParamDto paramDto : paramDtoList) {
			if(!CardUtil.isEmptyOrNull(paramDto.getParamData9())) {
				feeTypes.add(paramDto.getParamData9());
			}
		}
		try {
			if(CardConstant.CONS_Y.equalsIgnoreCase(props.getEopsDuplicateChekRequired())){
				creditCardsFutureList.add(transactionAsyncService.getAsyncEopsCemsServiceReqList(
					creditcardvo, CardConstant.EOPS_SR, feeTypes));
			} else {
				cardStatusMap.put(CardConstant.EOPS_SR,new HashMap<String,String>());
			}
			
			if(CardConstant.CONS_Y.equalsIgnoreCase(props.getCemsDuplicateChekRequired())){
				creditCardsFutureList.add(transactionAsyncService.getAsyncEopsCemsServiceReqList(
					creditcardvo, CardConstant.CEMS_SR, feeTypes));
			} else {
				cardStatusMap.put(CardConstant.CEMS_SR,new HashMap<String,String>());
			}
		
            CompletableFuture<List<TransactionAsyncDto>> creditCardDetailsFuture = allOf(creditCardsFutureList);
            for(TransactionAsyncDto transactionAsyncDto : creditCardDetailsFuture.get()){
            	if(transactionAsyncDto.getRequestType().equals(CardConstant.EOPS_SR)) {
            		cardStatusMap.put(CardConstant.EOPS_SR, transactionAsyncDto.getEOpsCemsTransactions());	
            	}
            	else if(transactionAsyncDto.getRequestType().equals(CardConstant.CEMS_SR)) {
            		cardStatusMap.put(CardConstant.CEMS_SR, transactionAsyncDto.getEOpsCemsTransactions());	
            	}
            }
        } catch(Exception ex){
        	log.info("getEopsCemsSRStatus..Exception during Eops or Cems call", ex);
        	throw new TechnicalException(ex);
        }
		log.info("CCFeeWaiverAsynService getEopsCemsSRStatus completed...");
		return cardStatusMap;
	}
	
	public String getMessageDesc(String errorCode,String langCode,Map<String,String> errorCodesAndDesc) {
		if (langCode != null && (langCode.equalsIgnoreCase(CardConstant.LANG_CH_TRADITIONAL) || 
				langCode.equalsIgnoreCase(CardConstant.LANG_CH_SIMPLIFIED))) {
			return errorCodesAndDesc.get(errorCode+"_"+langCode.toLowerCase());
		} else {
			return errorCodesAndDesc.get(errorCode);
		}
	}
	
	/**
	 * This method returns credit card details along with transactions when requested from IVR.
	 * 
	 * @param creditcardvo
	 * @return
	 */
	public List<CreditCardDto> getCreditcardTransactionsForIVR(
			CreditCardVO creditcardvo) {
		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsForIVR Entered] ");

		final List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();

		if (ArrayUtils.contains(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS, creditcardvo.getCountryCode())) {
			creditcardvo.setCardNoSearch(true);
		}  
		List<CreditCardDto> creditcardDtolist = creditCardService
				.getAllCreditCards(creditcardvo);
		
		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsForIVR creditcardDtolist] "+creditcardDtolist);
		
		CreditCardProperties ccProps = cardUtil.getCreditCardPropertiesBean();
		
		for(CreditCardDto creditCardDto : creditcardDtolist) {
			if(null != creditcardvo.getCardNo() && creditcardvo.getCardNo().equalsIgnoreCase(creditCardDto.getCardNum())) {
				validateBusinessRulesHK(creditCardDto, creditcardvo,
						activeCreditCardList,ccProps.getCreditCardFeeWaiverProps());
				break;
			}
		}
		
		log.info("[CreditCardFeeWaiverService getCreditcardTransactionsForIVR activeCreditCardList] "+activeCreditCardList);
		if (activeCreditCardList.isEmpty()) {
			CreditCardDto returnCreditCardDto = new CreditCardDto();
			returnCreditCardDto.setCustomerId(creditcardvo.getCustomerId());
			returnCreditCardDto.setEligibleFeeWaiver(creditcardvo.getEligibleFeeWaiver());
			returnCreditCardDto.setFeeType(creditcardvo.getFeeType());
			returnCreditCardDto.setCardNumbers(creditcardvo.getCardNo());
			returnCreditCardDto.setCardNum(creditcardvo.getCardNo());
			creditCardFeeWaiverService.setErrorMessage(returnCreditCardDto,CardConstant.CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS,
					getMessageDesc(CardConstant.CC_FEE_WAIVER_ERR_CD_NO_ACTIVE_CARDS,
							creditcardvo.getLangCode(),ccProps.getCreditCardFeeWaiverProps().getErrorCodesAndDesc()));
			activeCreditCardList.add(returnCreditCardDto);
			log.info("[CCFeeWaiverAsyncService getCreditcardTransactionsForIVR Exit][ activeCreditCardList size] "
					+ activeCreditCardList.size());
			return activeCreditCardList;
		}
		else {
			log.info("[CreditCardFeeWaiverService getCreditcardTransactionsForIVR else Entered] [Customer Id: "
					+ creditcardvo.getCustomerId() + "]");
			List<CreditCardDto> creditCardList = new ArrayList<CreditCardDto>();
			List<CreditCardDto> creditCardListing = null;
			Map<String, Map<String, String>> cardStatusMap = getEopsCemsSRStatus(creditcardvo);
			try {	
				creditcardvo.setCardNo(activeCreditCardList.get(0).getCardNum());
				creditcardvo.setTxtCurrCode(activeCreditCardList.get(0).getCurrencyCode());
				creditcardvo = creditCardFeeWaiverService.populateCreditCardVO(creditcardvo, creditcardvo.getCardNo());
				CreditCardDto creditCardDto = getCreditCardTransactionList(creditcardvo, creditcardvo.getCardNo(), 
						creditCardListing,cardStatusMap,"","N");
				creditCardList.add(creditCardDto);
				
	        } catch(BusinessException ex){
	            log.info("getCreditcardTransactionsForIVR...BusinessException....{}", ex.getErrorCode());
	            throw ex;
	        } catch (Exception ex) {
	        	log.info("getCreditcardTransactionsForIVR...Exception....{}", ex);
	            throw new TechnicalException(ex);
			}
			
			return creditCardList;
		}
	}
}

