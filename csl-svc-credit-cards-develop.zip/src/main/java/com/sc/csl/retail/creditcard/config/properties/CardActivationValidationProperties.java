package com.sc.csl.retail.creditcard.config.properties;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardActivationValidationProperties {

	private List<String> allowedBin = new ArrayList<>();
}
