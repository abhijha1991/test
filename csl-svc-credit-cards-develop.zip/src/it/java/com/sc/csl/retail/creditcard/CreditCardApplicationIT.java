
package com.sc.csl.retail.creditcard;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = { CreditCardApplication.class})
public class CreditCardApplicationIT {

    @Test
    public void run() throws Exception{
        CreditCardApplication.main(new String[] {"csl-svc-credit-cards"});
    }
}
