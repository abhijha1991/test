package com.sc.csl.retail.creditcard.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import com.sc.csl.retail.core.exception.CSLErrorCodeUtil;
import org.junit.Test;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.ErrorCode;

import lombok.Getter;
import org.mockito.Mock;

@Getter
public class CreditCardErrorCodeTest {

	@Mock
	CSLErrorCodeUtil cSLErrorCodeUtil;

	@Test
	public void shouldGenerate_throw_business_exception() {
		CreditCardErrorCode creditCardErrorCode = CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID;
		BusinessException exception = new BusinessException(creditCardErrorCode);

		ErrorCode actualErrorCode = exception.getErrorCode();

		assertEquals("ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID", actualErrorCode.getCode());
		assertEquals("Customer Id Invalid", actualErrorCode.getTitle());
		assertEquals("Response Empty", actualErrorCode.getDescription());

	}

	@Test
	public void shouldReturn_ErrorCode_When_getBusinessErrorCode_Method_Called() {
		ErrorCode error=CreditCardErrorCode.getBusinessErrorCode("");
		assertEquals("ERR_CSL_CREDIT_CARDS_GENERAL_ERROR", error.getCode());
	}

	@Test
	public void shouldReturn_ErrorCode_When_getBusinessErrorCode_Method_Called_With_badFormatErrorCode() throws Exception {
		ErrorCode error=CreditCardErrorCode.getBusinessErrorCode("ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID");
		assertEquals("ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID", error.getCode());
	}

	@Test
	public void shouldReturn_GeneralErrorCode_When_getBusinessErrorCode_Method_Called_With_badFormatErrorCode() {
		ErrorCode error=CreditCardErrorCode.getBusinessErrorCode("ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID : Customer Id Invalid : Response Empty");
		assertEquals("ERR_CSL_CREDIT_CARDS_GENERAL_ERROR", error.getCode());
	}

	@Test
	public void testToString(){
		CreditCardErrorCode creditCardErrorCode = CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID;
		String toString = "ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID : Customer Id Invalid : Response Empty";
		String resultString =CSLErrorCodeUtil.convertToString(creditCardErrorCode);
		assertEquals(toString, resultString);
	}

	@Test
	public void returnException_When_call_toString_Method()
	{
		CreditCardErrorCode creditCardErrorCode  =  CreditCardErrorCode.ERR_CSL_CREDIT_CARDS_INVALID_CUSTOMER_ID;
		String result = creditCardErrorCode.toString();
		assertNotNull(result);
	}
}
