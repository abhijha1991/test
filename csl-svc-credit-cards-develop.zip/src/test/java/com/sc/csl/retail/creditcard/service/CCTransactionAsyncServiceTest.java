package com.sc.csl.retail.creditcard.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.dto.Spv1ServiceRequestInfo;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestSPV1Gateway;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class CCTransactionAsyncServiceTest {

	@InjectMocks
	private CCTransactionAsyncService transactionAsyncService;
	
	@Mock
	private ServiceRequestSPV1Gateway statusEnquiryCEMSGateway;
	
	@Mock
	protected ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
	
	@Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
	
	@Test(expected=NullPointerException.class)
	public void getCreditCardTransactions() {
		CreditCardVO creditcardvo=new CreditCardVO();
		creditcardvo.setCountryCode("HK");
		creditcardvo.setRelId("51437658");
		creditcardvo.setActiveCards("Yes");
		transactionAsyncService.getCreditCardTransactions(creditcardvo, "U");
	}
	
	@Test
	public void fetchServiceRequestFromCems(){
		CreditCardVO creditcardvo=new CreditCardVO();
		creditcardvo.setCountryCode("HK");
		creditcardvo.setRelId("51437658");
		creditcardvo.setActiveCards("Yes");
		List<String> feeTypes = new ArrayList<>();
		feeTypes.add("Annual Fee");
		
		
		List<Spv1ServiceRequestInfo> serviceEnquiryList = new ArrayList<Spv1ServiceRequestInfo>();
		Spv1ServiceRequestInfo spv1ServiceRequestInfo = new Spv1ServiceRequestInfo();
        spv1ServiceRequestInfo.setReceiptId("CI1707171149F30005");
        spv1ServiceRequestInfo.setRelNumber("01S0000799D");
        spv1ServiceRequestInfo.setCountry("SG");
        spv1ServiceRequestInfo.setCompletedDate("17/07/2017");
        spv1ServiceRequestInfo.setStatus("Completed");
        HashMap<String,Object> payload = new HashMap<>();
        List<LinkedHashMap<String, String>> temp = new ArrayList<LinkedHashMap<String, String>>();
        payload.put("products",temp);
        spv1ServiceRequestInfo.setPayload(payload);
        serviceEnquiryList.add(spv1ServiceRequestInfo);
	        
		when(statusEnquiryCEMSGateway.getServiceRequests(any(String.class), any(String.class)))
        .thenReturn(serviceEnquiryList);
		
		transactionAsyncService.getAsyncEopsCemsServiceReqList(creditcardvo, "Cems", feeTypes);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void fetchServiceRequestFromEops(){
		CreditCardVO creditcardvo=new CreditCardVO();
		creditcardvo.setCountryCode("HK");
		creditcardvo.setRelId("51437658");
		creditcardvo.setChannelId("IBNK");
		creditcardvo.setActiveCards("Yes");
		List<String> feeTypes = new ArrayList<>();
		feeTypes.add("Annual Fee");
		
		HashMap<String, Object> payload = new HashMap<>();
		payload.put("products", new ArrayList<LinkedHashMap<String, String>>());
		List<ServiceRequest> serviceEnquiryList= new ArrayList<ServiceRequest>();
		ServiceRequest spv1ServiceRequestInfo = new ServiceRequest();
        spv1ServiceRequestInfo.setReceiptId("CI1707171149F30005");
        spv1ServiceRequestInfo.setStatus("Completed");
        spv1ServiceRequestInfo.setPayload(payload);
        serviceEnquiryList.add(spv1ServiceRequestInfo);
        
        List<String> serviceTypes = new ArrayList<>();
        serviceTypes.add("Fee Waiver");
	        
		when(serviceRequestJsonApiGateway.enquireStatus(any(String.class), any(String.class),any(String.class),any(List.class)))
        .thenReturn(serviceEnquiryList);
		
		transactionAsyncService.getAsyncEopsCemsServiceReqList(creditcardvo, "Eops", feeTypes);
	}
}
