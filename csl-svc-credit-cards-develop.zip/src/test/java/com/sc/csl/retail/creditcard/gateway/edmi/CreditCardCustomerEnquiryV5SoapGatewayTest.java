package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.v5.customer.*;
import com.sc.corebanking.v5.ws.provider.customer.*;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.GatewayHeaderProperties;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.scbml_1.Code;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.SCBMLHeaderType;

import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.powermock.api.mockito.PowerMockito;

import javax.xml.bind.Unmarshaller;
import javax.xml.ws.Holder;

import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doReturn;

/**
 * Created by 1572136 on 11/7/2017.
 */
public class CreditCardCustomerEnquiryV5SoapGatewayTest {

    @InjectMocks
    CreditCardCustomerEnquiryV5SoapGateway creditCardCustomerEnquiryV5SoapGateway;

    @Mock
    FreemarkerRenderer renderer;
    @Mock
    Unmarshaller unmarshaller;
    @Mock
    CSLSoapGatewayProperties creditCardProfileV1SoapGatewayProperties;
    @Mock
    CardUtil cardUtil;
    @Mock
    BaseCreditCardsSoapGateway baseSoapGateway;
    @Spy
    Map<String, CreditCardProperties> creditCardProperties= new HashMap<>();
    @Mock
    CSLXmlUtils cslXmlUtils;

    CreditCardProperties countryProp;
    Map<String, String> errorCodes;
    Map<String, String> currencyCodes;

    @Before
    public void init()throws Exception {

        countryProp = new CreditCardProperties();
        GatewayHeaderProperties gatewayHeaderProperties = new GatewayHeaderProperties();
        gatewayHeaderProperties.setCaptureSystem("CCMS");
        gatewayHeaderProperties.setEntityType("05");
        gatewayHeaderProperties.setFuncCode("16");
        gatewayHeaderProperties.setMessageVersion("1.0");
        gatewayHeaderProperties.setPayLoadVersion("1.0");
        gatewayHeaderProperties.setSourceFlag("IBK");
        countryProp.setCardDetailsProperties(gatewayHeaderProperties);
        countryProp.setCardHistoryProperties(gatewayHeaderProperties);
        countryProp.setCardListProperties(gatewayHeaderProperties);
        errorCodes = new HashMap();
        errorCodes.put("-1", "ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT");
        errorCodes.put( "0001", "ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO");
        errorCodes.put("10001", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
        errorCodes.put("10009", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
        currencyCodes = new HashMap();
        currencyCodes.put("248", "ALA");
        currencyCodes.put("008", "ALB");
        currencyCodes.put("012", "DZA");
        CreditCardFilterProperties creditCardFilterProperties = new CreditCardFilterProperties();
        creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0");
        creditCardFilterProperties.setIsSupplCardStausCheckEnabled("Y");
        creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0|1");
        creditCardFilterProperties.setBlockCodeDateBlockCodes("W:L|S");
        creditCardFilterProperties.setTransferEffectiveDateBlockCodes("W:L|S");
        creditCardFilterProperties.setBlockCodeDateDays(60);
        countryProp.setCreditCardFilters(creditCardFilterProperties);
        countryProp.setErrorCodes(errorCodes);
        countryProp.setCurrencyCodes(currencyCodes);
        creditCardProperties.put("IN", countryProp);

        baseSoapGateway = PowerMockito.mock(BaseCreditCardsSoapGateway.class, Mockito.CALLS_REAL_METHODS);


        creditCardCustomerEnquiryV5SoapGateway= PowerMockito.mock(CreditCardCustomerEnquiryV5SoapGateway.class, Mockito.CALLS_REAL_METHODS);

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getCreditCards() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();

        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");

        CustomerPortType cpt=new CustomerPortType(){
            public void notifyContactDetailsChange(NotifyContactDetailsChange2 notifyContactDetailsChange) {

            }

            @Override
            public CreateCustomerChoiceRes createCustomerChoice(CreateCustomerChoiceReq createCustomerChoiceRequest) {
                return null;
            }

            @Override
            public SetupConsolidatedStatementRes setupConsolidatedStatement(SetupConsolidatedStatementReq setupConsolidatedStatementRequest) {
                return null;
            }

            @Override
            public CreateCustomerHoldingPatternRes createCustomerHoldingPattern(CreateCustomerHoldingPatternReq createCustomerHoldingPatternRequest) {
                return null;
            }

            @Override
            public GetCustomerSearchDetailsRes getCustomerSearchDetails(GetCustomerSearchDetailsReq getcustomerSearchDetailsReq) {
                return null;
            }

            @Override
            public RegisterIBFTPayeeRes registerIBFTPayee(RegisterIBFTPayeeReq registerIBFTPayeeRequest) {
                return null;
            }

            @Override
            public GetCustomerRiskDetailsRes getCustomerRiskDetails(GetCustomerRiskDetailsReq getCustomerRiskDetailsReq) {
                return null;
            }

            @Override
            public GetCustomerCardDetailsRes getCustomerCardDetails(GetCustomerCardDetailsReq getCustomerCardDetailsRequest) {
                return null;
            }

            @Override
            public AddPayeeDetailsRes addPayeeDetails(AddPayeeDetailsReq addPayeeDetailsRequest) {
                return null;
            }

            @Override
            public CreateCustomerRes createCustomer(CreateCustomerReq createCustomerRequest) {
                return null;
            }

            @Override
            public GetAllRes getAll(GetAllReq getAllRequest) {
                return null;
            }

            @Override
            public GetCustomerPortfolioDetailsRes getCustomerPortfolioDetails(GetCustomerPortfolioDetailsReq getCustomerPortfolioDetailsRequest) {

                GetCustomerPortfolioDetailsRes getCustomerPortfolioDetailsRes=new GetCustomerPortfolioDetailsRes();
                SCBMLHeaderType header=new SCBMLHeaderType();

                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getCustomerPortfolioDetailsRes.setHeader(header);

                GetCustomerPortfolioDetailsResPayload getCustomerPortfolioDetailsResPayload=new GetCustomerPortfolioDetailsResPayload();

                Customer customer=new Customer();

                CustomerInfo customerInfo=new CustomerInfo();

                SingleCustomerView singleCustomerView=new SingleCustomerView();
                DocTypeRefComDataTypeString docTypeRefComDataTypeString=new DocTypeRefComDataTypeString();
                docTypeRefComDataTypeString.setValue(CardConstant.HOGAN_CREDIT_CARD_PRODUCT_CODE);

                singleCustomerView.setAccountProductCode(docTypeRefComDataTypeString);

                DocTypeRefComDataTypeString docTypeRefComDataTypeString1=new DocTypeRefComDataTypeString();
                docTypeRefComDataTypeString1.setValue("11");
                singleCustomerView.setAccountNumber(docTypeRefComDataTypeString1);

                DocTypeRefComDataTypeString docTypeRefComDataTypeString3=new DocTypeRefComDataTypeString();
                docTypeRefComDataTypeString3.setValue("Org");
                singleCustomerView.setV53Organization(docTypeRefComDataTypeString3);

                customerInfo.getSingleCustomerView().add(singleCustomerView);

                customer.setCustomerInfo(customerInfo);


                getCustomerPortfolioDetailsResPayload.setGetCustomerPortfolioDetailsRes(customer);


                getCustomerPortfolioDetailsRes.setGetCustomerPortfolioDetailsResPayload(getCustomerPortfolioDetailsResPayload);

                return getCustomerPortfolioDetailsRes;
            }

            @Override
            public ModifyPayeeDetailsRes modifyPayeeDetails(ModifyPayeeDetailsReq modifyPayeeDetailsRequest) {
                return null;
            }

            @Override
            public void notifyCustomerIDChange(NotifyCustomerIDChange2 notifyCustomerIDChange) {

            }

            @Override
            public ModifyCustomerHoldingPatternRes modifyCustomerHoldingPattern(ModifyCustomerHoldingPatternReq modifyCustomerHoldingPatternRequest) {
                return null;
            }

            @Override
            public ModifyCustomerContactDetailsRes modifyCustomerContactDetails(ModifyCustomerContactDetailsReq modifyCustomerContactDetailsRequest) {
                return null;
            }

            @Override
            public GetCustomerRestraintsRes getCustomerRestraints(GetCustomerRestraintsReq getCustomerRestraintsReq) {
                return null;
            }

            @Override
            public GetCustomerMasterDetailsRes getCustomerMasterDetails(GetCustomerMasterDetailsReq getCustomerMasterDetailsRequest) {
                return null;
            }

            @Override
            public GetCustomerFATCADetailsRes getCustomerFATCADetails(GetCustomerFATCADetailsReq getCustomerFATCADetailsRequest) {
                return null;
            }

            @Override
            public GetCustomerContactDetailsRes getCustomerContactDetails(GetCustomerContactDetailsReq getCustomerContactDetailsRequest) {
                return null;
            }

            @Override
            public GetCustomerChoiceRes getCustomerChoice(GetCustomerChoiceReq getCustomerChoiceRequest) {
                return null;
            }

            @Override
            public ModifyAsiaMilesFulfilmentDetailsRes modifyAsiaMilesFulfilmentDetails(ModifyAsiaMilesFulfilmentDetailsReq modifyAsiaMilesFulfilmentDetailsRequest) {
                return null;
            }

            @Override
            public ModifyCustomerDetailsRes modifyCustomerDetails(ModifyCustomerDetailsReq modifyCustomerDetailsRequest) {
                return null;
            }

            @Override
            public GetCustomerGeneralDetailsRes getCustomerGeneralDetails(GetCustomerGeneralDetailsReq getCustomerGeneralDetailsRequest) {
                return null;
            }

            @Override
            public GetAsiaMilesFulfillmentDetailsRes getAsiaMilesFulfillmentDetails(GetAsiaMilesFulfillmentDetailsReq getAsiaMilesFulfillmentDetailsRequest) {
                return null;
            }

            @Override
            public MaintainPhoneBankingIDRes maintainPhoneBankingID(MaintainPhoneBankingIDReq maintainPhoneBankingIDRequest) {
                return null;
            }

            @Override
            public DeleteIBFTPayeeRes deleteIBFTPayee(DeleteIBFTPayeeReq deleteIBFTPayeeRequest) {
                return null;
            }

            @Override
            public GetCustomerEmploymentDetailsRes getCustomerEmploymentDetails(GetCustomerEmploymentDetailsReq getCustomerEmploymentDetailsRequest) {
                return null;
            }

            public void notifyCustomer(NotifyCustomer2 notifyCustomer) {

            }

            @Override
            public ModifyCustomerChoiceRes modifyCustomerChoice(ModifyCustomerChoiceReq modifyCustomerChoiceRequest) {
                return null;
            }

			@Override
			public void notifyContactDetailsChange(
					NotifyContactDetailsChange2 notifyContactDetailsChange,
					Holder<String> protocol, Holder<String> subprotocol,
					Holder<Email> email, Holder<Http> http, Holder<Ftp> ftp,
					Holder<FilePolling> filePolling, Holder<Jms> jms) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void notifyCustomer(NotifyCustomer2 notifyCustomer,
					Holder<String> protocol, Holder<String> subprotocol,
					Holder<Email> email, Holder<Http> http, Holder<Ftp> ftp,
					Holder<FilePolling> filePolling, Holder<Jms> jms) {
				// TODO Auto-generated method stub
				
			}
        };

        doReturn(cpt).when(creditCardCustomerEnquiryV5SoapGateway, "getProxyClient");

        // com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes response
        // when(creditCardEnquiryV1SoapGateway.getProxyClient().getDetails()).thenReturn(new com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes());
        creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO);
    }
}