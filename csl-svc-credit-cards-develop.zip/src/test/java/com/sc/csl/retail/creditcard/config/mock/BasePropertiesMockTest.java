package com.sc.csl.retail.creditcard.config.mock;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 1452875
 * @since Sep 20, 2017
 */
@Getter
@Setter
public class BasePropertiesMockTest {
    private CreditCardPropertiesMockTest creditCardProps;
}
