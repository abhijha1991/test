package com.sc.csl.retail.creditcard.service;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dao.CreditCardTransactionEDMPDao;
import com.sc.csl.retail.creditcard.dao.impl.CreditCardTransactionEDMPDaoImpl;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.dto.ServiceRequest;
import com.sc.csl.retail.creditcard.dto.post.CCFeeWaiverPostDto;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestSPV1Gateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.EncryptionDecryptionHelper;
import com.sc.csl.retail.creditcard.helper.ReconcileRewardPoint;
import com.sc.csl.retail.creditcard.helper.ReconcileTransaction;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class CreditcardFeeWaiverServiceTest {
	
	@InjectMocks
	private CreditCardFeeWaiverService ccFeeWaiverService;
	@Mock
	private CreditCardService creditCardService;
	@Mock
	private CardUtil cardUtil;
	@Mock
	private ReconcileTransaction reconcileTransaction;
	@Mock
	private ReconcileRewardPoint reconcileRewardPoint;
	@Mock
	private CreditCardRepositoryDao ccDao;
	@Mock
	private EncryptionDecryptionHelper encryptDecryptHelper;
	@Mock
	private CreditCardTransactionEDMPDao transDao;
	@Mock
	private CreditCardTransactionEDMPDaoImpl transDaoImpl;
	@Mock
	private CreditCardValidator creditCardValidator;
	@Mock
	private ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
	@Mock
	private ServiceRequestSPV1Gateway spv1Gateway;
	@Mock
	private CSLRequestContext cslReqContxt;
	
	@Before
    public void setUp() {
       MockitoAnnotations.initMocks(this);

    }
	
	@Test
 public void getAllActiveCreditCards_active_cards_present(){
	List<CreditCardDto> cardList=new ArrayList<CreditCardDto>();
	
	SRParamDto inputParam=new SRParamDto();
	inputParam.setCountryCode("IN");
	inputParam.setParamId(CardConstant.ID_PARAM_I0006);
	inputParam.setParamKey1(CardConstant.CARD_NO_MASK_REQ);
	
	List<SRParamDto> srparamList = new ArrayList<SRParamDto>();
	srparamList.add(inputParam);
	
	CreditCardVO ccVo=new CreditCardVO();
	ccVo.setCountryCode("IN");
	ccVo.setRelId("51437658");
	ccVo.setActiveCards("Yes");
	
	CreditCardDto obj1=new CreditCardDto();
	obj1.setBlockCode("B");
	obj1.setCardNum("1237854763");
	obj1.setCardNum("0");
	obj1.setCardStatus("0");
	
	CreditCardDto obj2=new CreditCardDto();
	obj2.setBlockCode("A");
	obj2.setCardNum("8327984273");
	obj2.setCardNum("0");
	obj2.setCardStatus("1");
	
	List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
	
	activeCreditCardList.add(obj1);
	activeCreditCardList.add(obj2);
	
	when(creditCardService.getAllCreditCards(ccVo)).thenReturn(activeCreditCardList);
	CreditCardProperties credtProps=new CreditCardProperties();
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setBlockCode("A");
	props.setActiveStatusCode("0,1,2");
	credtProps.setCreditCardFeeWaiverProps(props);
	
	when(cardUtil.getCreditCardPropertiesBean()).thenReturn(credtProps);
	when(CardUtil.loadSrParamByObject(inputParam,
			ccDao)).thenReturn(srparamList);
	
	when(encryptDecryptHelper
	.performEncryptDecrypt(6,4,obj2.getCardNum(),
			CardConstant.ENCRYPT,
			ccVo.getCustomerId())).thenReturn("XXXXXX");
	
	 cardList =ccFeeWaiverService.getAllActiveCreditCards(ccVo);
	 assertEquals(1, cardList.size());
	
}
	
//@Test
public void getAllActiveCreditCards_active_cards_present1(){
	List<CreditCardDto> cardList=new ArrayList<CreditCardDto>();
	
	SRParamDto inputParam=new SRParamDto();
	inputParam.setCountryCode("IN");
	inputParam.setParamId(CardConstant.ID_PARAM_I0006);
	inputParam.setParamKey1(CardConstant.CARD_NO_MASK_REQ);
	
	List<SRParamDto> srparamList = new ArrayList<SRParamDto>();
	srparamList.add(inputParam);
	
	CreditCardVO ccVo=new CreditCardVO();
	ccVo.setCountryCode("SG");
	ccVo.setRelId("51437658");
	ccVo.setActiveCards("Yes");
	
	CreditCardDto obj1=new CreditCardDto();
	obj1.setBlockCode("B");
	obj1.setCardNum("1237854763");
	obj1.setCardNum("0");
	
	CreditCardDto obj2=new CreditCardDto();
	obj2.setBlockCode("B");
	obj2.setCardNum("8327984273");
	obj2.setCardNum("0");
	List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
	
	activeCreditCardList.add(obj1);
	activeCreditCardList.add(obj2);

	when(CardUtil.loadSrParamByObject(inputParam, ccDao)).thenReturn(srparamList);

	when(encryptDecryptHelper.performEncryptDecrypt(6,4,obj1.getCardNum(),CardConstant.ENCRYPT,
			ccVo.getCustomerId())).thenReturn("XXXXXX");
	when(encryptDecryptHelper.performEncryptDecrypt(6,4,obj2.getCardNum(),CardConstant.ENCRYPT,
			ccVo.getCustomerId())).thenReturn("XXXXXX");
	when(creditCardService.getAllCreditCards(ccVo)).thenReturn(activeCreditCardList);
	
	CreditCardProperties credtProps=new CreditCardProperties();
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setBlockCode("A");
	props.setActiveStatusCode("0,1,2");
	credtProps.setCreditCardFeeWaiverProps(props);
	
	when(cardUtil.getCreditCardPropertiesBean()).thenReturn(credtProps);
	
	
	cardList =ccFeeWaiverService.getAllActiveCreditCards(ccVo);
	assertEquals(2,cardList.size());
	
}

//@Test
public void getAllActiveCreditCards_active_cards_not_present1(){
	List<CreditCardDto> cardList=new ArrayList<CreditCardDto>();
	CreditCardVO ccVo=new CreditCardVO();
	ccVo.setCountryCode("IN");
	ccVo.setCustomerId("01S1394251Z");
	ccVo.setActiveCards("Yes");
	
	
	CreditCardDto obj1=new CreditCardDto();
	obj1.setBlockCode("A");
	obj1.setCardNum("1234543456567689");
	
	CreditCardDto obj2=new CreditCardDto();
	obj2.setBlockCode("A");
	obj2.setCardNum("1234543456567689");
	List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
	
	activeCreditCardList.add(obj1);
	activeCreditCardList.add(obj2);
	
	when(creditCardService.getAllCreditCards(ccVo)).thenReturn(activeCreditCardList);
	CreditCardProperties credtProps=new CreditCardProperties();
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setBlockCode("A");
	props.setActiveStatusCode("0,1,2");
	credtProps.setCreditCardFeeWaiverProps(props);
	
	when(cardUtil.getCreditCardPropertiesBean()).thenReturn(credtProps);
	when(encryptDecryptHelper
	.performEncryptDecrypt(6,4,obj2.getCardNum(),
			CardConstant.ENCRYPT,
			ccVo.getCustomerId())).thenReturn("XXXXXX");
	
	 cardList=ccFeeWaiverService.getAllActiveCreditCards(ccVo);
	assertEquals(1,cardList.size());
	//assertEquals("3000",cardList.get(0).getErrorCode());
	
}

@Test
public void getAllActiveCreditCards_active_cards_not_presentIVR(){
	CreditCardDto cardList=new CreditCardDto();
	CreditCardVO ccVo=new CreditCardVO();
	ccVo.setCountryCode("IN");
	ccVo.setRelId("51437658");
	ccVo.setActiveCards("Yes");
	
	CreditCardDto obj2=new CreditCardDto();
	obj2.setBlockCode("A");
	obj2.setCardNum("8327984273");
	obj2.setCardNum("0");
	List<CreditCardDto> activeCreditCardList = new ArrayList<CreditCardDto>();
	
	activeCreditCardList.add(obj2);
	
	when(creditCardService.findOneCreditCard(ccVo)).thenReturn(obj2);
	CreditCardProperties credtProps=new CreditCardProperties();
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setBlockCode("A");
	props.setActiveStatusCode("0,1,2");
	credtProps.setCreditCardFeeWaiverProps(props);
	
	when(cardUtil.getCreditCardPropertiesBean()).thenReturn(credtProps);
	
	cardList=ccFeeWaiverService.getCreditcardTransactionsAndRewardPointIVR(ccVo);
	assertEquals("3000",cardList.getErrorCode());
	
}

	@Test
	public void findAllTransactionsFromEDMP_check1() {
		CreditCardVO creditCardVO = new CreditCardVO();
		creditCardVO.setCardNo("1140xxxxxxxxx00002");
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		CreditCardDto cDto = new CreditCardDto();
		SRParamDto inputDto = new SRParamDto();
		inputDto.setParamData2("01");
		inputDto.setParamData3("AF");
		inputDto.setParamData4("02");
		inputDto.setParamData5("04");
		inputDto.setParamData9("AF");
		journeyMap.put(CardConstant.KEY_REWARD_PARAM_DTO, inputDto);
		CreditCardTransactionDto ccTransDto = new CreditCardTransactionDto();
		ccTransDto.setCardNum("1140xxxxxxxxx00002");
		ccTransDto.setTxnCode("01");
		ccTransDto.setTxnDate("01012017");
		ccTransDto.setActualTxnAmount(new BigDecimal("123"));
		ccTransDto.setDesc("AF");
		ccTransDto.setTxnRefNo("12312");
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		edmp12MonthTransactions.add(ccTransDto);
		CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
		ccFeeWaiverService.findAllTransactionsFromEDMP(creditCardVO, cDto,
				journeyMap, props);
		assertEquals(1, edmp12MonthTransactions.size());
	}

	    
    @Test
	public void getCreditCardPost() {
		CreditCardDto ccDto = new CreditCardDto();
		CCFeeWaiverPostDto ccPostDto = new CCFeeWaiverPostDto();
		
		List<CreditCardDto> postCreditCards = new ArrayList<CreditCardDto>(1);
		CreditCardDto cardPostDto = new CreditCardDto();
		cardPostDto.setCardNum("1234234");
		
		postCreditCards.add(cardPostDto);
		ccDto.setBlockCode("B");
		ccDto.setPostCreditCards(postCreditCards);
		ccDto.setRequestType("REVERSAL");
		//ccDto.setOperationName("FEEWPROC");
		
		ServiceRequest serviceRequest = new ServiceRequest();
		serviceRequest.setReceiptId("01010101");
		
		CSLRequestContext cslRequestContext = new CSLRequestContext();
		CreditCardFeeWaiverProperties cardFeeWaiverProperties = new CreditCardFeeWaiverProperties();
		
		when(creditCardValidator.validateCCFPostServiceRequest(ccDto)).thenReturn(true);
		when(cardUtil.populateCreditCardDTO(cslRequestContext , ccDto)).thenReturn(ccDto);
		when(creditCardService.generatePayLoad(cardPostDto, ccPostDto)).thenReturn(serviceRequest);
		//when(ccFeeWaiverService.getBean()).thenReturn(cardFeeWaiverProperties);
		//when(serviceRequestJsonApiGateway.createServiceRequest(serviceRequest)).thenReturn(serviceRequest);
		
		ccFeeWaiverService.createServiceRequest(ccDto);
		
		assertEquals("01010101", serviceRequest.getReceiptId());
	}	
    
	
//    @Test
//   	public void fetchServiceRequestFromEopsTest() {
//    	CreditCardVO creditcardvo = new CreditCardVO();
//    	String cardNumbersArray[] ={"1140xxxxxxxxx00002", "1140xxxxxxxxx00003"};
//    	String feeType ="LATE_FEE";
//    	HashMap payloadMap = new HashMap();
//    	LinkedHashMap<String, String> info = new LinkedHashMap<String, String>();
//    	payloadMap.put("products", info);
//    	
//    	List<ServiceRequest> serviceReq = new ArrayList<ServiceRequest>();
//    	ServiceRequest request = new ServiceRequest();
//    	request.setServiceType("Credit Card Fee Waiver Request");		
//    	request.setPayload(payloadMap);
//    	
//    	ccFeeWaiverService.fetchServiceRequestFromEops( creditcardvo, cardNumbersArray,  feeType);
//    	when(serviceRequestJsonApiGateway.enquireStatus(creditcardvo.getCountryCode(), creditcardvo.getRelId(), creditcardvo.getChannelId())).thenReturn(serviceReq);
//    	
//    	
//    }
}
