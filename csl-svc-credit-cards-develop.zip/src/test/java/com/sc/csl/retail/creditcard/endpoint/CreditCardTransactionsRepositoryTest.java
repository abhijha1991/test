package com.sc.csl.retail.creditcard.endpoint;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * Created by 1568078 on 7/7/2017.
 */
public class CreditCardTransactionsRepositoryTest {

    @Mock
    private CreditCardService creditCardService;

    @InjectMocks
    private CreditCardTransactionRepository creditCardTransactionRepository;

    @Mock
    QuerySpec querySpec;

    @Mock
    CardUtil cardUtil;

    @Mock
    private CSLRequestContext mockCSLRequestContext;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

    }

    @Test
    public void shouldReturn_CreditCardTransactionDto_ListObject_When_findAll_Method_Called() {
        ResourceList<CreditCardTransactionDto> creditTransDtoList = new DefaultResourceList<>();
        CreditCardTransactionDto creditCardTransactionDto = null;
        creditTransDtoList.add(manualBuildTransDtoObject(creditCardTransactionDto));
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        when(mockCSLRequestContext.getCustomerType()).thenReturn("01");
        when(mockCSLRequestContext.getRelId()).thenReturn("070565A0SH04005");
        when(mockCSLRequestContext.getCompositeRelId()).thenReturn("01070565A0SH04005");
        when(mockCSLRequestContext.getCountry()).thenReturn("IN");
        when(mockCSLRequestContext.getChannel()).thenReturn("WEB");
        when(cardUtil.populateCreditCardVO(mockCSLRequestContext)).thenReturn(creditCardVO);
        when(creditCardService.findAllCreditCardTransaction(creditCardVO)).thenReturn(creditTransDtoList);
        DefaultResourceList<CreditCardTransactionDto> list=new DefaultResourceList();
        list.add(manualBuildTransDtoObject(creditCardTransactionDto));
        when(querySpec.apply(creditTransDtoList)).thenReturn(list);
        List<CreditCardTransactionDto> creditTransDtoList1 =creditCardTransactionRepository.findAll(querySpec);
        assertNotNull(creditTransDtoList1);
        assertEquals("4129057530874005",creditTransDtoList1.get(0).getCardNum());
        assertEquals("Credit Card",creditTransDtoList1.get(0).getDesc());
        assertEquals("IN",creditTransDtoList1.get(0).getCountry());
        assertEquals("01070565A0SH04005",creditTransDtoList1.get(0).getCustomerId());
    }

   private CreditCardTransactionDto manualBuildTransDtoObject(CreditCardTransactionDto creditCardTransactionDto){
        creditCardTransactionDto=new CreditCardTransactionDto();
        creditCardTransactionDto.setCardNum("4129057530874005");
        creditCardTransactionDto.setDesc("Credit Card");
        creditCardTransactionDto.setOriginTxnAmt(new BigDecimal(200));
        creditCardTransactionDto.setTxnCurr("356");
        creditCardTransactionDto.setTxnRefNo("11290575308711111");
       creditCardTransactionDto.setCountry("IN");
       creditCardTransactionDto.setCustomerId("01070565A0SH04005");
        return creditCardTransactionDto;
    }

}