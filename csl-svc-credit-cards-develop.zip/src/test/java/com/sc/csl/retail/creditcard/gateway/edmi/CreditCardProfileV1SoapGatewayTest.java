package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.creditcard.v1.creditcardenquiry.*;
import com.sc.corebanking.creditcard.v1.creditcardenquiry.CardKeysType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.*;
import com.sc.corebanking.creditcard.v1.creditcardprofile.AcctBalType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.AcctInfoType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.AcctInqRsType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.AcctRecType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.BalTypeType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.CardPeriodDataType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.CurAmtType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.CurCodeType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.GetDetailsResData;
import com.sc.corebanking.creditcard.v1.creditcardprofile.GetDetailsResPayload;
import com.sc.corebanking.creditcard.v1.creditcardprofile.SCBAcctInfoType;
import com.sc.corebanking.creditcard.v1.creditcardprofile.SCBCardKeysType;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardprofile.*;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.GatewayHeaderProperties;
import com.sc.csl.retail.creditcard.config.properties.OfflineDataProperties;
import com.sc.csl.retail.creditcard.dto.CardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.gateway.csl.CreditCardSharedServiceJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.scbml_1.Code;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.SCBMLHeaderType;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.powermock.api.mockito.PowerMockito;


import javax.xml.bind.Unmarshaller;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doReturn;


public class CreditCardProfileV1SoapGatewayTest {

    @InjectMocks
    CreditCardProfileV1SoapGateway creditCardProfileV1SoapGateway;

    @Mock
    FreemarkerRenderer renderer;
    @Mock
    Unmarshaller unmarshaller;
    @Mock
    CSLSoapGatewayProperties creditCardProfileV1SoapGatewayProperties;
    @Mock
    CardUtil cardUtil;

    @Mock
    BaseCreditCardsSoapGateway baseSoapGateway;

    @Mock
    OfflineDataProperties offlineDataProperties;

    @Spy
    Map<String, CreditCardProperties> creditCardProperties = new HashMap<>();

    @Mock
    private CreditCardSharedServiceJsonApiGateway creditCardSharedServiceJsonApiGateway;

    CreditCardProperties countryProp;
    Map<String, String> errorCodes;
    Map<String, String> currencyCodes;

    @Before
    public void init() throws Exception {

        countryProp = new CreditCardProperties();
        GatewayHeaderProperties gatewayHeaderProperties = new GatewayHeaderProperties();
        gatewayHeaderProperties.setCaptureSystem("CCMS");
        gatewayHeaderProperties.setEntityType("05");
        gatewayHeaderProperties.setFuncCode("16");
        gatewayHeaderProperties.setMessageVersion("1.0");
        gatewayHeaderProperties.setPayLoadVersion("1.0");
        gatewayHeaderProperties.setSourceFlag("IBK");
        countryProp.setCardDetailsProperties(gatewayHeaderProperties);
        countryProp.setCardHistoryProperties(gatewayHeaderProperties);
        countryProp.setCardListProperties(gatewayHeaderProperties);
        errorCodes = new HashMap();
        errorCodes.put("-1", "ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT");
        errorCodes.put("0001", "ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO");
        errorCodes.put("10001", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
        errorCodes.put("10009", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
        currencyCodes = new HashMap();
        currencyCodes.put("248", "ALA");
        currencyCodes.put("008", "ALB");
        currencyCodes.put("012", "DZA");
        CreditCardFilterProperties creditCardFilterProperties = new CreditCardFilterProperties();
        creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0");
        creditCardFilterProperties.setIsSupplCardStausCheckEnabled("Y");
        creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0|1");
        creditCardFilterProperties.setBlockCodeDateBlockCodes("W:L|S");
        creditCardFilterProperties.setTransferEffectiveDateBlockCodes("W:L|S");
        creditCardFilterProperties.setBlockCodeDateDays(60);

        countryProp.setCreditCardFilters(creditCardFilterProperties);
        countryProp.setErrorCodes(errorCodes);
        countryProp.setCurrencyCodes(currencyCodes);
        creditCardProperties.put("IN", countryProp);

        baseSoapGateway = PowerMockito.mock(BaseCreditCardsSoapGateway.class, Mockito.CALLS_REAL_METHODS);

        /* offlineDataProperties=new OfflineDataProperties();
        offlineDataProperties.setCreditCardPortfolio("CC");*/

        creditCardProfileV1SoapGateway = PowerMockito.mock(CreditCardProfileV1SoapGateway.class, Mockito.CALLS_REAL_METHODS);

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void shouldReturn_CreditCardDto_List_When_getCreditCards_Method_Called() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map = new HashMap<>();

        creditCardProperties = (CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(), Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");


        CreditCardProfilePortType cc = new CreditCardProfilePortType() {
            @Override
            public UpdateRes update(UpdateReq updateRequest) {
                return null;
            }

            @Override
            public CreateRes create(CreateReq createRequest) {
                return null;
            }

            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardprofile.GetDetailsRes getDetails(com.sc.corebanking.creditcard.v1.ws.provider.creditcardprofile.GetDetailsReq getDetailsRequest) {
                return null;
            }

            @Override
            public GetLimitRes getLimit(GetLimitReq getLimitRequest) {
                return null;
            }

            @Override
            public GetCardListingRes getCardListing(GetCardListingReq getCardListingRequest) {

                GetCardListingRes getCardListingRes = new GetCardListingRes();

                SCBMLHeaderType header = new SCBMLHeaderType();
                //set header
                ExceptionListType exceptionListType = new ExceptionListType();
                ExceptionType exceptionType = new ExceptionType();
                Code value = new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getCardListingRes.setHeader(header);

                //response
                GetCardListingResPayload getCardListingResPayload = new GetCardListingResPayload();

                GetCardListingResData getCardListingResData = new GetCardListingResData();

                AcctStmtRecType acctStmtRecType = new AcctStmtRecType();


                AcctInqRsType acctInqRsType = new AcctInqRsType();
                acctInqRsType.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                acctInqRsType.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                AcctRecType acctRecType = new AcctRecType();

                AcctInfoType acctInfoType = new AcctInfoType();

                acctInfoType.setSCBCustBlockCode("Cd");
                CurCodeType curCodeType = new CurCodeType();
                acctInfoType.setCurCode(curCodeType);
                SCBAcctInfoType sCBAcctInfoType = new SCBAcctInfoType();

                SCBCardInfoType sCBCardInfoType = new SCBCardInfoType();
                sCBCardInfoType.setSCBCardCat("scb");
                sCBCardInfoType.setSCBRwdpts("11");
                sCBCardInfoType.setSCBCardNum("12345");
                AcctBalType acctBalType = new AcctBalType();
                BalTypeType balTypeType = new BalTypeType();
                balTypeType.setBalTypeValues(CardConstant.CREDIT_LIMIT);
                CurAmtType curAmtType = new CurAmtType();
                curAmtType.setAmt("111");
                acctBalType.setCurAmt(curAmtType);
                acctBalType.setBalType(balTypeType);
                sCBCardInfoType.getCardBal().add(acctBalType);
                CardPeriodDataType cardPeriodDataType = new CardPeriodDataType();
                cardPeriodDataType.setCardAmtType(CardConstant.STMT_BALANCE);
                sCBCardInfoType.getCardPeriodData().add(cardPeriodDataType);

                SCBCardKeysType sCBCardKeysType = new SCBCardKeysType();

                sCBCardInfoType.setSCBCardKeys(sCBCardKeysType);
                sCBAcctInfoType.getSCBCardInfo().add(sCBCardInfoType);


                acctInfoType.setSCBAcctInfo(sCBAcctInfoType);

                acctRecType.setAcctInfo(acctInfoType);

                AcctEnvrType acctEnvr = new AcctEnvrType();

                CardKeysType cardKeysType = new CardKeysType();
                cardKeysType.setCardNum(BigInteger.valueOf(111L));
                acctEnvr.setCardKeys(cardKeysType);
                //   acctRecType.setAcctEnvr(acctEnvr);

                acctInqRsType.getAcctRec().add(acctRecType);

                getCardListingResData.setGetCardListingRs(acctInqRsType);

                getCardListingResPayload.setGetCardListingRes(getCardListingResData);

                getCardListingRes.setGetCardListingResPayload(getCardListingResPayload);

                return getCardListingRes;
            }

            @Override
            public PreCUCORes preCUCO(PreCUCOReq preCUCORequest) {
                return null;
            }

            @Override
            public SearchRes search(SearchReq searchRequest) {
                return null;
            }

            @Override
            public UpdateLimitRes updateLimit(UpdateLimitReq updateLimitRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardProfileV1SoapGateway, "getProxyClient");

        creditCardProfileV1SoapGateway.getCreditCards(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardDto_List_When_getCreditCardsFromSharedService_Method_Called() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map = new HashMap<>();

        creditCardProperties = (CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);

        when(offlineDataProperties.getCreditCardPortfolio()).thenReturn("IN");

        List<CardDto> creditCardsFromSharedService = new ArrayList<>();

        CardDto cardDto=new CardDto();
        cardDto.setAvailableLimit(BigDecimal.ONE);
        cardDto.setCurrentBalance(BigDecimal.ONE);
        cardDto.setCreditLimit(BigDecimal.ONE);
        cardDto.setMinimumPayment(BigDecimal.ONE);

        creditCardsFromSharedService.add(cardDto);

        when(creditCardSharedServiceJsonApiGateway.fetchAllCreditCardAccounts()).thenReturn(creditCardsFromSharedService);

        creditCardProfileV1SoapGateway.getCreditCardsFromSharedService(creditCardVO,new Exception(),"'");
    }

    @Test
    public void shouldReturn_CreditCardDto_When_getCardDetails_Method_Called() throws Exception {
        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map = new HashMap<>();

        creditCardProperties = (CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(), Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");


        CreditCardProfilePortType cc = new CreditCardProfilePortType() {
            @Override
            public UpdateRes update(UpdateReq updateRequest) {
                return null;
            }

            @Override
            public CreateRes create(CreateReq createRequest) {
                return null;
            }

            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardprofile.GetDetailsRes getDetails(com.sc.corebanking.creditcard.v1.ws.provider.creditcardprofile.GetDetailsReq getDetailsRequest) {

                GetDetailsRes getDetailsRes = new GetDetailsRes();

                SCBMLHeaderType header = new SCBMLHeaderType();
                //set header
                ExceptionListType exceptionListType = new ExceptionListType();
                ExceptionType exceptionType = new ExceptionType();
                Code value = new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getDetailsRes.setHeader(header);

                //response
                GetDetailsResPayload getDetailsResPayload=new GetDetailsResPayload();

                GetDetailsResData getDetailsResData=new GetDetailsResData();

                PartyInqRsType partyInqRsType=new PartyInqRsType();
                partyInqRsType.setRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                partyInqRsType.setRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                PartyRecType partyRecType=new PartyRecType();
                IndividualCustomerInfoType individualCustomerInfoType=new IndividualCustomerInfoType();
                ContactInformationType contactInformationType=new ContactInformationType();
                AnyStringsType anyStringsType=new AnyStringsType();
                anyStringsType.setValue("Mobile");
                contactInformationType.setContactType(anyStringsType);
                contactInformationType.setCustomerContactNumber(anyStringsType);
                individualCustomerInfoType.getContactInformation().add(contactInformationType);
                partyRecType.setSCBICMPartyInfo(individualCustomerInfoType);

                partyInqRsType.getPartyRec().add(partyRecType);

                getDetailsResData.setGetDetailsRs(partyInqRsType);

                getDetailsResPayload.setGetDetailsRes(getDetailsResData);

                getDetailsRes.setGetDetailsResPayload(getDetailsResPayload);

                return getDetailsRes;
            }

            @Override
            public GetLimitRes getLimit(GetLimitReq getLimitRequest) {
                return null;
            }

            @Override
            public GetCardListingRes getCardListing(GetCardListingReq getCardListingRequest) {

                return null;

            }

            @Override
            public PreCUCORes preCUCO(PreCUCOReq preCUCORequest) {
                return null;
            }

            @Override
            public SearchRes search(SearchReq searchRequest) {
                return null;
            }

            @Override
            public UpdateLimitRes updateLimit(UpdateLimitReq updateLimitRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardProfileV1SoapGateway, "getProxyClient");

        creditCardProfileV1SoapGateway.getCardDetails(creditCardVO);
    }



    @Test(expected = Exception.class)
    public void shouldReturn_CreditCardVO_When_getAsyncCreditCardsList_Method_Called() throws Exception {
        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        creditCardProfileV1SoapGateway.getAsyncCreditCardsList(creditCardVO);
    }

    @Test(expected=Exception.class)
    public void shouldReturn_CreditCardVO_When_getCreditCardListCreditCardVO_Method_Called() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        when(creditCardProfileV1SoapGateway.getCreditCards(Mockito.anyObject())).thenReturn(new ArrayList<CreditCardDto>());

        creditCardProfileV1SoapGateway.getCreditCardListCreditCardVO(creditCardVO);
    }

}