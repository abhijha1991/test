package com.sc.csl.retail.creditcard.service.security;

import io.katharsis.errorhandling.ErrorResponse;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.helpers.IOUtils;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.core.web.header.CSLUser;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.dto.customer.CreditCardContact;
import com.sc.csl.retail.creditcard.dto.security.SmsOtp;
import com.sc.csl.retail.creditcard.dto.security.ValidateOtp;
import com.sc.csl.retail.creditcard.exception.CardException;
import com.sc.csl.retail.creditcard.exception.CardExceptionMapper;
import com.sc.csl.retail.creditcard.gateway.csl.CustomerJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.csl.SmsOtpGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ValidateOtpGateway;

@RunWith(MockitoJUnitRunner.class)
public class SmsOtpRequiredServiceTest {

    @InjectMocks
    private SmsOtpRequiredService smsOtpRequiredService;

    @Mock
    private CSLRequestContext cslRequestContext;

    @Mock
    private SmsOtpGateway otpGateway;
    @Mock
    private ValidateOtpGateway validateOtpGateway;
    @Mock
    private CustomerJsonApiGateway customerJsonApiGateway;
    @Mock
    private CreditCardRepositoryDao ccDao;
    
    @Rule
    public final ExpectedException exception = ExpectedException.none();
    
    public SmsOtp response;
    
    public void initialize() throws IOException {
        CSLUser cslUser = new CSLUser("9113237694", "01010145RDGE0", "IN", "en", "EXBN");
        CSLRequestContext cslRequestContext = new CSLRequestContext("mock_test_session_id_creditcard2", "mock_test_req_id_creditcard2", cslUser, null);
        smsOtpRequiredService = new SmsOtpRequiredService();
        smsOtpRequiredService.setCslRequestContext(cslRequestContext);

        CustomerJsonApiGateway customerJsonApiGateway = Mockito.mock(CustomerJsonApiGateway.class);
        SmsOtpGateway otpGateway = Mockito.mock(SmsOtpGateway.class);
        response = Mockito.mock(SmsOtp.class);
        SmsOtp smsOtpResponse = new SmsOtp();
        smsOtpResponse.setBase64Challenge("MTUwNDYwOTAxOTc3M18tX0lCS18tX0hLXy1fMDFDMzAzMzYwXy1faWlCbHVRQUtfLV9uUGhndGNNL1BQNjFSdGNrd1prU2hvSHcwTUhjck9DUXNTZ2p6VVZkMDBzPQ==");
        smsOtpResponse.setModulus("b6b44e815345da9297e595cc88bd6ba7ac5fe4d08bb7aa795951b71b093ad0e0bde4b638570ca038ba0d73222c62286c6a926793f88ae411280c3b92ac5c79d2c142d4a600a376420e101a31936697c2adb56ee0e96be21320eacfefe7f97fd5ad0e59bbf1ff75efa2ae50b6fdb3acd46e89fd993efe4fbf775a071c19d9d694c6f97a47fdd64df0b87338aa839db9b4d5cc907de7c409c5fd7db5921123081b766f795afcb70a7fce5b953a9c4b557b5cebed277cec522fe752c09706d571ebb6620ebdece8c6cd66fc146f562dc5b674cba1361afc6bbe2f050558071b691a0e67e6e57bc9abb8ee64971c23ef14302ab27643fcfad50e123af630c9bc77d9");
        smsOtpResponse.setKeyIndex("3");
        smsOtpResponse.setStatusCode("100");
        smsOtpResponse.setOtpSn("89");
        smsOtpResponse.setOtpPrefix("uXvd");
        smsOtpResponse.setExponent("10001");
        List<CreditCardContact> creditCardContacts = new ArrayList<CreditCardContact>();
        creditCardContacts = constructCreditCardConstacts(creditCardContacts);
        ReflectionTestUtils.setField(smsOtpRequiredService, "customerJsonApiGateway", customerJsonApiGateway);
        ReflectionTestUtils.setField(smsOtpRequiredService, "otpGateway", otpGateway);
        //ReflectionTestUtils.setField(smsOtpRequiredService, "msgTemplate", "RU5UUkVaIExFIE1PVCBERSBQQVNTRSBBIFVTQUdFIFVOSVFVRSAoT1RQKSBDT01QT1NFIERFIDYgQ0hJRkZSRVMgRU5WT1lFIEEgVk9UUkUgVEVMRVBIT05FIFBPUlRBQkxFIHtvdHB9");
        ReflectionTestUtils.setField(smsOtpRequiredService, "otpGateway", otpGateway);
        ReflectionTestUtils.setField(smsOtpRequiredService, "ccDao", ccDao);
        List<SRParamDto> srParamList = new ArrayList<SRParamDto>();
        SRParamDto srParam = new SRParamDto();
        srParam.setParamData1("ON");
        srParamList.add(srParam);
        Mockito.when(ccDao.getSrParam(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(srParamList);
        Mockito.when(customerJsonApiGateway.getCustomerCCContact(Mockito.anyString())).thenReturn(creditCardContacts);
        Mockito.when(otpGateway.sendOtp(Mockito.anyString())).thenReturn(smsOtpResponse);
       // Mockito.when(smsOtpRequiredService.getOTPStatus()).thenReturn(true);

    }
    
    public void initializeValidateOtpData() {
        ValidateOtpGateway validateOtpGateway = Mockito.mock(ValidateOtpGateway.class);
        CSLUser cslUser = new CSLUser("9113237694", "01010145RDGE0", "IN", "en", "EXBN");
        CSLRequestContext cslRequestContext = new CSLRequestContext("mock_test_session_id_creditcard2", "mock_test_req_id_creditcard2", cslUser, null);
        cslRequestContext._otpToken("[{\"smsOtp\":{\"otpSn\":\"17025\",\"encOtp\":\"rKaRV8cFG9ZxBZR+jiaWPwtOc3r7QfouC8aHEiCcH8JiB09doC9KP8ic3ZlAf5SAwaWWBKa5XiN2Eh7nBujwaXy7z1yT1fLg4WPfF18MdwwRy4iUbkGTVeUOIKlybBvWEQhRknrhcQsZycvdEbClwhANs+ORlxVPF4GuwiCZxwZ2VZTQJ27pgRqUkb+HVvmp/ZhFHQgk5C3D6B318Q3yg65VcQejMdp21j094RXnnFtmIZJ9+bOdFfJHcNPmLY57WuK6GZ0asOzrXPlJcDJHOd5H8S/hZFqx4ji7s0NwfH+IDv52Vl5oINw8cklCB4jTrF0CAEJ1sELSEW7fsTZBSQ==\",\"purpose\":\"1\",\"keyIndex\":\"3\"}}]");
        smsOtpRequiredService = new SmsOtpRequiredService();
        smsOtpRequiredService.setCslRequestContext(cslRequestContext);
        ReflectionTestUtils.setField(smsOtpRequiredService, "validateOtpGateway", validateOtpGateway);
        ReflectionTestUtils.setField(smsOtpRequiredService, "ccDao", ccDao);
        ValidateOtp validateOtp = new ValidateOtp();
        validateOtp.setEncOtp("CFUJ7A63tBc0KrGBVb9JK8mJFxXka6NCOFFyqqSapVzMd0bkltKu");
        validateOtp.setOtpSn("86");
        validateOtp.setPurpose("1");
        validateOtp.setKeyIndex("3");
        validateOtp.setCountry("HK");

        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("100");
        validateOtpResponse.setErrorMessage("");
        List<SRParamDto> srParamList = new ArrayList<SRParamDto>();
        SRParamDto srParam = new SRParamDto();
        srParam.setParamData1("ON");
        srParamList.add(srParam);
        Mockito.when(validateOtpGateway.validateOtp(Mockito.any())).thenReturn(validateOtpResponse);
        Mockito.when(ccDao.getSrParam(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(srParamList);
        //Mockito.when(CSLJsonUtils.parseJson(cslRequestContext._otpToken(), ValidateOtp.class)).thenReturn(validateOtp);
        }
    
    @Test
    public void send_Otp_test_() throws IOException {
        initialize();
       // String jsonSmsOtpResponse = getMockData("security/SmsOtpResponse.json");
        //Mockito.when(CSLJsonUtils.toJson(response)).thenReturn(jsonSmsOtpResponse);
        //String jsonSmsOtpResponse = getMockData("security/SmsOtpResponse.json");
        //Mockito.when(CSLJsonUtils.toJson(response)).thenReturn(jsonSmsOtpResponse);
        try {
            smsOtpRequiredService.otprequired();
        } catch (CardException e) {
            CardExceptionMapper cardExceptionMapper = new CardExceptionMapper();
            ErrorResponse errorResponse = cardExceptionMapper.toErrorResponse(e);
            Assert.assertNotNull(errorResponse);
        }

        smsOtpRequiredService.getCslRequestContext()._otpToken();
    }
    
    @Test
    public void validate_Otp_test_() throws IOException {
        initializeValidateOtpData();
        
        try {
            smsOtpRequiredService.otprequired();
        } catch (CardException e) {
            CardExceptionMapper cardExceptionMapper = new CardExceptionMapper();
            ErrorResponse errorResponse = cardExceptionMapper.toErrorResponse(e);
            Assert.assertNotNull(errorResponse);
        }
    }
    protected String getMockData(String fileLoc) throws IOException {
        ClassLoader classLoader = this.getClass().getClassLoader();
        InputStream inputStream = classLoader.getResourceAsStream(fileLoc);
        String mockData = IOUtils.toString(inputStream);
        return mockData;
    }
    
    // In-Eligible CreditCard without excess balance mock: creditcardEnquiry.getCardListing() service Enquiry
    private List<CreditCardContact> constructCreditCardConstacts(
            List<CreditCardContact> creditCardContacts) {
        creditCardContacts = new ArrayList<CreditCardContact>();

        CreditCardContact creditCardContact1 = new CreditCardContact();
        creditCardContact1.setContactDetails("98765456789");
        creditCardContact1.setContactTypeCode("M");
        creditCardContacts.add(creditCardContact1);
        

        CreditCardContact creditCardContact2 = new CreditCardContact();
        creditCardContact2.setContactDetails("98876875175");
        creditCardContact2.setContactTypeCode("H");
        creditCardContacts.add(creditCardContact2);

        return creditCardContacts;
    }

}
