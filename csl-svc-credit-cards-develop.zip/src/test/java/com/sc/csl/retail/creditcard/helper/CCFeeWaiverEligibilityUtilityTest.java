package com.sc.csl.retail.creditcard.helper;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardEligibilityCriteriaDao;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityCriteriaDto;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class CCFeeWaiverEligibilityUtilityTest {

	@InjectMocks
	private CCFeeWaiverEligibilityUtility ccFeeWaiverUtility;
	
	@Mock
	private CreditCardEligibilityCriteriaDao eligibilityDao;
		
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	@Test
	public void getEligibilityDetails_check1_IN() {
		CreditCardDto ccDto = new CreditCardDto();
		ccDto.setBlockCode("u");
		CreditCardVO creditCardVO = new CreditCardVO();
		creditCardVO.setFeeType("annualfee");
		creditCardVO.setCountryCode("IN");
		CreditCardEligibilityCriteriaDto creditCardEligibilityDto = new CreditCardEligibilityCriteriaDto();
		creditCardEligibilityDto.setIsObjNull("N");
		CreditCardEligibilityDto ccEligibiltyDto = new CreditCardEligibilityDto();
		ccEligibiltyDto.setPercentageEligible(new BigDecimal("1"));
		ccEligibiltyDto.setCardEligibilityFlag("Y");
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		Map<String, String> eligibleFeeTypes = new HashMap<String, String>();
		eligibleFeeTypes.put("eligibleFeeTypes",
				"'annualFee','lateFee','overLimitFee','interestCharge'");
		eligibleFeeTypes.put("deliquencycardBlockCodes",
				"'A','C','J','K','P','Q','Z'");
		String tableName = "sj_in_cc_fees_waiver_rst";
		CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
		props.setRaEligibilityCriteria(eligibleFeeTypes);
		when(eligibilityDao.getINEligibilityCriteria(journeyMap,
				creditCardVO.getCardNo(),
				CardConstant.ELIGIBILITY_CARD_LEVEL, tableName)).thenReturn(creditCardEligibilityDto);
		ccFeeWaiverUtility
				.getEligibilityDetails(journeyMap, creditCardVO, ccDto, props);
		assertEquals("Y", ccEligibiltyDto.getCardEligibilityFlag());
	}
	@Test
	public void getEligibilityDetails_check1_SG() {
		CreditCardDto ccDto = new CreditCardDto();
		ccDto.setBlockCode("u");
		CreditCardVO ccVO = new CreditCardVO();
		ccVO.setFeeType("annualfee");
		ccVO.setCountryCode("SG");
		CreditCardEligibilityCriteriaDto creditCardEligibilityDto = new CreditCardEligibilityCriteriaDto();
		creditCardEligibilityDto.setIsObjNull("N");
		CreditCardEligibilityDto ccEligibiltyDto = new CreditCardEligibilityDto();
		ccEligibiltyDto.setCardEligibilityFlag("Y");
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		Map<String, String> eligibleFeeTypes = new HashMap<String, String>();
		eligibleFeeTypes.put("eligibleFeeTypes",
				"'annualFee','latefee','overlimitfee','interestcharge'");
		eligibleFeeTypes.put("deliquencycardBlockCodes",
				"'A','C','J','K','P','Q','Z'");
		CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
		props.setRaEligibilityCriteria(eligibleFeeTypes);
		ccFeeWaiverUtility
				.getEligibilityDetails(journeyMap, ccVO, ccDto, props);
		assertEquals("Y", ccEligibiltyDto.getCardEligibilityFlag());
	}
	
	@Test
	public void getEligibilityDetails_check1_MY() {
		CreditCardDto ccDto = new CreditCardDto();
		ccDto.setBlockCode("u");
		CreditCardVO ccVO = new CreditCardVO();
		ccVO.setFeeType("annualfee");
		ccVO.setCountryCode("MY");
		CreditCardEligibilityCriteriaDto creditCardEligibilityDto = new CreditCardEligibilityCriteriaDto();
		creditCardEligibilityDto.setIsObjNull("N");
		CreditCardEligibilityDto ccEligibiltyDto = new CreditCardEligibilityDto();
		ccEligibiltyDto.setCardEligibilityFlag("Y");
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		Map<String, String> eligibleFeeTypes = new HashMap<String, String>();
		eligibleFeeTypes.put("eligibleFeeTypes",
				"'annualFee','latefee','overlimitfee','interestcharge'");
		eligibleFeeTypes.put("deliquencycardBlockCodes",
				"'A','C','J','K','P','Q','Z'");
		CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
		props.setRaEligibilityCriteria(eligibleFeeTypes);
		ccFeeWaiverUtility
				.getEligibilityDetails(journeyMap, ccVO, ccDto, props);
		assertEquals("Y", ccEligibiltyDto.getCardEligibilityFlag());
	}
	
    @Test
    public void getEligibilityIN_check1() {
           Map<String, Object> journeyMap = new HashMap<String, Object>();
           CreditCardVO creditCardVO = new CreditCardVO();
           creditCardVO.setCardNo("1140xxxxxxxxx00002");
           creditCardVO.setCustomerId("01R70000023");
           CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
           Map<String, String> raEligibilityCriteria = new HashMap<String, String>();
           raEligibilityCriteria.put("deliquencycardBlockCodes",
                        "'A','C','J','K','P','Q','Z'");
           CreditCardEligibilityCriteriaDto ccEligibilityCriteriaDto = new CreditCardEligibilityCriteriaDto();
           props.setEligibiltityTable("SJAPP:sj_in_cc_fees_waiver_rst");
           props.setRaEligibilityCriteria(raEligibilityCriteria);
           String blockCode = "B";
           String feeType = "annualFee";
           ccEligibilityCriteriaDto.setCardNumber("1140");
           ccEligibilityCriteriaDto.setCustomerId("01R70000023");
           ccEligibilityCriteriaDto.setIsObjNull("N");
           String customerId = "01R70000023";
           String tableName = "SJAPP:sj_in_cc_fees_waiver_rst";
           when(
                        eligibilityDao.getINEligibilityCriteria(journeyMap,
                                      creditCardVO.getCardNo(),
                                      CardConstant.ELIGIBILITY_CARD_LEVEL,
                                      props.getEligibiltityTable())).thenReturn(
                        ccEligibilityCriteriaDto);
           when(eligibilityDao
           .getINEligibilityCriteria(journeyMap, customerId,
                        CardConstant.ELIGIBILITY_CUSTOMER_LEVEL,
                        tableName)).thenReturn(ccEligibilityCriteriaDto);
           ccFeeWaiverUtility.getEligibilityIN(journeyMap, creditCardVO, props,
                        blockCode, feeType);

    }
    
    @Test
    public void getEligibilitySG_check1() {
           Map<String, Object> journeyMap = new HashMap<String, Object>();
           CreditCardVO creditCardVO = new CreditCardVO();
           creditCardVO.setCardNo("1140xxxxxxxxx00002");
           creditCardVO.setCustomerId("01R70000023");
           CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
           Map<String, String> raEligibilityCriteria = new HashMap<String, String>();
           raEligibilityCriteria.put("deliquencycardBlockCodes",
                        "'A','C','J','K','P','Q','Z'");
           CreditCardEligibilityCriteriaDto ccEligibilityCriteriaDto = new CreditCardEligibilityCriteriaDto();
           props.setEligibiltityTable("SJAPP:sj_sg_cc_fees_waiver_rst");
           props.setRaEligibilityCriteria(raEligibilityCriteria);
           String feeType = "ANNUAL_FEE";
           ccEligibilityCriteriaDto.setCardNumber("1140");
           ccEligibilityCriteriaDto.setCustomerId("01R70000023");
           ccEligibilityCriteriaDto.setIsObjNull("N");
           ccEligibilityCriteriaDto.setAnnualFeeEligible("Y");
           String tableName = "SJAPP:sj_sg_cc_fees_waiver_rst";
           when(
                        eligibilityDao.getSGEligibilityCriteria(
                                      journeyMap, creditCardVO.getCardNo(),
                                      CardConstant.ELIGIBILITY_CARD_LEVEL, tableName)).thenReturn(
                        ccEligibilityCriteriaDto);
           ccFeeWaiverUtility.getEligibilitySG(journeyMap, creditCardVO, feeType, props);
    }
    
    @Test
    public void getEligibilityMY_check1() {
           Map<String, Object> journeyMap = new HashMap<String, Object>();
           CreditCardVO creditCardVO = new CreditCardVO();
           creditCardVO.setCardNo("1140xxxxxxxxx00002");
           creditCardVO.setCustomerId("01R70000023");
           CreditCardFeeWaiverProperties props = new CreditCardFeeWaiverProperties();
           Map<String, String> raEligibilityCriteria = new HashMap<String, String>();
           raEligibilityCriteria.put("deliquencycardBlockCodes",
                        "'A','C','J','K','P','Q','Z'");
           CreditCardEligibilityCriteriaDto ccEligibilityCriteriaDto = new CreditCardEligibilityCriteriaDto();
           props.setEligibiltityTable("SJAPP:sj_my_cc_fees_waiver_rst");
           props.setRaEligibilityCriteria(raEligibilityCriteria);
           ccEligibilityCriteriaDto.setCardNumber("1140");
           ccEligibilityCriteriaDto.setCustomerId("01R70000023");
           ccEligibilityCriteriaDto.setIsObjNull("N");
           ccEligibilityCriteriaDto.setAnnualFeeEligible("Y");
           ccEligibilityCriteriaDto.setXRemark("Transactor");
           String tableName = "SJAPP:sj_my_cc_fees_waiver_rst";
           when(
                        eligibilityDao
                        .getMYEligibilityCriteria(journeyMap,
                                      creditCardVO.getCustomerId(), tableName)).thenReturn(
                        ccEligibilityCriteriaDto);
           ccFeeWaiverUtility.getEligibilityMY(journeyMap, creditCardVO, props);
    }

	
	}
