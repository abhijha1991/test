package com.sc.csl.retail.creditcard.gateway;

import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CardCustDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.IncludeRelationSpec;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.repository.ResourceRepositoryV2;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
public class CreditCardRestGatewayTest {

    @Mock
    ResourceRepositoryV2 creditCardlist;

    @Mock
    CSLKatharsisClient cslKatharsisClient;

    @Mock
    private CSLRequestContext cslRequestContext;
    @Mock
    CSLAsyncRequestContext cslAsyncRequestContext;
    @InjectMocks
    CreditCardRestGateway creditCardRestGateway;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void shouldReturn_CreditCardDto_ListObject_When_getOfflineCreditCardSummary_Method_Called() {
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;
        creditDtoList.add(manualBuildDtoObject(creditCardDto));
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("HK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setRelId("01C303360");
        cslAsyncRequestContext.setCountry("HK");
        cslAsyncRequestContext.setRelId("01C303360");
        cslAsyncRequestContext.setLanguage("en");
        Mockito.when(cslRequestContext.getCountry()).thenReturn("HK");
        Mockito.when(cslRequestContext.getRelId()).thenReturn("01C303360");
        Mockito.when(cslRequestContext.getLanguage()).thenReturn("en");
        Mockito.when(cslRequestContext.getUaas2id()).thenReturn("DB2INST5");
        Mockito.when(cslRequestContext.getRequestId()).thenReturn("csl-ce877743-dc0a-4d1c-99fa-c1e99e6f8fdd");
        List<IncludeRelationSpec> includes = new ArrayList<>();
        IncludeRelationSpec includeRelationSpec = new IncludeRelationSpec(Arrays.asList("credit-cards"));
        includes.add(includeRelationSpec);
        QuerySpec querySpec = new QuerySpec(CreditCardDto.class);
        querySpec.setIncludedRelations(includes);
        when(cslKatharsisClient.getRepositoryForType(eq(CreditCardDto.class))).thenReturn(creditCardlist);
        when((creditCardRestGateway.getOfflineCreditCardSummary())).thenReturn(creditDtoList);
        List<CreditCardDto> cardDtoList = creditCardRestGateway.getOfflineCreditCardSummary();
        assertNotNull(cardDtoList.get(0));
        assertEquals("1118",cardDtoList.get(0).getExpDt());
        log.info("Values are Comming for List === " + cardDtoList.get(0).getExpDt());
    }
    @Test(expected = Exception.class)
    public void shouldReturn_BusinessException_When_getOfflineCreditCardSummary_Method_Called(){
        CreditCardVO creditCardVO = new CreditCardVO();
        List<CreditCardDto> cardDtoList = creditCardRestGateway.getOfflineCreditCardSummary();
    }

    @Test
    public void shouldReturn_CreditCardDto_Object_When_getOfflineCreditCardDetails_Method_Called() {
        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto = manualBuildDtoObject(creditCardDto);
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("HK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setRelId("01C303360");
        Mockito.when(cslRequestContext.getCountry()).thenReturn("HK");
        Mockito.when(cslRequestContext.getRelId()).thenReturn("01C303360");
        Mockito.when(cslRequestContext.getLanguage()).thenReturn("en");
        Mockito.when(cslRequestContext.getUaas2id()).thenReturn("DB2INST5");
        Mockito.when(cslRequestContext.getRequestId()).thenReturn("csl-ce877743-dc0a-4d1c-99fa-c1e99e6f8fdd");

        List<IncludeRelationSpec> includes = new ArrayList<>();
        IncludeRelationSpec includeRelationSpec = new IncludeRelationSpec(Arrays.asList("credit-cards"));
        includes.add(includeRelationSpec);
        QuerySpec querySpec = new QuerySpec(CreditCardDto.class);
        querySpec.setIncludedRelations(includes);
        when(cslKatharsisClient.getRepositoryForType(eq(CreditCardDto.class))).thenReturn(creditCardlist);
        when(creditCardRestGateway.getOfflineCreditCardDetails(creditCardVO)).thenReturn(creditCardDto);
        CreditCardDto cardDto = creditCardRestGateway.getOfflineCreditCardDetails(creditCardVO);
        assertNotNull(cardDto);
        assertEquals("1118",cardDto.getExpDt());
        log.info("Values are Comming for Details === " + cardDto.getExpDt());
    }

    @Test(expected = Exception.class)
    public void shouldReturn_Exception_Object_When_getOfflineCreditCardDetails_Method_Called() {
        CreditCardVO creditCardVO = new CreditCardVO();
        CreditCardDto cardDto = creditCardRestGateway.getOfflineCreditCardDetails(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardDto_ListObject_When_getCardNumber_Method_Called() {
        ResourceList<CardCustDto> cardCustDtoList = new DefaultResourceList<>();
        CardCustDto cardCustDto = new CardCustDto();
        cardCustDto.setCreditCardNo("4129057530874005");
        cardCustDto.setCustomerId("01C303360");
        cardCustDto.setCustomerIdType("01");
        cardCustDtoList.add(cardCustDto);
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("HK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setRelId("01C303360");
        cslAsyncRequestContext.setCountry("HK");
        cslAsyncRequestContext.setRelId("01C303360");
        cslAsyncRequestContext.setLanguage("en");
        Mockito.when(cslRequestContext.getCountry()).thenReturn("HK");
        Mockito.when(cslRequestContext.getRelId()).thenReturn("01C303360");
        Mockito.when(cslRequestContext.getLanguage()).thenReturn("en");
        Mockito.when(cslRequestContext.getUaas2id()).thenReturn("DB2INST5");
        Mockito.when(cslRequestContext.getRequestId()).thenReturn("csl-ce877743-dc0a-4d1c-99fa-c1e99e6f8fdd");
        List<IncludeRelationSpec> includes = new ArrayList<>();
        IncludeRelationSpec includeRelationSpec = new IncludeRelationSpec(Arrays.asList("card-customer"));
        includes.add(includeRelationSpec);
        QuerySpec querySpec = new QuerySpec(CardCustDto.class);
        querySpec.setIncludedRelations(includes);
        when(cslKatharsisClient.getRepositoryForType(eq(CardCustDto.class))).thenReturn(creditCardlist);
        when((creditCardRestGateway.getCardNumber())).thenReturn(cardCustDtoList);
        List<CardCustDto> cardCustDtos = creditCardRestGateway.getCardNumber();
        assertNotNull(cardCustDtos.get(0));
        assertEquals("4129057530874005",cardCustDtos.get(0).getCreditCardNo());
        log.info("Values are Comming for provide RelId === " + cardCustDtos.get(0).getCustomerId());
    }
    @Test(expected = Exception.class)
    public void shouldReturn_BusinessException_When_getCardNumber_Method_Called(){
        List<CardCustDto> cardCustDtoList = creditCardRestGateway.getCardNumber();
    }

    private CreditCardDto manualBuildDtoObject(CreditCardDto creditCardDto){
        creditCardDto=new CreditCardDto();
        creditCardDto.setBlkInd("02");
        creditCardDto.setFranchise("Visa");
        creditCardDto.setProd("53");
        creditCardDto.setCardType("Visa");
        creditCardDto.setExpDt("1118");
        creditCardDto.setCardNum("4129057530874005");
        creditCardDto.setCardImgName("in-manhattan-platinum");
        creditCardDto.setIsPrimary("Y");
        creditCardDto.setCustomerId("01C303360");
        creditCardDto.setVariant("200");
        creditCardDto.setCustShortName("INORR57");
        creditCardDto.setCurrencyCode("HKD");
        creditCardDto.setDesc("Credit Card");
        creditCardDto.setCountry("HK");
        creditCardDto.setStatus("2");
        return creditCardDto;
    }
}