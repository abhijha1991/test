package com.sc.csl.retail.creditcard.service;

import com.sc.corebanking.creditcard.v1.creditcardlimit.*;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardlimit.ValidateLimitIncreaseRes;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.core.web.header.CSLClient;
import com.sc.csl.retail.core.web.header.CSLHeader;
import com.sc.csl.retail.core.web.header.CSLUser;
import com.sc.csl.retail.creditcard.dto.CardBalanceLimitDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.DebitCardDto;
import com.sc.csl.retail.creditcard.dto.post.CCFeeWaiverPostDto;
import com.sc.csl.retail.creditcard.gateway.CreditCardRestGateway;
import com.sc.csl.retail.creditcard.gateway.csl.DebitCardsV3CSLGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardCustomerEnquiryV5SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardLimitV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardProfileV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.QuerySpec;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;
import ma.glasnost.orika.MapperFacade;
import org.apache.commons.collections.CollectionUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.doReturn;

public class CreditCardServiceTest {

    @InjectMocks
    private CreditCardService creditCardService;

    @Mock
    private CreditCardValidator creditCardValidator;

    @Mock
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;

    @Mock
    private CreditCardProfileV1SoapGateway creditCardProfileV1SoapGateway;

    @Mock
    private CreditCardCustomerEnquiryV5SoapGateway creditCardCustomerEnquiryV5SoapGateway;

    @Mock
    QuerySpec querySpec;

    @Mock
    private DebitCardsV3CSLGateway debitCardsV3CSLGateway;

    @Mock
    private CSLRequestContext mockCSLRequestContext;

    @Mock
    private ExecutorService executor;

    @Mock
    CollectionUtils collectionUtils;

    @Mock
    CompletableFuture<DebitCardDto>  debitCardDtoFuture;

    @Mock
    CreditCardLimitV1SoapGateway creditCardLimitV1SoapGateway;

    @Mock
    MapperFacade orikaMapper;

    @Mock
    CreditCardRestGateway creditCardRestGateway;

    @Before
    public void setUp() {

        creditCardProfileV1SoapGateway = PowerMockito.mock(CreditCardProfileV1SoapGateway.class, Mockito.CALLS_REAL_METHODS);

        creditCardValidator = PowerMockito.mock(CreditCardValidator.class, Mockito.CALLS_REAL_METHODS);
        creditCardService = PowerMockito.mock(CreditCardService.class, Mockito.CALLS_REAL_METHODS);

        MockitoAnnotations.initMocks(this);

    }

    @Test(expected = Exception.class)
    public void shouldThrow_BusinessException_when_findAllCreditCard_method_called_With_CC_FUNCTION_CODE_CCPROFILE_USING_CC() {
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));

        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
        // arrange
      /*  when(executor.submit(any(ComboCardDetailsCallable.class))).thenAnswer(new Answer<Future<CreditCardDto>>() {
            @Override
            public Future<CreditCardDto> answer(InvocationOnMock invocationOnMock) throws Throwable {
                Future<CreditCardDto> future = mock(FutureTask.class);
                when(future.isDone()).thenReturn(false, false, true);
                when(future.get()).thenReturn(manualBuildDtoObject(creditCardDto));
                return future;
            }
        });*/


        List<CreditCardDto> creditDtoList1 =creditCardService.findAllCreditCard(creditCardVO);

    }
    @Test
    public void shouldThrow_BusinessException_when_findAllCreditCard_method2() {
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);
        creditCardVO.setInclude(CardConstant.OFFLINE);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));

        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);

        List<CreditCardDto> creditCardDtoLst=new ArrayList<>();

        creditCardDtoLst.add(manualBuildDtoObject(creditCardDto));

        when(creditCardRestGateway.getOfflineCreditCardSummary()).thenReturn(creditCardDtoLst);

        List<CreditCardDto> creditDtoList1 =creditCardService.findAllCreditCard(creditCardVO);

    }
    @Test(expected = Exception.class)
    public void shouldThrow_BusinessException_when_findAllCreditCard_method_called_With_RelId() {

        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");

        //to cover else change relId
        creditCardVO.setRelId("1234");
        creditCardVO.setFunctionCd("");


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));

        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
        // arrange
     /*   when(executor.submit(any(ComboCardDetailsCallable.class))).thenAnswer(new Answer<Future<CreditCardDto>>() {
            @Override
            public Future<CreditCardDto> answer(InvocationOnMock invocationOnMock) throws Throwable {
                Future<CreditCardDto> future = mock(FutureTask.class);
                when(future.isDone()).thenReturn(false, false, true);
                when(future.get()).thenReturn(manualBuildDtoObject(creditCardDto));
                return future;
            }
        });*/

        //to cover else change relId
        creditCardVO.setRelId("1234");
        creditCardVO.setFunctionCd("");
        List<CreditCardDto> creditDtoList2 =creditCardService.findAllCreditCard(creditCardVO);

    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_Exception_when_findAllCreditCard_method_called_With_RelId2() throws Exception{

        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");

        //to cover else change relId
        creditCardVO.setRelId("1234");
        creditCardVO.setFunctionCd("");


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));

        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenThrow(new NullPointerException());

       // doReturn(null).when(creditCardService,"populateReplacementFileds",creditDtoList,creditCardVO);

        //to cover else change relId
        creditCardVO.setRelId("1234");
        creditCardVO.setFunctionCd("");
        List<CreditCardDto> creditDtoList2 =creditCardService.findAllCreditCard(creditCardVO);

    }

    @Test(expected = Exception.class)
    public void shouldThrow_BusinessException_when_findAllCreditCard_method_called() {
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));

        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
        // arrange
      /*  when(executor.submit(any(ComboCardDetailsCallable.class))).thenAnswer(new Answer<Future<CreditCardDto>>() {
            @Override
            public Future<CreditCardDto> answer(InvocationOnMock invocationOnMock) throws Throwable {
                Future<CreditCardDto> future = mock(FutureTask.class);
                when(future.isDone()).thenReturn(false, false, true);
                when(future.get()).thenReturn(manualBuildDtoObject(creditCardDto));
                return future;
            }
        });*/

        List<CreditCardDto> creditDtoList1 =creditCardService.findAllCreditCard(creditCardVO);
    }

    @Test(expected = Exception.class)
    public void shouldThrow_BusinessException_When_findAllCreditCard_Method_Called_WithEmptyObject() throws Exception{
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("SG");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));
        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
   /*     CardDetailsCallable cardDetailsCallable = mock(CardDetailsCallable.class);
        CardDetailsCallable cardDetailsCallable1 = new CardDetailsCallable();
        ReflectionTestUtils.setField(new CardDetailsCallable(), "creditCardEnquiryV1SoapGateway", creditCardEnquiryV1SoapGateway);
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(manualBuildDtoObject(creditCardDto));
        when(cardDetailsCallable.onCall()).thenReturn(manualBuildDtoObject(creditCardDto));
        when(cardDetailsCallable.init(creditCardVO, creditCardEnquiryV1SoapGateway)).thenReturn(cardDetailsCallable1);*/
        Future<CreditCardDto> mockFuture = mock(Future.class);
        ExecutorService executor = mock(ExecutorService.class);
        when(executor.submit(any(Callable.class))).thenReturn(mockFuture);

        when(mockFuture.get()).thenReturn(manualBuildDtoObject(creditCardDto));
        List<CreditCardDto> creditDtoList1 =creditCardService.findAllCreditCard(creditCardVO);
    }

    @Test(expected = Exception.class)
    public void shouldThrow_BusinessException_When_getAsyncCreditCardFinanceDetails_Method() throws Exception{
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("SG");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));
        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
   /*     CardDetailsCallable cardDetailsCallable = mock(CardDetailsCallable.class);
        CardDetailsCallable cardDetailsCallable1 = new CardDetailsCallable();
        ReflectionTestUtils.setField(new CardDetailsCallable(), "creditCardEnquiryV1SoapGateway", creditCardEnquiryV1SoapGateway);
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(manualBuildDtoObject(creditCardDto));
        when(cardDetailsCallable.onCall()).thenReturn(manualBuildDtoObject(creditCardDto));
        when(cardDetailsCallable.init(creditCardVO, creditCardEnquiryV1SoapGateway)).thenReturn(cardDetailsCallable1);*/
        Future<CreditCardDto> mockFuture = mock(Future.class);
        ExecutorService executor = mock(ExecutorService.class);
        when(executor.submit(any(Callable.class))).thenReturn(mockFuture);

        when(mockFuture.get()).thenReturn(manualBuildDtoObject(creditCardDto));
        List<CreditCardDto> creditDtoList1 =creditCardService.getAsyncCreditCardFinanceDetails(creditDtoList,creditCardVO);
    }

    @Test
    public void shouldReturn_EmptyList_When_findAllCreditCard_Method_Called_WithEmptyObject_For_ComboCards() throws Exception{
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;
        DebitCardDto debitCardDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("SG");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));
        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
      /*  CardDetailsCallable cardDetailsCallable = mock(CardDetailsCallable.class);
        CardDetailsCallable cardDetailsCallable1 = new CardDetailsCallable();
        ReflectionTestUtils.setField(new CardDetailsCallable(), "creditCardEnquiryV1SoapGateway", creditCardEnquiryV1SoapGateway);*/
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(manualBuildDtoObject(creditCardDto));
      /*  when(cardDetailsCallable.init(creditCardVO, creditCardEnquiryV1SoapGateway)).thenReturn(cardDetailsCallable1);
        when(cardDetailsCallable.onCall()).thenReturn(manualBuildDtoObject(creditCardDto));
        Future<CreditCardDto> mockFuture = mock(Future.class);
        ExecutorService executor = mock(ExecutorService.class);
        when(executor.submit(any(Callable.class))).thenReturn(mockFuture);
        ComboCardDetailsCallable comboCardDetailsCallable = mock(ComboCardDetailsCallable.class);
        ComboCardDetailsCallable comboCardDetailsCallable1 = new ComboCardDetailsCallable();
        ReflectionTestUtils.setField(new ComboCardDetailsCallable(), "debitCardsV3CSLGateway", debitCardsV3CSLGateway);*/
        when(debitCardsV3CSLGateway.getCardDetails(creditCardVO)).thenReturn(manualBuildDtoObject(debitCardDto));
       /* when(comboCardDetailsCallable.onCall()).thenReturn(manualBuildDtoObject(debitCardDto));
        when(comboCardDetailsCallable.init(creditCardVO, creditCardEnquiryV1SoapGateway)).thenReturn(comboCardDetailsCallable1);
        Future<DebitCardDto> mockFutureForCombo = mock(Future.class);
        ExecutorService executorCombo = mock(ExecutorService.class);
        when(executorCombo.submit(any(Callable.class))).thenReturn(mockFutureForCombo);
        CardUtil util=mock(CardUtil.class);
        when(!util.isEmptyOrNull(mockFuture.get())).thenReturn(true);
        when(mockFuture.get()).thenReturn(manualBuildDtoObject(creditCardDto));*/
        List<CreditCardDto> creditDtoList1 =creditCardService.findAllCreditCard(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardDto_Object_When_findOneCreditCard_Method_Called() throws Exception {


        CreditCardDto creditCardDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditCardDto=manualBuildDtoObject(creditCardDto);
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(creditCardDto);
        when(creditCardEnquiryV1SoapGateway.findOneCreditCardInfoFromDB(creditCardVO,new Throwable("Prod Desc Not Available"),"")).thenReturn(creditCardDto);
        creditCardService.setCslRequestContext(cSLRequestContext);
        doReturn("12345").when(creditCardService).getCreditCardFromCardId(Mockito.anyString(),Mockito.any());
        //    doNothing().when(creditCardService,"validateCreditCardNo",creditCardVO);
        // when(creditCardService.getCreditCardFromCardId("12344555565555555",creditCardVO)).thenReturn("12345");
        doNothing().when(creditCardValidator).validateRequest(creditCardVO);
        CreditCardDto creditDtoList1 =creditCardService.findOneCreditCard(creditCardVO);
        assertNotNull(creditDtoList1);
       /* assertEquals("4129057530874005",creditDtoList1.getCardNum());
        assertEquals("Visa",creditDtoList1.getFranchise());
        assertEquals("356",creditDtoList1.getCurrencyCode());
        assertEquals("1114",creditDtoList1.getExpDt());*/
    }

    @Test
    public void shouldReturn_CreditCardTransactionDto_ListObject_When_findAllCreditCardTransaction_Method_Called() throws Exception {
        ResourceList<CreditCardTransactionDto> creditCardTransactionDtoList = new DefaultResourceList<>();
        CreditCardTransactionDto creditCardTransactionDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setNoOfDaysToFetchTransactions("10");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditCardTransactionDtoList.add(new CreditCardTransactionDto());

        List<CreditCardTransactionDto> creditCardTransactions = new ArrayList<>();
        creditCardTransactions.add(creditCardTransactionDto);


        when(creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO)).thenReturn(creditCardTransactionDtoList);

        List<CreditCardTransactionDto> creditCardTransactionDtoList1=creditCardService.findAllCreditCardTransaction(creditCardVO);
    }

    @Test
    public void shouldThrow_BusinessException_When_findAllCreditCard_Method_Called_WithEmptyObject_For_FinanceCall() throws Exception{
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;
        DebitCardDto debitCardDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("AE");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setOperationName("Replacement");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditDtoList.add(manualBuildDtoObject(creditCardDto));
        when(creditCardProfileV1SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
    /*    CardDetailsCallable cardDetailsCallable = mock(CardDetailsCallable.class);
        CardDetailsCallable cardDetailsCallable1 = new CardDetailsCallable();
        ReflectionTestUtils.setField(new CardDetailsCallable(), "creditCardEnquiryV1SoapGateway", creditCardEnquiryV1SoapGateway);*/
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(manualBuildDtoObject(creditCardDto));
       /* when(cardDetailsCallable.init(creditCardVO, creditCardEnquiryV1SoapGateway)).thenReturn(cardDetailsCallable1);
        when(cardDetailsCallable.onCall()).thenReturn(manualBuildDtoObject(creditCardDto));
        Future<CreditCardDto> mockFuture = mock(Future.class);
        ExecutorService executor = mock(ExecutorService.class);
        when(executor.submit(any(Callable.class))).thenReturn(mockFuture);
        CreditCardFinanceCallable creditCardFinanceCallable = mock(CreditCardFinanceCallable.class);
        CreditCardFinanceCallable creditCardFinanceCallable1 = new CreditCardFinanceCallable();
        ReflectionTestUtils.setField(new CreditCardFinanceCallable(), "creditCardEnquiryV1SoapGateway", creditCardEnquiryV1SoapGateway);
        when(creditCardFinanceCallable.onCall()).thenReturn(manualBuildCreditFinanceDtoObject());
        when(creditCardFinanceCallable.init(creditCardVO, creditCardEnquiryV1SoapGateway)).thenReturn(creditCardFinanceCallable1);
        Future<DebitCardDto> mockFutureForComboFinance = mock(Future.class);
        ExecutorService executorCombo = mock(ExecutorService.class);
        when(executorCombo.submit(any(Callable.class))).thenReturn(mockFutureForComboFinance);
        CardUtil util=mock(CardUtil.class);
        when(!util.isEmptyOrNull(mockFuture.get())).thenReturn(true);
        when(mockFuture.get()).thenReturn(manualBuildDtoObject(creditCardDto));*/
        List<CreditCardDto> creditDtoList1 =creditCardService.findAllCreditCard(creditCardVO);
    }

    public static Future<CreditCardDto> createFuture(Callable<CreditCardDto> callable)
    {
        ExecutorService service = Executors.newSingleThreadExecutor();
        Future<CreditCardDto> ret = service.submit(callable);
        service.shutdown();
        return ret;
    }

    private CreditCardDto manualBuildDtoObject(CreditCardDto creditCardDto){
        creditCardDto=new CreditCardDto();
        creditCardDto.setBlkInd("02");
        creditCardDto.setFranchise("Visa");
        creditCardDto.setProd("53");
        creditCardDto.setCardType("Visa");
        creditCardDto.setExpDt("1114");
        creditCardDto.setCardNum("4129057530874005");
        creditCardDto.setCardImgName("in-manhattan-platinum");
        creditCardDto.setIsPrimary("Y");
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setVariant("200");
        creditCardDto.setCustShortName("INORR57");
        creditCardDto.setCurrencyCode("356");
        creditCardDto.setDesc("Credit Card");
        creditCardDto.setStatus("2");
        creditCardDto.setOrgNum("123");
        creditCardDto.setCardNum("4321");
        return creditCardDto;
    }

    private DebitCardDto manualBuildDtoObject(DebitCardDto debitCardDto){
        debitCardDto=new DebitCardDto();
        debitCardDto.setCardNum("03");
        debitCardDto.setCardSubType("");
        debitCardDto.setCountry("SG");
        debitCardDto.setCardType("Visa");
        debitCardDto.setCustomerId("01070565A0SH04005");
        debitCardDto.setStatus("2");
        debitCardDto.setStatusCode("");
        debitCardDto.setId("03");
        debitCardDto.setChannel("WEB");
        return debitCardDto;
    }

    private CreditCardDto manualBuildCreditFinanceDtoObject(){

        CreditCardDto cardFinanceDetailsVO = new CreditCardDto();
        cardFinanceDetailsVO.setAgreementStatus(new BigInteger("010705"));
        cardFinanceDetailsVO.setCardNum("01070565A0SH04005");
        return cardFinanceDetailsVO;
    }

    private CreditCardTransactionDto manualBuildTransactionDtoObject(CreditCardTransactionDto creditCardTransactionDto){
        return creditCardTransactionDto;
    }

    private CreditCardTransactionDto manualBuildTransactionDtoObject(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        CreditCardTransactionDto creditCardTransactionDto=new CreditCardTransactionDto();
        creditCardTransactionDto.setCardNum("4129057530874005");
        creditCardTransactionDto.setDesc("Credit Card");
        creditCardTransactionDto.setOriginTxnAmt(new BigDecimal(200));
        creditCardTransactionDto.setTxnCurr("356");
        creditCardTransactionDto.setTxnRefNo("11290575308711111");
        creditCardTransactionDto.setSendPageCount("01N02");
        creditCardTransactionDto.setEffDt(LocalDate.now().minusDays(1).format(formatter));
        return creditCardTransactionDto;
    }

    @Test
    public void shouldReturn_CreditCardDto_Object_When_findOneCreditCardDelinquencyHistory_Method_Called() {
        CreditCardDto creditCardDto = null;
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CSLHeader header=new CSLHeader();
        CSLClient client=new CSLClient();
        client.setChannel("WEB");
        CSLUser user=new CSLUser();
        user.setCountry("IN");
        user.setRelId("01070565A0SH04005");
        header.setClient(client);
        header.setUser(user);
        CSLAsyncRequestContext cSLRequestContext=new CSLAsyncRequestContext();
        cSLRequestContext.setChannel("WEB");
        cSLRequestContext.setCountry("IN");
        cSLRequestContext.setRelId("01070565A0SH04005");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditCardDto=manualBuildDtoObject(creditCardDto);
        when(creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO)).thenReturn(creditCardDto);
        CreditCardDto creditDtoList1 =creditCardService.findOneCreditCardDelinquencyHistory(creditCardVO);
        assertNotNull(creditDtoList1);
/*     assertEquals("4129057530874005",creditDtoList1.getCardNum());
       assertEquals("Visa",creditDtoList1.getFranchise());
       assertEquals("356",creditDtoList1.getCurrencyCode());
       assertEquals("1114",creditDtoList1.getExpDt());
       assertEquals(null,creditDtoList1.getDelinquencyCycle1Amt());
       assertEquals(null,creditDtoList1.getDelinquencyCycle2Amt());*/
    }

    @Test
    public void shouldReturn_List_CreditCardDto_Object_When_getAllCreditCards_Method_Called() {
        List<CreditCardDto> creditCardDtoLst=creditCardService.getAllCreditCards(new CreditCardVO());

    }

    @Test(expected = Exception.class)
    public void shouldReturn_Exception_findOneCreditCard_When_Called(){

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setOperationName("CARDRPL");
        creditCardDto.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        //when(creditCardService.getCreditCardFromCardId(creditCardVO.getCardNo(),creditCardVO)).thenReturn("12345");
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(creditCardDto);

        creditCardService.findOneCreditCard(creditCardVO);
    }

    @Test
    public void shouldReturn_Exception_getCreditCardTransaction_When_Called(){

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setOperationName("CARDRPL");
        creditCardDto.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        List<CreditCardDto> creditCardDtos=new ArrayList<CreditCardDto>();
        creditCardDtos.add(manualBuildDtoObject(creditCardDto));


        List<CreditCardTransactionDto> tmpCreditCardTransactions=new ArrayList<CreditCardTransactionDto>();

        CreditCardTransactionDto creditCardTransactionDto=new CreditCardTransactionDto();
        creditCardTransactionDto.setSendPageCount("1023232");

        tmpCreditCardTransactions.add(creditCardTransactionDto);

        //when(creditCardService.getCreditCardFromCardId(creditCardVO.getCardNo(),creditCardVO)).thenReturn("12345");
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(creditCardDto);
        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditCardDtos);
        when(creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO)).thenReturn(tmpCreditCardTransactions);
        creditCardService.getCreditCardTransaction(creditCardVO);

        //covering if statement
        creditCardVO.setFunctionCd("S");
        creditCardService.getCreditCardTransaction(creditCardVO);

    }

    @Test
    public void shouldReturn_CreditCardTransactions_findCreditCardTransactions_When_Called(){

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setOperationName("CARDRPL");
        creditCardDto.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        List<CreditCardDto> creditCardDtos=new ArrayList<CreditCardDto>();
        creditCardDtos.add(manualBuildDtoObject(creditCardDto));


        List<CreditCardTransactionDto> tmpCreditCardTransactions=new ArrayList<CreditCardTransactionDto>();

        CreditCardTransactionDto creditCardTransactionDto=new CreditCardTransactionDto();
        creditCardTransactionDto.setSendPageCount("1023232");

        tmpCreditCardTransactions.add(creditCardTransactionDto);

        //when(creditCardService.getCreditCardFromCardId(creditCardVO.getCardNo(),creditCardVO)).thenReturn("12345");
        when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(creditCardDto);
        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditCardDtos);
        when(creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO)).thenReturn(tmpCreditCardTransactions);

        creditCardService.findCreditCardTransactions(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardTransactions_generatePayLoad_When_Called(){

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setOperationName("CARDRPL");
        creditCardDto.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        //when(creditCardService.getCreditCardFromCardId(creditCardVO.getCardNo(),creditCardVO)).thenReturn("12345");
        when(mockCSLRequestContext.getRelId()).thenReturn("1234");

        creditCardService.generatePayLoad(creditCardDto,new CCFeeWaiverPostDto());
    }

    @Test
    public void shouldReturn_CreditCardDto_getCardDetail_When_Called(){
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);


        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        when(creditCardProfileV1SoapGateway.getCardDetails(creditCardVO)).thenReturn(new CreditCardDto());

        creditCardService.getCardDetail(creditCardVO);

    }

    @Test(expected=Exception.class)
    public void shouldReturn_getAsyncCreditCardList_When_Called()throws Exception{

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        Map<String, String> cardNumMap=new HashMap<String, String>();
        cardNumMap.put("4129057530874005","4129057530874005");

        List<CreditCardDto> creditCardDtos=new ArrayList<CreditCardDto>();
        creditCardDtos.add(manualBuildDtoObject(new CreditCardDto()));

        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setOperationName("CARDRPL");
        creditCardDto.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);
        creditCardDtos.add(creditCardDto);

        when(creditCardProfileV1SoapGateway.getAsyncCreditCardsList(creditCardVO)).thenReturn(CompletableFuture.completedFuture(new CreditCardVO()));
        List<CompletableFuture<CreditCardVO>> futuresList=new ArrayList<CompletableFuture<CreditCardVO>>();


        List<CreditCardVO> CreditCardVOLst=new ArrayList<CreditCardVO>();
        CreditCardVOLst.add(creditCardVO);


       /* when(creditCardService.allOf(futuresList)).
                thenReturn(CompletableFuture.completedFuture(CreditCardVOLst));*/

        creditCardService.getAsyncCreditCardList(cardNumMap,creditCardVO);

    }


    @Test(expected = Exception.class)
    public void shouldReturn_getAsyncComboCardDetails_When_Called()throws Exception{
        //   creditCardService=spy(new CreditCardService());
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        Map<String, String> cardNumMap=new HashMap<String, String>();
        cardNumMap.put("4129057530874005","4129057530874005");

        List<CreditCardDto> creditCardDtos=new ArrayList<CreditCardDto>();
        creditCardDtos.add(manualBuildDtoObject(new CreditCardDto()));

        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setOperationName("CARDRPL");
        creditCardDto.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);
        creditCardDtos.add(creditCardDto);

  /*      when(creditCardProfileV1SoapGateway.getAsyncCreditCardsList(creditCardVO)).thenReturn(CompletableFuture.completedFuture(new CreditCardVO()));
        List<CompletableFuture<CreditCardVO>> futuresList=new ArrayList<CompletableFuture<CreditCardVO>>();*/


        List<CreditCardVO> CreditCardVOLst=new ArrayList<CreditCardVO>();
        CreditCardVOLst.add(creditCardVO);

/*        when(debitCardsV3CSLGateway.getAsyncComboCardDetails(any())).thenReturn(debitCardDtoFuture);
        when(debitCardDtoFuture.get()).thenReturn(new DebitCardDto());*/

        creditCardService.getAsyncComboCardDetails(creditCardDtos,creditCardVO);

    }

    @Test
    public void shouldReturn_distinctByKey_When_Called()throws Exception{

        creditCardService.distinctByKey(null);
    }
    @Test
    public void shouldReturn_Exception_findCCMSUnprocessedCCTransactions_When_Called()throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        creditCardService.findCCMSUnprocessedCCTransactions(creditCardVO);
    }
    @Test
    public void shouldReturn_findOneCreditCardDelinquencyHistory_When_Called()throws Exception{

        List<CreditCardDto> creditDtoList=new ArrayList<CreditCardDto>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        creditDtoList.add(manualBuildDtoObject(new CreditCardDto()));

        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);

        creditCardService.findOneCreditCardDelinquencyHistory(creditCardVO);
    }

    @Test
    public void shouldReturn__combineNextCreditCardsListByPageIndicator_When_Called()throws Exception{
        List<CreditCardDto> creditDtoList=new ArrayList<CreditCardDto>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        CreditCardDto creditCardDto=manualBuildDtoObject(new CreditCardDto());
        creditCardDto.setStartPageRefNum(CardConstant.CONS_Y+CardConstant.CONS_Y+CardConstant.CONS_Y+CardConstant.CONS_Y);
        creditDtoList.add(creditCardDto);

        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);

        creditCardService.combineNextCreditCardsListByPageIndicator(creditDtoList,creditCardVO);

    }

    @Test
    public void shouldReturn__getCreditCardLimitBalance_When_Called()throws Exception{
        List<CreditCardDto> creditDtoList=new ArrayList<CreditCardDto>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);

        CreditCardDto creditCardDto=manualBuildDtoObject(new CreditCardDto());
        creditCardDto.setStartPageRefNum(CardConstant.CONS_Y+CardConstant.CONS_Y+CardConstant.CONS_Y+CardConstant.CONS_Y);
        creditDtoList.add(creditCardDto);
        ValidateLimitIncreaseRes response=new ValidateLimitIncreaseRes();

        ValidateLimitIncreaseResPayload validateLimitIncreaseResPayload=new ValidateLimitIncreaseResPayload();

        ValidateLimitIncreaseResData validateLimitIncreaseResData=new ValidateLimitIncreaseResData();
        SCBValidateLimitIncreaseRsType sCBValidateLimitIncreaseRsType=new SCBValidateLimitIncreaseRsType();

        SCBCLIResultDetailsType sCBCLIResultDetailsType=new SCBCLIResultDetailsType();
        AcctBalType acctBalType=new AcctBalType();

        sCBCLIResultDetailsType.getCardBal().add(acctBalType);

        sCBValidateLimitIncreaseRsType.setSCBCLIResultDetails(sCBCLIResultDetailsType);

        validateLimitIncreaseResData.setValidateLimitIncreaseRs(sCBValidateLimitIncreaseRsType);
        validateLimitIncreaseResPayload.setValidateLimitIncreaseRes(validateLimitIncreaseResData);

        response.setValidateLimitIncreaseResPayload(validateLimitIncreaseResPayload);


        when(creditCardCustomerEnquiryV5SoapGateway.getCreditCards(creditCardVO)).thenReturn(creditDtoList);
        when(creditCardLimitV1SoapGateway.getCreditCardBalanceLimit(creditCardVO)).thenReturn(response);

        List<CardBalanceLimitDto> cardBalanceList=new ArrayList<CardBalanceLimitDto>();
        CardBalanceLimitDto cardBalanceLimitDto=new CardBalanceLimitDto();
        cardBalanceLimitDto.setBalTypeValue(CardConstant.EXISITING_CARD_LIMIT);

        cardBalanceList.add(cardBalanceLimitDto);

        when(orikaMapper.mapAsList(sCBCLIResultDetailsType.getCardBal(), CardBalanceLimitDto.class)).thenReturn(cardBalanceList);

        creditCardService.getCreditCardLimitBalance(creditCardVO);

    }

    @Test
    public void shouldReturn__findCreditCardTransactionsFromDB_When_Called()throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode(CardConstant.CARD_LIST_FROM_HOGAN_CTRD_CDS[0]);
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setOperationName("CARDRPL");
        creditCardVO.setFunctionCd(CardConstant.FUNCTION_CODE_CCPROFILE_USING_CC);

        creditCardService.findCreditCardTransactionsFromDB(creditCardVO,new NullPointerException());
    }

}