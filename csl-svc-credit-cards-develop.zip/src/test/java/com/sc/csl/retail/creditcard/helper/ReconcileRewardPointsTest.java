package com.sc.csl.retail.creditcard.helper;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.RewardPointDto;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;


public class ReconcileRewardPointsTest {
	
	@InjectMocks
	ReconcileRewardPoint reconcileRewardPoints;
	
	@Mock
	CreditCardService cardService;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}
	

@Test
public void reconcileRewardpoints(){
	
	CreditCardDto creditcardDto= new CreditCardDto();
	CreditCardVO creditcardvo= new CreditCardVO();
	
	List<CreditCardTransactionDto> reconciledTransactionList= new ArrayList<CreditCardTransactionDto>();
	List<CreditCardDto> creditcardlist= new ArrayList<CreditCardDto>();
	Map<String, Object> journeyMap= new HashMap<String, Object>();
	
	CreditCardDto obj1= new CreditCardDto();
	obj1.setCardNum("126532653434");
	obj1.setCardType("Emirates");
	obj1.setBlockCode("D");
	RewardPointDto rewardpoint=new RewardPointDto();
	rewardpoint.setRewardsPoints("100");
	obj1.setCardAvailableRewardpoint(rewardpoint);
	creditcardlist.add(obj1);
	
	journeyMap.put("Credit_Reward_List", creditcardlist);
	journeyMap.put("overAllrewardpoints", Integer.valueOf(0));
	
	creditcardDto.setCardType("Emirates");
	creditcardDto.setBlockCode("D");
	creditcardDto.setCardNum("12345");
	CreditCardTransactionDto transactionDto= new CreditCardTransactionDto();
	RewardPointDto rewardpoint2=new RewardPointDto();
	rewardpoint2.setRewardsPoints("60");
	creditcardDto.setFeeType("Annual_Fee");
	transactionDto.setEquivalentRewardPoints(rewardpoint2);
	reconciledTransactionList.add(transactionDto);
	
	Map<String, Object> rewardpropmap= new HashMap<String, Object>();
	Map<String, String> exclutionmap= new HashMap<String, String>();
	exclutionmap.put("Annual_Fee", "Infinite");
	rewardpropmap.put("execusionCardTypes", exclutionmap);
	rewardpropmap.put("exclusionBlockCodes", "A,B,C");
	
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setRewardPoint(rewardpropmap);
	reconcileRewardPoints.reconcileRewardPoint(creditcardDto, creditcardvo, reconciledTransactionList, journeyMap, props);
	
	
	assertEquals(0,journeyMap.get("overAllrewardpoints"));
}
@Test
public void reconcileRewardpoints_notenough(){
	
	CreditCardDto creditcardDto= new CreditCardDto();
	CreditCardVO creditcardvo= new CreditCardVO();
	
	List<CreditCardTransactionDto> reconciledTransactionList= new ArrayList<CreditCardTransactionDto>();
	List<CreditCardDto> creditcardlist= new ArrayList<CreditCardDto>();
	Map<String, Object> journeyMap= new HashMap<String, Object>();
	
	CreditCardDto obj1= new CreditCardDto();
	obj1.setCardNum("126532653434");
	obj1.setCardType("Emirates");
	obj1.setBlockCode("D");
	RewardPointDto rewardpoint=new RewardPointDto();
	rewardpoint.setRewardsPoints("100");
	obj1.setCardAvailableRewardpoint(rewardpoint);
	creditcardlist.add(obj1);
	
	journeyMap.put("Credit_Reward_List", creditcardlist);
	journeyMap.put("overAllrewardpoints", Integer.valueOf(0));
	
	creditcardDto.setCardType("Emirates");
	creditcardDto.setBlockCode("D");
	creditcardDto.setCardNum("123412");
	creditcardDto.setFeeType("Annual_Fee");
	CreditCardTransactionDto transactionDto= new CreditCardTransactionDto();
	RewardPointDto rewardpoint2=new RewardPointDto();
	rewardpoint2.setRewardsPoints("160");
	transactionDto.setEquivalentRewardPoints(rewardpoint2);
	reconciledTransactionList.add(transactionDto);
	Map<String, Object> rewardpropmap= new HashMap<String, Object>();
	Map<String, String> exclutionmap= new HashMap<String, String>();
	exclutionmap.put("Annual_Fee", "Infinite");
	rewardpropmap.put("execusionCardTypes", exclutionmap);
	rewardpropmap.put("exclusionBlockCodes", "A,B,C");
	
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setRewardPoint(rewardpropmap);
	reconcileRewardPoints.reconcileRewardPoint(creditcardDto, creditcardvo, reconciledTransactionList, journeyMap, props);
	
	
	assertEquals(0,journeyMap.get("overAllrewardpoints"));
	//assertEquals(CardConstant.CC_FEE_WAIVER_ERR_CD_CUST_NOT_ELIGIBLE,creditcardDto.getErrorCode());
}
@Test
public void reconcileRewardpoints_not_eligible_card_type(){
	
	CreditCardDto creditcardDto= new CreditCardDto();
	CreditCardVO creditcardvo= new CreditCardVO();
	
	List<CreditCardTransactionDto> reconciledTransactionList= new ArrayList<CreditCardTransactionDto>();
	List<CreditCardDto> creditcardlist= new ArrayList<CreditCardDto>();
	Map<String, Object> journeyMap= new HashMap<String, Object>();
	
	CreditCardDto obj1= new CreditCardDto();
	obj1.setCardNum("126532653434");
	obj1.setCardType("Emirates");
	obj1.setBlockCode("D");
	RewardPointDto rewardpoint=new RewardPointDto();
	rewardpoint.setRewardsPoints("100");
	obj1.setCardAvailableRewardpoint(rewardpoint);
	creditcardlist.add(obj1);
	
	journeyMap.put("Credit_Reward_List", creditcardlist);
	journeyMap.put("overAllrewardpoints", Integer.valueOf(0));
	creditcardDto.setFeeType("Annual_Fee");
	creditcardDto.setCardType("Emirates");
	creditcardDto.setBlockCode("D");
	creditcardDto.setCardNum("57654655789876");
	CreditCardTransactionDto transactionDto= new CreditCardTransactionDto();
	RewardPointDto rewardpoint2=new RewardPointDto();
	rewardpoint2.setRewardsPoints("160");
	transactionDto.setEquivalentRewardPoints(rewardpoint2);
	reconciledTransactionList.add(transactionDto);
	
	Map<String, Object> rewardpropmap= new HashMap<String, Object>();
	Map<String, String> exclutionmap= new HashMap<String, String>();
	exclutionmap.put("Annual_Fee", "Emirates");
	rewardpropmap.put("execusionCardTypes", exclutionmap);
	rewardpropmap.put("exclusionBlockCodes", "A,B,C");
	
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setRewardPoint(rewardpropmap);
	reconcileRewardPoints.reconcileRewardPoint(creditcardDto, creditcardvo, reconciledTransactionList, journeyMap, props);
	assertEquals(0,journeyMap.get("overAllrewardpoints"));
	//assertEquals(CardConstant.CC_FEE_WAIVER_ERR_CD_CUST_NOT_ELIGIBLE,creditcardDto.getErrorCode());
}
@Test
public void reconcileRewardpoints_not_eligible_block(){
	
	CreditCardDto creditcardDto= new CreditCardDto();
	CreditCardVO creditcardvo= new CreditCardVO();
	
	List<CreditCardTransactionDto> reconciledTransactionList= new ArrayList<CreditCardTransactionDto>();
	List<CreditCardDto> creditcardlist= new ArrayList<CreditCardDto>();
	Map<String, Object> journeyMap= new HashMap<String, Object>();
	
	CreditCardDto obj1= new CreditCardDto();
	obj1.setCardNum("126532653434");
	obj1.setCardType("Emirates");
	obj1.setBlockCode("B");
	RewardPointDto rewardpoint=new RewardPointDto();
	rewardpoint.setRewardsPoints("100");
	obj1.setCardAvailableRewardpoint(rewardpoint);
	creditcardlist.add(obj1);
	
	journeyMap.put("Credit_Reward_List", creditcardlist);
	
	journeyMap.put("overAllrewardpoints", Integer.valueOf(0));
	creditcardDto.setFeeType("Annual_Fee");
	creditcardDto.setCardType("Emirates");
	creditcardDto.setBlockCode("D");
	CreditCardTransactionDto transactionDto= new CreditCardTransactionDto();
	RewardPointDto rewardpoint2=new RewardPointDto();
	rewardpoint2.setRewardsPoints("160");
	transactionDto.setEquivalentRewardPoints(rewardpoint2);
	reconciledTransactionList.add(transactionDto);
	
	Map<String, Object> rewardpropmap= new HashMap<String, Object>();
	Map<String, String> exclutionmap= new HashMap<String, String>();
	rewardpropmap.put("Annual_Fee", "Emirates");
	rewardpropmap.put("execusionCardTypes", exclutionmap);
	rewardpropmap.put("exclusionBlockCodes", "A,B,C");
	
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setRewardPoint(rewardpropmap);
	reconcileRewardPoints.reconcileRewardPoint(creditcardDto, creditcardvo, reconciledTransactionList, journeyMap, props);
	
	
	assertEquals(0,journeyMap.get("overAllrewardpoints"));
//	assertEquals(CardConstant.CC_FEE_WAIVER_ERR_CD_CUST_NOT_ELIGIBLE,creditcardDto.getErrorCode());
}
@Test
public void reconcileRewardpoints_FinadAll(){
	
	CreditCardDto creditcardDto= new CreditCardDto();
	CreditCardVO creditcardvo= new CreditCardVO();
	
	List<CreditCardTransactionDto> reconciledTransactionList= new ArrayList<CreditCardTransactionDto>();
	List<CreditCardDto> creditcardlist= new ArrayList<CreditCardDto>();
	Map<String, Object> journeyMap= new HashMap<String, Object>();
	creditcardDto.setFeeType("Annual_Fee");
	CreditCardDto obj1= new CreditCardDto();
	obj1.setCardNum("126532653434");
	obj1.setCardType("Emirates");
	obj1.setBlockCode("B");
	RewardPointDto rewardpoint=new RewardPointDto();
	rewardpoint.setRewardsPoints("100");
	obj1.setCardAvailableRewardpoint(rewardpoint);
	creditcardlist.add(obj1);
	when(cardService.getAllCreditCards(creditcardvo)).thenReturn(creditcardlist);
	 
	journeyMap.put("overAllrewardpoints", Integer.valueOf(0));
	
	creditcardDto.setCardType("Emirates");
	creditcardDto.setBlockCode("D");
	CreditCardTransactionDto transactionDto= new CreditCardTransactionDto();
	RewardPointDto rewardpoint2=new RewardPointDto();
	rewardpoint2.setRewardsPoints("160");
	transactionDto.setEquivalentRewardPoints(rewardpoint2);
	reconciledTransactionList.add(transactionDto);
	
	Map<String, Object> rewardpropmap= new HashMap<String, Object>();
	Map<String, String> exclutionmap= new HashMap<String, String>();
	exclutionmap.put("Annual_Fee", "Emirates");
	rewardpropmap.put("execusionCardTypes", exclutionmap);
	rewardpropmap.put("exclusionBlockCodes", "A,B,C");
	
	CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
	props.setRewardPoint(rewardpropmap);
	reconcileRewardPoints.reconcileRewardPoint(creditcardDto, creditcardvo, reconciledTransactionList, journeyMap, props);
	
	
	assertEquals(0,journeyMap.get("overAllrewardpoints"));
	assertEquals(creditcardlist.hashCode(),journeyMap.get("Credit_Reward_List").hashCode());
//	assertEquals(CardConstant.CC_FEE_WAIVER_ERR_CD_CUST_NOT_ELIGIBLE,creditcardDto.getErrorCode());
}
}
