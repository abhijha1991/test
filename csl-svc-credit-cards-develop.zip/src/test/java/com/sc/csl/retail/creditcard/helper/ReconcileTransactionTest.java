package com.sc.csl.retail.creditcard.helper;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import io.katharsis.queryspec.QuerySpec;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class ReconcileTransactionTest {

	@InjectMocks
	private ReconcileTransaction reconcileTransaction;

	@Mock
	private CSLRequestContext cslRequestContext;

	@Mock
	QuerySpec querySpec;

	@Mock
	SRParamDto param;
	@Mock
	SRParamDto param1;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);

	}

	//@Test
	public void reconcileTransactionSG()  {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");

		CreditCardTransactionDto obj1 = new CreditCardTransactionDto();
		obj1.setTxnCode("18");
		obj1.setDesc("B4INTEREST");
		obj1.setTxnDate("12/12/2106");
		obj1.setOriginTxnAmt(BigDecimal.valueOf(100));
		
		journeyMap.put("rewardPointConvRatio", param1);
		when(param1.getParamData2()).thenReturn("100");
		when(param1.getParamData3()).thenReturn("0");
		when(param1.getParamData4()).thenReturn("1000");

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("ABC12/12/2016B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(10));

		edmp12MonthTransactions.add(obj1);
		edmp12MonthTransactions.add(obj2);

		creditcardvo.setCountryCode("SG");
		
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		List<CreditCardTransactionDto> reconcileList = reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(1, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(1, journeyMap.get("CREDIT_TRANC_LIST"));
		assertEquals(1, reconcileList.size());
	}

	//@Test
	public void reconcileTransactionSG_All_Debit_Processed() {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");
		
		journeyMap.put("rewardPointConvRatio", param1);
		when(param1.getParamData2()).thenReturn("100");
		when(param1.getParamData3()).thenReturn("200");
		when(param1.getParamData4()).thenReturn("1000");

		CreditCardTransactionDto obj1 = new CreditCardTransactionDto();
		obj1.setTxnCode("18");
		obj1.setDesc("B4INTEREST");
		obj1.setTxnDate("12/12/2106");
		obj1.setOriginTxnAmt(BigDecimal.valueOf(100));

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("ABC12/12/2016B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(100));

		edmp12MonthTransactions.add(obj1);
		edmp12MonthTransactions.add(obj2);

		creditcardvo.setCountryCode("SG");
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		List<CreditCardTransactionDto> reconcileList = reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(1, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(1, journeyMap.get("CREDIT_TRANC_LIST"));
		assertEquals(1, reconcileList.size());
		assertEquals("2000", reconcileList.get(0).getErrorCode());
	}

	@Test
	public void mergeTransactionsTransaction()   {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);
		journeyMap.put("rewardPointConvRatio", param1);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");
		
		journeyMap.put("rewardPointConvRatio", param1);
		when(param1.getParamData2()).thenReturn("100");
		when(param1.getParamData3()).thenReturn("0");
		when(param1.getParamData4()).thenReturn("1000");

		CreditCardTransactionDto obj1 = new CreditCardTransactionDto();
		obj1.setTxnCode("18");
		obj1.setDesc("B4INTEREST");
		obj1.setTxnDate("12/12/2106");
		obj1.setOriginTxnAmt(BigDecimal.valueOf(100));

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("ABC12/12/2016B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(10));

		edmp12MonthTransactions.add(obj1);
		edmp12MonthTransactions.add(obj2);

		statemantedTransaction.add(obj1);
		unStatementtransactionList.add(obj1);
		statemantedTransaction.add(obj2);
		unStatementtransactionList.add(obj2);

		creditcardvo.setCountryCode("");
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(3, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(3, journeyMap.get("CREDIT_TRANC_LIST"));
	}

	@Test
	public void mergeTransactionsTransaction_NoDebit()   {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("ABC12/12/2016B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(10));

		edmp12MonthTransactions.add(obj2);
		statemantedTransaction.add(obj2);
		unStatementtransactionList.add(obj2);

		creditcardvo.setCountryCode("");
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		List<CreditCardTransactionDto> reconcileList = reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(0, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(3, journeyMap.get("CREDIT_TRANC_LIST"));
		assertEquals("1000", reconcileList.get(0).getErrorCode());
	}

	@Test
	public void reconcileTransactionIN_allDebitprocessed()   {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");

		CreditCardTransactionDto obj1 = new CreditCardTransactionDto();
		obj1.setTxnCode("18");
		obj1.setDesc("B4INTEREST");
		obj1.setTxnDate("12/12/2016");
		obj1.setOriginTxnAmt(BigDecimal.valueOf(100));
		
		journeyMap.put("rewardPointConvRatio", param1);
		when(param1.getParamData2()).thenReturn("100");
		when(param1.getParamData3()).thenReturn("5000");
		when(param1.getParamData4()).thenReturn("10000");

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("200121216B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(100));

		edmp12MonthTransactions.add(obj1);
		edmp12MonthTransactions.add(obj2);

		creditcardvo.setCountryCode("IN");
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		journeyMap.put(CardConstant.REWARD_POINT_REQUIRED,false);
		List<CreditCardTransactionDto> reconcileList = reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(1, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(1, journeyMap.get("CREDIT_TRANC_LIST"));
		assertEquals(1, reconcileList.size());
		assertEquals("2000", reconcileList.get(0).getErrorCode());
	}

	@Test
	public void reconcileTransactionIN_partialPaid()   {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");
		
		journeyMap.put("rewardPointConvRatio", param1);
		when(param1.getParamData2()).thenReturn("100");
		when(param1.getParamData3()).thenReturn("0");
		when(param1.getParamData4()).thenReturn("1000");

		CreditCardTransactionDto obj1 = new CreditCardTransactionDto();
		obj1.setTxnCode("18");
		obj1.setDesc("B4INTEREST");
		obj1.setTxnDate("12/12/2016");
		obj1.setOriginTxnAmt(BigDecimal.valueOf(100));

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("200121216B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(50));

		edmp12MonthTransactions.add(obj1);
		edmp12MonthTransactions.add(obj2);

		creditcardvo.setCountryCode("IN");
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		journeyMap.put(CardConstant.REWARD_POINT_REQUIRED,false);
		List<CreditCardTransactionDto> reconcileList = reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(1, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(1, journeyMap.get("CREDIT_TRANC_LIST"));
		assertEquals(1, reconcileList.size());
	//	assertEquals(BigDecimal.valueOf(50), reconcileList.get(0)
		//		.getOriginTxnAmt());
	}

	@Test
	public void reconcileTransactionIN_DebitFound()   {

		List<CreditCardTransactionDto> unStatementtransactionList = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> edmp12MonthTransactions = new ArrayList<CreditCardTransactionDto>();
		List<CreditCardTransactionDto> statemantedTransaction = new ArrayList<CreditCardTransactionDto>();
		CreditCardVO creditcardvo = new CreditCardVO();
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		journeyMap.put("paramDto", param);

		when(param.getParamData2()).thenReturn("18");
		when(param.getParamData3()).thenReturn("B4INTEREST");
		when(param.getParamData4()).thenReturn("60");
		when(param.getParamData5()).thenReturn("13");
		when(param.getParamData9()).thenReturn("B4INT REVSD");
		
		journeyMap.put("rewardPointConvRatio", param1);
		when(param1.getParamData2()).thenReturn("100");
		when(param1.getParamData3()).thenReturn("0");
		when(param1.getParamData4()).thenReturn("1000");

		CreditCardTransactionDto obj1 = new CreditCardTransactionDto();
		obj1.setTxnCode("18");
		obj1.setDesc("B4INTEREST");
		obj1.setTxnDate("12/12/2016");
		obj1.setOriginTxnAmt(BigDecimal.valueOf(100));

		CreditCardTransactionDto obj2 = new CreditCardTransactionDto();
		obj2.setTxnCode("60");
		obj2.setDesc("20012112016B4INT REVSD");
		obj2.setTxnDate("12/12/2106");
		obj2.setOriginTxnAmt(BigDecimal.valueOf(50));

		CreditCardTransactionDto obj3 = new CreditCardTransactionDto();
		obj3.setTxnCode("60");
		obj3.setDesc("20012112016B4INT REVSD");
		obj3.setTxnDate("12/12/2106");
		obj3.setOriginTxnAmt(BigDecimal.valueOf(50));

		edmp12MonthTransactions.add(obj1);
		edmp12MonthTransactions.add(obj2);

		creditcardvo.setCountryCode("IN");
		CreditCardDto 	ccdto=new CreditCardDto();
		ccdto.setIsPrimary("P");
		journeyMap.put(CardConstant.REWARD_POINT_REQUIRED,false);
		List<CreditCardTransactionDto> reconcileList = reconcileTransaction
				.getReconciledTransaction(unStatementtransactionList,
						edmp12MonthTransactions, statemantedTransaction,
						creditcardvo, journeyMap,ccdto);

		assertEquals(1, journeyMap.get("DEBT_TRANC_LIST"));
		assertEquals(1, journeyMap.get("CREDIT_TRANC_LIST"));
		assertEquals(1, reconcileList.size());
	}
}
