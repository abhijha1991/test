package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.xml.bind.Unmarshaller;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.Mockito.when;

public class CreditCardLimitV1SoapGatewayTest {


    @Mock
    FreemarkerRenderer renderer;
    @Mock
    CSLSoapGatewayProperties creditCardProfileV1SoapGatewayProperties;
    @Mock
    CardUtil cardUtil;
    @Mock
    BaseCreditCardsSoapGateway baseSoapGateway;
    @Mock
    private CreditCardLimitV1SoapGateway creditCardLimitV1SoapGateway;
    @Mock
    Unmarshaller unmarshaller;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getCreditCardBalanceLimit() throws Exception {
    }

    @Test(expected = Exception.class)
    public void shouldThrow_Exception_When_getCreditCardBalanceLimit_Called_With_EmptyMapObject() throws Exception {
        Map<String, Object> creditCardMap = new HashMap<>();
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("HK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01C303360");
        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();
        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "HK");
        when(baseSoapGateway.getValuePropertiesByKey(map, "HK")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("HK")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);
        when(renderer.render("card-limit-balance-details.ftl",creditCardMap)).thenReturn("<xml></xml>");
        Field field = creditCardLimitV1SoapGateway.getClass().getDeclaredField("renderer");
        field.setAccessible(true);
        field.set(creditCardLimitV1SoapGateway, renderer);
        //when(unmarshaller.unmarshal(any(ValidateLimitIncreaseRes.class))).thenReturn(new ValidateLimitIncreaseRes());
        creditCardLimitV1SoapGateway.getCreditCardBalanceLimit(creditCardVO);
    }

}