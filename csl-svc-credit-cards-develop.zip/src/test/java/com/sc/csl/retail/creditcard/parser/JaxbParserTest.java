package com.sc.csl.retail.creditcard.parser;

import org.junit.Test;

import javax.xml.datatype.XMLGregorianCalendar;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

public class JaxbParserTest {

    @Test
    public void shouldReturn_Date_When_parseDateTime_Method_Called() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseDateTime("25072017");
        assertNotNull(date);
    }

    /*
  * Created by 1572681 on 23/08/2017
  * Added code for checking for array empty
  * */
    @Test
    public void shouldReturn_Null_When_parseDateTime_Method_Called_With_Empty_Object() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseDateTime("");
        assertNull(date);
    }

    /*
  * Created by 1572681 on 23/08/2017
  * Added code for checking for array empty
  * */
    @Test
    public void shouldReturn_Null_When_parseDateTime_Method_Called_With_UnFormated() {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseDateTime("!fdfsfdsfsds720179899898");
        assertNull(date);
    }

    @Test
    public void shouldReturn_Date_When_parseTime_Method_Called() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseTime("25072017");
        assertNotNull(date);
    }

    @Test
    public void shouldReturn_Null_When_parseTime_Method_Called_With_UnFormated() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseTime("0");
        assertNull(date);
    }

    @Test
    public void shouldReturn_Date_When_parseDate_Method_Called() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseDate("25072017");
        assertNotNull(date);
    }

    @Test
    public void shouldReturn_Null_When_parseDate_Method_Called_With_Unformated() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        XMLGregorianCalendar date= jaxbParser.parseDate("0");
        assertNull(date);
    }

    @Test
    public void shouldReturn_Date_When_parseInteger_Method_Called() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        java.math.BigInteger date= jaxbParser.parseInteger("25072017");
        assertNotNull(date);
    }

    @Test
    public void shouldReturn_Null_When_parseInteger_Method_Called_with_Empty_Parameter() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        java.math.BigInteger date= jaxbParser.parseInteger("");
        assertNull(date);
    }

    @Test
    public void shouldReturn_Zero_When_parseInteger_Method_Called_with_N() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        java.math.BigInteger date= jaxbParser.parseInteger("N");
        assertNotNull(date);
    }

    @Test
    public void shouldReturn_One_When_parseInteger_Method_Called_with_Y() throws Exception {
        JaxbParser jaxbParser = new JaxbParser();
        java.math.BigInteger date= jaxbParser.parseInteger("Y");
        assertNotNull(date);
    }

}