package com.sc.csl.retail.creditcard.gateway;

import com.sc.csl.retail.core.exception.BusinessException;

import com.sc.csl.retail.core.gateway.CSLSoapGateway;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.GatewayHeaderProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway.PropertyCodes;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.scbml_1.Code;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.SCBMLHeaderType;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.powermock.api.mockito.PowerMockito;

import javax.xml.bind.Unmarshaller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

public class BaseCreditCardsSoapGatewayTest {
    @InjectMocks
    BaseCreditCardsSoapGateway baseSoapGateway;

        @Spy
        Map<String, CreditCardProperties> creditCardProperties;

        @Mock
        CardUtil cardUtil;

        @Mock
        CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;

        @Mock
        FreemarkerRenderer renderer;

        @Mock
        Unmarshaller unmarshaller;

        @Mock
        private CSLSoapGateway cSLSoapGateway;

        @Mock
        CSLSoapGatewayProperties creditCardProfileV1SoapGatewayProperties;

        CreditCardProperties countryProp;
        Map<String, String> errorCodes;
        Map<String, String> currencyCodes;

        @Before
        public void set()
        {
            creditCardProperties= new HashMap<>();


            countryProp = new CreditCardProperties();
            GatewayHeaderProperties gatewayHeaderProperties = new GatewayHeaderProperties();
            gatewayHeaderProperties.setCaptureSystem("CCMS");
            gatewayHeaderProperties.setEntityType("05");
            gatewayHeaderProperties.setFuncCode("16");
            gatewayHeaderProperties.setMessageVersion("1.0");
            gatewayHeaderProperties.setPayLoadVersion("1.0");
            gatewayHeaderProperties.setSourceFlag("IBK");
            countryProp.setCardDetailsProperties(gatewayHeaderProperties);


            errorCodes = new HashMap();
            errorCodes.put("-1", "ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT");
            errorCodes.put( "0001", "ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO");
            errorCodes.put("10001", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
            errorCodes.put("10009", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");

            currencyCodes = new HashMap();
            currencyCodes.put("248", "ALA");
            currencyCodes.put("008", "ALB");
            currencyCodes.put("012", "DZA");

            CreditCardFilterProperties creditCardFilterProperties = new CreditCardFilterProperties();
            creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0");
            creditCardFilterProperties.setIsSupplCardStausCheckEnabled("Y");
            creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0|1");

            countryProp.setCreditCardFilters(creditCardFilterProperties);
            countryProp.setErrorCodes(errorCodes);
            countryProp.setCurrencyCodes(currencyCodes);
            creditCardProperties.put("IN", countryProp);
            creditCardProperties.put("ALL", countryProp);


            baseSoapGateway = Mockito.mock(BaseCreditCardsSoapGateway.class, Mockito.CALLS_REAL_METHODS);
            cSLSoapGateway = Mockito.mock(CSLSoapGateway.class, Mockito.CALLS_REAL_METHODS);
            MockitoAnnotations.initMocks(this);

        }

        @Test
        public void getValuePropertiesByKey() throws Exception {
        }

        @Test
        public void getCreditCardPropertiesByCountry() throws Exception {
        }

        @Test
        public void return_ErrorCodeMap_When_called_getErrorCodes() {
            when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(countryProp);
            Map<String, String> errorCodes = baseSoapGateway.getPropertiesByCode("IN",PropertyCodes.ERROR_CODES);
            assertEquals("ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT",errorCodes.get("-1"));
        }

        @Test
        public void return_ErrorCodeMap_When_called_getErrorCodes_isNull() {
            when(baseSoapGateway.getValuePropertiesByKey(creditCardProperties, "IN")).thenReturn(countryProp);
            Map<String, String> errorCode = new HashMap();
            countryProp.setErrorCodes(null);
            when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(countryProp);
            when(baseSoapGateway.getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL)).thenReturn(countryProp);
            Map<String, String> errorCodes = baseSoapGateway.getPropertiesByCode("IN",PropertyCodes.ERROR_CODES);
            assertNull(errorCodes);
        }

        @Test
        public void shouldReturn_Map_Object_When_getCurrencyCodes_Method_Called() {

            when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(countryProp);
            Map<String, String> currencyCode = baseSoapGateway.getPropertiesByCode("IN",PropertyCodes.CURRENCY_CODES);
            assertEquals("ALA",currencyCode.get("248"));

        }

        @Test
        public void shouldReturn_Null_When_getCurrencyCodes_Method_Called() {

            when(baseSoapGateway.getValuePropertiesByKey(creditCardProperties, "IN")).thenReturn(countryProp);
            countryProp.setCurrencyCodes(null);
            when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(countryProp);
            when(baseSoapGateway.getCreditCardPropertiesByCountry(CardConstant.CTR_CD_ALL)).thenReturn(countryProp);
            Map<String, String> currencyCode = baseSoapGateway.getPropertiesByCode("IN",PropertyCodes.CURRENCY_CODES);
            assertNull(currencyCode);
        }

        @Test
        public void shouldReturn_Map_Object_When_getGatewayTemplateMap_Method_Called (){
            CreditCardVO creditCardVO = new CreditCardVO();
            creditCardVO.setCountryCode("IN");
            creditCardVO.setCardNo("4129057530874005");
            creditCardVO.setCardTransactionRefNo("11290575308711111");
            creditCardVO.setChannelId("WEB");
            creditCardVO.setCustomerId("01070565A0SH04005");

            Map<String, Object> templateMap = new HashMap();
            templateMap.put("gatewayProps", countryProp.getCardDetailsProperties());
            templateMap.put("creditCardVO", creditCardVO);
            Map<String, Object> gatewayMap = baseSoapGateway.getGatewayTemplateMap(countryProp.getCardDetailsProperties(),creditCardVO);
            assertNotNull(gatewayMap);
            assertEquals(templateMap,gatewayMap);
        }

        @Test
        public void return_Exception_When_call_validateSCBMLHeader_Header_isNull() throws Exception {
            baseSoapGateway.validateSCBMLHeader(null,new CreditCardVO());
        }

        @Test(expected = BusinessException.class)
        public void should_Return_BusinessException_When_call_validateSCBMLHeader_Header__creditCardVo_isNotNull(){
            List<ExceptionType> exceptions = new ArrayList<ExceptionType>();
            ExceptionType  exceptionType = new ExceptionType();

            Code code = new Code();
            code.setExceptionCodeScheme("00000");
            code.setValue("desc");

            exceptionType.setCode(code);
            exceptionType.setDescription("test description");

            exceptions.add(exceptionType);

            SCBMLHeaderType header = new SCBMLHeaderType();
            ExceptionListType exceptionListType = PowerMockito.mock(ExceptionListType.class);
            when(exceptionListType.getException()).thenReturn(exceptions);

            header.setExceptions(exceptionListType);

            CreditCardVO creditCardVO = new CreditCardVO();
            creditCardVO.setCountryCode("IN");
            creditCardVO.setCardNo("4129057530874005");
            creditCardVO.setCardTransactionRefNo("11290575308711111");
            creditCardVO.setChannelId("WEB");
            creditCardVO.setCustomerId("01070565A0SH04005");
            baseSoapGateway.validateSCBMLHeader(header,creditCardVO);
        }

    @Test
    public void should_Return_Nothing_When_call_validateSCBMLHeader_Header__creditCardVo_isNotNull(){
        List<ExceptionType> exceptions = new ArrayList<ExceptionType>();
        ExceptionType  exceptionType = new ExceptionType();

        Code code = new Code();
        code.setExceptionCodeScheme("00000");
        code.setValue("00000");

        exceptionType.setCode(code);
        exceptionType.setDescription("test description");

        exceptions.add(exceptionType);

        SCBMLHeaderType header = new SCBMLHeaderType();
        ExceptionListType exceptionListType = PowerMockito.mock(ExceptionListType.class);
        when(exceptionListType.getException()).thenReturn(exceptions);

        header.setExceptions(exceptionListType);

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        baseSoapGateway.validateSCBMLHeader(header,creditCardVO);
    }

        @Test(expected = BusinessException.class)
        public void return_BusinessException_When_Call_validateResponseCode() {
            String responseCode="10001";
            String responseDesc="desc";

            CreditCardVO creditCardVO = new CreditCardVO();
            creditCardVO.setCountryCode("IN");
            creditCardVO.setCardNo("4129057530874005");
            creditCardVO.setCardTransactionRefNo("11290575308711111");
            creditCardVO.setChannelId("WEB");
            creditCardVO.setCustomerId("01070565A0SH04005");
            baseSoapGateway.validateResponseCode(responseCode,responseDesc,creditCardVO);

        }

        @Test
        public void return_BusinessException_When_Call_validateResponseCode_With_ResponseCode_00000() {
            String responseCode="00000";
            String responseDesc="desc";

            CreditCardVO creditCardVO = new CreditCardVO();
            creditCardVO.setCountryCode("IN");
            creditCardVO.setCardNo("4129057530874005");
            creditCardVO.setCardTransactionRefNo("11290575308711111");
            creditCardVO.setChannelId("WEB");
            creditCardVO.setCustomerId("01070565A0SH04005");
            when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(countryProp);
            when(baseSoapGateway.getPropertiesByCode("IN",PropertyCodes.ERROR_CODES)).thenReturn(errorCodes);



            baseSoapGateway.validateResponseCode(responseCode,responseDesc,creditCardVO);
            assertTrue(true);

        }

        @Test
        public void populateCreditCardPrimaryStatus() throws Exception {
            CreditCardDto creditCardDto=new CreditCardDto();
            creditCardDto.setBlkInd("02");
            creditCardDto.setFranchise("Visa");
            creditCardDto.setProd("53");
            creditCardDto.setCardType("Visa");
            creditCardDto.setExpDt("1114");
            creditCardDto.setCardNum("4129057530874005");
            creditCardDto.setCardImgName("in-manhattan-platinum");
            creditCardDto.setIsPrimary("Y");
            creditCardDto.setCustomerId("01070565A0SH04005");
            creditCardDto.setVariant("200");
            creditCardDto.setCustShortName("INORR57");
            creditCardDto.setCurrencyCode("356");
            creditCardDto.setDesc("Credit Card");
            creditCardDto.setStatus("2");
            creditCardDto.setIsPrimary("N");

            List<CreditCardDto> creditCardDtoList = new ArrayList<>();
            creditCardDtoList.add(creditCardDto);
            baseSoapGateway.populateCreditCardPrimaryStatus(countryProp,creditCardDtoList);


        }

    @Test(expected = Exception.class)
    public void  setupInterceptors(){
        baseSoapGateway.setupInterceptors();
    }

}