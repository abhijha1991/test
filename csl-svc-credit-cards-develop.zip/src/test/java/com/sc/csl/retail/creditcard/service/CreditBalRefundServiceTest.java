package com.sc.csl.retail.creditcard.service;

import static org.hamcrest.Matchers.both;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hamcrest.beans.HasPropertyWithValue;
import org.hamcrest.core.Every;
import org.hamcrest.core.Is;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditBalRefundProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.BusinessRuleAlert;
import com.sc.csl.retail.creditcard.dto.BusinessRuleAlertType;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.gateway.csl.ServiceRequestJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * CreditBalRefundServiceTest.java
 * 
 * <pre>
 * 
 * </pre>
 * 
 * @author 1523165
 * @since Aug 11, 2017
 * @version CSL-SVC-CREDIT-CARDS-1.0.0
 */
@RunWith(MockitoJUnitRunner.class)
public class CreditBalRefundServiceTest {

    @InjectMocks
    CreditBalRefundService creditBalRefundService;

    @Mock
    private CreditCardService creditCardService;

    @Mock
    private CardUtil cardUtil;

    @Mock
    private CSLRequestContext cslRequestContext;
    
    @Mock
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
    @Mock
    ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
    
    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @Test
    public void shouldReturn_ListOfEligibleCreditCards() throws Throwable {
        List<CreditCardDto> ccList = new ArrayList<CreditCardDto>();
        CreditCardVO creditCardVO = new CreditCardVO();
        CreditCardDto creditCardDto = null;
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        when(cslRequestContext.getRelId()).thenReturn("01070565A0SH04005");
        when(cslRequestContext.getCountry()).thenReturn("IN");
        creditCardVO.setCslRequestContext(cslRequestContext);
        ccList.addAll(constructEligibleCreditCardDtoList(ccList));
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(constructCreditCardProperties());
        /*when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(
                constructEligibleCreditCardDto(creditCardDto));*/
        when(creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO)).thenReturn(
                constructEligibleDeliquencyCreditCardDto(creditCardDto));
        when(creditCardService.getAllCreditCards(creditCardVO)).thenReturn(ccList);
        ReflectionTestUtils.setField(creditBalRefundService, "serviceRequestJsonApiGateway", serviceRequestJsonApiGateway);
        ccList = creditBalRefundService.validateCreditBalRefundEligibility(creditCardVO);

        assertThat(ccList, hasSize(3));
        assertThat(ccList,
                Every.everyItem(HasPropertyWithValue.hasProperty("eligibleForCreditBalRefund", Is.is("yes"))));

    }

    @Test
    public void shouldThrow_BusinessException_ERR_CSL_NO_VALID_CARDS_FOUND() {
//        exception.expect(BusinessException.class);
//        exception.expectMessage("You do not have any eligible Credit Card(s) to initiate the request.");
        List<CreditCardDto> ccList = new ArrayList<CreditCardDto>();
        CreditCardVO creditCardVO = new CreditCardVO();
        CreditCardDto creditCardDto = null;
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CreditCardProperties cardProp = constructCreditCardProperties();
        Map<String, String> alerts = new HashMap<String, String>();
        alerts.put("en.novalidcardsfound",
                "You do not have any eligible Credit Card(s) to initiate the request.");
        cardProp.getCreditBalRefundProperties().setAlertMessages(alerts);
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(cardProp);
        when(cslRequestContext.getRelId()).thenReturn("01070565A0SH04005");
        when(cslRequestContext.getCountry()).thenReturn("IN");
        when(cslRequestContext.getLanguage()).thenReturn("en");
        creditCardVO.setCslRequestContext(cslRequestContext);
        ccList.addAll(constructInEligibleCreditCardDtoList(ccList));
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(cardProp);
        /*when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(
                constructEligibleCreditCardDto(creditCardDto));*/
        /*when(creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO)).thenReturn(
                constructEligibleDeliquencyCreditCardDto(creditCardDto));*/
        when(creditCardService.getAllCreditCards(creditCardVO)).thenReturn(ccList);
        ReflectionTestUtils.setField(creditBalRefundService, "serviceRequestJsonApiGateway", serviceRequestJsonApiGateway);
        ccList = creditBalRefundService.validateCreditBalRefundEligibility(creditCardVO);
        BusinessRuleAlert alert = new BusinessRuleAlert(BusinessRuleAlertType.ERROR, null,
                "You do not have any eligible Credit Card(s) to initiate the request.");
        assertThat(ccList.get(0).getAlerts(), both(hasSize(1)).and(contains(alert)));
    }

    @Test
    public void shouldThrow_BusinessException_ERR_CSL_NO_EXCESS_AMOUNT() {
//        exception.expect(BusinessException.class);
//        exception.expectMessage("There is no excess amount to refund.");
        List<CreditCardDto> ccList = new ArrayList<CreditCardDto>();
        CreditCardVO creditCardVO = new CreditCardVO();
        CreditCardDto creditCardDto = null;
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        CreditCardProperties cardProp = constructCreditCardProperties();
        Map<String, String> alerts = new HashMap<String, String>();
        alerts.put("en.noexcessamountcard",
                "There is no excess amount to refund.");
        cardProp.getCreditBalRefundProperties().setAlertMessages(alerts);
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(cardProp);
        when(cslRequestContext.getRelId()).thenReturn("01070565A0SH04005");
        when(cslRequestContext.getCountry()).thenReturn("IN");
        when(cslRequestContext.getLanguage()).thenReturn("en");
        creditCardVO.setCslRequestContext(cslRequestContext);
        ccList.addAll(constructInEligibleCreditCardDtoListWithoutExcessBalance(ccList));
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(cardProp);
        /*when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(
                constructEligibleCreditCardDto(creditCardDto));*/
        when(creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO)).thenReturn(
                constructEligibleDeliquencyCreditCardDto(creditCardDto));
        when(creditCardService.getAllCreditCards(creditCardVO)).thenReturn(ccList);
        ReflectionTestUtils.setField(creditBalRefundService, "serviceRequestJsonApiGateway", serviceRequestJsonApiGateway);
        creditBalRefundService.validateOneCardCreditBalRefund(creditCardVO, "4129057530874005");
        ccList = creditBalRefundService.validateCreditBalRefundEligibility(creditCardVO);
        BusinessRuleAlert alert = new BusinessRuleAlert(BusinessRuleAlertType.ERROR, null,
                "There is no excess amount to refund.");
        assertThat(ccList.get(0).getAlerts(), both(hasSize(1)).and(contains(alert)));
    }

    @Test
    public void shouldThrow_GiveAlert_MIN_ELIGIBLE_REFUND_AMOUNT_NOT_AVAILABLE() {
        List<CreditCardDto> ccList = new ArrayList<CreditCardDto>();
        CreditCardVO creditCardVO = new CreditCardVO();
        CreditCardDto creditCardDto = null;
        creditCardVO.setCountryCode("MY");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        when(cslRequestContext.getRelId()).thenReturn("01070565A0SH04005");
        when(cslRequestContext.getCountry()).thenReturn("MY");
        when(cslRequestContext.getLanguage()).thenReturn("en");
        creditCardVO.setCslRequestContext(cslRequestContext);
        ccList.addAll(constructInEligibleCreditCardDtoListMY(ccList));
        CreditCardProperties cardProp = constructCreditCardProperties();
        cardProp.getCreditBalRefundProperties().setEligibleMinimumRefundAmount("10");
        Map<String, String> alerts = new HashMap<String, String>();
        alerts.put("en.amountnoteligibleforrefund",
                "If credit balance is below {0} {1}, the amount will not be refunded.");
        cardProp.getCreditBalRefundProperties().setAlertMessages(alerts);
        //cardProp.getCreditBalRefundProperties().setRequestContext(cslRequestContext);
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(cardProp);
        /*when(creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO)).thenReturn(
                constructEligibleCreditCardDto(creditCardDto));*/
        when(creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO)).thenReturn(
                constructEligibleDeliquencyCreditCardDto(creditCardDto));
        when(cslRequestContext.getLanguage()).thenReturn("en");
        when(creditCardService.getAllCreditCards(creditCardVO)).thenReturn(ccList);
        ReflectionTestUtils.setField(creditBalRefundService, "serviceRequestJsonApiGateway", serviceRequestJsonApiGateway);
        creditBalRefundService.validateOneCardCreditBalRefund(creditCardVO, "4129057530874005");
        ccList = creditBalRefundService.validateCreditBalRefundEligibility(creditCardVO);

        BusinessRuleAlert alert = new BusinessRuleAlert(BusinessRuleAlertType.ERROR, null,
                "If credit balance is below MYR 10, the amount will not be refunded.");
        assertThat(ccList.get(0).getAlerts(), both(hasSize(1)).and(contains(alert)));
    }

    private CreditBalRefundProperties constructCreditBalRefundProperties() {
        CreditBalRefundProperties cbp = new CreditBalRefundProperties();

        cbp.setEligibleFromCardFirstDigitOfAccNumber("'4','5','9'");
        cbp.setEligibleToCardFirstDigitOfAccNumber("'4','5','9'");
        cbp.setIneligibleFromCardFirstDigitOfAccNumber(null);
        cbp.setIneligibleToCardFirstDigitOfAccNumber(null);
        cbp.setEligibleFromCardBlockCode(null);
        cbp.setEligibleToCardBlockCode(null);
        cbp.setIneligibleFromCardBlockCode(null);
        cbp.setIneligibleToCardBlockCode(null);
        cbp.setIneligibleFromCardCustomerBlockCode("'I','P','C','H','F','Q','Z','O'");
        cbp.setIneligibleToCardCustomerBlockCode(null);
        cbp.setEligibleFromCardCustomerBlockCode(null);
        cbp.setEligibleToCardCustomerBlockCode(null);
        cbp.setEligibleFromCardCardHolderStatus(null);
        cbp.setEligibleToCardCardHolderStatus("'0','1','2','4','5'");
        cbp.setIneligibleFromCardCardHolderStatus(null);
        cbp.setIneligibleToCardCardHolderStatus("");
        cbp.setExcessAmountCalculationLogic("CCMS_Logic");
        cbp.setDelinquencyCheckApplicable("yes");
        return cbp;
    }

    private CreditCardProperties constructCreditCardProperties() {
        CreditCardProperties ccp = new CreditCardProperties();
        ccp.setCreditBalRefundProperties(constructCreditBalRefundProperties());
        return ccp;
    }

    // Eligible CreditCard mock: creditcardEnquiry.getDetails() service Enquiry
    /*private CreditCardDto constructEligibleCreditCardDto(CreditCardDto creditCardDto) {
        creditCardDto = new CreditCardDto();
        creditCardDto.setCardStatus("4");
        creditCardDto.setDesc("Credit Card");
        creditCardDto.setProd("53");
        creditCardDto.setCardType("Visa");

        return creditCardDto;
    }*/

    // In-eligible CreditCard mock: creditcardEnquiry.getDetails() service Enquiry
    /*private CreditCardDto constructInEligibleCreditCardDto(CreditCardDto creditCardDto) {
        creditCardDto = new CreditCardDto();
        creditCardDto.setCardStatus("8");
        creditCardDto.setDesc("Credit Card");
        creditCardDto.setProd("53");
        creditCardDto.setCardType("Visa");

        return creditCardDto;
    }*/

    // Eligible CreditCard mock: creditcardEnquiry.getDetails() service Enquiry
    private CreditCardDto constructEligibleDeliquencyCreditCardDto(CreditCardDto creditCardDto) {
        creditCardDto = new CreditCardDto();
        creditCardDto.setDelinquencyAmount("0.00");
        return creditCardDto;
    }

    // In-eligible CreditCard mock: creditcardEnquiry.getDetails() service Enquiry
   /* private CreditCardDto constructInEligibleDeliquencyCreditCardDto(CreditCardDto creditCardDto) {
        creditCardDto = new CreditCardDto();
        creditCardDto.setDelinquencyAmount("1500.00");
        return creditCardDto;
    }*/

    // In-Eligible CreditCard mock: creditcardEnquiry.getCardListing() service Enquiry
    private List<CreditCardDto> constructInEligibleCreditCardDtoList(List<CreditCardDto> creditCardDtoList) {
        creditCardDtoList = new ArrayList<CreditCardDto>();

        CreditCardDto creditCardDto1 = new CreditCardDto();
        creditCardDto1.setBlkInd("02");
        creditCardDto1.setFranchise("Visa");
        creditCardDto1.setProd("53");
        creditCardDto1.setCardType("Visa");
        creditCardDto1.setExpDt("1114");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardImgName("in-manhattan-platinum");
        creditCardDto1.setIsPrimary("Y");
        creditCardDto1.setCustomerId("01070565A0SH04005");
        creditCardDto1.setVariant("200");
        creditCardDto1.setCustShortName("INORR57");
        creditCardDto1.setCurrencyCode("INR");
        creditCardDto1.setDesc("Credit Card");
        creditCardDto1.setStatus("2");
        creditCardDto1.setBlockCode("C");
        creditCardDto1.setCustBlockCode("C");
        creditCardDto1.setCardNum("04129057530874005");
        creditCardDto1.setCardStatus("4");
        creditCardDto1.setAvlblLimit("34500.50");
        creditCardDto1.setCreditLimit("25000.00");
        creditCardDto1.setCurrentBalance("25000.00");
        creditCardDtoList.add(creditCardDto1);

        CreditCardDto creditCardDto2 = new CreditCardDto();
        creditCardDto2.setBlkInd("02");
        creditCardDto2.setFranchise("Visa");
        creditCardDto2.setProd("53");
        creditCardDto2.setCardType("Visa");
        creditCardDto2.setExpDt("1114");
        creditCardDto2.setCardNum("4129057530874005");
        creditCardDto2.setCardImgName("in-manhattan-platinum");
        creditCardDto2.setIsPrimary("Y");
        creditCardDto2.setCustomerId("01070565A0SH04005");
        creditCardDto2.setVariant("200");
        creditCardDto2.setCustShortName("INORR57");
        creditCardDto2.setCurrencyCode("INR");
        creditCardDto2.setDesc("Credit Card");
        creditCardDto2.setStatus("2");
        creditCardDto2.setBlockCode("C");
        creditCardDto2.setCustBlockCode("C");
        creditCardDto2.setCardNum("04129057530874005");
        creditCardDto2.setCardStatus("4");
        creditCardDto2.setAvlblLimit("34500.50");
        creditCardDto2.setCreditLimit("25000.00");
        creditCardDto2.setCurrentBalance("25000.00");
        creditCardDto2.setDelinquencyAmount("12000.65");
        creditCardDtoList.add(creditCardDto2);

        return creditCardDtoList;
    }

    // In-Eligible CreditCard without excess balance mock: creditcardEnquiry.getCardListing() service Enquiry
    private List<CreditCardDto> constructInEligibleCreditCardDtoListWithoutExcessBalance(
            List<CreditCardDto> creditCardDtoList) {
        creditCardDtoList = new ArrayList<CreditCardDto>();

        CreditCardDto creditCardDto1 = new CreditCardDto();
        creditCardDto1.setBlkInd("02");
        creditCardDto1.setFranchise("Visa");
        creditCardDto1.setProd("53");
        creditCardDto1.setCardType("Visa");
        creditCardDto1.setExpDt("1114");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardImgName("in-manhattan-platinum");
        creditCardDto1.setIsPrimary("Y");
        creditCardDto1.setCustomerId("01070565A0SH04005");
        creditCardDto1.setVariant("200");
        creditCardDto1.setCustShortName("INORR57");
        creditCardDto1.setCurrencyCode("INR");
        creditCardDto1.setDesc("Credit Card");
        creditCardDto1.setStatus("2");
        creditCardDto1.setBlockCode("C");
        creditCardDto1.setCustBlockCode("C");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardStatus("4");
        creditCardDto1.setAvlblLimit("34500.50");
        creditCardDto1.setCreditLimit("34500.50");
        creditCardDto1.setCurrentBalance("0.00");
        creditCardDtoList.add(creditCardDto1);

        CreditCardDto creditCardDto2 = new CreditCardDto();
        creditCardDto2.setBlkInd("02");
        creditCardDto2.setFranchise("Visa");
        creditCardDto2.setProd("53");
        creditCardDto2.setCardType("Visa");
        creditCardDto2.setExpDt("1114");
        creditCardDto2.setCardNum("4129057530874005");
        creditCardDto2.setCardImgName("in-manhattan-platinum");
        creditCardDto2.setIsPrimary("Y");
        creditCardDto2.setCustomerId("01070565A0SH04005");
        creditCardDto2.setVariant("200");
        creditCardDto2.setCustShortName("INORR57");
        creditCardDto2.setCurrencyCode("INR");
        creditCardDto2.setDesc("Credit Card");
        creditCardDto2.setStatus("2");
        creditCardDto2.setBlockCode("C");
        creditCardDto2.setCustBlockCode("C");
        creditCardDto2.setCardNum("4129057530874005");
        creditCardDto2.setCardStatus("4");
        creditCardDto2.setAvlblLimit("34500.50");
        creditCardDto2.setCreditLimit("40000.50");
        creditCardDto2.setCurrentBalance("1000.00");
        creditCardDto2.setDelinquencyAmount("12000.65");
        creditCardDtoList.add(creditCardDto2);

        return creditCardDtoList;
    }

    private List<CreditCardDto> constructInEligibleCreditCardDtoListMY(List<CreditCardDto> creditCardDtoList) {
        creditCardDtoList = new ArrayList<CreditCardDto>();

        CreditCardDto creditCardDto1 = new CreditCardDto();
        creditCardDto1.setBlkInd("02");
        creditCardDto1.setFranchise("Visa");
        creditCardDto1.setProd("53");
        creditCardDto1.setCardType("Visa");
        creditCardDto1.setExpDt("1114");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardImgName("in-manhattan-platinum");
        creditCardDto1.setIsPrimary("Y");
        creditCardDto1.setCustomerId("01070565A0SH04005");
        creditCardDto1.setVariant("200");
        creditCardDto1.setCustShortName("INORR57");
        creditCardDto1.setCurrencyCode("MYR");
        creditCardDto1.setDesc("Credit Card");
        creditCardDto1.setStatus("2");
        creditCardDto1.setBlockCode("E");
        creditCardDto1.setCustBlockCode("E");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardStatus("4");
        creditCardDto1.setAvlblLimit("34500.50");
        creditCardDto1.setCreditLimit("34498.50");
        creditCardDto1.setCurrentBalance("0.00");
        creditCardDtoList.add(creditCardDto1);

        return creditCardDtoList;
    }

    private List<CreditCardDto> constructEligibleCreditCardDtoList(List<CreditCardDto> creditCardDtoList) {
        creditCardDtoList = new ArrayList<CreditCardDto>();

        CreditCardDto creditCardDto1 = new CreditCardDto();
        creditCardDto1.setBlkInd("02");
        creditCardDto1.setFranchise("Visa");
        creditCardDto1.setProd("53");
        creditCardDto1.setCardType("Visa");
        creditCardDto1.setExpDt("1114");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardImgName("in-manhattan-platinum");
        creditCardDto1.setIsPrimary("Y");
        creditCardDto1.setCustomerId("01070565A0SH04005");
        creditCardDto1.setVariant("200");
        creditCardDto1.setCustShortName("INORR57");
        creditCardDto1.setCurrencyCode("INR");
        creditCardDto1.setDesc("Credit Card");
        creditCardDto1.setStatus("2");
        creditCardDto1.setBlockCode("A");
        creditCardDto1.setCustBlockCode("A");
        creditCardDto1.setCardNum("4129057530874005");
        creditCardDto1.setCardStatus("4");
        creditCardDto1.setAvlblLimit("34500.50");
        creditCardDto1.setCreditLimit("25000.00");
        creditCardDto1.setCurrentBalance("25000.00");
        creditCardDtoList.add(creditCardDto1);

        CreditCardDto creditCardDto2 = new CreditCardDto();
        creditCardDto2.setBlkInd("02");
        creditCardDto2.setFranchise("Visa");
        creditCardDto2.setProd("53");
        creditCardDto2.setCardType("Visa");
        creditCardDto2.setExpDt("1114");
        creditCardDto2.setCardNum("4129057530874005");
        creditCardDto2.setCardImgName("in-manhattan-platinum");
        creditCardDto2.setIsPrimary("Y");
        creditCardDto2.setCustomerId("01070565A0SH04005");
        creditCardDto2.setVariant("200");
        creditCardDto2.setCustShortName("INORR57");
        creditCardDto2.setCurrencyCode("INR");
        creditCardDto2.setDesc("Credit Card");
        creditCardDto2.setStatus("2");
        creditCardDto2.setBlockCode("A");
        creditCardDto2.setCustBlockCode("A");
        creditCardDto2.setCardNum("4129057530874005");
        creditCardDto2.setCardStatus("4");
        creditCardDto2.setAvlblLimit("34500.50");
        creditCardDto2.setCreditLimit("25000.00");
        creditCardDto2.setCurrentBalance("25000.00");
        creditCardDto2.setDelinquencyAmount("12000.65");
        creditCardDtoList.add(creditCardDto2);

        CreditCardDto creditCardDto3 = new CreditCardDto();
        creditCardDto3.setBlkInd("02");
        creditCardDto3.setFranchise("Visa");
        creditCardDto3.setProd("53");
        creditCardDto3.setCardType("Visa");
        creditCardDto3.setExpDt("1114");
        creditCardDto3.setCardNum("4129057530874005");
        creditCardDto3.setCardImgName("in-manhattan-platinum");
        creditCardDto3.setIsPrimary("Y");
        creditCardDto3.setCustomerId("01070565A0SH04005");
        creditCardDto3.setVariant("200");
        creditCardDto3.setCustShortName("INORR57");
        creditCardDto3.setCurrencyCode("INR");
        creditCardDto3.setDesc("Credit Card");
        creditCardDto3.setStatus("2");
        creditCardDto3.setBlockCode("A");
        creditCardDto3.setCustBlockCode("A");
        creditCardDto3.setCardNum("4129057530874005");
        creditCardDto3.setCardStatus("4");
        creditCardDto3.setAvlblLimit("25000.00");
        creditCardDto3.setCreditLimit("34500.50");
        creditCardDto3.setCurrentBalance("25000.00");
        creditCardDtoList.add(creditCardDto3);

        return creditCardDtoList;
    }
}
