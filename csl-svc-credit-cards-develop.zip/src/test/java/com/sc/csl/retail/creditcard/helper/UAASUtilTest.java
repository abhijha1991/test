package com.sc.csl.retail.creditcard.helper;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CardInfo;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.post.OtpInfo;
import com.sc.csl.retail.creditcard.dto.post.PinChangeDto;
import com.sc.csl.retail.creditcard.dto.security.UAASOtpInfo;
import com.sc.csl.retail.creditcard.dto.security.UAASTransactionInfo;

public class UAASUtilTest {

    @Mock
    private CSLRequestContext cslRequestContext;
       
    @Mock
    PinChangeDto pinChangeDto;
    
    @InjectMocks
    private UAASUtil uaasUtil;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getTxnInfo()  {
    	UAASTransactionInfo txtInfo = uaasUtil.setTransactionInfo("AE");
        assertNotNull(txtInfo);
    }

    @Test
    public void getOtpInfo() {
    	PinChangeDto pinChangeDto =new PinChangeDto();
    	OtpInfo otpInfo= new OtpInfo();    	
    	otpInfo.setOtpSn("1269");
    	otpInfo.setEncOtp("fF/0UjZGNfTfF+vLf9oVWy4jBLmbzznD0Q10IL5Fj0Wnu0BuSyabCF0er2+uSOhE8dY/GtvYH9d9faAHkQH3TOwYJYP2X+Mi2l//NmY/WkoND5OR6MlsD3sXJ6fDimSNzLzZs6NrEOZrMyEdFzYEb/ezXWp64LmwRMaCHHgDwOo72Prji/q3seUFNxtEjgEpDAo2MX+pxNsbSGiK1S/0f6KCG6xDd/F0BBrXY88yRghYMeMJcnLTjJ0XmmI3wu/VBW0N/OpB7s3XQLAbJGvTD/Z2NVtYM1mbwbvopffUgBIoDgPbzR/SjoKucGA09EEej+Rstf8ptq/Tnevqdtj/gg==");
    	otpInfo.setKeyIndex("3");
    	pinChangeDto.setOtpInfo(otpInfo);
    	UAASOtpInfo str = uaasUtil.setUAASOtpInfo(pinChangeDto);
        assertNotNull(str);
    }
    
    @Test
    public void getCardInfo() {
    	CreditCardDto creditCardDto = new CreditCardDto();
    	PinChangeDto pinChangeDto= new PinChangeDto();
    	pinChangeDto.setEncCardInfo("anV13iQlhMyAL9jcJd0HFutnTS3m/GNIXUqQxo4pjjeRNypQw0UdTcnzry+6TWGQKGqpMbMX71nUvAt7GsDEDZ0GyZwVzZgB3SqdhZ20BasJpKwbnrbkRMwZJIsehT2wOvqtRAIBNGobcXaJz/P6BOR5wbInpWYAOaAEOxkEJJgcx+0JQFxQGRn3gEzlfse7swjLBdnsqqocKRDM4FEHDPFr2WeA8+DTfXNBNz1v6tJQ3ZAtLQpToehq/n86yIxDg4C/9Q3ENlmTwfkMf3+MK8N+pTJOHN0mPcbj5t52mGiHDEBXG5o62Lo12NwCbZoRnrcB4k3M6JhRu6P4Gb4vzA==");
    	pinChangeDto.setEncCardPin("anV13iQlhMyAL9jcJd0HFutnTS3m/GNIXUqQxo4pjjeRNypQw0UdTcnzry+6TWGQKGqpMbMX71nUvAt7GsDEDZ0GyZwVzZgB3SqdhZ20BasJpKwbnrbkRMwZJIsehT2wOvqtRAIBNGobcXaJz/P6BOR5wbInpWYAOaAEOxkEJJgcx+0JQFxQGRn3gEzlfse7swjLBdnsqqocKRDM4FEHDPFr2WeA8+DTfXNBNz1v6tJQ3ZAtLQpToehq/n86yIxDg4C/9Q3ENlmTwfkMf3+MK8N+pTJOHN0mPcbj5t52mGiHDEBXG5o62Lo12NwCbZoRnrcB4k3M6JhRu6P4Gb4vzA==");
    	pinChangeDto.setPinKeyIndex("3");
    	creditCardDto.setPinChangeDto(pinChangeDto);
    	creditCardDto.setSeqNo("002");
    	creditCardDto.setCardType("CREDIT");
    	CardInfo str = uaasUtil.setCardInfo(creditCardDto, "AE");
        assertNotNull(str);
    }
    
    @Test
    public void getTransactionRefNumber() {
    	String str = uaasUtil.getTransactionRefNumber("AE");
        assertNotNull(str);
    }
    
    
}