package com.sc.csl.retail.creditcard.gateway.csl;

import com.sc.csl.retail.core.gateway.CSLJsonApiGateway;
import com.sc.csl.retail.core.katharsis.CSLKatharsisClient;
import com.sc.csl.retail.creditcard.dto.DebitCardDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.repository.ResourceRepositoryV2;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.lang.reflect.Method;

/**
 * Created by 1572681 on 9/5/2017.
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(CSLJsonApiGateway.class)
public class DebitCardsV3CSLGatewayTest {

  //  protected ResourceRepositoryV2<Task, Long> taskRepo;

    @InjectMocks
    DebitCardsV3CSLGateway debitCardsV3CSLGateway;

    @Mock
    CSLJsonApiGateway cSLJsonApiGateway;

    @Before
    public void setUp(){
        debitCardsV3CSLGateway = Mockito.mock(DebitCardsV3CSLGateway.class, Mockito.CALLS_REAL_METHODS);
        debitCardsV3CSLGateway.setBaseUrl("http://10.23.210.50:9082");
        debitCardsV3CSLGateway.setServiceUrl("/retail/csl/v3/");
        debitCardsV3CSLGateway.setScbInternal(true);
        debitCardsV3CSLGateway.setTimeout(20000L);

        cSLJsonApiGateway = Mockito.mock(CSLJsonApiGateway.class, Mockito.CALLS_REAL_METHODS);
        MockitoAnnotations.initMocks(this);
    }

    @Test(expected = Exception.class)
    public void should_Return_Exception_When_getCardDetails_Called_With_Connection_Error() throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");


        Method method = debitCardsV3CSLGateway.getClass().getDeclaredMethod("getKatharsisClient");
        method.setAccessible(true);
        Object r = method.invoke(debitCardsV3CSLGateway);
        CSLKatharsisClient katharsisClient = (CSLKatharsisClient)r;
        ResourceRepositoryV2<DebitCardDto, String> custRepo = katharsisClient.getRepositoryForType(DebitCardDto.class);
        //katharsisClient.set

        debitCardsV3CSLGateway.getCardDetails(creditCardVO);
    }

    @Test(expected = Exception.class)
    public void should_Return_DebitCardDto_getAsyncComboCardDetails_When_Called(){

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");

        debitCardsV3CSLGateway.getAsyncComboCardDetails(creditCardVO);
    }

}