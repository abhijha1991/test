package com.sc.csl.retail.creditcard.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.powermock.api.mockito.PowerMockito;

import com.sc.csl.retail.core.web.CSLAsyncRequestContext;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CardActivationValidationProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.post.CardActivationDto;
import com.sc.csl.retail.creditcard.dto.post.OtpInfo;
import com.sc.csl.retail.creditcard.dto.security.SmsOtp;
import com.sc.csl.retail.creditcard.dto.security.ValidateOtp;
import com.sc.csl.retail.creditcard.gateway.csl.SmsOtpGateway;
import com.sc.csl.retail.creditcard.gateway.csl.ValidateOtpGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.validator.CreditCardValidator;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class CardActivaionServiceTest {

    @InjectMocks
    private CardActivationService creditCardActivation;

    @Mock
    private CreditCardValidator creditCardValidator;

    @Mock
    private CreditCardV1SoapGateway creditCardV1SoapGateway;
   
    @Mock
    private SmsOtpGateway smsOtpGateway;
    
    @Mock
    private ValidateOtpGateway validateOtpGateway;
    
    @Mock
    private CSLAsyncRequestContext cslAsyncRequestContext;
    
    @Mock
    private CSLRequestContext mockCSLRequestContext;
    
    @Spy
    Map<String, CreditCardProperties> creditCardProperties = new HashMap<>();
    
    @Mock
    private CardActivationProcessingService postProcessingService;
    
    @Mock
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;


    
    @Mock
    CardUtil cardUtil;
   
    @Before
    public void setUp() {

    	creditCardV1SoapGateway = PowerMockito.mock(CreditCardV1SoapGateway.class, Mockito.CALLS_REAL_METHODS);

        creditCardValidator = PowerMockito.mock(CreditCardValidator.class, Mockito.CALLS_REAL_METHODS);

        MockitoAnnotations.initMocks(this);

    }
 
    @Test(expected=Exception.class)
    public void testActivateCardWithout2FA() {
    	CreditCardDto creditCardDto = manualBuildDtoObjectForActivation();
    	String contactNo="+60103913403";
		String messageTemplate = "Authentication {otp}";
		SmsOtp smsOtp=new SmsOtp();
		  SmsOtp smsOtpResponse = new SmsOtp();
	        smsOtpResponse.setBase64Challenge("MTUwNDYwOTAxOTc3M18tX0lCS18tX0hLXy1fMDFDMzAzMzYwXy1faWlCbHVRQUtfLV9uUGhndGNNL1BQNjFSdGNrd1prU2hvSHcwTUhjck9DUXNTZ2p6VVZkMDBzPQ==");
	        smsOtpResponse.setModulus("b6b44e815345da9297e595cc88bd6ba7ac5fe4d08bb7aa795951b71b093ad0e0bde4b638570ca038ba0d73222c62286c6a926793f88ae411280c3b92ac5c79d2c142d4a600a376420e101a31936697c2adb56ee0e96be21320eacfefe7f97fd5ad0e59bbf1ff75efa2ae50b6fdb3acd46e89fd993efe4fbf775a071c19d9d694c6f97a47fdd64df0b87338aa839db9b4d5cc907de7c409c5fd7db5921123081b766f795afcb70a7fce5b953a9c4b557b5cebed277cec522fe752c09706d571ebb6620ebdece8c6cd66fc146f562dc5b674cba1361afc6bbe2f050558071b691a0e67e6e57bc9abb8ee64971c23ef14302ab27643fcfad50e123af630c9bc77d9");
	        smsOtpResponse.setKeyIndex("3");
	        smsOtpResponse.setStatusCode("100");
	        smsOtpResponse.setOtpSn("89");
	        smsOtpResponse.setOtpPrefix("uXvd");
	        smsOtpResponse.setExponent("10001");
        when(smsOtpGateway.sendOtp(contactNo, messageTemplate)).thenReturn(smsOtp);
    	when(creditCardV1SoapGateway.getDecryptedCardNumber(creditCardDto)).thenReturn("4129057530874005");
    	CreditCardDto resultDto=creditCardActivation.activateCard(creditCardDto);
    	assertNotNull(resultDto);
    }   
    
    
    @Test
    public void testActivateCardWith2FA() {
    	CreditCardDto creditCardDto = manualBuildDtoObjectForActivation();
    	OtpInfo otpInfo=new OtpInfo();
    	otpInfo.setEncOtp("EncryptedOTP");
    	otpInfo.setKeyIndex("10");
    	otpInfo.setOtpSn("3459");
    	otpInfo.setPurpose("1");
    	creditCardDto.getCardActivationDto().setOtpInfo(otpInfo);
    	String contactNo="+60103913403";
		String messageTemplate = "Authentication {otp}";
		SmsOtp smsOtp=new SmsOtp();
		SmsOtp smsOtpResponse = new SmsOtp();
        smsOtpResponse.setBase64Challenge("MTUwNDYwOTAxOTc3M18tX0lCS18tX0hLXy1fMDFDMzAzMzYwXy1faWlCbHVRQUtfLV9uUGhndGNNL1BQNjFSdGNrd1prU2hvSHcwTUhjck9DUXNTZ2p6VVZkMDBzPQ==");
        smsOtpResponse.setModulus("b6b44e815345da9297e595cc88bd6ba7ac5fe4d08bb7aa795951b71b093ad0e0bde4b638570ca038ba0d73222c62286c6a926793f88ae411280c3b92ac5c79d2c142d4a600a376420e101a31936697c2adb56ee0e96be21320eacfefe7f97fd5ad0e59bbf1ff75efa2ae50b6fdb3acd46e89fd993efe4fbf775a071c19d9d694c6f97a47fdd64df0b87338aa839db9b4d5cc907de7c409c5fd7db5921123081b766f795afcb70a7fce5b953a9c4b557b5cebed277cec522fe752c09706d571ebb6620ebdece8c6cd66fc146f562dc5b674cba1361afc6bbe2f050558071b691a0e67e6e57bc9abb8ee64971c23ef14302ab27643fcfad50e123af630c9bc77d9");
               
        smsOtpResponse.setKeyIndex("3");
        smsOtpResponse.setStatusCode("100");
        smsOtpResponse.setOtpSn("89");
        smsOtpResponse.setOtpPrefix("uXvd");
        smsOtpResponse.setExponent("10001");
	        
        ValidateOtp validateOtpResponse = new ValidateOtp();
        validateOtpResponse.setStatusCode("100");
        validateOtpResponse.setErrorMessage("");    
        when(mockCSLRequestContext.getRequestId()).thenReturn("01");
        when(mockCSLRequestContext.getRelId()).thenReturn("070565A0SH04005");
        when(mockCSLRequestContext.getLanguage()).thenReturn("ENGLISH");
        when(mockCSLRequestContext.getCountry()).thenReturn("IN");
        when(mockCSLRequestContext.getChannel()).thenReturn("WEB");
        when(smsOtpGateway.sendOtp(contactNo, messageTemplate)).thenReturn(smsOtp);
        when(validateOtpGateway.validateOtp(Mockito.any())).thenReturn(validateOtpResponse);
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        when(creditCardEnquiryV1SoapGateway.getCreditCard(Mockito.any())).thenReturn(creditCardDto);
        when(cardUtil.populateCreditCardVO(Mockito.any())).thenReturn(creditCardVO);
        when(creditCardV1SoapGateway.updateCardStatus(Mockito.any())).thenReturn(creditCardVO);
       	when(creditCardV1SoapGateway.getDecryptedCardNumber(creditCardDto)).thenReturn("4129057530874005");
       	CreditCardProperties creditCardProperties = new CreditCardProperties();
        CardActivationValidationProperties creditCardActivationProps = new CardActivationValidationProperties();
        List<String> allowedBinList = new ArrayList<>();
       
        allowedBinList.add("412905");        
        
        creditCardActivationProps.setAllowedBin(allowedBinList);
        creditCardProperties.setCreditCardActivationProps(creditCardActivationProps);
        
        when(cardUtil.getCreditCardPropertiesBean(Mockito.any())).thenReturn(creditCardProperties);
       	
       	
    	CreditCardDto resultDto=creditCardActivation.activateCard(creditCardDto);
    	assertNotNull(resultDto);    
    }   
     private CreditCardDto manualBuildDtoObjectForActivation(){
    	CreditCardDto creditCardDto=new CreditCardDto();
        creditCardDto.setCardNum("4129057530874005");
        creditCardDto.setCountry("MY");
        creditCardDto.setCountryCode("MY");
        creditCardDto.setEmbossedName("CARD HOLDER NAME");
        creditCardDto.setOperationName("CCACTV");
        creditCardDto.setLanguage(CardConstant.ENG_LANG_CODE);
        creditCardDto.setRelId("MY001057207");
        
        CardActivationDto cardActivcationDto=new CardActivationDto();
        cardActivcationDto.setCountry("MY");
        cardActivcationDto.setKeyIndex("10");
        cardActivcationDto.setEncData("EncryptedData");
        cardActivcationDto.setCountry("MY");
        creditCardDto.setCardActivationDto(cardActivcationDto);

        return creditCardDto;
    }
}