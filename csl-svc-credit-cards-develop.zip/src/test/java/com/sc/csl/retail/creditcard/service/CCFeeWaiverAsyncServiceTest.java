package com.sc.csl.retail.creditcard.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;

import com.sc.csl.retail.creditcard.config.properties.CreditCardFeeWaiverProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dao.impl.CreditCardEligibilityCriteriaDaoImpl;
import com.sc.csl.retail.creditcard.dao.impl.CreditCardTransactionEDMPDaoImpl;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.helper.EncryptionDecryptionHelper;
import com.sc.csl.retail.creditcard.helper.ReconcileTransaction;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class CCFeeWaiverAsyncServiceTest {

	@InjectMocks
	private CCFeeWaiverAsyncService ccFeeWaiverAsyncService;
	
	@Mock
	private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
	
	@Mock
	private CardUtil cardUtil;
	
	@Mock
	private CreditCardTransactionEDMPDaoImpl transDao;
	
	@Mock
	private CreditCardEligibilityCriteriaDaoImpl eligibilityDao;
	
	@Mock
	private ReconcileTransaction reconcileTransaction;
	
	@Mock
	private EncryptionDecryptionHelper encryptDecryptHelper;
	
	@Mock
	private CreditCardService creditCardService;
	
	@Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }
	
	@Test(expected=NullPointerException.class)
	public void getCreditCardTransactionList_HK() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		CreditCardVO ccVo=new CreditCardVO();
		ccVo.setCountryCode("HK");
		ccVo.setRelId("51437658");
		ccVo.setActiveCards("Yes");
		
		CreditCardProperties credtProps=new CreditCardProperties();
		CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
		props.setBlockCode("A");
		props.setActiveStatusCode("0,1,2");
		credtProps.setCreditCardFeeWaiverProps(props);
		
		Map<String, Object> journeyMap = new HashMap<String, Object>();
		List<CreditCardTransactionDto> ccmsC400Transactions= new ArrayList<CreditCardTransactionDto>();
		CreditCardTransactionDto creditCardListingDto = new CreditCardTransactionDto();
		ccmsC400Transactions.add(creditCardListingDto);
		journeyMap.put(CardConstant.UNPROCESSED_CREDIT_TRANC, ccmsC400Transactions);
		
		CreditCardFeeWaiverService creditCardFeeWaiverService = new CreditCardFeeWaiverService();
		Field field = ccFeeWaiverAsyncService.getClass().getDeclaredField("creditCardFeeWaiverService");
        field.setAccessible(true);
        field.set(ccFeeWaiverAsyncService, creditCardFeeWaiverService);
		
		CreditCardDto obj2=new CreditCardDto();
		obj2.setBlockCode("A");
		obj2.setCardNum("8327984273");
		obj2.setCardNum("0");
		//when(creditCardFeeWaiverService.getCardMaskRequiredStatus(any(String.class))).thenReturn("");
		when(creditCardEnquiryV1SoapGateway.getCreditCard(ccVo)).thenReturn(obj2);
		when(cardUtil.getCreditCardPropertiesBean(any(String.class))).thenReturn(credtProps);
		doNothing().when(transDao).getTxnRefreshdate(new HashMap(), props);
		doNothing().when(eligibilityDao).getEligibilityRefreshdate(new HashMap(), props);
		when(encryptDecryptHelper
				.performEncryptDecrypt(6,4,obj2.getCardNum(),
						CardConstant.ENCRYPT,
						ccVo.getCustomerId())).thenReturn("XXXXXX");
		ccFeeWaiverAsyncService.getCreditCardTransactionList(ccVo, null,
				null,null,null,"");
	}
	
	@Test(expected=NullPointerException.class)
    public void findAllCreditCard_HK() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
    	CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCustomerId("01R70000023");
        List<CreditCardDto> creditcardDtolist = new ArrayList<>();
        CreditCardDto obj2=new CreditCardDto();
		obj2.setBlockCode("A");
		obj2.setCardNum("8327984273");
		obj2.setCardNum("0");
		obj2.setCardStatus("7");
		creditcardDtolist.add(obj2);
		
		CreditCardProperties credtProps=new CreditCardProperties();
		CreditCardFeeWaiverProperties props= new CreditCardFeeWaiverProperties();
		props.setBlockCode("A");
		props.setActiveStatusCode("0,1,2");
		credtProps.setCreditCardFeeWaiverProps(props);
        
		CreditCardFeeWaiverService creditCardFeeWaiverService = new CreditCardFeeWaiverService();
		Field field = ccFeeWaiverAsyncService.getClass().getDeclaredField("creditCardFeeWaiverService");
        field.setAccessible(true);
        field.set(ccFeeWaiverAsyncService, creditCardFeeWaiverService);
        
        when(creditCardService.findAllCreditCard(creditCardVO)).thenReturn(creditcardDtolist);
        when(cardUtil.getCreditCardPropertiesBean()).thenReturn(credtProps);
        ccFeeWaiverAsyncService.findAllCreditCard(creditCardVO);
    }
}
