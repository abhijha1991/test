package com.sc.csl.retail.creditcard.helper;

import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.dao.CreditCardRepositoryDao;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.EligibleInstallmentDto;
import com.sc.csl.retail.creditcard.dto.SRParamDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import io.katharsis.queryspec.FilterOperator;
import io.katharsis.queryspec.FilterSpec;
import io.katharsis.queryspec.QuerySpec;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.util.*;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(PowerMockRunner.class)
@PrepareForTest(GregorianCalendar.class)
public class CardUtilTest {

    @InjectMocks
    private CardUtil cardUtil;

    @Mock
    private CSLRequestContext cslRequestContext;

    @Mock
    QuerySpec querySpec;

    @Mock
    FilterSpec filterSpec;

    @Mock
    CreditCardRepositoryDao creditCardRepositoryDao;

    @Mock
    CreditCardRepositoryDao ccDao;

    @Before
    public void setUp() {
        cslRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        MockitoAnnotations.initMocks(this);

    }


    @Test
    public void shouldReturn_false_when_isEmptyOrNull_method_called_withObject() throws Exception {
        boolean str = cardUtil.isEmptyOrNull("val");
        assertNotNull(str);
        assertEquals(false,str);
    }

    @Test
    public void shouldReturn_false_when_isEmptyOrNull_method_called_withObjectArray() throws Exception {
        Object[] value={};
        boolean str = cardUtil.isEmptyOrNull(value);
        assertNotNull(str);
        assertEquals(false,str);
    }

    @Test
    public void shouldReturn_true_when_isEmptyOrNull_method_called_withMapObject() throws Exception {
        Map<String,String> value=null;
        boolean str = cardUtil.isEmptyOrNull(value);
        assertNotNull(str);
        assertEquals(true,str);
    }

    @Test
    public void shouldReturn_true_when_isEmptyOrNull3_method_called_withListObject() throws Exception {
        List<String> value=null;
        boolean str = cardUtil.isEmptyOrNull(value);
        assertNotNull(str);
        assertEquals(true,str);
    }

    @Test
    public void shouldReturn_Value_getValueByKey_method_called_withValidKey() throws Exception {
        Map<String,String> value=new HashMap<>();
        value.put("key","value");
        Object str = cardUtil.getValueByKey(value,"key");
        assertNotNull(str);
        assertEquals("value",str);
    }

    @Test
    public void shouldReturn_true_when_isRegexMatch_method_called_withValidInput() throws Exception {
        boolean str = cardUtil.isRegexMatch("regex","input");
        assertNotNull(str);
        assertEquals(true,str);
    }

    @Test
    public void shouldReturn_ProductCode_when_getProductCode_method_called() throws Exception {
        String str = cardUtil.getProductCode("product");
        assertNotNull(str);
        assertEquals("product",str);
    }

    @Test
    public void shouldReturn_ProductCode_when_getProductCode_method_called_withEmptyProductCode() throws Exception {
        String str = cardUtil.getProductCode("");
        assertNotNull(str);
        assertEquals("000",str);
    }

    @Test
    public void shouldReturn_ProductCode_when_getProductCode_method_called_withProductCode_Lenght_LessThan_Three() throws Exception {
        String str = cardUtil.getProductCode("pr");
        assertNotNull(str);
        assertEquals("0pr",str);
    }

    @Test
    public void shouldReturn_ProductDescription_when_getProductDescription_method_called() throws Exception {
        Map<String, String> productCodeMap=new HashMap<>();
        productCodeMap.put("2345_450234","Primary");
        String str = cardUtil.getProductDescription("2345","4502344502344502","Y",productCodeMap, 6, productCodeMap, "IN");
        assertNotNull(str);
        assertEquals("Primary (P)",str);
    }

    @Test
    public void shouldReturn_ProductDescription_when_getProductDescription_method_called_With_Supplementory_CardType() throws Exception {
        Map<String, String> productCodeMap=new HashMap<>();
        productCodeMap.put("2345_450234","SUPPLEMENTARY");
        String str = cardUtil.getProductDescription("2345","4502344502344502","S",productCodeMap, 6,productCodeMap, "IN");
        assertNotNull(str);
        assertEquals("SUPPLEMENTARY (S)",str);
    }

    @Test
    public void shouldReturn_ProductDescription_when_getProductDescription_method_called_With_Different_ProductCode() throws Exception {
        Map<String, String> productCodeMap=new HashMap<>();
        productCodeMap.put("234512_450234","SUPPLEMENTARY");
        productCodeMap.put("Visa","W:4");
        String str = cardUtil.getProductDescription("2345","4502344502344502","S",productCodeMap, 6, productCodeMap, "IN");
        assertNotNull(str);
        assertEquals("Visa Credit Card (S)",str);
    }

    @Test
    public void shouldReturn_ProductImage_when_getProductImage_method_called() throws Exception {
        Map<String, String> productImageMap=new HashMap<>();
        productImageMap.put("2345_450234","Primary");
        String str = cardUtil.getProductImage("4502344502344502","2345",productImageMap, 6);
        assertNotNull(str);
        assertEquals("Primary",str);
    }

    @Test
    public void shouldReturn_ProductImage_when_getProductImage_method_called_With_CardImg_Empty() throws Exception {
        Map<String, String> productImageMap=new HashMap<>();
        productImageMap.put("2345123_450234","Primary");
        String str = cardUtil.getProductImage("4502344502344502","2345",productImageMap, 6);
        assertNotNull(str);
        assertEquals("",str);
    }

    @Test
    public void shouldReturn_CardBolckCode_when_getCardBlockCode_method_called() throws Exception {
        String str = cardUtil.getCardBlockCode("block");
        assertNotNull(str);
        assertEquals("block",str);
    }

    @Test
    public void shouldReturn_CardType_when_getCardType_method_called() throws Exception {
        Map<String, String> cardTypes=new HashMap<>();
        cardTypes.put("Visa","W:4");
        cardTypes.put("Visa_Exclude_StartWith","412903488,4940");
        String str = cardUtil.getCardType("4940057530874005",cardTypes);
        assertNotNull(str);
        assertEquals("",str);
    }

    @Test
    public void shouldReturn_CardBlockCodeIndicator_when_getCardBlockCodeIndicator_method_called() throws Exception {
        Map<String, String> blockInds=new HashMap<>();
        blockInds.put("01","W:E");
        String str = cardUtil.getCardBlockCodeIndicator("01",blockInds);
        assertNotNull(str);
        assertEquals("",str);
    }

    @Test
    public void shouldReturn_CardBlockCodeIndicator_when_getCardBlockCodeIndicator_method_called_WithEmpty_BlockCode() throws Exception {
        Map<String, String> blockInds=new HashMap<>();
        blockInds.put("01","W:E");
        String str = cardUtil.getCardBlockCodeIndicator("",blockInds);
        assertNotNull(str);
        assertEquals("",str);
    }

    @Test
    public void shouldReturn_CardStatus_when_getCardStatus_method_called() throws Exception {
        Map<String, String> cardStatusMap=new HashMap<>();
        cardStatusMap.put("Active","W:0|1");
        String str = cardUtil.setCardStatus("Active",cardStatusMap);
        assertNotNull(str);
        assertEquals("",str);
    }

    @Test
    public void shouldReturn_Date_when_toGetXMLGregorianCalendar_method_called() throws Exception {
        XMLGregorianCalendar date= cardUtil.toGetXMLGregorianCalendar();
        assertNotNull(date);
    }

    @Test
    public void shouldReturn_CreditCardVO_when_populateCreditCardVO_method_called() throws Exception {

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        CreditCardVO creditCardVO= cardUtil.populateCreditCardVO(cSLRequestContext);
        assertNotNull(creditCardVO);
    }

    @Test
    public void shouldReturn_CardID_when_generateCardId_method_called() throws Exception {
        String str = cardUtil.generateCardId("IN","4129057530874005","4129057530874005");
        assertNotNull(str);

    }

    @Test
    public void shouldReturn_CardExpDateFlag_when_isCardExpired_method_called() throws Exception {
        String str = cardUtil.isCardExpired("ddMMyyyy","25072017");
        assertNotNull(str);
        assertEquals("Y",str);
    }

    @Test
    public void shouldReturn_CardExpDateFlag_when_isCardExpired_method_called_WithInvalidDate() throws Exception {
        String str = cardUtil.isCardExpired("ddMMyyyy","testdate");
        assertNotNull(str);
        assertEquals("N",str);
    }

    @Test
    public void shouldReturn_BlockCodeDateReplacementFlag_when_getBlockCodeDateReplacementPeriod_method_called() throws Exception {
        String str = cardUtil.getBlockCodeDateReplacementPeriod("blockcodes",2,"block",DatatypeFactory.newInstance().newXMLGregorianCalendar("25072017"));
        assertNotNull(str);
        assertEquals("Y",str);
    }

    @Test
    public void shouldReturn_CardReplacementTransferEffectiveDateFlag_when_getCardReplacementTransferEffectiveDate_method_called() throws Exception {
        CreditCardFilterProperties filterProperties = new CreditCardFilterProperties();
        String str = cardUtil.getCardReplacementTransferEffectiveDate(filterProperties,"block", DatatypeFactory.newInstance().newXMLGregorianCalendar("25072017"), "2014-03-12");
        assertNotNull(str);
        assertEquals("Y",str);
    }

    @Test
    public void shouldReturn_Empty_When_getPrimaryCardStatusForSupplCardStatus_Called_withEmpty_CardList() throws Exception{
        List<CreditCardDto> cardList = new ArrayList<>();
        Map<String, String> cardStatusMap = new HashMap<>();
        String str = cardUtil.getPrimaryCardStatusForSupplCardStatus("", cardList, cardStatusMap);
        assertNotNull(str);
        assertEquals("",CardConstant.PAD_EMPTY);
    }

    @Test
    public void shouldReturn_Active_When_getPrimaryCardStatusForSupplCardStatus_Called() throws Exception{
        List<CreditCardDto> cardList = new ArrayList<>();
        CreditCardDto creditCard = new CreditCardDto();
        creditCard.setCardID("4129057530874005");
        creditCard.setCardStatus("1");
        creditCard.setIsPrimary("Y");
        cardList.add(creditCard);

        Map<String, String> cardStatusMap=new HashMap<>();
        cardStatusMap.put("Active","W:0|1");
        //String str = cardUtil.setCardStatus("Active",cardStatusMap);

        String str = cardUtil.getPrimaryCardStatusForSupplCardStatus("4129", cardList, cardStatusMap);
        assertNotNull(str);
        assertEquals("Active",str);
    }

    @Test
    public void shouldReturn_Empty_When_getPrimaryCardStatusForSupplCardStatus_Called_WithInvalid_CardList() throws Exception{
        List<CreditCardDto> cardList = new ArrayList<>();
        CreditCardDto creditCard = new CreditCardDto();
        creditCard.setCardID("4122057530874005");
        creditCard.setCardStatus("");
        cardList.add(creditCard);

        Map<String, String> cardStatusMap=new HashMap<>();
        cardStatusMap.put("Active","W:0|1");

        String str = cardUtil.getPrimaryCardStatusForSupplCardStatus("Wbcd", cardList, cardStatusMap);
        assertNotNull(str);
        assertEquals("",str);
    }

    @Test
    public void shouldReturn_Empty_When_getStatementFlags_Called_WithEmpty_StatementFlag() throws Exception{
        Map<String, String> statementFlagsMap=new HashMap<>();
        statementFlagsMap.put("Active","W:0|1");
        String str = cardUtil.getStatementFlags("", statementFlagsMap);
        assertNotNull(str);
        assertEquals("",CardConstant.PAD_EMPTY);
    }

    @Test
    public void getStatementFlags() throws Exception{
        Map<String, String> statementFlagsMap=new HashMap<>();
        statementFlagsMap.put("Active","W:0|1");
        String str = cardUtil.getStatementFlags("1", statementFlagsMap);
        assertNotNull(str);
        assertEquals("Active",str);
    }

    @Test
    public void getISOCurrencyCode_WithEmpty_CurrencyCode() throws Exception{
        Map<String, String> currencyCodesMap=new HashMap<>();
        currencyCodesMap.put("248", "ALA");
        currencyCodesMap.put("008", "ALB");
        currencyCodesMap.put("012", "DZA");
        String str = cardUtil.getISOCurrencyCode("", currencyCodesMap);
        assertNotNull(str);
        assertEquals("",CardConstant.PAD_EMPTY);
    }

    @Test
    public void getISOCurrencyCode() throws Exception{
        Map<String, String> currencyCodesMap=new HashMap<>();
        currencyCodesMap.put("248", "ALA");
        currencyCodesMap.put("008", "ALB");
        currencyCodesMap.put("012", "DZA");
        String str = cardUtil.getISOCurrencyCode("248", currencyCodesMap);
        assertNotNull(str);
        assertEquals("ALA",str);
    }

    @Test
    public void getAltBlockCodeFlags_withEmpty_AllowedAltBlockCodes() throws Exception{
        String str = cardUtil.getAltBlockCodeFlags("", "", "","");
        assertNotNull(str);
        assertEquals("",CardConstant.PAD_EMPTY);
    }

    @Test
    public void getAltBlockCodeFlags() throws Exception{
        String str = cardUtil.getAltBlockCodeFlags("00", "00", "00","");
        assertNotNull(str);
        assertEquals("N",CardConstant.CONS_N);
    }

    @Test
    public void getAltBlockCodeFlags_With_Allowed_Block_Codes() throws Exception{
        String str = cardUtil.getAltBlockCodeFlags("00", "W0", "00","");
        assertNotNull(str);
        assertEquals("N",CardConstant.CONS_N);
    }

    @Test
    public void getCardVariant_With_Empty_CardOrg() throws Exception{
        String str = cardUtil.getCardVariant("");
        assertNotNull(str);
        assertEquals("000",CardConstant.PRODUCT_CODE_DEFAULT);
    }

    @Test
    public void getCardVariant_With_CardOrg() throws Exception{
        String str = cardUtil.getCardVariant("00");
        assertNotNull(str);
        assertEquals("000",CardConstant.PRODUCT_CODE_DEFAULT);
    }

    @Test
    public void getAgreementStatusIndicator() throws Exception{
        Map<String, String> agmtStsInds=new HashMap<String, String>();
        agmtStsInds.put("1","h");
        String str = cardUtil.getAgreementStatusIndicator(BigInteger.valueOf(1L),agmtStsInds);
        assertNotNull(str);
    }

    @Test
    public void setGatewayProperties () throws Exception{
        cardUtil.setGatewayProperties(new CreditCardVO());
    }

    @Test
    public void getCurrentDateTime () throws Exception{
        cardUtil.getCurrentDateTime();
    }

    @Test
    public void populateCreditCardDTO () throws Exception{
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        CreditCardDto  creditCardDto = cardUtil.populateCreditCardDTO(cSLRequestContext,new CreditCardDto());
        assertNotNull(creditCardDto);
    }

    @Test
    public void populateQuerySpec() throws Exception{

        cardUtil.populateQuerySpec(null,new CreditCardVO());
        cardUtil.populateQuerySpec(querySpec,null);

        querySpec=new QuerySpec(CardUtil.class);

        List<FilterSpec> filterList=new ArrayList<FilterSpec>();
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_ACTIVE_CARDS));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_FEE_TYPE));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_SR_NAME));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_CARD_NO));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_ELIGIBLE_FOR_CREDIT_BAL_REFUND));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_REQUEST_TYPE));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_ORG_NUM));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_CARD_NO));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FUNCTION_CD));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.TXN_TYPE));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ,CardConstant.FILTER_ELIGIBLE_FEEWAIVER));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_CD_OPERATION_NAME));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, "otpRequired"));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ, CardConstant.FILTER_FUN_CODE));
        filterList.add(new FilterSpec(Arrays.asList("filterAttr"), FilterOperator.EQ,   CardConstant.SEQ_NO));


        querySpec.getFilters().addAll(filterList);

        cardUtil.populateQuerySpec(querySpec,new CreditCardVO());

    }

    @Test(expected = Exception.class)
    public void getCreditCardPropertiesBean() throws Exception{
        cardUtil.getCreditCardPropertiesBean();
        when(cslRequestContext.getCountry()).thenReturn("IN");
        cardUtil.getCreditCardPropertiesBean();

    }

    @Test
    public void loadSrParamByObject() throws Exception{

        SRParamDto param=new SRParamDto();
        param.setParamKey1("ParamKey1");
        param.setParamKey2("ParamKey2");
        param.setParamKey3("ParamKey3");

        param.setParamKey4("ParamKey4");
        param.setParamKey5("ParamKey5");
        param.setParamKey6("ParamKey6");
        param.setParamKey7("ParamKey7");
        param.setParamKey8("ParamKey8");
        param.setParamKey9("ParamKey9");
        param.setParamKey10("ParamKey10");


        cardUtil.loadSrParamByObject(param,creditCardRepositoryDao);
    }

    @Test
    public void formatDate() throws Exception{

        cardUtil.formatDate("dd/mm/yyyy","10/30/2017");
        cardUtil.formatDate("ddmm/yyyy","10/30/2017");
    }

    @Test(expected = TechnicalException.class)
    public void parseDate() throws Exception{
        cardUtil.parseDate("","");
        cardUtil.parseDate("dd/mm/yyyy","10/30/2017");
        cardUtil.parseDate("ddmm/yyyy","10/30/2017");
    }

    @Test
    public void isValueInList(){
        cardUtil.isValueInList("","",true);
        cardUtil.isValueInList("ss","",true);
    }

    @Test
    public void isValueInList2(){
        cardUtil.isValueInList("ss","s");
    }

    @Test
    public void formatMessage(){
        cardUtil.formatMessage("ss",new String[1]);
    }

    @Test
    public void converDateToString() throws Exception{
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date());
        XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH)+1, cal.get(Calendar.DAY_OF_MONTH), DatatypeConstants.FIELD_UNDEFINED);

        cardUtil.converDateToString(xmlDate);
    }

    @Test
    public void formatStringDate() throws Exception{
        cardUtil.formatStringDate("10/30/2017","dd/mm/yyyy","mm/dd/yyyy");
        cardUtil.formatStringDate("1030/2017","dd/mm/yyyy","mm/dd/yyyy");
    }

    @Test
    public void setEligibleGatewayProperties() throws Exception{
        cardUtil.setEligibleGatewayProperties(new EligibleInstallmentDto());
    }

    @Test
    public void getProductImage() throws Exception{
        Map<String, String> productImageMap=new HashMap<>();
        productImageMap.put("123","123");
        cardUtil.getProductImage("11111","123",productImageMap,3);
    }




    @Test
    public void formatDate2() throws Exception{
        cardUtil.formatDate(new Date(),"dd/mm/yyyy");
    }

    @Test
    public void getCardRplStatusInd() throws Exception{
        cardUtil.getCardRplStatusInd("sts","td","W","W");
    }

    @Test
    public void getCardRplC400Ind_With_CardConstant_CONS_Y() throws Exception{

        List<CreditCardDto> cardList=new ArrayList<>();
        CreditCardDto creditCardDto=new CreditCardDto();
        cardList.add(creditCardDto);
        CreditCardFilterProperties filterProps=new CreditCardFilterProperties();
        filterProps.setCardRplIndActPrimaryStopReasonCodes("1222");
        cardUtil.getCardRplC400Ind("1111","12343",BigInteger.valueOf(123L),CardConstant.CONS_Y,cardList,"vv",filterProps);
    }

    @Test
    public void getCardRplC400Ind_With_CardConstant() throws Exception{

        List<CreditCardDto> cardList=new ArrayList<>();
        CreditCardDto creditCardDto=new CreditCardDto();
        cardList.add(creditCardDto);
        CreditCardFilterProperties filterProps=new CreditCardFilterProperties();
        filterProps.setCardRplIndActPrimaryStopReasonCodes("1222");
        filterProps.setCardRplIndActSupCardStatus("34322");
        filterProps.setCardRplIndActSupStopReasonCodes("12343");
        filterProps.setCardRplIndActSupCardStatus("123");
        cardUtil.getCardRplC400Ind("1111","12343",BigInteger.valueOf(123L),CardConstant.CONS_N,cardList,"vv",filterProps);
    }


/*    @Test(expected = Exception.class)
    public void getCreditCardPropertiesBean_With_Param() throws Exception {

        cardUtil.getCreditCardPropertiesBean("ss");
    }

    @Test
    public void loadSrParamListByObject_With_Param() throws Exception {

        cardUtil.loadSrParamListByObject(new ArrayList<Serializable>(),ccDao);
    }*/

    @Test
    public void getOriginalCardType() throws Exception {
        Map<String, String> cardTypes=new HashMap<>();
        cardTypes.put("CC","CC");
        cardUtil.getOriginalCardType("CC",cardTypes);
    }

    @Test
    public void getProductDescCode() throws Exception {
        Map<String, String> cardTypes=new HashMap<>();
        cardTypes.put("CC","CC");
        cardUtil.getProductDescCode("CC",CardConstant.AMEX_CARD_PREFIX,1);
    }

    @Test
    public void convertCalendarToDate() throws Exception {
        GregorianCalendar c = new GregorianCalendar();
        c.setTime(new Date());
        XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
        cardUtil.convertCalendarToDate(date2);
    }

    @Test
    public void convertStringToDate() throws Exception {

        cardUtil.convertStringToDate("01/01/2017");
    }

}