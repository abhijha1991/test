package com.sc.csl.retail.creditcard.helper;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class EncryptionDecryptionHelperTest {

	
	
@Test
	public void performEncryptDecrypt_Encrypt(){
		
		String CreditCardNum="987654321234567";
		String Mode="ENCRYPT";
		String Key="S7530497H";
		EncryptionDecryptionHelper encryptionDecryptionHelper= new EncryptionDecryptionHelper();
		String actualEncCardNum = encryptionDecryptionHelper.performEncryptDecrypt(6,4,CreditCardNum, Mode, Key);
		String Mode1="DECRYPT";
		String actualEncCardNum1 =encryptionDecryptionHelper.performEncryptDecrypt(6,4,actualEncCardNum, Mode1, Key);
		assertEquals(CreditCardNum, actualEncCardNum1);
	}
}
