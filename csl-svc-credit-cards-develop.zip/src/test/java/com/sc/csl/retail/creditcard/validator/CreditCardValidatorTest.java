package com.sc.csl.retail.creditcard.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.sc.csl.retail.core.exception.BusinessException;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardEligibilityDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * Created by 1568078 on 7/7/2017.
 */
public class CreditCardValidatorTest {


    @Test(expected = BusinessException.class)
    public void shouldThrow_BusinessException_When_validateCardNo_Method_Called_With_CardNo_IsNull() {
        CreditCardVO creditCardVO = new CreditCardVO();
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateCardNo(creditCardVO);
    }

    @Test
    public void should_Return_Nothing_BusinessException_When_validateCardNo_Method_Called_With_Valid_Data() {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setRelId("01070565A0SH04005");
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateCardNo(creditCardVO);
    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CreditCardVO_Object_IsNull() {
        CreditCardVO creditCardVO = null;
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CountryCode_IsNull() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_Channel_IsNull() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CustomerId_IsNull() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLRequestContext_Object_IsNull() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLRequestContext_Object_IsEmpty() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_RelID_Mismatch() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }

    @Test
    public void should_Return_Nothing_When_validateRequest_Method_Called() {
        List<CreditCardDto> creditCardDtos = new ArrayList<>();
        creditCardDtos.add(manualBuildDtoObject());
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("070565A0SH040005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setRelId("01070565A0SH040005");
        creditCardVO.setCustomerType("01");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardDto_Object_When_isCardExistByCustomerId_Method_Called() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874005");
        List<CreditCardDto> creditCardDtos=new ArrayList<>();
        creditCardDtos.add(manualBuildDtoObject());
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        CreditCardDto dto=creditCardValidator.isCardExistByCustomerId(creditCardDtos,creditCardVO);
        assertEquals("IN",dto.getCountry());
        assertEquals("4129057530874005",dto.getCardNum());
        assertEquals("Credit Card",dto.getDesc());
        assertEquals("356",dto.getCurrencyCode());
        assertEquals("Visa",dto.getCardType());
    }

    @Test(expected = BusinessException.class)
    public void shouldThrow_BusinessException_When_isCardExistByCustomerId_Method_Called_With_Mismatched_CardNo() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        List<CreditCardDto> creditCardDtos=new ArrayList<>();
        creditCardDtos.add(manualBuildDtoObject());
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        CreditCardDto dto=creditCardValidator.isCardExistByCustomerId(creditCardDtos,creditCardVO);
        assertEquals("IN",dto.getCountry());
        assertEquals("4129057530874005",dto.getCardNum());
        assertEquals("Credit Card",dto.getDesc());
        assertEquals("356",dto.getCurrencyCode());
        assertEquals("Visa",dto.getCardType());
    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLContext_isNull() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        creditCardVO.setRelId("01070565A0SH04005");
        creditCardVO.setCslRequestContext(null);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLContext_Country_isEmpty() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        creditCardVO.setRelId("01070565A0SH04005");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLContext_RelId_isEmpty() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        creditCardVO.setRelId("01070565A0SH04005");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLContext_Channel_isEmpty() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        creditCardVO.setRelId("01070565A0SH04005");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }
    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_With_CSLContext_CutomerId_isEmpty() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        creditCardVO.setRelId("01070565A0SH04005");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }

    @Test(expected = TechnicalException.class)
    public void shouldThrow_BusinessException_When_validateRequest_Method_Called_CSLRelId_NtEqualWIthCreditCardRelId() {
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874000");
        creditCardVO.setRelId("01070565A0SH04005");

        CSLRequestContext cSLRequestContext=new CSLRequestContext("01070565A0SH040005", "uaas2id", "IN", "IBNK", "en", "INO");
        creditCardVO.setCslRequestContext(cSLRequestContext);
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        creditCardValidator.validateRequest(creditCardVO);
    }



    @Test
    public void shouldreturn_CreditCardDto_When_isCardExistByCustomerId_isCalled()
    {
        List<CreditCardDto> creditCardDtos = new ArrayList<>();
        creditCardDtos.add(manualBuildDtoObject());
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCustomerId("01070565A0SH04005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setRelId("01070565A0SH04005");
        CreditCardValidator creditCardValidator=new CreditCardValidator();
        CreditCardDto creditCardDto = creditCardValidator.isCardExistByCustomerId(creditCardDtos,creditCardVO);
        assertNotNull(creditCardDto);
        assertEquals("4129057530874005",creditCardDto.getCardNum());
    }

    private CreditCardDto manualBuildDtoObject(){
        CreditCardDto creditCardDto=new CreditCardDto();
        creditCardDto.setCountry("IN");
        creditCardDto.setBlkInd("02");
        creditCardDto.setFranchise("Visa");
        creditCardDto.setProd("53");
        creditCardDto.setCardType("Visa");
        creditCardDto.setExpDt("1114");
        creditCardDto.setCardNum("4129057530874005");
        creditCardDto.setCardImgName("in-manhattan-platinum");
        creditCardDto.setIsPrimary("Y");
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setVariant("200");
        creditCardDto.setCustShortName("INORR57");
        creditCardDto.setCurrencyCode("356");
        creditCardDto.setDesc("Credit Card");
        creditCardDto.setStatus("2");
        return creditCardDto;
    }
    
    //@Test(expected = TechnicalException.class)
    public void shouldThrow_TechnicalException_When_validateCCFServiceRequest_Method_Called_With_CreditCardDto_IsNull() {
        CreditCardDto creditCardDto = new CreditCardDto();
        CreditCardDto ccDto = new CreditCardDto();
        ccDto.setCardNum("4129057530874005");
        ccDto.setCardType("VISA");
        ccDto.setBlockCode("A");
        CreditCardEligibilityDto ccEligibilityDto = new CreditCardEligibilityDto();
        ccEligibilityDto.setCardEligibilityFlag("Y");
        ccEligibilityDto.setEligibilityOverrideFlag("Y");
        CreditCardTransactionDto creditCardTransDto = new CreditCardTransactionDto();
        creditCardTransDto.setActualTxnAmount(new BigDecimal("1"));
        List<CreditCardTransactionDto> transactions = new ArrayList<CreditCardTransactionDto>();
        ccDto.setCardtransactions(transactions);
        ccDto.setCreditCardEligibility(ccEligibilityDto);
        List<CreditCardDto> postCreditCards = new ArrayList<CreditCardDto>();
        postCreditCards.add(ccDto);
        creditCardDto.setPostCreditCards(postCreditCards);
       CreditCardValidator creditCardValidator=new CreditCardValidator();
        assertEquals(true,creditCardValidator.validateCCFPostServiceRequest(creditCardDto));
        
    }

}