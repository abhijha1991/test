package com.sc.csl.retail.creditcard.config;

import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardLimitV1SoapGateway;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardProfileV1SoapGateway;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class GatewayConfigTest {
    @Test
    public void shouldReturn_CSLSoapGatewayProperties_Object_When_edmiCreditCardProfileV1SoapGatewayProperties_Method_Called() throws Exception {
        GatewayConfig gatewayConfig=new GatewayConfig();
        CSLSoapGatewayProperties cslSoapGatewayProperties=gatewayConfig.edmiCreditCardProfileV1SoapGatewayProperties();
        assertNotNull(cslSoapGatewayProperties);
    }

    @Test
    public void shouldReturn_CSLSoapGatewayProperties_Object_When_edmiCreditCardEnquiryV1SoapGatewayProperties_Method_Called() throws Exception {
        GatewayConfig gatewayConfig=new GatewayConfig();
        CSLSoapGatewayProperties cslSoapGatewayProperties=gatewayConfig.edmiCreditCardEnquiryV1SoapGatewayProperties();
        assertNotNull(cslSoapGatewayProperties);
    }

    @Test
    public void shouldReturn_CreditCardProfileV1SoapGateway_Object_When_edmiCreditCardProfileV1SoapGateway_Method_Called() throws Exception {
        GatewayConfig gatewayConfig=new GatewayConfig();
        CSLSoapGatewayProperties edmiCreditCardProfileV1SoapGatewayProperties=new CSLSoapGatewayProperties();
        CreditCardProfileV1SoapGateway creditCardProfileV1SoapGateway=gatewayConfig.edmiCreditCardProfileV1SoapGateway(edmiCreditCardProfileV1SoapGatewayProperties);
        assertNotNull(creditCardProfileV1SoapGateway);
    }

    @Test
    public void shouldReturn_CSLSoapGatewayProperties_Object_When_edmiCreditCardLimitV1SoapGatewayProperties_Method_Called() throws Exception {
        GatewayConfig gatewayConfig=new GatewayConfig();
        CSLSoapGatewayProperties cslSoapGatewayProperties=gatewayConfig.edmiCreditCardLimitV1SoapGatewayProperties();
        assertNotNull(cslSoapGatewayProperties);
    }

    @Test
    public void shouldReturn_CreditCardEnquiryV1SoapGateway_Object_When_edmiCreditCardEnquiryV1SoapGateway_Method_Called() throws Exception {
        GatewayConfig gatewayConfig=new GatewayConfig();
        CSLSoapGatewayProperties edmiCreditCardEnquiryV1SoapGatewayProperties=new CSLSoapGatewayProperties();
        CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway=gatewayConfig.edmiCreditCardEnquiryV1SoapGateway(edmiCreditCardEnquiryV1SoapGatewayProperties);
        assertNotNull(creditCardEnquiryV1SoapGateway);
    }

    @Test
    public void shouldReturn_CreditCardLimitV1SoapGateway_Object_When_edmiCreditCardLimitV1SoapGateway_Method_Called() throws Exception {
        GatewayConfig gatewayConfig=new GatewayConfig();
        CSLSoapGatewayProperties edmiCreditCardLimitV1SoapGatewayProperties=new CSLSoapGatewayProperties();
        CreditCardLimitV1SoapGateway creditCardLimitV1SoapGateway = gatewayConfig.edmiCreditCardLimitV1SoapGateway(edmiCreditCardLimitV1SoapGatewayProperties);
        assertNotNull(creditCardLimitV1SoapGateway);
    }
}