package com.sc.csl.retail.creditcard.gateway.csl;

import static org.mockito.Mockito.when;
import io.katharsis.repository.ResourceRepositoryV2;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.creditcard.dto.ServiceRequest;

public class ServiceRequestJsonApiGatewayTest{

	@InjectMocks
	ServiceRequestJsonApiGateway serviceRequestJsonApiGateway;
	@Mock
	ResourceRepositoryV2 serviceRepo;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = NullPointerException.class)
	public void createServiceRequest() {
		ServiceRequest serviceReq = new ServiceRequest();
		when(serviceRepo.create(serviceReq)).thenReturn(serviceReq);
		serviceRequestJsonApiGateway.createServiceRequest(serviceReq);

	}

}
