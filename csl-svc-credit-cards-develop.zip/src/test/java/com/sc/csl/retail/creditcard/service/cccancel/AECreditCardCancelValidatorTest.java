package com.sc.csl.retail.creditcard.service.cccancel;


import static org.junit.Assert.assertTrue;
import java.math.BigDecimal;
import org.junit.Test;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelValidationProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;


public class AECreditCardCancelValidatorTest {

    CreditCardDto creditCardDto = new CreditCardDto();
    CreditCardCancelValidationProperties creditCardCancelValidationProperties = new CreditCardCancelValidationProperties();
    
    private CreditCardDto setcreditCardDto(){
        creditCardDto.setBlockCode("CC");
        creditCardDto.setOutstandingBalance(new BigDecimal(Double.toString(109903.1849)));
        creditCardDto.setReasonCode("CCCRSN06");
        creditCardDto.setLanguage("en");
        return creditCardDto;
    }
    
    private CreditCardCancelValidationProperties setreditCardCancelValidationProperties(){
        creditCardCancelValidationProperties.setIneligibleReasonCode("CCCRSN06");
        return creditCardCancelValidationProperties;
    }
    
    @Test
    public void validateFinancialDetail_with_In_correct_request() throws Throwable {
        AECreditCardCancelValidator aeCreditCardCancelValidator = new AECreditCardCancelValidator();
        aeCreditCardCancelValidator.validateFinancialDetail(this.setcreditCardDto(), this.setreditCardCancelValidationProperties());
        assertTrue(creditCardDto.getAlerts()==null);
    }
    
    @Test
    public void validateFinancialDetail_with_correct_request() throws Throwable {
        creditCardDto.setReasonCode("CCCRSN01");
        creditCardDto.setBlockCode("AA");
        creditCardDto.setOutstandingBalance(new BigDecimal(Double.toString(10.1849)));
        creditCardCancelValidationProperties.setIneligibleSanctionedBlockCode("AA");
        AECreditCardCancelValidator aeCreditCardCancelValidator = new AECreditCardCancelValidator();
        aeCreditCardCancelValidator.validateFinancialDetail(this.setcreditCardDto(), this.setreditCardCancelValidationProperties());
        assertTrue(creditCardDto.getAlerts()==null);
    }
}

