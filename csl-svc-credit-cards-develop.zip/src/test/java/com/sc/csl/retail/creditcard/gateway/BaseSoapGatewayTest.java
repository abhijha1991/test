package com.sc.csl.retail.creditcard.gateway;

import org.junit.Test;

import static org.junit.Assert.*;

public class BaseSoapGatewayTest {

    @Test
    public void getValuePropertiesByKey() throws Exception {
    }

    @Test
    public void getCreditCardPropertiesByCountry() throws Exception {
    }

    @Test
    public void getErrorCodes() throws Exception {
    }

    @Test
    public void getCurrencyCodes() throws Exception {
    }

    @Test
    public void getGatewayTemplateMap() throws Exception {
    }

    @Test
    public void validateSCBMLHeader() throws Exception {
    }

    @Test
    public void validateResponseCode() throws Exception {
    }

    @Test
    public void populateCreditCardPrimaryStatus() throws Exception {
    }

}