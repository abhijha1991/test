package com.sc.csl.retail.creditcard.endpoint;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.post.CardActivationDto;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardV1SoapGateway;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.service.CardActivationService;
import com.sc.csl.retail.creditcard.service.CreditBalRefundService;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

import io.katharsis.queryspec.QuerySpec;
import io.katharsis.resource.list.DefaultResourceList;
import io.katharsis.resource.list.ResourceList;

/**
 * Created by 1568078 on 7/7/2017.
 */
public class CreditCardRepositoryTest {

    @InjectMocks
    private CreditCardRepository creditCardRepository;

    @Mock
    private CreditCardService creditCardService;
    
    @Mock
	private CreditCardV1SoapGateway creditCardV1SoapGateway;

    @Mock
    QuerySpec querySpec;

    @Mock
    private CSLRequestContext mockCSLRequestContext;

    @Mock
    CardUtil cardUtil;
    
    @Mock
    CreditBalRefundService creditBalRefundService;
    
    @Mock
    CardActivationService creditCardActivation;
   
    
    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

    }

    @Test
    public void shouldReturn_CreditCardDto_ListObject_When_findAll_Method_Called() {
        ResourceList<CreditCardDto> creditDtoList = new DefaultResourceList<>();
        CreditCardDto creditCardDto = null;
        creditDtoList.add(manualBuildDtoObject(creditCardDto));
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        when(mockCSLRequestContext.getCustomerType()).thenReturn("01");
        when(mockCSLRequestContext.getRelId()).thenReturn("070565A0SH04005");
        when(mockCSLRequestContext.getCompositeRelId()).thenReturn("01070565A0SH04005");
        when(mockCSLRequestContext.getCountry()).thenReturn("IN");
        when(mockCSLRequestContext.getChannel()).thenReturn("WEB");
        DefaultResourceList<CreditCardDto> list=new DefaultResourceList();
        list.add(manualBuildDtoObject(creditCardDto));
        when(cardUtil.populateCreditCardVO(mockCSLRequestContext)).thenReturn(creditCardVO);
        when(cardUtil.populateQuerySpec(querySpec, creditCardVO)).thenReturn(querySpec);
        when(creditCardService.findAllCreditCard(creditCardVO)).thenReturn(creditDtoList);
        when(querySpec.apply(creditDtoList)).thenReturn(list);
        List<CreditCardDto> creditDtoList1=creditCardRepository.findAll(querySpec);
        assertNotNull(creditDtoList1);
        assertEquals("4129057530874005",creditDtoList1.get(0).getCardNum());
        assertEquals("1118",creditDtoList1.get(0).getExpDt());
        assertEquals("Credit Card",creditDtoList1.get(0).getDesc());
        assertEquals("356",creditDtoList1.get(0).getCurrencyCode());
        assertEquals("IN",creditDtoList1.get(0).getCountry());
        assertEquals("01070565A0SH04005",creditDtoList1.get(0).getCustomerId());

    }

    @Test
    public void shouldReturn_CreditCardDto_Object_When_findOne_Method_Called() {
        CreditCardDto creditCardDto =null;
        creditCardDto= manualBuildDtoObject(creditCardDto);
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("WEB");
        creditCardVO.setCustomerId("01070565A0SH04005");
        when(mockCSLRequestContext.getCustomerType()).thenReturn("01");
        when(mockCSLRequestContext.getRelId()).thenReturn("070565A0SH04005");
        when(mockCSLRequestContext.getCompositeRelId()).thenReturn("01070565A0SH04005");
        when(mockCSLRequestContext.getCountry()).thenReturn("IN");
        when(mockCSLRequestContext.getChannel()).thenReturn("WEB");
        
        DefaultResourceList<CreditCardDto> list=new DefaultResourceList();
        list.add(manualBuildDtoObject(creditCardDto));
        when(cardUtil.populateCreditCardVO(mockCSLRequestContext)).thenReturn(creditCardVO);
        when(cardUtil.populateQuerySpec(querySpec, creditCardVO)).thenReturn(querySpec);
        when(creditBalRefundService.validateOneCardCreditBalRefund(creditCardVO, "4129057530874005")).thenReturn(creditCardDto);
        when(creditCardService.findOneCreditCard(creditCardVO)).thenReturn(creditCardDto);
        CreditCardDto creditDtoList1=creditCardRepository.findOne("4129057530874005",querySpec);
        assertNotNull(creditDtoList1);
        assertEquals("4129057530874005",creditDtoList1.getCardNum());
        assertEquals("1118",creditDtoList1.getExpDt());
        assertEquals("Credit Card",creditDtoList1.getDesc());
        assertEquals("356",creditDtoList1.getCurrencyCode());
        assertEquals("IN",creditDtoList1.getCountry());
        assertEquals("01070565A0SH04005",creditDtoList1.getCustomerId());

    }

    
    @Test
    public void testSaveForCardActivaion() {
        CreditCardDto creditCardDto =null;
        creditCardDto= manualBuildDtoObjectForActivation(creditCardDto);
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("MY");

        when(creditCardActivation.activateCard(creditCardDto)).thenReturn(creditCardDto);
        CreditCardDto creditCardResultDto =creditCardRepository.save(creditCardDto);
        assertNotNull(creditCardResultDto);
        assertEquals("4129057530874005",creditCardResultDto.getCardNum());
        assertEquals("MY",creditCardResultDto.getCountry());
        assertNotNull(creditCardResultDto.getCardActivationDto());
        assertEquals(creditCardResultDto.getCardActivationDto().getEncData(),"EncryptedData");
        assertEquals(creditCardResultDto.getCardActivationDto().getKeyIndex(),"10");
        assertEquals(creditCardResultDto.getCardActivationDto().getCountry(),"MY");
    }
    private CreditCardDto manualBuildDtoObject(CreditCardDto creditCardDto){
        creditCardDto=new CreditCardDto();
        creditCardDto.setBlkInd("02");
        creditCardDto.setFranchise("Visa");
        creditCardDto.setProd("53");
        creditCardDto.setCardType("Visa");
        creditCardDto.setExpDt("1118");
        creditCardDto.setCardNum("4129057530874005");
        creditCardDto.setCardImgName("in-manhattan-platinum");
        creditCardDto.setIsPrimary("Y");
        creditCardDto.setCustomerId("01070565A0SH04005");
        creditCardDto.setVariant("200");
        creditCardDto.setCustShortName("INORR57");
        creditCardDto.setCurrencyCode("356");
        creditCardDto.setDesc("Credit Card");
        creditCardDto.setCountry("IN");
        creditCardDto.setStatus("2");
        return creditCardDto;
    }
    
    private CreditCardDto manualBuildDtoObjectForActivation(CreditCardDto creditCardDto){
        creditCardDto=new CreditCardDto();
        creditCardDto.setCardNum("4129057530874005");
        creditCardDto.setCountry("MY");
        creditCardDto.setEmbossedName("CARD HOLDER NAME");
        creditCardDto.setOperationName("CCACTV");
        
        CardActivationDto cardActivcationDto=new CardActivationDto();
        cardActivcationDto.setCountry("MY");
        cardActivcationDto.setKeyIndex("10");
        cardActivcationDto.setEncData("EncryptedData");
        cardActivcationDto.setCountry("MY");
        creditCardDto.setCardActivationDto(cardActivcationDto);

        return creditCardDto;
    }    
   
    
    
    
}
