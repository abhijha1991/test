package com.sc.csl.retail.creditcard.service.cccancel;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.context.ApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.sc.csl.retail.core.exception.TechnicalException;
import com.sc.csl.retail.core.web.CSLRequestContext;
import com.sc.csl.retail.creditcard.config.EnricherServiceConfig;
import com.sc.csl.retail.creditcard.config.mock.BasePropertiesMockTest;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardCancelDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.service.CreditCardService;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

/**
 * @author 1452875
 * @since Sep 20, 2017
 */
public class CreditCardCancelServiceTest {

    @InjectMocks
    private CreditCardCancelService creditCardCancelService;
    @Mock
    private CreditCardService creditCardService;
    @Mock
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
    @Mock
    private CSLRequestContext cslRequestContext;
    @Mock
    public ApplicationContext context;

    private CreditCardProperties creditCardProps = null;
    private CreditCardCancelProperties creditCardCancelProps = null;
    private CreditCardCancelEnricher creditCardCancelEnricher = null;
    private EnricherServiceConfig enricherServiceConfig = new EnricherServiceConfig();
    private Map<String, CreditCardDto> allCardsMap = null;

    private String channel = "IBNK";
    private String countryCode;
    private String customerId;
    private String relId;
    private String customerType;

    private void initSG() throws Throwable {
        countryCode = "SG";
        relId = "01030347RJKA0";
        customerId = "030347RJKA0";
        customerType = "01";

        File file = new File("./src/main/resources/config/application-credit-card-sg.yml");
        BasePropertiesMockTest baseMockProp = getMapper(file);
        creditCardProps = baseMockProp.getCreditCardProps().getSg();
        creditCardCancelEnricher = enricherServiceConfig.creditCardCancelRequestEnricherSG();

        init();
    }

    public void init() throws Throwable {
        MockitoAnnotations.initMocks(this);

        Comparable c = mock(Comparable.class);
        when(c.compareTo("Java Code Geeks")).thenReturn(100).thenReturn(11).thenReturn(11);

        when(cslRequestContext.getCountry()).thenReturn(countryCode);
        when(cslRequestContext.getRelId()).thenReturn(relId);
        when(cslRequestContext.getCustomerId()).thenReturn(customerId);
        when(cslRequestContext.getCustomerType()).thenReturn(customerType);
        when(cslRequestContext.getChannel()).thenReturn(channel);

        when(context.getBean(countryCode)).thenReturn(creditCardProps);
        when(creditCardService.findAllCreditCard(any(CreditCardVO.class))).thenReturn(getAllCreditCards());
        when(creditCardEnquiryV1SoapGateway.getCreditCardFinancialDetails(any(CreditCardVO.class))).thenAnswer(
                new Answer<CreditCardDto>() {
                    @Override
                    public CreditCardDto answer(InvocationOnMock invocation) {
                        CreditCardVO ccVO = (CreditCardVO) invocation.getArguments()[0];
                        return allCardsMap.get(ccVO.getCardNo());
                    }
                });
        creditCardCancelProps = creditCardProps.getCreditCardCancelProps();
    }

    private List<CreditCardDto> getAllCreditCards() {
        List<CreditCardDto> allCards = new ArrayList<CreditCardDto>();
        allCards.add(getCreditCardDto("4444555566667771", "E", "0", "AA", "N"));
        allCards.add(getCreditCardDto("4444555566667772", "E", "0", "FL", "N"));
        allCards.add(getCreditCardDto("4444555566667773", "E", "0", "AA", "Y"));
        allCards.add(getCreditCardDto("4444555566667774", "F", "0", "AA", "Y"));
        allCards.add(getCreditCardDto("4444555566667775", "F", "3", "AA", "N"));
        allCards.add(getCreditCardDto("4444555566667776", "A", "2", "AA", "N"));
        allCards.add(getCreditCardDto("4444555566667777", "A", "2", "FL", "N"));
        allCards.add(getCreditCardDto("4444555566667778", "E", "2", "AB", "N"));
        allCards.add(getCreditCardDto("5555666677778881", "E", "0", "AA", "N"));
        allCards.add(getCreditCardDto("3333444455556661", "E", "0", "AA", "N"));
        allCards.add(getCreditCardDto("3333444455556662", "E", "0", "AA", "N"));
        allCards.add(getCreditCardDto("9999000011112221", "E", "0", "AA", "N"));
        allCards.add(getCreditCardDto("9999000011112222", "F", "0", "AA", "N"));

        allCardsMap = new HashMap<String, CreditCardDto>();
        for (CreditCardDto creditCardDto : allCards) {
            allCardsMap.put(creditCardDto.getCardNum(), creditCardDto);
        }
        return allCards;
    }

    private CreditCardDto getCreditCardDto(String cardNum, String blockCode, String cardStatus, String collateralCode,
            String comboFlag) {
        CreditCardDto creditCardDto = new CreditCardDto();
        creditCardDto.setCardNum(cardNum);
        creditCardDto.setBlockCode(blockCode);
        creditCardDto.setCardStatus(cardStatus);
        creditCardDto.setCollateralCode(collateralCode);
        creditCardDto.setIsComboFlag(comboFlag);
        return creditCardDto;
    }

    private BasePropertiesMockTest getMapper(File file) {
        try {
            final ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
            // mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            return mapper.readValue(file, BasePropertiesMockTest.class);
        } catch (IOException ex) {
            // ex.printStackTrace();
            throw new TechnicalException(ex.getMessage());
        }
    }

    @Test
    public void shouldThrow_BusinessException_When_PassingListForSG_getEligibleCreditCards() throws Throwable {
        initSG();
        CreditCardCancelDto creditCardCancelDto = new CreditCardCancelDto();
        CreditCardVO creditCardVO = new CreditCardVO();
        List<CreditCardDto> eligibleCreditCards = creditCardCancelService.getEligibleCreditCards(creditCardVO);
        CreditCardDto creditCardDto = eligibleCreditCards.get(0);
        assertEquals(true, (creditCardCancelDto != null));
    }

    // @Test
    // public void shouldThrow_BusinessException_When_PassingListForSG_requestCreditCardCancellation() throws Throwable
    // {
    // initSG();
    // CreditCardCancelDto creditCardCancelDto = new CreditCardCancelDto();
    // assertEquals(true, (creditCardCancelDto != null));
    // }

}
