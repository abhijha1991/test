package com.sc.csl.retail.creditcard.config;

import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class CreditCardConfigTest {

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_ALL_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.ALL();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_IN_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.IN();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_SG_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.SG();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_MY_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.MY();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_HK_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.HK();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_AE_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.AE();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_KE_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.KE();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_GH_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.GH();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_BW_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.BW();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_NG_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.NG();
        assertNotNull(creditCardProperties);
    }

    @Test
    public void shouldReturn_CreditCardProperties_Object_When_ZM_Method_Called() throws Exception {
        CreditCardConfig creditCardConfig=new CreditCardConfig();
        CreditCardProperties creditCardProperties=creditCardConfig.ZM();
        assertNotNull(creditCardProperties);
    }

}