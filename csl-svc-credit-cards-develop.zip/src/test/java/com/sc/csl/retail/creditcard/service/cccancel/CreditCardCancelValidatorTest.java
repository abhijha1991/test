package com.sc.csl.retail.creditcard.service.cccancel;

import static org.junit.Assert.assertFalse;
import org.junit.Test;
import org.mockito.Mock;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardCancelValidationProperties;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.gateway.edmi.CreditCardEnquiryV1SoapGateway;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;

public class CreditCardCancelValidatorTest {
    
    @Mock
    private CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;
    
    CreditCardDto creditCardDto = new CreditCardDto();
    
    private CreditCardDto setcreditCardDto(){
        creditCardDto.setCardNum("44444778653839229");
        creditCardDto.setChannel("MBNK");
        creditCardDto.setCountry("AE");
        creditCardDto.setBlockCode("CC");
        return creditCardDto;
    }
    
    private CreditCardCancelProperties setreditCardCancelProperties(){
        CreditCardCancelValidationProperties ccValidationProperties = new CreditCardCancelValidationProperties();
        CreditCardCancelProperties creditCardCancelProperties = new CreditCardCancelProperties();
        ccValidationProperties.setEligibleCreditCardServiceProvider("444447");
        ccValidationProperties.setIneligibleBlockCode("CC");
        ccValidationProperties.setIneligibleOverrideCode("ZZ");
        ccValidationProperties.setIneligibleSanctionedBlockCode("SP");
        ccValidationProperties.setIneligibleAgreementStatus("11");
        creditCardCancelProperties.setValidation(ccValidationProperties);
        return creditCardCancelProperties;
    }
    
    
    @Test
    public void test_isValidCreditCard_with_valid_req(){
        CreditCardCancelValidator creditCardCancelValidator = new CreditCardCancelValidator();
        CreditCardVO creditCardVO = new CreditCardVO();
        boolean result = creditCardCancelValidator.isValidCreditCard(creditCardVO, this.setcreditCardDto(), this.setreditCardCancelProperties());
        assertFalse(result);
    }
}
