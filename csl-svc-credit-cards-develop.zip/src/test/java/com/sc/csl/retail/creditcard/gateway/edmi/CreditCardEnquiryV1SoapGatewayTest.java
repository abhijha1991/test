package com.sc.csl.retail.creditcard.gateway.edmi;

import com.sc.corebanking.creditcard.v1.creditcardenquiry.*;
import com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.*;
import com.sc.csl.retail.core.gateway.CSLSoapGatewayProperties;
import com.sc.csl.retail.core.render.FreemarkerRenderer;
import com.sc.csl.retail.core.util.CSLXmlUtils;
import com.sc.csl.retail.creditcard.config.properties.CreditCardFilterProperties;
import com.sc.csl.retail.creditcard.config.properties.CreditCardProperties;
import com.sc.csl.retail.creditcard.config.properties.GatewayHeaderProperties;
import com.sc.csl.retail.creditcard.dto.CardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardDto;
import com.sc.csl.retail.creditcard.dto.CreditCardTransactionDto;
import com.sc.csl.retail.creditcard.gateway.BaseCreditCardsSoapGateway;
import com.sc.csl.retail.creditcard.gateway.csl.CreditCardSharedServiceJsonApiGateway;
import com.sc.csl.retail.creditcard.gateway.helper.CardGatewayConstant;
import com.sc.csl.retail.creditcard.helper.CardConstant;
import com.sc.csl.retail.creditcard.helper.CardUtil;
import com.sc.csl.retail.creditcard.vo.CreditCardVO;
import com.sc.scbml_1.Code;
import com.sc.scbml_1.ExceptionListType;
import com.sc.scbml_1.ExceptionType;
import com.sc.scbml_1.SCBMLHeaderType;
import ma.glasnost.orika.MapperFacade;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import org.powermock.api.mockito.PowerMockito;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.util.*;

import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.doReturn;


public class CreditCardEnquiryV1SoapGatewayTest {

    @InjectMocks
    CreditCardEnquiryV1SoapGateway creditCardEnquiryV1SoapGateway;

    @Mock
    FreemarkerRenderer renderer;

    @Mock
    Unmarshaller unmarshaller;

    @Mock
    CSLSoapGatewayProperties creditCardProfileV1SoapGatewayProperties;

    @Mock
    CardUtil cardUtil;

    @Mock
    BaseCreditCardsSoapGateway baseSoapGateway;

    @Spy
    Map<String, CreditCardProperties> creditCardProperties= new HashMap<>();

    @Mock
    CSLXmlUtils cslXmlUtils;

    @Mock
    CreditCardSharedServiceJsonApiGateway creditCardSharedServiceJsonApiGateway;

    @Mock
    MapperFacade orikaMapper;

    CreditCardProperties countryProp;
    Map<String, String> errorCodes;
    Map<String, String> currencyCodes;

    @Before
    public void init()throws Exception {

        countryProp = new CreditCardProperties();
        GatewayHeaderProperties gatewayHeaderProperties = new GatewayHeaderProperties();
        gatewayHeaderProperties.setCaptureSystem("CCMS");
        gatewayHeaderProperties.setEntityType("05");
        gatewayHeaderProperties.setFuncCode("16");
        gatewayHeaderProperties.setMessageVersion("1.0");
        gatewayHeaderProperties.setPayLoadVersion("1.0");
        gatewayHeaderProperties.setSourceFlag("IBK");
        countryProp.setCardDetailsProperties(gatewayHeaderProperties);
        countryProp.setCardHistoryProperties(gatewayHeaderProperties);
        countryProp.setCardListProperties(gatewayHeaderProperties);
        errorCodes = new HashMap();
        errorCodes.put("-1", "ERR_CSL_CREDIT_CARDS_EDMI_DOWN_TIMEOUT");
        errorCodes.put( "0001", "ERR_CSL_CREDIT_CARDS_INVALID_CARD_NO");
        errorCodes.put("10001", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
        errorCodes.put("10009", "ERR_CSL_CREDIT_CARDS_INVALID_INPUT");
        currencyCodes = new HashMap();
        currencyCodes.put("248", "ALA");
        currencyCodes.put("008", "ALB");
        currencyCodes.put("012", "DZA");
        CreditCardFilterProperties creditCardFilterProperties = new CreditCardFilterProperties();
        creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0");
        creditCardFilterProperties.setIsSupplCardStausCheckEnabled("Y");
        creditCardFilterProperties.setAllowedPrimaryCardStatus("W:0|1");
        creditCardFilterProperties.setBlockCodeDateBlockCodes("W:L|S");
        creditCardFilterProperties.setTransferEffectiveDateBlockCodes("W:L|S");
        creditCardFilterProperties.setBlockCodeDateDays(60);
        countryProp.setCreditCardFilters(creditCardFilterProperties);
        countryProp.setErrorCodes(errorCodes);
        countryProp.setCurrencyCodes(currencyCodes);
        creditCardProperties.put("IN", countryProp);

        baseSoapGateway = PowerMockito.mock(BaseCreditCardsSoapGateway.class, Mockito.CALLS_REAL_METHODS);

        creditCardSharedServiceJsonApiGateway= PowerMockito.mock(CreditCardSharedServiceJsonApiGateway.class, Mockito.CALLS_REAL_METHODS);

        creditCardEnquiryV1SoapGateway= PowerMockito.mock(CreditCardEnquiryV1SoapGateway.class, Mockito.CALLS_REAL_METHODS);

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void shouldReturn_CreditDTo_When_getCreditCard_Method_Called_With_EmptyMapObject() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        creditCardProperties.getCreditCardFilters().setTransferEffectiveDateBlockCodes("CD");
        creditCardProperties.getCreditCardFilters().setAltBlockCodes("ABC");
        creditCardProperties.getCreditCardFilters().setBlockCodesForAltBlockCodeCheck("BC");

        Map<String, CreditCardProperties> map=new HashMap<>();

       /* creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");*/

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");


        CreditCardEnquiryPortType cc = new CreditCardEnquiryPortType() {
            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes getDetails(GetDetailsReq getDetailsRequest) {

                com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes  getDetailsRes
                        =new com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes();
                SCBMLHeaderType header=new SCBMLHeaderType();

                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getDetailsRes.setHeader(header);

                //set response
                GetDetailsResPayload getDetailsResPayload=new GetDetailsResPayload();

                GetDetailsResData getDetailsResData=new GetDetailsResData();
                CardInqRsType cardInqRsType=new CardInqRsType();
                cardInqRsType.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                cardInqRsType.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                CardRecType cardRecType=new CardRecType();

                CardInfoType cardInfoType=new CardInfoType();
                cardInfoType.setCardNum(BigInteger.valueOf(12323L));
                SCBCardBlockType sCBCardBlockType=new SCBCardBlockType();
                sCBCardBlockType.setSCBALTBlockCode("T");
                cardInfoType.setSCBCardBlock(sCBCardBlockType);
                SCBCardXferUpgradeType sCBCardXferUpgradeType=new SCBCardXferUpgradeType();
                try {
                    GregorianCalendar c = new GregorianCalendar();
                    c.setTime(new Date());
                    XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
                    sCBCardXferUpgradeType.setSCBCardXferEffDt(date2);
                    cardInfoType.setSCBCardXferUpgrade(sCBCardXferUpgradeType);
                }catch (Exception e){
                    e.printStackTrace();
                }
                SCBCardEmbossingGroupType sCBCardEmbossingGroupType=new SCBCardEmbossingGroupType();
                SCBCardEmbossingLineType sCBCardEmbossingLineType=new SCBCardEmbossingLineType();
                sCBCardEmbossingLineType.setSCBEmbosserName("qwww");
                sCBCardEmbossingGroupType.getSCBCardEmbossingLine().add(sCBCardEmbossingLineType);
                cardInfoType.setSCBCardEmbossingGroup(sCBCardEmbossingGroupType);
                cardRecType.setCardInfo(cardInfoType);

                CardStatusType cardStatusType=new CardStatusType();
                cardRecType.setCardStatus(cardStatusType);

                cardInqRsType.getCardRec().add(cardRecType);

                getDetailsResData.setGetDetailsRs(cardInqRsType);

                getDetailsResPayload.setGetDetailsRes(getDetailsResData);

                getDetailsRes.setGetDetailsResPayload(getDetailsResPayload);

                return getDetailsRes;
            }

            @Override
            public GetDelinquencyHistoryRes getDelinquencyHistory(GetDelinquencyHistoryReq getDelinquencyHistoryRequest) {
                return null;
            }

            @Override
            public GetBalanceHistoryRes getBalanceHistory(GetBalanceHistoryReq getBalanceHistoryRequest) {
                return null;
            }

            @Override
            public GetInterestHistoryRes getInterestHistory(GetInterestHistoryReq getInterestHistoryRequest) {
                return null;
            }

            @Override
            public GetTransactionHistoryRes getTransactionHistory(GetTransactionHistoryReq getTransactionHistoryRequest) {
                return null;
            }

            @Override
            public GetFinancialDetailsRes getFinancialDetails(GetFinancialDetailsReq getFinancialDetailsRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardEnquiryV1SoapGateway, "getProxyClient");

        // com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes response
        // when(creditCardEnquiryV1SoapGateway.getProxyClient().getDetails()).thenReturn(new com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes());
        creditCardEnquiryV1SoapGateway.getCreditCard(creditCardVO);

    }

    @Test
    public void shouldReturn_List_CreditCardTransactionDto_When_getCreditCardTransactions_Method_Called() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setFunctionType(CardConstant.TRANSACTION);

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();

        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");

        CreditCardEnquiryPortType cc = new CreditCardEnquiryPortType() {

            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes getDetails(GetDetailsReq getDetailsRequest) {
                return null;
            }

            @Override
            public GetDelinquencyHistoryRes getDelinquencyHistory(GetDelinquencyHistoryReq getDelinquencyHistoryRequest) {
                return null;
            }

            @Override
            public GetBalanceHistoryRes getBalanceHistory(GetBalanceHistoryReq getBalanceHistoryRequest) {
                return null;
            }

            @Override
            public GetInterestHistoryRes getInterestHistory(GetInterestHistoryReq getInterestHistoryRequest) {
                return null;
            }

            @Override
            public GetTransactionHistoryRes getTransactionHistory(GetTransactionHistoryReq getTransactionHistoryRequest) {

                GetTransactionHistoryRes getTransactionHistoryRes=new GetTransactionHistoryRes();

                SCBMLHeaderType header=new SCBMLHeaderType();

                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getTransactionHistoryRes.setHeader(header);

                //response
                GetTransactionHistoryResPayload getTransactionHistoryResPayload=new GetTransactionHistoryResPayload();

                GetTransactionHistoryResData getTransactionHistoryData=new GetTransactionHistoryResData();

                AcctStmtInqRsType getTransactionHistoryRs=new AcctStmtInqRsType();
                getTransactionHistoryRs.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                getTransactionHistoryRs.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                AcctStmtRecType acctStmtRecType=new AcctStmtRecType();

                AcctStmtInfoType acctStmtInfo=new AcctStmtInfoType();
                AcctKeysType acctKeysType=new AcctKeysType();
                CardKeysType cardKeys=new CardKeysType();
                cardKeys.setCardNum(BigInteger.valueOf(1111L));
                acctKeysType.setCardKeys(cardKeys);
                acctStmtInfo.setAcctKeys(acctKeysType);

                AcctTrnRefType acctTrnRefType=new AcctTrnRefType();

                AcctTrnRecType acctTrnRecType=new AcctTrnRecType();

                AcctTrnInfoType acctTrnInfo=new AcctTrnInfoType();

                RefDataType refDataType=new RefDataType();
                acctTrnInfo.setRefData(refDataType);

                TotalCurAmtType totalCurAmtType=new TotalCurAmtType();
                totalCurAmtType.setAmt("10000");
                acctTrnInfo.setTotalCurAmt(totalCurAmtType);

                CompositeCurAmtType compositeCurAmt=new CompositeCurAmtType();

                CurAmtType curAmtType=new CurAmtType();

                CurCodeType curCodeType=new CurCodeType();
                curAmtType.setCurCode(curCodeType);

                compositeCurAmt.setCurAmt(curAmtType);

                acctTrnInfo.setCompositeCurAmt(compositeCurAmt);

                acctTrnRecType.setAcctTrnInfo(acctTrnInfo);

                acctTrnRefType.setAcctTrnRec(acctTrnRecType);

                acctStmtInfo.getAcctTrnRef().add(acctTrnRefType);

                acctStmtRecType.setAcctStmtInfo(acctStmtInfo);

                //  acctStmtRecType.getAcctStmtInfo().getAcctKeys().getCardKeys()
                getTransactionHistoryRs.getAcctStmtRec().add(acctStmtRecType);

                getTransactionHistoryData.setGetTransactionHistoryRs(getTransactionHistoryRs);

                getTransactionHistoryResPayload.setGetTransactionHistoryRes(getTransactionHistoryData);

                getTransactionHistoryRes.setGetTransactionHistoryResPayload(getTransactionHistoryResPayload);

                return getTransactionHistoryRes;
            }

            @Override
            public GetFinancialDetailsRes getFinancialDetails(GetFinancialDetailsReq getFinancialDetailsRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardEnquiryV1SoapGateway, "getProxyClient");

        creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
    }

    @Test
    public void shouldReturn_List_CreditCardTransactionDto_When_getCreditCardTransactions_Method_Called2() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setFunctionType(CardConstant.TRANSACTION);
        creditCardVO.setFunctionCd("S");
        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();

        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");

        CreditCardEnquiryPortType cc = new CreditCardEnquiryPortType() {
            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes getDetails(GetDetailsReq getDetailsRequest) {
                return null;
            }

            @Override
            public GetDelinquencyHistoryRes getDelinquencyHistory(GetDelinquencyHistoryReq getDelinquencyHistoryRequest) {
                return null;
            }

            @Override
            public GetBalanceHistoryRes getBalanceHistory(GetBalanceHistoryReq getBalanceHistoryRequest) {
                return null;
            }

            @Override
            public GetInterestHistoryRes getInterestHistory(GetInterestHistoryReq getInterestHistoryRequest) {
                return null;
            }

            @Override
            public GetTransactionHistoryRes getTransactionHistory(GetTransactionHistoryReq getTransactionHistoryRequest) {


                GetTransactionHistoryRes getTransactionHistoryRes=new GetTransactionHistoryRes();

                SCBMLHeaderType header=new SCBMLHeaderType();

                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getTransactionHistoryRes.setHeader(header);

                //response
                GetTransactionHistoryResPayload getTransactionHistoryResPayload=new GetTransactionHistoryResPayload();

                GetTransactionHistoryResData getTransactionHistoryData=new GetTransactionHistoryResData();

                AcctStmtInqRsType getTransactionHistoryRs=new AcctStmtInqRsType();
                getTransactionHistoryRs.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                getTransactionHistoryRs.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                AcctStmtRecType acctStmtRecType=new AcctStmtRecType();

                AcctStmtInfoType acctStmtInfo=new AcctStmtInfoType();
                AcctKeysType acctKeysType=new AcctKeysType();
                CardKeysType cardKeys=new CardKeysType();
                cardKeys.setCardNum(BigInteger.valueOf(1111L));
                acctKeysType.setCardKeys(cardKeys);
                acctStmtInfo.setAcctKeys(acctKeysType);

                AcctTrnRefType acctTrnRefType=new AcctTrnRefType();

                AcctTrnRecType acctTrnRecType=new AcctTrnRecType();

                AcctTrnInfoType acctTrnInfo=new AcctTrnInfoType();

                RefDataType refDataType=new RefDataType();
                acctTrnInfo.setRefData(refDataType);

                TotalCurAmtType totalCurAmtType=new TotalCurAmtType();
                totalCurAmtType.setAmt("10000");
                acctTrnInfo.setTotalCurAmt(totalCurAmtType);

                CompositeCurAmtType compositeCurAmt=new CompositeCurAmtType();

                CurAmtType curAmtType=new CurAmtType();

                CurCodeType curCodeType=new CurCodeType();
                curAmtType.setCurCode(curCodeType);

                compositeCurAmt.setCurAmt(curAmtType);

                acctTrnInfo.setCompositeCurAmt(compositeCurAmt);

                acctTrnRecType.setAcctTrnInfo(acctTrnInfo);

                acctTrnRefType.setAcctTrnRec(acctTrnRecType);

                acctStmtInfo.getAcctTrnRef().add(acctTrnRefType);

                CreditStmtDataType creditStmtDataType=new CreditStmtDataType();
                try {
                    GregorianCalendar c = new GregorianCalendar();
                    c.setTime(new Date());
                    XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
                    creditStmtDataType.setDueDt(date2);

                    acctStmtInfo.setEffDt(date2);
                }catch (Exception e){
                    e.printStackTrace();
                }
                acctStmtInfo.setCreditStmtData(creditStmtDataType);
                acctStmtRecType.setAcctStmtInfo(acctStmtInfo);

                //  acctStmtRecType.getAcctStmtInfo().getAcctKeys().getCardKeys()
                getTransactionHistoryRs.getAcctStmtRec().add(acctStmtRecType);

                getTransactionHistoryData.setGetTransactionHistoryRs(getTransactionHistoryRs);

                getTransactionHistoryResPayload.setGetTransactionHistoryRes(getTransactionHistoryData);

                getTransactionHistoryRes.setGetTransactionHistoryResPayload(getTransactionHistoryResPayload);

                return getTransactionHistoryRes;
            }

            @Override
            public GetFinancialDetailsRes getFinancialDetails(GetFinancialDetailsReq getFinancialDetailsRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardEnquiryV1SoapGateway, "getProxyClient");

        creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardDto_When_getDelinquencyHistory_Method_Called() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();

        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        AcctRecType acctRecType=new AcctRecType();
        CreditCardDto creditCardDto=new CreditCardDto();

        when(orikaMapper.map(Mockito.any(), Mockito.any())).thenReturn(null);

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");


        CreditCardEnquiryPortType cc = new CreditCardEnquiryPortType() {
            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes getDetails(GetDetailsReq getDetailsRequest) {

                return null;
            }

            @Override
            public GetDelinquencyHistoryRes getDelinquencyHistory(GetDelinquencyHistoryReq getDelinquencyHistoryRequest) {

                GetDelinquencyHistoryRes getDelinquencyHistoryRes=new GetDelinquencyHistoryRes();

                SCBMLHeaderType header=new SCBMLHeaderType();

                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getDelinquencyHistoryRes.setHeader(header);

                //response
                GetDelinquencyHistoryResPayload getDelinquencyHistoryResPayload=new GetDelinquencyHistoryResPayload();

                GetDelinquencyHistoryResData getDelinquencyHistoryResData=new GetDelinquencyHistoryResData();

                AcctInqRsType acctInqRsType=new AcctInqRsType();
                acctInqRsType.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                acctInqRsType.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                AcctRecType acctRecType=new AcctRecType();

                AcctInfoType acctInfoType=new AcctInfoType();
                SCBAcctInfoType sCBAcctInfoType=new SCBAcctInfoType();
                acctInfoType.setSCBAcctInfo(sCBAcctInfoType);
                acctRecType.setAcctInfo(acctInfoType);

                AcctEnvrType acctEnvr=new AcctEnvrType();

                CardKeysType cardKeysType=new CardKeysType();
                cardKeysType.setCardNum(BigInteger.valueOf(111L));
                acctEnvr.setCardKeys(cardKeysType);
                acctRecType.setAcctEnvr(acctEnvr);

                acctInqRsType.getAcctRec().add(acctRecType);
                getDelinquencyHistoryResData.setGetDelinquencyHistoryRs(acctInqRsType);

                getDelinquencyHistoryResPayload.setGetDelinquencyHistoryRes(getDelinquencyHistoryResData);
                getDelinquencyHistoryRes.setGetDelinquencyHistoryResPayload(getDelinquencyHistoryResPayload);

                return getDelinquencyHistoryRes;
            }

            @Override
            public GetBalanceHistoryRes getBalanceHistory(GetBalanceHistoryReq getBalanceHistoryRequest) {
                return null;
            }

            @Override
            public GetInterestHistoryRes getInterestHistory(GetInterestHistoryReq getInterestHistoryRequest) {
                return null;
            }

            @Override
            public GetTransactionHistoryRes getTransactionHistory(GetTransactionHistoryReq getTransactionHistoryRequest) {
                return null;
            }

            @Override
            public GetFinancialDetailsRes getFinancialDetails(GetFinancialDetailsReq getFinancialDetailsRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardEnquiryV1SoapGateway, "getProxyClient");

        //     com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes response
        //      when(creditCardEnquiryV1SoapGateway.getProxyClient().getDetails()).thenReturn(new com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes());
        creditCardEnquiryV1SoapGateway.getDelinquencyHistory(creditCardVO);
    }

    @Test
    public void shouldReturn_List_CreditCardTransactionDto_When_getCreditCardTransactions_Method_Called3() throws Exception {

        Map<String, Object> creditCardMap = new HashMap<>();
        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setFunctionType(CardConstant.TRANSACTION);

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();

        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");

        CreditCardEnquiryPortType cc = new CreditCardEnquiryPortType() {
            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes getDetails(GetDetailsReq getDetailsRequest) {
                return null;
            }

            @Override
            public GetDelinquencyHistoryRes getDelinquencyHistory(GetDelinquencyHistoryReq getDelinquencyHistoryRequest) {
                return null;
            }

            @Override
            public GetBalanceHistoryRes getBalanceHistory(GetBalanceHistoryReq getBalanceHistoryRequest) {
                return null;
            }

            @Override
            public GetInterestHistoryRes getInterestHistory(GetInterestHistoryReq getInterestHistoryRequest) {
                return null;
            }

            @Override
            public GetTransactionHistoryRes getTransactionHistory(GetTransactionHistoryReq getTransactionHistoryRequest) {


                GetTransactionHistoryRes getTransactionHistoryRes=new GetTransactionHistoryRes();

                SCBMLHeaderType header=new SCBMLHeaderType();

                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getTransactionHistoryRes.setHeader(header);

                //response
                GetTransactionHistoryResPayload getTransactionHistoryResPayload=new GetTransactionHistoryResPayload();

                GetTransactionHistoryResData getTransactionHistoryData=new GetTransactionHistoryResData();

                AcctStmtInqRsType getTransactionHistoryRs=new AcctStmtInqRsType();
                getTransactionHistoryRs.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                getTransactionHistoryRs.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                AcctStmtRecType acctStmtRecType=new AcctStmtRecType();

                AcctStmtInfoType acctStmtInfo=new AcctStmtInfoType();


                AcctTrnRefType acctTrnRefType=new AcctTrnRefType();

                AcctTrnRecType acctTrnRecType=new AcctTrnRecType();

                AcctTrnInfoType acctTrnInfo=new AcctTrnInfoType();

                RefDataType refDataType=new RefDataType();
                acctTrnInfo.setRefData(refDataType);

                TotalCurAmtType totalCurAmtType=new TotalCurAmtType();
                totalCurAmtType.setAmt("10000");
                acctTrnInfo.setTotalCurAmt(totalCurAmtType);

                CompositeCurAmtType compositeCurAmt=new CompositeCurAmtType();

                CurAmtType curAmtType=new CurAmtType();

                CurCodeType curCodeType=new CurCodeType();
                curAmtType.setCurCode(curCodeType);

                compositeCurAmt.setCurAmt(curAmtType);

                acctTrnInfo.setCompositeCurAmt(compositeCurAmt);

                acctTrnRecType.setAcctTrnInfo(acctTrnInfo);

                AcctTrnEnvrType acctTrnEnvrType=new AcctTrnEnvrType();

                acctTrnRecType.setAcctTrnEnvr(acctTrnEnvrType);

                CardKeysType cardKeys=new CardKeysType();
                cardKeys.setCardNum(BigInteger.valueOf(1111L));
                acctTrnEnvrType.setCardKeys(cardKeys);

                acctTrnRefType.setAcctTrnRec(acctTrnRecType);

                acctStmtInfo.getAcctTrnRef().add(acctTrnRefType);

                acctStmtRecType.setAcctStmtInfo(acctStmtInfo);

                //  acctStmtRecType.getAcctStmtInfo().getAcctKeys().getCardKeys()
                getTransactionHistoryRs.getAcctStmtRec().add(acctStmtRecType);

                getTransactionHistoryData.setGetTransactionHistoryRs(getTransactionHistoryRs);

                getTransactionHistoryResPayload.setGetTransactionHistoryRes(getTransactionHistoryData);

                getTransactionHistoryRes.setGetTransactionHistoryResPayload(getTransactionHistoryResPayload);

                return getTransactionHistoryRes;
            }

            @Override
            public GetFinancialDetailsRes getFinancialDetails(GetFinancialDetailsReq getFinancialDetailsRequest) {
                return null;
            }
        };

        doReturn(cc).when(creditCardEnquiryV1SoapGateway, "getProxyClient");

        creditCardEnquiryV1SoapGateway.getCreditCardTransactions(creditCardVO);
    }

    @Test
    public void shouldReturn_CreditCardDto_When_getCreditCardFinancialDetails_Method_Called() throws Exception {
        Map<String, Object> creditCardMap = new HashMap<>();

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardVO.setCustomerId("01070565A0SH04005");

        CreditCardProperties creditCardProperties = new CreditCardProperties();
        Map<String, CreditCardProperties> map=new HashMap<>();

        creditCardProperties=(CreditCardProperties) cardUtil.getValueByKey(map, "IN");

        when(baseSoapGateway.getValuePropertiesByKey(map, "IN")).thenReturn(creditCardProperties);
        when(baseSoapGateway.getCreditCardPropertiesByCountry("IN")).thenReturn(creditCardProperties);
        cardUtil.setGatewayProperties(creditCardVO);

        // when(renderer.render(CardConstant.CARD_ENQUIRY_CARD_DETAILS_TEMPLATE_NAME,creditCardMap)).thenReturn("<xml><get>3</get></xml>");

        when(renderer.render(Mockito.anyString(),Mockito.anyMap())).thenReturn("<xml><get>3</get></xml>");


        CreditCardEnquiryPortType cc = new CreditCardEnquiryPortType() {
            @Override
            public com.sc.corebanking.creditcard.v1.ws.provider.creditcardenquiry.GetDetailsRes getDetails(GetDetailsReq getDetailsRequest) {

                return null;
            }

            @Override
            public GetDelinquencyHistoryRes getDelinquencyHistory(GetDelinquencyHistoryReq getDelinquencyHistoryRequest) {

                return null;
            }

            @Override
            public GetBalanceHistoryRes getBalanceHistory(GetBalanceHistoryReq getBalanceHistoryRequest) {
                return null;
            }

            @Override
            public GetInterestHistoryRes getInterestHistory(GetInterestHistoryReq getInterestHistoryRequest) {
                return null;
            }

            @Override
            public GetTransactionHistoryRes getTransactionHistory(GetTransactionHistoryReq getTransactionHistoryRequest) {
                return null;
            }

            @Override
            public GetFinancialDetailsRes getFinancialDetails(GetFinancialDetailsReq getFinancialDetailsRequest) {

                GetFinancialDetailsRes getFinancialDetailsRes=new GetFinancialDetailsRes();

                SCBMLHeaderType header=new SCBMLHeaderType();
                //set header
                ExceptionListType exceptionListType=new ExceptionListType();
                ExceptionType exceptionType=new ExceptionType();
                Code value=new Code();
                value.setValue(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionType.setCode(value);
                exceptionType.setDescription(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                exceptionListType.getException().add(exceptionType);
                header.setExceptions(exceptionListType);

                getFinancialDetailsRes.setHeader(header);

                //response
                GetFinancialDetailsResPayload getFinancialDetailsResPayload=new GetFinancialDetailsResPayload();

                GetFinancialDetailsResData getFinancialDetailsResData=new GetFinancialDetailsResData();
                AcctStmtRecType acctStmtRecType=new AcctStmtRecType();


                AcctInqRsType acctInqRsType=new AcctInqRsType();
                acctInqRsType.setSCBRespCode(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);
                acctInqRsType.setSCBRespDesc(CardGatewayConstant.EDMI_SUCCESS_RES_CDS[0]);

                AcctRecType acctRecType=new AcctRecType();
                AcctEnvrType acctEnvr=new AcctEnvrType();

                CardKeysType cardKeysType=new CardKeysType();
                cardKeysType.setCardNum(BigInteger.valueOf(111L));
                acctEnvr.setCardKeys(cardKeysType);
                acctRecType.setAcctEnvr(acctEnvr);

                acctInqRsType.getAcctRec().add(acctRecType);

                getFinancialDetailsResData.setGetFinancialDetailsRs(acctInqRsType);

                getFinancialDetailsResPayload.setGetFinancialDetailsRes(getFinancialDetailsResData);

                getFinancialDetailsRes.setGetFinancialDetailsResPayload(getFinancialDetailsResPayload);

                return getFinancialDetailsRes;
            }
        };

        doReturn(cc).when(creditCardEnquiryV1SoapGateway, "getProxyClient");

        creditCardEnquiryV1SoapGateway.getCreditCardFinancialDetails(creditCardVO);
    }

    @Test(expected = Exception.class)
    public void shouldReturn_CreditCardDto_When_getAsyncCreditCard_Method_Called() throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardEnquiryV1SoapGateway.getAsyncCreditCard(creditCardVO);

    }

    @Test(expected = Exception.class)
    public void shouldReturn_CreditCardDto_When_getAsyncCreditCardFinancialDetails_Method_Called() throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");
        creditCardEnquiryV1SoapGateway.getAsyncCreditCardFinancialDetails(creditCardVO);

    }

    @Test
    public void shouldReturn_CreditCardDto_When_findOneCreditCardInfoFromDB_Method_Called() throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");

        when(creditCardSharedServiceJsonApiGateway.fetchOneCreditCardAccount(creditCardVO.getCardNo(),null)).thenReturn(new CardDto());
        creditCardEnquiryV1SoapGateway.findOneCreditCardInfoFromDB(creditCardVO,new Exception(),"");

    }

    @Test
    public void shouldReturn_CreditCardDto_When_fetchCreditCardTransactions_Method_Called() throws Exception {

        CreditCardVO creditCardVO = new CreditCardVO();
        creditCardVO.setCountryCode("IN");
        creditCardVO.setCardNo("4129057530874005");
        creditCardVO.setCardTransactionRefNo("11290575308711111");
        creditCardVO.setChannelId("IBNK");

        CardDto cardDto=new CardDto();
        List<CreditCardTransactionDto> creditCardTransactionDtoLst=new ArrayList<>();
        creditCardTransactionDtoLst.add(new CreditCardTransactionDto());
        cardDto.setCardtransactions(creditCardTransactionDtoLst);

        when(creditCardSharedServiceJsonApiGateway.fetchOneCreditCardAccount(creditCardVO.getCardNo(),null)).thenReturn(cardDto);

        List<CreditCardTransactionDto> txnDto = creditCardEnquiryV1SoapGateway.fetchCreditCardTransactions(creditCardVO);

        Assert.assertNotNull(txnDto);

    }


}